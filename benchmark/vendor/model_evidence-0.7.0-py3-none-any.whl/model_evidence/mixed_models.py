"""Bounded existing-fit Gaussian random-intercept evidence, not a mixed-model engine.

The caller supplies a trusted exact-stock statsmodels fit. No fitting, prediction,
formula evaluation, per-group effects or object deserialization is performed.
"""
from collections import Counter
from copy import copy
import math
import warnings

import numpy as np

from .diagnostics import _complete
from .registry import load_registry
from .report import evidence, make_report
from . import model_visuals as visuals


ADAPTER_VERSION = "gaussian-random-intercept/0.6.0"
MAX_CELLS = 2_000_000
GROUP_WARNING_THRESHOLD = 20
BOUNDARY_RATIO_THRESHOLD = 1e-8


def _scalar_number(value, label):
    if (isinstance(value, (bool, np.bool_)) or
            not isinstance(value, (int, float, np.integer, np.floating))):
        raise ValueError(label + " must be a native numeric scalar; its invalid value is withheld")
    value = float(value)
    if not math.isfinite(value) or abs(value) > 1e100:
        raise ValueError(label + " must be finite and bounded")
    return value


def is_mixed_model_candidate(value):
    """A dispatch hint only; the adapter still requires exact stock classes."""
    return type(value).__module__ == "statsmodels.regression.mixed_linear_model"


def _bad(reason, purpose, requirement=None, n=0, p=0):
    from .adapters import _unsupported
    return _unsupported(reason, purpose, n=n, p=p, failed_requirement=requirement,
                        model_name="statsmodels Gaussian random-intercept fit")


def _array(value, dimensions, label):
    if np.ma.isMaskedArray(value) and np.ma.getmaskarray(value).any():
        raise ValueError(label + " contains masked values; no mask is silently dropped")
    if np.iscomplexobj(value):
        raise ValueError(label + " must be real")
    try:
        result = np.asarray(value, dtype=float)
    except (ValueError, TypeError) as exc:
        raise ValueError(label + " must be numeric; native error details are withheld") from exc
    if (result.ndim != dimensions or not result.size or result.size > MAX_CELLS
            or not np.isfinite(result).all() or np.any(np.abs(result) > 1e100)):
        raise ValueError(label + " must contain bounded, finite, aligned values")
    return result


def _stock(value):
    from statsmodels.regression.mixed_linear_model import (
        MixedLM, MixedLMResults, MixedLMResultsWrapper,
    )
    raw = value._results if type(value) is MixedLMResultsWrapper else value
    if type(raw) is not MixedLMResults or type(raw.model) is not MixedLM:
        raise ValueError("Only exact stock, already-fitted MixedLM Gaussian random-intercept results are supported; subclasses and other model types require a separate adapter")
    model = raw.model
    if (_scalar_number(getattr(model, "k_re", -1), "Native random-effect count") != 1
            or _scalar_number(getattr(model, "k_vc", -1), "Native variance-component count") != 0):
        raise ValueError("Only one random intercept is supported; random slopes, crossed/variance-component structures and generalized mixed models are unsupported")
    names = getattr(getattr(model, "exog_vc", None), "names", None)
    if names is None or len(names):
        raise ValueError("Variance-component/crossed structures are unsupported by the random-intercept adapter")
    if any(getattr(model, key, None) is not None for key in ("weights", "offset", "exposure")):
        raise ValueError("Weighted, offset or exposure models are unsupported by the unweighted random-intercept adapter")
    if (type(getattr(raw, "reml", None)) not in {bool, np.bool_}
            or not hasattr(raw, "freepat") or raw.freepat is not None
            or any(getattr(model, key, None) is not None for key in ("fe_pen", "cov_pen"))
            or getattr(raw, "cov_pen", None) is not None):
        raise ValueError("Only ordinary unpenalized, unconstrained MixedLM fitting states are supported; regularized, penalized or free-parameter-constrained fits require a separate adapter")
    if (str(getattr(raw, "method", "")) != ("REML" if bool(raw.reml) else "ML")
            or type(getattr(model, "reml", None)) not in {bool, np.bool_}
            or bool(model.reml) != bool(raw.reml)):
        raise ValueError("Native ML/REML fit-state provenance disagrees; reused or incomplete state is unsupported")
    view = copy(raw)
    # Native inference properties can populate lazy caches. Never add those
    # entries to the caller's result object.
    view._cache = dict(getattr(raw, "_cache", {}))
    return view


def _group_counts(model, n):
    supplied = np.asarray(model.groups, dtype=object)
    if supplied.ndim != 1 or len(supplied) != n:
        raise ValueError("Stored group assignments must align with every original fitting row")
    for value in supplied:
        if (isinstance(value, (bool, np.bool_)) or
                not isinstance(value, (str, int, float, np.integer, np.floating))):
            raise ValueError("Stored groups require bounded, nonmissing scalar labels; label values are withheld")
        if isinstance(value, str):
            if not value or len(value) > 128:
                raise ValueError("Stored group labels must be nonempty and bounded; label values are withheld")
        elif not math.isfinite(float(value)) or abs(float(value)) > 1e100:
            raise ValueError("Stored group labels must be finite and bounded; label values are withheld")
    counts = np.asarray(list(Counter(supplied.tolist()).values()), dtype=int)
    labels = getattr(model, "group_labels", None)
    if (_scalar_number(getattr(model, "n_groups", -1), "Native group count") != len(counts)
            or labels is None or len(labels) != len(counts)):
        raise ValueError("Stored group counts disagree with native model metadata; stale group state is unsupported")
    return counts


def _native_uncertainty(result, names, coefficients):
    """Read only fixed-effect uncertainty under the existing native reference."""
    k = len(coefficients)
    use_t = getattr(result, "use_t", None)
    use_t = bool(use_t) if type(use_t) in {bool, np.bool_} else None
    try:
        df = _scalar_number(getattr(result, "df_resid", None), "Native residual degrees of freedom")
        df = df if df > 0 else None
    except ValueError:
        df = None
    reference = ("t with native residual degrees of freedom" if use_t is True else
                 "native normal/asymptotic Wald reference" if use_t is False else
                 "native uncertainty reference unavailable")
    standard = covariance = interval = statistics = pvalues = None
    available = False
    try:
        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            standard = np.asarray(result.bse_fe, dtype=float)
            covariance_all = np.asarray(result.cov_params(), dtype=float)
            interval_all = np.asarray(result.conf_int(alpha=.05), dtype=float)
            statistics_all = np.asarray(result.tvalues, dtype=float)
            pvalues_all = np.asarray(result.pvalues, dtype=float)
        covariance = covariance_all[:k, :k]
        interval = interval_all[:k]
        statistics = statistics_all[:k]
        pvalues = pvalues_all[:k]
        available = bool(
            use_t is not None and (use_t is False or df is not None)
            and standard.shape == (k,) and covariance.shape == (k, k)
            and interval.shape == (k, 2) and statistics.shape == (k,) and pvalues.shape == (k,)
            and all(np.isfinite(a).all() and not np.any(np.abs(a) > 1e100)
                    for a in (standard, covariance, interval, statistics, pvalues))
            and np.all(standard >= 0) and np.all(np.diag(covariance) >= 0)
            and np.all((pvalues >= 0) & (pvalues <= 1))
            and np.all(interval[:, 0] <= interval[:, 1]))
        if available:
            covariance_scale = max(float(np.max(np.abs(covariance))), 1e-300)
            normalized = covariance / covariance_scale
            available = bool(
                np.max(np.abs(normalized - normalized.T)) <= 1e-10
                and np.min(np.linalg.eigvalsh((normalized + normalized.T) / 2)) >= -1e-10)
    except (ValueError, TypeError, AttributeError, ArithmeticError, np.linalg.LinAlgError):
        available = False
    table = []
    for position, name in enumerate(names):
        table.append({"term": name, "estimate": float(coefficients[position]),
                      "standard_error": float(standard[position]) if available else None,
                      "statistic": float(statistics[position]) if available else None,
                      "p_value": float(pvalues[position]) if available else None,
                      "ci_lower": float(interval[position, 0]) if available else None,
                      "ci_upper": float(interval[position, 1]) if available else None})
    return {"fixed_effects": table,
            "fixed_effect_covariance": covariance.tolist() if available else None,
            "uncertainty_available": available, "confidence_level": .95,
            "uncertainty_reference": reference, "use_t": use_t,
            "native_residual_df": df}


def _visual_evidence(values, coefficients, names, sizes, marginal_residuals):
    n = values["n_observations"]
    g = values["n_groups"]
    limitations = [
        "Group sizes and marginal residuals describe the original fitting rows; these are not independent observations from a validation sample.",
        "Group identifiers and individual random-effect predictions are withheld; aggregates and coefficient names may still be sensitive.",
    ]
    panels = [visuals._bars(
        "mixed_fixed_effects", "Existing mixed-model fixed effects", names, coefficients,
        n, "training", role="main_result",
        units="response per fixed-design unit; intercept in response units",
        comparison="Native fixed-effect estimates in original design order; full native SE/95% CI are in the supporting result table",
        interpretation="Point estimates describe the assumed Gaussian random-intercept model; bars do not display uncertainty or establish population/causal support.",
        limitations=limitations + ["Columns can have different units. Do not compare coefficient sizes as universal importance."]),
        visuals._bars(
            "mixed_variances", "Native random-intercept and residual variance", ["random-intercept variance", "residual variance"],
            [values["random_intercept_variance"], values["residual_variance"]], n, "training",
            role="diagnostic", requirement="error_structure", units="squared response units",
            comparison="Native cov_re[0,0] versus native residual scale; no variance-component interval or p-value is manufactured",
            interpretation="This is an estimated variance decomposition under the model; a positive estimate does not prove the latent distribution or grouping design.",
            limitations=limitations + ["Variance estimates near zero are boundary cases with nonstandard inference."]),
        visuals.histogram_panel(
            "mixed_group_sizes", "Observation counts per retained group", sizes,
            role="diagnostic", requirement="grouping_structure", source_split="training",
            axes={"x":"Retained observations per group", "y":"Number of groups"},
            units="retained observations per group", comparison="Counts across the actual retained groups; denominator is groups, not observations",
            threshold="Fewer than 20 groups is a review heuristic; all singleton groups or fewer than two groups leave variance separation unsupported",
            interpretation="Counts reveal support for the specified hierarchy. They do not verify independent groups or that the grouping variable represents the intended population.",
            limitations=limitations, bins=12),
        visuals.histogram_panel(
            "mixed_marginal_residuals", "Marginal deviations from the fixed component", marginal_residuals,
            role="descriptive", requirement="residual_shape", source_split="training",
            units="response units", comparison="Original y minus X times native fixed effects; group intercepts are deliberately retained in these deviations",
            interpretation="This describes marginal deviations. It is not an IID error sample, conditional residual-normality diagnostic or unseen-group prediction assessment.",
            limitations=limitations, bins=16),
        visuals.status_panel(
            "mixed_unverified", "Hierarchy assumptions remain unresolved", n=n, source_split="training",
            requirement="random_effect_distribution",
            message="Independent groups, covariate/latent-intercept exogeneity, Gaussian random effects, within-group conditional errors, sampling and missingness require design evidence.",
            comparison="No distributional test or optimizer flag verifies these assumptions",
            limitations=limitations)]
    # The envelope is n observations, while the group-size panel explicitly uses
    # g groups. g <= n is required by stored grouping checks.
    assert g <= n
    return visuals._finish(n, "training", panels)


def audit_mixed_model(model, X=None, y=None, *, purpose="association",
                      baseline_predictions=None, positive_label=None, metadata=None,
                      attestations=None, split_role="unknown"):
    """Audit an existing stock Gaussian random-intercept fit without refitting.

    Only original fitting rows are supported. ``X`` and ``y`` must be omitted;
    prediction, random slopes, crossed/variance-component and Bayesian models
    require separate adapters. ``metadata={'entity_ids': ...}`` can screen
    repeated observational units at the declared row grain without exporting IDs.
    Human assumptions remain distinct from numerical checks.
    """
    if purpose not in load_registry()["use_cases"]:
        raise ValueError("Unknown intended purpose")
    if purpose not in {"association", "description"}:
        return _bad("This bounded mixed-model adapter supports original-fit association/description only; unseen-group prediction, forecasting and causal identification are unsupported", purpose)
    if X is not None or y is not None or baseline_predictions is not None or positive_label is not None:
        return _bad("Original-fit mixed-model extraction requires X=y=None and no prediction/class options; supplied new rows cannot replace the original fitting design", purpose)
    if not isinstance(split_role, str) or split_role not in {"unknown", "training", "validation", "evaluation", "final_holdout"}:
        raise ValueError("Unknown split role")
    if metadata is not None and (not isinstance(metadata, dict) or set(metadata) - {"entity_ids"}):
        return _bad("Mixed-model metadata supports only aligned entity_ids; grouping is read from the retained native fitting design", purpose)
    try:
        result = _stock(model)
    except ImportError:
        return _bad("Optional statsmodels dependency is unavailable; use the documented statsmodels extra in a chosen environment", purpose)
    except (ValueError, TypeError, AttributeError, OverflowError) as exc:
        return _bad(str(exc), purpose)
    n = k = 0
    try:
        design = _array(result.model.exog, 2, "stored fixed design")
        target = _array(result.model.endog, 1, "stored target")
        n, k = design.shape
        if n < 3 or not 1 <= k <= 32 or len(target) != n:
            raise ValueError("Mixed-model extraction requires at least three aligned original rows and 1..32 fixed-design columns")
        if (_scalar_number(result.nobs, "Native observation count") != n
                or _scalar_number(result.model.k_fe, "Native fixed-effect count") != k):
            raise ValueError("Native row/parameter counts disagree with the retained fixed design; stale state is unsupported")
        random_design = _array(result.model.exog_re, 2, "stored random design")
        if random_design.shape != (n, 1) or not np.all(random_design == 1):
            raise ValueError("The one random-design column must be exactly constant one; a single random slope is not a random intercept")
        coefficients = _array(result.fe_params, 1, "native fixed effects")
        packed = _array(result.params, 1, "native parameter state")
        if coefficients.shape != (k,) or packed.shape != (k + 1,) or not np.array_equal(packed[:k], coefficients):
            raise ValueError("Native fixed-effect state and packed parameter ordering disagree; stale or unsupported state")
        names = list(result.model.exog_names)
        if (len(names) != k or len(set(names)) != k or
                any(not isinstance(name, str) or not name or len(name) > 128 for name in names)):
            raise ValueError("Fixed-effect names must be bounded, distinct and align with the original design")
        counts = _group_counts(result.model, n)
        groups = len(counts)
        covariance_re = _array(result.cov_re, 2, "native random-effect covariance")
        if covariance_re.shape != (1, 1):
            raise ValueError("Only a 1-by-1 native random-intercept covariance is supported")
        tau2 = float(covariance_re[0, 0])
        sigma2 = _scalar_number(result.scale, "Native residual variance")
        if tau2 < 0 or not math.isfinite(sigma2) or not 0 <= sigma2 <= 1e100:
            raise ValueError("Native variance components must be finite and nonnegative; no negative estimate is clipped or repaired")
        total_variance = tau2 + sigma2
        if not math.isfinite(total_variance) or total_variance > 1e100:
            raise ValueError("Native total variance exceeds the bounded reporting range")
        icc = tau2 / total_variance if total_variance > 0 else None
        with np.errstate(over="ignore", invalid="ignore"):
            fixed_component = design @ coefficients
            marginal_residuals = target - fixed_component
        _array(marginal_residuals, 1, "marginal deviations")
        rank = int(np.linalg.matrix_rank(design))
        condition = float(np.linalg.cond(design))
        condition = condition if math.isfinite(condition) and condition <= 1e100 else None
    except (ValueError, TypeError, AttributeError, OverflowError, ArithmeticError, np.linalg.LinAlgError) as exc:
        return _bad(str(exc), purpose, "target_compatibility", n=n, p=k)

    dropped = getattr(result.model.data, "missing_row_idx", None)
    # Formula preprocessing can remove rows before the core model sees them and
    # leave an empty missing_row_idx. No recorded indices therefore cannot be
    # interpreted as zero source rows dropped.
    missing_history_known = isinstance(dropped, (list, tuple, np.ndarray)) and len(dropped) > 0
    dropped_count = len(dropped) if missing_history_known else 0
    singleton_groups = int(np.sum(counts == 1))
    repeated_groups = int(np.sum(counts >= 2))
    grouping_failure = groups < 2 or repeated_groups == 0
    grouping_concern = groups < GROUP_WARNING_THRESHOLD or repeated_groups < 2
    native_converged = getattr(result, "converged", None)
    native_converged = bool(native_converged) if type(native_converged) in {bool, np.bool_} else None
    uncertainty = _native_uncertainty(result, names, coefficients)
    boundary = total_variance == 0 or icc is None or icc <= BOUNDARY_RATIO_THRESHOLD
    zero_residual = sigma2 == 0
    grouping_values = {
        "groups": groups, "observation_denominator": n, "minimum_group_size": int(counts.min()),
        "maximum_group_size": int(counts.max()), "median_group_size": float(np.median(counts)),
        "singleton_groups": singleton_groups, "repeated_groups": repeated_groups,
    }
    rows = [
        evidence("missingness", "warning" if dropped_count else "no_issue_detected",
            "Finite retained fitting values; native missing-row history inspected where available", sample_size=n,
            observed={"retained_nonfinite_cells": 0, "retained_cells_checked": int(design.size + target.size),
                      "native_missing_history_available": missing_history_known,
                      "known_rows_dropped_by_native_fit": dropped_count if missing_history_known else None},
            thresholds={"maximum_retained_nonfinite": 0, "known_dropped_rows_review_above": 0},
            limitations=["The adapter does not delete or impute rows. Empty/absent native indices cannot rule out earlier formula preprocessing; unrecorded source missingness, sentinel codes and selection remain unknown."],
            remedies=["Review the original missingness/selection mechanism and retained-row history."]),
        evidence("target_compatibility", "no_issue_detected",
            "Retained outcome and fixed design are finite numeric arrays for the existing Gaussian model", sample_size=n,
            observed={"observed_rows": n, "fixed_design_columns": k, "target_minimum": float(target.min()), "target_maximum": float(target.max())},
            thresholds={"comparison": "numeric finite target; semantic continuous-response suitability is unverified"},
            limitations=["Finite numbers do not establish an appropriate measurement scale, Gaussian conditional errors or scientific meaning."]),
        evidence("grouping_structure", "fail" if grouping_failure else "warning" if grouping_concern else "no_issue_detected",
            "Retained group support and repeated observations under one constant-one random-intercept design", sample_size=n,
            observed=grouping_values,
            thresholds={"minimum_distinct_groups_for_variance_separation": 2, "minimum_repeated_groups_for_review": 2,
                        "groups_warning_below": GROUP_WARNING_THRESHOLD, "comparison": "20 groups is a review heuristic, not a universal sufficiency guarantee"},
            limitations=["Group labels are not exported. Counts cannot verify independent groups, correct nesting, random sampling or the scientific grouping variable.",
                         "All-singleton groups cannot separate random-intercept and residual variance in this bounded design."],
            remedies=["Check the study hierarchy and independent-group sampling; investigate weak or sparse group support before interpreting uncertainty."]),
        evidence("identifiability", "fail" if rank != k or n <= k or grouping_failure else "warning" if condition is None or condition > 1e8 else "no_issue_detected",
            "Retained fixed-design rank and condition-number screen, with random-intercept support check", sample_size=n,
            observed={"fixed_design_rank": rank, "fixed_design_columns": k, "observations": n, "condition_number": condition,
                      "all_singleton_groups": repeated_groups == 0},
            thresholds={"required_fixed_rank": k, "condition_warning_above": 1e8, "required_positive_n_minus_fixed_rank": 0},
            limitations=["Numerical rank and condition thresholds depend on units. Full rank does not establish exogeneity, the hierarchy or model identification in the target population."],
            remedies=["Review design aliasing/scaling and between/within-group variation; refitting or changing the question requires a separate review."]),
        evidence("convergence", "not_checked" if native_converged is None else "no_issue_detected" if native_converged else "fail",
            "Recorded native MixedLM optimizer completion; no optimization rerun", sample_size=n,
            observed={"native_converged": native_converged, "native_fit_method": str(getattr(result, "method", "unavailable"))[:64]},
            thresholds={"comparison": "recorded convergence flag is true; this does not verify the variance boundary or specification"},
            limitations=["A successful flag does not prove a global optimum, valid uncertainty, independent groups or the assumed distributions."],
            remedies=["Inspect original training warnings, optimizer diagnostics and sensitivity to justified specifications."]),
        evidence("error_structure", "fail" if zero_residual else "warning" if boundary or not uncertainty["uncertainty_available"] else "no_issue_detected",
            "Native variance support, random-intercept boundary and fixed-effect uncertainty availability", sample_size=n,
            observed={"random_intercept_variance": tau2, "residual_variance": sigma2, "conditional_icc": icc,
                      "fixed_effect_uncertainty_available": uncertainty["uncertainty_available"], "near_zero_random_intercept_boundary": boundary},
            thresholds={"random_intercept_fraction_warning_at_or_below": BOUNDARY_RATIO_THRESHOLD,
                        "residual_variance_required_above": 0, "comparison": "ICC <= 1e-8 is a numerical boundary heuristic, not a variance-component significance test"},
            limitations=["The uncertainty and ICC are conditional on the fitted model. No variance-component confidence interval or p-value is inferred.",
                         "A positive variance decomposition does not verify within-group error independence/homoskedasticity, Gaussian latent effects or covariance correctness."],
            remedies=["Review the original covariance assumptions and group support; boundary inference needs an appropriate separately justified procedure."]),
        evidence("independence", "not_checked", "Independent groups and the within-group conditional error model require study-design evidence",
            source="manual_required", sample_size=n, observed={"groups": groups, "rows": n},
            limitations=["Repeated rows inside a group are not treated as independent observations. Group support is a different check from between-group independence."],
            remedies=["Document the independently sampled units and remaining dependence after the specified random intercept."]),
        evidence("grouping_structure", "not_checked", "The declared scientific hierarchy, nesting and grain are not established from stored group labels",
            source="manual_required", sample_size=n,
            remedies=["Record why this single grouping factor represents the study hierarchy and whether further cross-classification, random slopes or dependence are needed."]),
        evidence("random_effect_distribution", "not_checked", "Gaussian latent intercepts and their independence from fixed covariates require substantive justification",
            source="manual_required", sample_size=n,
            limitations=["The adapter exports no empirical BLUP normality test. Fitted or shrunk group effects cannot prove the latent distribution."]),
        evidence("conditional_error_model", "not_checked", "Within-group conditional error independence, variance structure and Gaussian inference require design/model justification",
            source="manual_required", sample_size=n,
            limitations=["Native covariance availability and a marginal deviation histogram cannot verify the errors conditional on a latent group intercept."],
            remedies=["Document the conditional likelihood, remaining within-group dependence/heteroskedasticity and why its uncertainty approximation suits this sampling design."]),
        evidence("residual_shape", "not_checked", "Gaussian conditional errors are not verified by the marginal deviation histogram",
            source="manual_required", sample_size=n,
            limitations=["y-X beta still includes each group's latent intercept, and those repeated deviations are not an IID residual sample."]),
        evidence("error_structure", "not_checked", "The random-intercept covariance and within-group conditional error assumptions remain unverified",
            source="manual_required", sample_size=n,
            limitations=["Native Wald covariance is extracted, not independently certified; HC3 for individual OLS rows is not a repair for this hierarchy."]),
    ]
    if metadata and "entity_ids" in metadata:
        ids = metadata["entity_ids"]
        try:
            from .diagnostics import _common
            row_evidence = _common(design, target, {"entity_ids": ids})
            rows.extend(row for row in row_evidence if row["requirement"] == "duplicate_entities")
        except (ValueError, TypeError, OverflowError) as exc:
            return _bad(str(exc), purpose, "duplicate_entities", n=n, p=k)
    if split_role not in {"unknown", "training"}:
        rows.append(evidence("evaluation_protocol", "warning", "Original MixedLM fitting rows cannot be relabelled as held-out evaluation", sample_size=n,
            observed={"requested_split": split_role, "actual_split": "training"},
            thresholds={"comparison": "stored original fit is always training"},
            limitations=["No supplied future rows or unseen-group predictions were evaluated."]))
    values = {
        "computational_status": "computed", "n_observations": n, "n_groups": groups,
        **grouping_values, **uncertainty, "random_intercept_variance": tau2,
        "residual_variance": sigma2, "conditional_icc": icc,
        "fixed_design_rank": rank, "native_converged": native_converged,
        "fit_method": str(getattr(result, "method", "unavailable"))[:64],
        "source_split": "training", "variance_component_inference": "not implemented; no ordinary normal p-value or interval claimed",
        "group_effects_exported": False,
    }
    estimates = {
        "mixed_model": values,
        "adapter": {"implementation": ADAPTER_VERSION, "estimator_type": "MixedLM",
                    "model_refit": False, "source_split": "training", "input_ownership": "retained native original design",
                    "scope": "existing Gaussian random-intercept only; fixed-effect associations conditional on unverified design assumptions",
                    "per_group_predictions_exported": False},
        "visual_evidence": _visual_evidence(values, coefficients, names, counts, marginal_residuals),
    }
    rows = _complete("gaussian_mixed_intercept", purpose, rows, attestations)
    return make_report("gaussian_mixed_intercept", purpose, rows,
        {"n": n, "training_n": n, "p": k, "groups": groups}, estimates,
        ["This bounded frequentist adapter does not implement Bayesian inference, random slopes, crossed structures, causal identification or unseen-group prediction.",
         "Population and coefficient interpretations require independent-group sampling, a justified hierarchy, exogeneity and the stated Gaussian covariance assumptions.",
         "No fit, data repair, optimizer rerun, variance-component test, BLUP export or external connection was performed."])
