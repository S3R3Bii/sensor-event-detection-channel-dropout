"""Offline, bounded synthetic diagnostic dashboard and scientific figures.

This module is an executable demonstration, not a universal model adapter. It
does not read files, serve HTTP, repair inputs, or certify assumptions. Existing
fitted-model users should use ``audit_fitted`` / ``audit_report`` instead.
"""
from copy import deepcopy
from io import BytesIO
import json

import numpy as np
from scipy import stats
from scipy.special import expit
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (average_precision_score, brier_score_loss, log_loss,
                             roc_auc_score)
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from .causal import balance_overlap
from .corrections import compare_ols_covariance, propose_correction
from .dag import assess_assumed_dag
from .diagnostics import audit_split

STATUS_LABELS = {
    "fail": "[!] Observed failure or concern",
    "warning": "[!] Concern requiring review",
    "no_issue_detected": "[OK] No issue detected by this diagnostic",
    "not_checked": "[?] Unresolved / manual justification",
    "not_applicable": "[-] Not applicable",
}
STAGES = [
    {"id": "before_fit", "label": "Before fitting"},
    {"id": "after_fit", "label": "After fitting: training data"},
    {"id": "evaluation", "label": "Untouched evaluation: descriptive performance"},
    {"id": "causal_design", "label": "Causal design: assumed graph and limited diagnostics"},
    {"id": "corrections", "label": "What changes? Same-fit uncertainty comparison"},
]


def _metric(name, value, units="dimensionless", *, comparison="descriptive", threshold=None, status="no_issue_detected"):
    return {"name": name, "value": value, "units": units, "comparison": comparison,
            "threshold": threshold, "status": status}


def _panel(identifier, stage, title, status, *, n, purpose, variables, split,
           comparison, interpretation, chart=None, metrics=None,
           threshold=None, rationale="Descriptive comparison; no universal pass threshold.",
           limitations=None, impact="Interpret within the recorded diagnostic's scope.",
           remedy="Review the evidence; no automatic data or model changes.", units="supplied synthetic units"):
    return {"id": identifier, "stage": stage, "title": title, "status": status,
            "status_label": STATUS_LABELS[status], "input": "fixed synthetic demonstration",
            "split": split, "purpose": purpose, "n": n, "variables": variables,
            "units": units, "comparison": comparison, "threshold": threshold,
            "threshold_rationale": rationale, "interpretation": interpretation,
            "limitations": list(limitations or []), "impact": impact, "remedy": remedy,
            "chart": chart or {"kind": "status"}, "metrics": list(metrics or [])}


def summarize_numeric_inputs(X, y=None, *, feature_names=None):
    """Summarize bounded raw numeric arrays without dropping or repairing values.

    Histograms explicitly count finite values only; downstream fitting must stop
    when ``status == 'fail'``. Missingness mechanisms, grain and sentinel codes
    cannot be inferred from arrays. This helper is independent of the demo fits.
    """
    if any(np.ma.isMaskedArray(value) and np.ma.getmaskarray(value).any() for value in (X,y)):
        raise ValueError("Masked values require explicit handling; no mask is silently dropped")
    if np.iscomplexobj(X) or (y is not None and np.iscomplexobj(y)):
        raise ValueError("Real numeric arrays required")
    try:
        X = np.asarray(X, dtype=float)
        y = None if y is None else np.asarray(y, dtype=float)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("Numeric arrays required") from exc
    if X.ndim != 2 or not 3 <= X.shape[0] <= 200_000 or not 1 <= X.shape[1] <= 128 or X.size > 2_000_000:
        raise ValueError("Bounded 2D X with at least three rows and 1..128 columns required")
    if y is not None and (y.ndim != 1 or len(y) != len(X)):
        raise ValueError("Aligned one-dimensional target required")
    if feature_names is None:
        feature_names = ["x" + str(i + 1) for i in range(X.shape[1])]
    if not isinstance(feature_names, (list, tuple)) or len(feature_names) != X.shape[1] or any(
            not isinstance(v, str) or not v.strip() or len(v) > 128 for v in feature_names) or len(set(feature_names)) != len(feature_names):
        raise ValueError("Distinct bounded feature names must match columns")
    arrays = [X[:, i] for i in range(X.shape[1])] + ([] if y is None else [y])
    names = list(feature_names) + ([] if y is None else ["target"])
    columns = []
    for name, column in zip(names, arrays):
        finite = column[np.isfinite(column)]
        # Do not permit enormous finite values to overflow histogram internals.
        in_range = not finite.size or bool(np.max(np.abs(finite)) <= 1e12)
        counts, edges = np.histogram(finite, bins=12) if finite.size and in_range else (np.array([], dtype=int), np.array([]))
        columns.append({"name": name, "n": len(column), "finite_count": int(len(finite)),
                        "nonfinite_count": int(len(column) - len(finite)),
                        "minimum": float(finite.min()) if finite.size else None,
                        "maximum": float(finite.max()) if finite.size else None,
                        "mean": float(finite.mean()) if finite.size and in_range else None,
                        "sample_sd": float(finite.std(ddof=1)) if len(finite) > 1 and in_range else None,
                        "unique_finite_values": int(len(np.unique(finite))),
                        "histogram_counts": counts.tolist(), "histogram_edges": edges.tolist(),
                        "histogram_denominator": int(len(finite)) if in_range else 0,
                        "histogram_scope": "finite values only; nonfinite counts retained separately",
                        "magnitude_supported": in_range})
    nonfinite = sum(v["nonfinite_count"] for v in columns)
    unsupported = any(not v["magnitude_supported"] for v in columns)
    return {"status": "fail" if nonfinite or unsupported else "no_issue_detected",
            "n": len(X), "p": X.shape[1], "total_cells": int(sum(len(v) for v in arrays)),
            "nonfinite_cells": nonfinite, "columns": columns,
            "data_repaired": False, "fit_permitted": not(nonfinite or unsupported),
            "limitations": ["Array finiteness does not identify missingness mechanisms, sentinel codes, scientific grain, or leakage.",
                            "Feature distributions need not be normal for OLS prediction, trees, or SVM."]}


def _regression_fixture(preset):
    rng = np.random.default_rng(20261020)
    X = rng.normal(size=(400, 3))
    noise = rng.normal(size=400)
    if preset == "problematic":
        X[:, 1] = X[:, 0] + .015 * X[:, 1]
        y = 1 + X @ np.array([2., -.7, .4]) + .9 * (X[:, 0] ** 2 - 1) + noise * np.exp(.8 * X[:, 0])
    else:
        y = 1 + X @ np.array([2., -.7, .4]) + noise
    return X, y


def _regression_metrics(y, predicted):
    residual = y - predicted
    tss = float(np.sum((y - y.mean()) ** 2))
    return {"mae": float(np.mean(np.abs(residual))), "rmse": float(np.sqrt(np.mean(residual ** 2))),
            "r2": float(1 - np.sum(residual ** 2) / tss) if tss else None}


def _binary_fixture(preset):
    rng = np.random.default_rng(20261021)
    X = rng.normal(size=(1000, 3))
    y = rng.binomial(1, expit(-1.6 + .9 * X[:, 0] - .4 * X[:, 1] + .3 * X[:, 2]))
    model = make_pipeline(StandardScaler(), LogisticRegression(C=1., max_iter=500, random_state=0))
    model.fit(X[:700], y[:700])
    decision = model.decision_function(X[700:])
    # Prespecified overconfidence stress case, never selected using evaluation labels.
    probability = expit(decision * (3 if preset == "problematic" else 1))
    y_test = y[700:]
    baseline = np.full(len(y_test), y[:700].mean())
    rows = []
    for index in range(10):
        lower, upper = index / 10, (index + 1) / 10
        mask = (probability >= lower) & ((probability < upper) if index < 9 else (probability <= upper))
        count = int(mask.sum())
        rows.append({"bin": index, "lower": lower, "upper": upper, "n": count,
                     "mean_probability": float(probability[mask].mean()) if count else None,
                     "event_fraction": float(y_test[mask].mean()) if count else None,
                     "events": int(y_test[mask].sum())})
    metrics = {"n": len(y_test), "events": int(y_test.sum()), "prevalence": float(y_test.mean()),
               "roc_auc": float(roc_auc_score(y_test, probability)),
               "average_precision": float(average_precision_score(y_test, probability)),
               "brier": float(brier_score_loss(y_test, probability)),
               "baseline_brier": float(brier_score_loss(y_test, baseline)),
               "log_loss": float(log_loss(y_test, probability)),
               "baseline_log_loss": float(log_loss(y_test, baseline)),
               "baseline_training_prevalence": float(y[:700].mean()),
               "weighted_absolute_bin_gap": float(sum(v["n"] * abs(v["mean_probability"] - v["event_fraction"]) for v in rows if v["n"]) / len(y_test))}
    return metrics, rows


def _causal_fixture(preset, dag):
    rng = np.random.default_rng(20261022)
    if preset == "clean":
        z = np.repeat(rng.normal(size=120), 2)
        t = np.tile([0, 1], 120)
        propensity = np.full(240, .5)
    else:
        z = rng.normal(size=240)
        propensity = expit(2.4 * z)
        t = rng.binomial(1, propensity)
    weights = np.where(t == 1, 1 / propensity, 1 / (1 - propensity))
    # The numeric covariate is Z only. A supplied unrelated graph is not mapped
    # automatically to it; such a graph can be displayed but cannot reinterpret Z.
    names = {v["name"] for v in dag.get("nodes", [])} if isinstance(dag, dict) else set()
    mapped_dag = dag if "Z" in names and dag.get("exposure") == "T" and dag.get("outcome") == "Y" else None
    unweighted = balance_overlap(z[:, None], t, propensity=propensity, dag=mapped_dag,
                                 covariate_names=["Z"] if mapped_dag is not None else None)
    weighted = balance_overlap(z[:, None], t, propensity=propensity, weights=weights,
                               dag=mapped_dag, covariate_names=["Z"] if mapped_dag is not None else None)
    return unweighted, weighted, {"control": propensity[t == 0].tolist(), "treated": propensity[t == 1].tolist()}, weights, t, mapped_dag is not None


def build_dashboard_data(preset="clean", purpose="prediction", *, evaluation_contaminated=False, dag=None):
    """Execute fixed synthetic diagnostics; return JSON-safe panel/metric data.

    A supplied DAG is assessed, never auto-confirmed. None means graph-dependent
    claims remain unresolved. Editing a graph cannot change these fixed numerical
    examples or re-estimate a causal effect. No causal effect is estimated here.
    """
    if not isinstance(preset, str) or preset not in {"clean", "problematic"}:
        raise ValueError("preset must be clean or problematic")
    if not isinstance(purpose, str) or purpose not in {"prediction", "association"}:
        raise ValueError("Supported demonstration purposes: prediction, association")
    if type(evaluation_contaminated) is not bool:
        raise ValueError("evaluation_contaminated must be boolean")
    graph = assess_assumed_dag(dag)
    X, y = _regression_fixture(preset)
    n_train, names = 300, ["x1", "x2", "x3"]
    train, test = np.arange(n_train), np.arange(n_train, len(X))
    xt, yt = X[train], y[train]
    A = np.column_stack([np.ones(n_train), xt])
    coef = np.linalg.lstsq(A, yt, rcond=None)[0]
    fitted, prediction = A @ coef, np.column_stack([np.ones(len(test)), X[test]]) @ coef
    residual = yt - fitted
    projection = np.linalg.pinv(A)
    leverage = np.sum(A * projection.T, axis=1)
    mse = float(residual @ residual / (n_train - A.shape[1]))
    cooks = residual ** 2 / (A.shape[1] * mse) * leverage / (1 - leverage) ** 2
    standardized = residual / np.sqrt(mse * (1 - leverage))
    panels = []
    context = {"n": n_train, "purpose": purpose, "variables": names + ["target"], "split": "training"}
    raw = summarize_numeric_inputs(xt, yt, feature_names=names)
    panels.append(_panel("pre_missingness", "before_fit", "Missingness and finite input", raw["status"], **context,
        comparison=f"{raw['nonfinite_cells']} nonfinite values / {raw['total_cells']} supplied training cells; no deletion or imputation.",
        interpretation="All supplied synthetic training cells are finite. Missingness mechanisms and sentinel codes remain a separate question.",
        metrics=[_metric("nonfinite cells", raw["nonfinite_cells"], "cells", comparison="nonfinite / all supplied cells", threshold=0), _metric("supplied cells", raw["total_cells"], "cells")],
        threshold=0, rationale="These numerical adapters require finite values; finiteness does not establish data quality.", limitations=raw["limitations"]))
    panels.append(_panel("pre_distributions", "before_fit", "Observed feature distributions", "no_issue_detected", **context,
        comparison="Twelve equal-width bins per supplied training column; counts sum to the recorded finite denominator.",
        interpretation="These are observed distributions, without a universal normal-feature requirement or an automatic normality verdict.",
        chart={"kind": "histograms", "columns": raw["columns"]},
        metrics=[_metric(c["name"] + " mean", c["mean"], "supplied units") for c in raw["columns"]],
        limitations=["Distributions alone do not establish sampling validity, causal roles, or missingness mechanisms."]))
    support = [{"variable": names[i], "training_min": float(xt[:, i].min()), "training_max": float(xt[:, i].max()),
                "evaluation_below": int(np.sum(X[test, i] < xt[:, i].min())), "evaluation_above": int(np.sum(X[test, i] > xt[:, i].max()))} for i in range(3)]
    outside = sum(v["evaluation_below"] + v["evaluation_above"] for v in support)
    panels.append(_panel("pre_support", "before_fit", "Support, target, categorical levels", "warning" if outside else "no_issue_detected", **{**context, "n": 400, "split": "300 training range / 100 evaluation rows; feature support only"},
        comparison=f"{outside} / {len(test) * 3} evaluation feature cells outside training min/max; numeric target; no categorical columns.",
        interpretation="Observed range extrapolation prompts review. Categorical level compatibility is not applicable to this numeric fixture.",
        metrics=[_metric(v["variable"] + " evaluation cells beyond training range", v["evaluation_below"] + v["evaluation_above"], "cells", threshold=0, status="warning" if v["evaluation_below"] + v["evaluation_above"] else "no_issue_detected") for v in support],
        chart={"kind": "status", "support": support}, threshold=0,
        limitations=["Min/max screening is not a multivariate support or distribution-shift test; post-evaluation observations cannot justify tuning on this holdout."],
        remedy="Review deployment support; any model revision needs training-only development and a new final evaluation."))
    # Explicit synthetic entity/timing metadata. Repeated rows are not silently
    # treated as duplicate people. The stress case intentionally crosses groups.
    groups = np.arange(400) if preset == "clean" else np.arange(400) % 80
    repeated = n_train - len(np.unique(groups[train]))
    panels.append(_panel("pre_duplicates", "before_fit", "Declared grain and repeated entities", "warning" if repeated else "no_issue_detected", **context,
        comparison=f"{repeated} repeated training entity positions / {n_train} rows under the declared synthetic entity metadata.",
        interpretation="The declared grain is one synthetic observation per position; repeated entities require dependence and split review.",
        metrics=[_metric("repeated entity positions", repeated, "rows", threshold=0, status="warning" if repeated else "no_issue_detected")], threshold=0,
        limitations=["Entity metadata are declared, not inferred; repeated observations may be legitimate. Entity identifiers are withheld."]))
    group_evidence = audit_split(train, test, groups=groups, strategy="grouped")
    time_evidence = audit_split(train, test, times=np.arange(400), strategy="time", gap=0)
    split_status = "fail" if any(v["status"] == "fail" for v in group_evidence + time_evidence) else "no_issue_detected"
    group_count = group_evidence[0]["observed"]["overlapping_groups"]
    panels.append(_panel("pre_split", "before_fit", "Group and time split audit", split_status, **{**context, "n": 400, "split": "300 training / 100 final evaluation"},
        comparison=f"0 shared row positions; {group_count} groups cross training/evaluation; maximum training time 299 < minimum evaluation time 300 (gap 0).",
        interpretation="A strict forward row split is recorded. " + ("Shared entities prevent independent-group generalization claims." if group_count else "No supplied entity crosses the split."),
        metrics=[_metric("crossing groups", group_count, "groups", threshold=0, status=split_status), _metric("training maximum time", 299., "synthetic time units"), _metric("evaluation minimum time", 300., "synthetic time units")],
        threshold="zero row/group crossing; training maximum + gap < evaluation minimum", chart={"kind": "status", "evidence": group_evidence + time_evidence},
        limitations=["Disjoint rows/groups and forward times cannot prove no content leakage, safe label windows, or an untouched historical holdout."]))
    prediction_cutoffs = np.arange(n_train, dtype=float)
    feature_availability = np.repeat((prediction_cutoffs - 1)[:, None], 3, axis=1)
    if preset == "problematic":
        feature_availability[:12, 2] = prediction_cutoffs[:12] + 1
    late = int(np.sum(feature_availability > prediction_cutoffs[:, None]))
    panels.append(_panel("pre_feature_timing", "before_fit", "Declared feature availability", "fail" if late else "no_issue_detected", **context,
        comparison=f"{late} / {xt.size} declared training feature cells available after their prediction cutoff.",
        interpretation="This metadata audit flags unavailable-at-prediction features. " + ("Prediction-use claims are blocked until a training-only feature revision and fresh evaluation." if late else "No late feature is declared in this synthetic example."),
        metrics=[_metric("late feature cells", late, "cells", comparison=f"availability > cutoff / {feature_availability.size} comparisons", threshold=0, status="fail" if late else "no_issue_detected")], threshold=0,
        limitations=["Synthetic metadata demonstrate a timing audit; arrays alone cannot reveal feature availability or target leakage."],
        remedy="Review feature construction and label windows; no feature is silently removed."))
    panels.append(_panel("ols_residuals", "after_fit", "Residuals versus fitted values", "not_checked", **context,
        comparison=f"{n_train} training residuals compared with zero across fitted response values.",
        interpretation="Look for systematic curvature or changing spread; the scatter is a descriptive review aid and does not prove a correct conditional mean.",
        chart={"kind": "scatter", "x": fitted.tolist(), "y": residual.tolist(), "xlabel": "Fitted response (response units)", "ylabel": "Residual (response units)", "zero_line": True},
        metrics=[_metric("training RMSE", float(np.sqrt(np.mean(residual ** 2))), "response units")],
        limitations=["Training residuals are fitted quantities; mean adequacy and exogeneity require substantive review."]))
    sw = stats.shapiro(residual)
    theoretical, ordered = stats.probplot(standardized, dist="norm", fit=False)
    qq_status = "warning" if sw.pvalue < .05 else "no_issue_detected"
    panels.append(_panel("ols_qq", "after_fit", "Residual Q-Q and shape screen", qq_status, **context,
        comparison=f"Shapiro-Wilk W={sw.statistic:.6g}, p={sw.pvalue:.6g} versus alpha .05 on {n_train} estimated residuals.",
        interpretation="Normal errors are not required for OLS point prediction. " + ("Residual shape differs from the illustrative normal reference." if qq_status == "warning" else "This test did not detect a departure; non-significance is not proof of normal errors."),
        chart={"kind": "qq", "x": np.asarray(theoretical).tolist(), "y": np.asarray(ordered).tolist(), "xlabel": "Theoretical normal quantile", "ylabel": "Ordered standardized residual"},
        metrics=[_metric("Shapiro-Wilk W", float(sw.statistic)), _metric("Shapiro-Wilk p", float(sw.pvalue), comparison="p < .05 prompts review", threshold=.05, status=qq_status)], threshold=.05,
        rationale="Illustrative alpha .05 shape screen; estimated residuals are dependent; sample size affects sensitivity.",
        limitations=["Normality is neither a universal predictor requirement nor proof of valid coefficient inference; conventional exact finite-sample inference has additional assumptions."]))
    squared = residual ** 2
    auxiliary = A @ np.linalg.lstsq(A, squared, rcond=None)[0]
    auxiliary_r2 = max(0., 1 - float(np.sum((squared - auxiliary) ** 2) / np.sum((squared - squared.mean()) ** 2)))
    lm, bp_p = float(n_train * auxiliary_r2), float(stats.chi2.sf(n_train * auxiliary_r2, 3))
    bp_status = "warning" if bp_p < .05 else "no_issue_detected"
    panels.append(_panel("ols_scale_location", "after_fit", "Scale-location and heteroskedasticity", bp_status, **context,
        comparison=f"Koenker/studentized BP nR²={lm:.6g} on 3 auxiliary predictors, p={bp_p:.6g} versus alpha .05.",
        interpretation="Changing residual variance can invalidate homoskedastic uncertainty calculations. A non-significant screen does not establish constant variance.",
        chart={"kind": "scatter", "x": fitted.tolist(), "y": np.sqrt(np.abs(standardized)).tolist(), "xlabel": "Fitted response (response units)", "ylabel": "sqrt(abs(standardized residual))"},
        metrics=[_metric("Koenker nR2", lm), _metric("Koenker p", bp_p, comparison="p < .05 flags evidence", threshold=.05, status=bp_status), _metric("auxiliary R2", auxiliary_r2)], threshold=.05,
        rationale="Squared residuals regressed on the original design; asymptotic chi-square reference with 3 df.",
        limitations=["This screen can miss nonlinear variance patterns. HC3 does not fix dependence, a wrong mean, confounding, or prediction calibration."],
        remedy="Review a prespecified robust-covariance policy and remaining assumptions; compare same-fit HC3 below without pretest-based selection."))
    corr = np.corrcoef(xt, rowvar=False)
    vif = []
    for i in range(xt.shape[1]):
        others = np.column_stack([np.ones(n_train), np.delete(xt, i, axis=1)])
        error = xt[:, i] - others @ np.linalg.lstsq(others, xt[:, i], rcond=None)[0]
        total = float(np.sum((xt[:, i] - xt[:, i].mean()) ** 2))
        vif.append(float(total / np.sum(error ** 2)))
    centered = (xt - xt.mean(axis=0)) / xt.std(axis=0, ddof=1)
    singular = np.linalg.svd(np.column_stack([np.ones(n_train), centered]), compute_uv=False)
    condition_indices = (singular.max() / singular).tolist()
    col_status = "warning" if max(vif) > 5 else "no_issue_detected"
    panels.append(_panel("ols_collinearity", "after_fit", "Correlation, VIF and condition indices", col_status, **context,
        comparison=f"Maximum VIF {max(vif):.6g} versus illustrative threshold 5; maximum standardized-design condition index {max(condition_indices):.6g}.",
        interpretation="Collinearity inflates coefficient variance and can make coefficient estimates unstable; it does not automatically imply poor forecasting.",
        chart={"kind": "correlation", "matrix": corr.tolist(), "labels": names, "vif": vif, "condition_indices": condition_indices},
        metrics=[_metric(name + " VIF", value, comparison="VIF > 5 prompts review", threshold=5, status="warning" if value > 5 else "no_issue_detected") for name, value in zip(names, vif)] + [_metric("maximum condition index", max(condition_indices))], threshold=5,
        rationale="VIF=training centered target-column SST / auxiliary SSE; standardized-design singular-value ratios. Threshold 5 is a review convention, not a validity boundary.",
        limitations=["Conditioning depends on scaling and design. Neither correlation nor permutation importance establishes causation."],
        remedy="Review scientific variables and training-only ridge/feature plans; dropping covariates changes fit and potentially estimand. No automatic removal."))
    influence_status = "warning" if np.any(cooks > 4 / n_train) else "no_issue_detected"
    panels.append(_panel("ols_influence", "after_fit", "Leverage and Cook distance", influence_status, **context,
        comparison=f"{int(np.sum(cooks > 4/n_train))} / {n_train} Cook distances exceed 4/n={4/n_train:.6g}; maximum leverage {leverage.max():.6g}.",
        interpretation="Influential training observations deserve measurement and sensitivity review; the screen is not an automatic deletion rule.",
        chart={"kind": "influence", "leverage": leverage.tolist(), "cooks_distance": cooks.tolist(), "cooks_threshold": 4 / n_train},
        metrics=[_metric("maximum Cook distance", float(cooks.max()), threshold=4/n_train, status=influence_status), _metric("Cook distances above 4/n", int(np.sum(cooks > 4/n_train)), "rows"), _metric("maximum leverage", float(leverage.max()))], threshold=4/n_train,
        rationale="Exploratory Cook 4/n convention, calculated from the unchanged training OLS fit.",
        limitations=["High influence is not a data error; no rows are deleted or winsorized."], remedy="Inspect measurement and prespecified sensitivity analyses; any data change requires a reviewable refit."))
    order = np.argsort(xt[:, 0])
    bins = [np.asarray(index) for index in np.array_split(order, 10)]
    binned = {"x": [float(xt[b, 0].mean()) for b in bins], "y": [float(residual[b].mean()) for b in bins], "n": [len(b) for b in bins]}
    panels.append(_panel("ols_nonlinearity", "after_fit", "Residual mean pattern by x1", "not_checked", **context,
        comparison="Ten equal-count training bins of x1; each residual mean compared descriptively with zero.",
        interpretation="A visible curved pattern can motivate a scientifically justified training-only specification review; this panel supplies no proof or universal functional-form test.",
        chart={"kind": "scatter", **binned, "xlabel": "Bin mean x1 (feature units)", "ylabel": "Bin mean residual (response units)", "zero_line": True},
        metrics=[_metric("maximum absolute binned mean residual", float(max(abs(v) for v in binned["y"])), "response units", status="not_checked")],
        limitations=["Binning is descriptive and can hide structure. No polynomial is selected and no holdout outcome is used for tuning."],
        remedy="Review possible mean misspecification on training folds; a changed model needs refit and new evaluation."))
    panels.append(_panel("ols_convergence", "after_fit", "Solver convergence and separation", "not_applicable", **context,
        comparison="Closed-form least-squares computation; binary-MLE separation does not apply to OLS.",
        interpretation="No logistic-MLE convergence or separation claim is supplied by this OLS panel.",
        metrics=[_metric("OLS design rank", int(np.linalg.matrix_rank(A)), "columns", comparison="rank versus 4 columns", threshold=4, status="not_applicable")],
        limitations=["The separate binary evaluation uses a regularized sklearn classifier; its performance plots do not certify unpenalized-MLE coefficient inference."]))
    regression = _regression_metrics(y[test], prediction)
    baseline = _regression_metrics(y[test], np.full(len(test), yt.mean()))
    eval_status = "warning" if regression["rmse"] >= baseline["rmse"] else "no_issue_detected"
    panels.append(_panel("heldout_regression", "evaluation", "Held-out regression and reference baseline", eval_status,
        n=len(test), purpose=purpose, variables=["target", "fixed OLS prediction", "training-mean baseline"], split="final evaluation; 100 rows; no tuning",
        comparison=f"OLS RMSE {regression['rmse']:.6g} versus training-mean baseline {baseline['rmse']:.6g}, on the same 100 evaluation rows.",
        interpretation="Observed errors describe this synthetic evaluation. They do not establish deployment performance or causality; uncertainty is not assessed.",
        chart={"kind": "bars", "labels": ["OLS MAE", "Baseline MAE", "OLS RMSE", "Baseline RMSE"], "values": [regression["mae"], baseline["mae"], regression["rmse"], baseline["rmse"]], "ylabel": "Response units"},
        metrics=[_metric("OLS " + k, v, "dimensionless" if k == "r2" else "response units") for k, v in regression.items()] + [_metric("baseline " + k, v, "dimensionless" if k == "r2" else "response units") for k, v in baseline.items()],
        threshold="RMSE compared with fixed training-mean reference", limitations=["Intervals/resampling uncertainty are not implemented. Viewing results and then changing the model contaminates this evaluation."]))
    binary, calibration = _binary_fixture(preset)
    calibration_status = "warning" if binary["brier"] >= binary["baseline_brier"] or binary["log_loss"] >= binary["baseline_log_loss"] else "no_issue_detected"
    panels.append(_panel("heldout_calibration", "evaluation", "Binary calibration, discrimination and imbalance", calibration_status,
        n=binary["n"], purpose="prediction", variables=["binary target", "probability of class 1"], split="700 training / 300 final evaluation; positive class 1",
        comparison=f"Brier {binary['brier']:.6g} versus training-prevalence reference {binary['baseline_brier']:.6g}; log loss {binary['log_loss']:.6g} versus {binary['baseline_log_loss']:.6g}; ROC AUC {binary['roc_auc']:.6g}; AP {binary['average_precision']:.6g}; prevalence {binary['events']}/{binary['n']}={binary['prevalence']:.6g}.",
        interpretation="Calibration concerns probability reliability; AUC/AP concern ranking. AP depends on prevalence and the evaluation population. A favorable rank score can coexist with poor probabilities.",
        chart={"kind": "calibration", "bins": calibration},
        metrics=[_metric(k, v, "rows" if k in {"n", "events"} else "probability squared" if "brier" in k else "natural-log loss" if "log_loss" in k else "dimensionless") for k, v in binary.items()],
        threshold="Brier/log loss versus fixed reference; reliability bins versus diagonal", rationale="Ten fixed probability bins, including empty bins explicitly; a worse Brier or log loss than the fixed reference prompts review, not a calibration theorem.",
        limitations=["No uncertainty intervals or formal calibration test are implemented; sparse bins are unstable. Queue capture is not accuracy. No calibration model is fitted to holdout outcomes.", "The problematic fixture prespecifies threefold logit scaling to demonstrate overconfidence; the model and ranking are not selected using evaluation labels."],
        remedy="Any calibration fitting must use separate training/validation or cross-fitting and a fresh final evaluation."))
    unweighted, weighted, propensities, weights, treatment, dag_mapped = _causal_fixture(preset, dag)
    graph_status = "no_issue_detected" if graph["status"] == "assumed_confirmed" else "not_checked"
    panels.append(_panel("causal_dag", "causal_design", "Assumed directional DAG", graph_status,
        n=None, purpose="causal inference", variables=[v["name"] for v in graph.get("nodes", [])], split="design evidence; no estimated causal effect",
        comparison="Graph status: " + graph["status"] + "; " + ("; ".join(graph.get("edge_list", [])) or "no assumed edges supplied"),
        interpretation="Arrows and confirmation are human assumptions, not verified causal relationships. " + ("The displayed numeric Z is explicitly matched by name to this graph." if dag_mapped else "The numeric Z example has no confirmed scientific graph mapping."),
        chart={"kind": "dag", "nodes": graph.get("nodes", []), "edges": graph.get("edges", [])},
        metrics=[_metric("graph nodes", len(graph.get("nodes", [])), "nodes", status=graph_status), _metric("graph edges", len(graph.get("edges", [])), "arrows", status=graph_status)],
        limitations=graph.get("limitations", []) + graph.get("warnings", []), impact="Graph-dependent claims remain conditional or unresolved; editing the graph never reuses an old effect estimate.", remedy="Inspect plausible alternative graphs and explicitly confirm the exact current revision; confirmation cannot override failed numerical checks."))
    before, after = unweighted["balance"], weighted["balance"]
    balance_status = "warning" if any(v["status"] == "warning" for v in (before, after)) else "no_issue_detected"
    balance_rows = []
    for label, result in (("unweighted", before), ("ATE IPW", after)):
        row = result["comparisons"][0]
        for key in ("control_mean", "treated_mean", "control_variance", "treated_variance", "pooled_standard_deviation", "absolute_standardized_mean_difference"):
            balance_rows.append(_metric(label + " Z " + key, row[key], "dimensionless" if key == "absolute_standardized_mean_difference" else "squared Z units" if "variance" in key else "Z units", comparison=row["comparison"], threshold=.1 if key == "absolute_standardized_mean_difference" else None, status=result["status"]))
    panels.append(_panel("causal_balance", "causal_design", "Measured balance: Love plot and denominators", balance_status,
        n=len(treatment), purpose="causal inference; intended ATE", variables=["synthetic Z", "treatment 0/1"], split="separate design demonstration; not regression holdout",
        comparison="Unweighted Z SMD " + str(before["absolute_standardized_mean_differences"][0]) + " versus ATE-IPW SMD " + str(after["absolute_standardized_mean_differences"][0]) + "; screening threshold .1; means and sample variances shown in table.",
        interpretation="Mean balance on an assumed pre-treatment common cause, if its role is justified, is conditional evidence about one measured mean. Successful balance does not certify causation, exchangeability, distributional balance, or identification.",
        chart={"kind": "love", "labels": ["Z"], "unweighted": before["absolute_standardized_mean_differences"], "weighted": after["absolute_standardized_mean_differences"], "threshold": .1},
        metrics=balance_rows + [_metric("control raw n", before["raw_arm_sizes"][0], "rows"), _metric("treated raw n", before["raw_arm_sizes"][1], "rows"), _metric("weighted control ESS", after["effective_sample_sizes"][0], "effective rows"), _metric("weighted treated ESS", after["effective_sample_sizes"][1], "effective rows")],
        threshold=.1, rationale=before["threshold_rationale"] + " Weighted sample-variance denominator: sum(w) - sum(w²)/sum(w); SMD denominator sqrt((control variance + treated variance)/2).",
        limitations=before["limitations"] + ["ATE inverse-probability weights use the synthetic generator's propensities; no propensity model or causal outcome effect is estimated. Changing adjustment sets would require refitting the real propensity model and rerunning diagnostics."],
        remedy="Review DAG roles and balance beyond means. Proposed mediator/collider/descendant adjustment must be reviewed by the causal code-plan module."))
    overlap = unweighted["overlap"]
    ess = after["effective_sample_sizes"]
    extreme = int(np.sum(weights > 10))
    panels.append(_panel("causal_overlap", "causal_design", "Propensity overlap, extreme weights and ESS", overlap["status"],
        n=len(treatment), purpose="causal inference; intended ATE", variables=["synthetic propensity", "ATE inverse-probability weight"], split="separate design demonstration",
        comparison=f"{overlap['outside_screen_bounds_count']} / {len(treatment)} propensities outside [.05,.95]; {extreme} weights >10; raw arm sizes {before['raw_arm_sizes']}; weighted ESS {ess}.",
        interpretation="Observed support and weight stability constrain this sample's weighted comparison. Sample overlap cannot establish population positivity or no unmeasured confounding.",
        chart={"kind": "overlap", **propensities, "screen_bounds": [.05, .95]},
        metrics=[_metric("propensities outside bounds", overlap["outside_screen_bounds_count"], "rows", threshold=".05 <= p <= .95", status=overlap["status"]), _metric("weights above 10", extreme, "rows", threshold=10, status="warning" if extreme else "no_issue_detected"), _metric("maximum raw ATE weight", float(weights.max())), _metric("control weighted ESS", ess[0], "effective rows"), _metric("treated weighted ESS", ess[1], "effective rows")],
        threshold={"propensity_bounds": [.05, .95], "weight_screen": 10}, rationale="Illustrative [.05,.95] support and >10 raw ATE weight review screens; ESS=(sum w)^2/sum(w²), not a universal validity rule.",
        limitations=overlap["limitations"] + ["Weights are shown without trimming. Trimming can change the target population and estimand, not just a metric."], remedy="Review population, support and uncertainty; any trimming or new propensity model is a reviewable proposal requiring rerun."))
    panels.append(_panel("causal_assumptions", "causal_design", "Identification assumptions remain unresolved", "not_checked",
        n=None, purpose="causal inference", variables=["exchangeability", "consistency", "interference", "measurement", "selection", "temporality"], split="manual design evidence",
        comparison="No causal effect, exchangeability test, exclusion test, or counterfactual-trend proof was computed.",
        interpretation="This demonstration cannot authorize a causal conclusion. Assumed arrows, balance, overlap and model fit cannot establish the substantive identifying assumptions.",
        metrics=[_metric("unmeasured-confounding identification", None, status="not_checked"), _metric("causal effect estimate", None, status="not_checked")],
        limitations=["Design-specific RCT, matching/weighting, DiD, RD and IV requirement matrices are available separately; most evidence is manual. No universal causal-validity score is provided."],
        impact="Strong causal language is blocked even with confirmed DAG and perfect measured mean balance.", remedy="Supply explicit design evidence and sensitivity reasoning; unsupported identification has no numerical repair."))
    conditions = {key: {"status": "no_issue_detected", "reviewer": "Synthetic generator declaration", "basis": "Independent generated errors and declared linear conditional mean; synthetic only, not real-data evidence."} for key in ("independence", "mean_specification", "exogeneity")}
    if preset == "problematic":
        conditions["mean_specification"] = {"status": "fail", "reviewer": "Synthetic generator declaration", "basis": "The fixed stress generator includes an omitted quadratic conditional-mean term; HC3 cannot fix this."}
    correction = compare_ols_covariance(xt, yt, conditions=conditions, policy="comparison_only", source_split="training")
    correction_status = "warning" if correction["gates"]["conditional_inference"] == "blocked" else "no_issue_detected"
    comparison_rows = correction["comparison_rows"]
    panels.append(_panel("hc3_comparison", "corrections", "What changes? Conventional versus HC3 uncertainty", correction_status, **context,
        comparison="One unchanged OLS fit: conventional and HC3 SE/95% CI/p-values, using an approximate Student-t reference with 296 residual df. No pretest chooses a result.",
        interpretation="Only uncertainty fields change. Coefficients, predictions, records, MAE/RMSE/R² and the target question stay identical. " + ("Mean misspecification in this stress case blocks conditional coefficient interpretation despite computed HC3 arithmetic." if preset == "problematic" else "The interpretation remains conditional on the explicitly declared synthetic assumptions."),
        chart={"kind": "uncertainty", "rows": comparison_rows},
        metrics=[_metric(row["term"] + " " + field, row[field], "coefficient units" if field in {"estimate", "conventional_se", "hc3_se"} else "probability" if field.endswith("_p") else "coefficient interval", status=correction_status) for row in comparison_rows for field in ("estimate", "conventional_se", "hc3_se", "conventional_ci", "hc3_ci", "conventional_p", "hc3_p")] + [_metric("unchanged training " + key, value, "dimensionless" if key == "r2" else "response units") for key, value in correction["original"]["fit"]["training_metrics"].items()],
        threshold="95% intervals; two-sided coefficient=0 tests; no significance-selected policy", rationale="HC3 uses squared residual/(1-leverage); Student-t with residual df is an approximation, not an exact robust pivot.",
        limitations=correction["limitations"], remedy="Prespecify inference policy. Cluster/HAC, model refits, calibration, missingness handling and trimming remain proposals, not automatic corrections."))
    failed_prerequisites = [p["id"] for p in panels if p["stage"] == "before_fit" and p["status"] == "fail"]
    contaminated = evaluation_contaminated
    evaluated_status = "blocked" if contaminated or failed_prerequisites else "descriptive_only"
    claims = {
        "evaluated_prediction": {"status": evaluated_status, "reason": "Evaluation was declared reused for selection; metrics remain descriptive and a fresh final evaluation is required." if contaminated else "Failed prerequisites: " + ", ".join(failed_prerequisites) if failed_prerequisites else "Fixed holdout measurements only; deployment and external validity remain unestablished."},
        "causal_interpretation": {"status": "blocked", "reason": "No identifying design is established and no causal effect is estimated; balance and assumed arrows cannot authorize causation."},
        "graph_dependent_claims": {"status": "conditional_on_assumed_graph" if graph["status"] == "assumed_confirmed" and dag_mapped else "unresolved", "reason": "Graph confirmation is an attestation; only numeric Z name mapping is supplied, not identification or scientific-population mapping."},
        "conditional_inference": {"status": correction["gates"]["conditional_inference"], "reason": "Same-fit covariance interpretation is conditional on recorded synthetic mean, exogeneity and independence assumptions; it never authorizes a causal claim."},
    }
    payload = {"schema_version": "1.0.0", "dashboard_version": "0.1.0", "preset": preset, "purpose": purpose,
               "synthetic": True, "evaluation_contaminated": contaminated, "stages": deepcopy(STAGES), "panels": panels,
               "summary": {status: sum(p["status"] == status for p in panels) for status in STATUS_LABELS},
               "metrics": {"regression": regression, "regression_baseline": baseline, "binary": binary},
               "claims": claims, "correction": correction, "assumed_dag": graph,
               "causal_diagnostics": {"unweighted": unweighted, "weighted": weighted},
               "proposed_remedies": [propose_correction(name) for name in ("multicollinearity", "calibration", "extreme_weights", "confounding", "cluster", "hac", "missingness", "outliers")],
               "protocol": {"regression_seed": 20261020, "binary_seed": 20261021, "causal_seed": 20261022,
                            "regression_training_rows": 300, "regression_evaluation_rows": 100,
                            "binary_training_rows": 700, "binary_evaluation_rows": 300,
                            "selection": "Both stress presets and all thresholds fixed in source before viewing evaluation outcomes; no holdout-driven selection or repair.",
                            "preprocessing": "OLS raw columns; binary StandardScaler fitted inside sklearn Pipeline on 700 training rows only.",
                            "evaluation_history": "Caller declaration only; the library cannot authenticate historical holdout usage.",
                            "causal_effect_estimated": False, "network_used": False},
               "limitations": ["This executable synthetic dashboard is a bounded teaching/demo slice, not an arbitrary-data dashboard or universal assumption checker.",
                               "Aggregates, plots, graph labels and explanations can be sensitive with real inputs; local-only does not anonymize them.",
                               "No graph is inferred from correlations and no human graph is automatically confirmed.",
                               "Default user-facing reports use the separate audit_report renderer; this demonstration does not replace fitted-model adapters."]}
    json.dumps(payload, allow_nan=False)
    return payload


def render_panel_figure(dashboard, panel_id, *, format="svg"):
    """Return SVG/PNG bytes from one panel's exact values, with no filesystem I/O.

    The bounded local UI must supply a dashboard produced by this module, rather
    than expose this Python function as a network plotting or deserialization API.
    Manual/unsupported panels render a status figure, never invented numerics.
    """
    if not isinstance(format, str) or format not in {"svg", "png"}:
        raise ValueError("Figure format must be svg or png")
    if not isinstance(panel_id, str) or not isinstance(dashboard, dict):
        raise ValueError("Existing dashboard and panel identifier required")
    try:
        serialized = json.dumps(dashboard, allow_nan=False)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("Dashboard must contain finite JSON data; no nonfinite plotting omission") from exc
    if len(serialized) > 4_000_000:
        raise ValueError("Dashboard exceeds this local demonstration's bounded size")
    matches = [p for p in dashboard.get("panels", []) if p.get("id") == panel_id]
    if len(matches) != 1:
        raise ValueError("Unknown or duplicate panel identifier")
    panel = matches[0]
    chart = panel["chart"]
    if chart.get("kind") in {"scatter", "qq"} and (not chart.get("x") or len(chart["x"]) != len(chart.get("y", [])) or any(v is None for v in chart["x"] + chart["y"])):
        raise ValueError("Scatter coordinates must be nonempty, finite and aligned")
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    figure = Figure(figsize=(8, 4.8), layout="constrained")
    FigureCanvasAgg(figure)
    axis = figure.subplots()
    kind = chart["kind"]
    if kind == "histograms":
        axis.remove()
        axes = figure.subplots(2, 2).ravel()
        for ax, column in zip(axes, chart["columns"]):
            ax.stairs(column["histogram_counts"], column["histogram_edges"], fill=True, alpha=.65)
            ax.set_title(column["name"] + f"; n={column['histogram_denominator']}")
            ax.set_xlabel("Supplied units"); ax.set_ylabel("Finite training count")
    elif kind in {"scatter", "qq"}:
        axis.scatter(chart["x"], chart["y"], s=15, alpha=.65, edgecolors="none")
        if chart.get("zero_line"): axis.axhline(0, color="black", linestyle="--", linewidth=1)
        if kind == "qq":
            bounds = [min(chart["x"]), max(chart["x"])]
            axis.plot(bounds, bounds, color="black", linestyle="--", label="standard-normal reference")
            axis.legend(fontsize=8)
        axis.set_xlabel(chart["xlabel"]); axis.set_ylabel(chart["ylabel"])
    elif kind == "correlation":
        image = axis.imshow(chart["matrix"], vmin=-1, vmax=1, cmap="coolwarm")
        axis.set_xticks(range(len(chart["labels"])), chart["labels"])
        axis.set_yticks(range(len(chart["labels"])), chart["labels"])
        for i, row in enumerate(chart["matrix"]):
            for j, value in enumerate(row): axis.text(j, i, f"{value:.3f}", ha="center", va="center", bbox={"facecolor": "white", "alpha": .75, "edgecolor": "none"})
        figure.colorbar(image, ax=axis, label="Training Pearson correlation")
    elif kind == "influence":
        axis.scatter(chart["leverage"], chart["cooks_distance"], s=17, alpha=.7)
        axis.axhline(chart["cooks_threshold"], linestyle="--", color="black", label="Cook 4/n review screen")
        axis.set_xlabel("Training leverage (dimensionless)"); axis.set_ylabel("Cook distance (dimensionless)"); axis.legend(fontsize=8)
    elif kind == "bars":
        axis.bar(chart["labels"], chart["values"], color=["#245a81", "#777777"] * 2)
        for index, value in enumerate(chart["values"]): axis.text(index, value, f"{value:.3g}", ha="center", va="bottom")
        axis.set_ylabel(chart["ylabel"])
    elif kind == "calibration":
        rows = [r for r in chart["bins"] if r["n"]]
        axis.plot([0, 1], [0, 1], "k--", label="equal observed / predicted probability")
        axis.plot([r["mean_probability"] for r in rows], [r["event_fraction"] for r in rows], marker="o", label="fixed-bin reliability; no uncertainty")
        for r in rows: axis.annotate("n=" + str(r["n"]), (r["mean_probability"], r["event_fraction"]), fontsize=7, xytext=(3, 4), textcoords="offset points")
        axis.set_xlim(0, 1); axis.set_ylim(0, 1); axis.set_xlabel("Mean predicted P(class=1)"); axis.set_ylabel("Observed event fraction"); axis.legend(fontsize=7)
    elif kind == "love":
        y = np.arange(len(chart["labels"]))
        axis.scatter(chart["unweighted"], y, marker="o", s=65, label="Unweighted")
        axis.scatter(chart["weighted"], y, marker="x", s=90, label="ATE IPW")
        axis.axvline(chart["threshold"], color="black", linestyle="--", label=".1 review screen")
        axis.set_yticks(y, chart["labels"]); axis.set_ylim(-.7, len(y)-.3)
        axis.set_xlabel("Absolute SMD: mean difference / pooled within-arm SD"); axis.legend(fontsize=8)
    elif kind == "overlap":
        bins = np.linspace(0, 1, 21)
        axis.hist(chart["control"], bins=bins, alpha=.5, label="Control (0)")
        axis.hist(chart["treated"], bins=bins, alpha=.5, label="Treated (1)", hatch="/")
        for value in chart["screen_bounds"]: axis.axvline(value, color="black", linestyle="--")
        axis.set_xlabel("Synthetic P(treatment=1 | Z)"); axis.set_ylabel("Raw observations per bin"); axis.legend(fontsize=8)
    elif kind == "uncertainty":
        rows = chart["rows"]
        positions = np.arange(len(rows))
        for offset, key, label in ((-.1, "conventional_ci", "Conventional 95% CI"), (.1, "hc3_ci", "HC3 95% CI")):
            estimates = np.array([r["estimate"] for r in rows])
            intervals = np.array([r[key] for r in rows])
            axis.errorbar(estimates, positions + offset, xerr=np.vstack([estimates - intervals[:, 0], intervals[:, 1] - estimates]), fmt="o", capsize=3, label=label)
        axis.axvline(0, color="black", linestyle="--")
        axis.set_yticks(positions, [r["term"] for r in rows]); axis.set_xlabel("Same coefficient estimate; coefficient units"); axis.legend(fontsize=8)
    elif kind == "dag" and chart["nodes"]:
        nodes = chart["nodes"]
        positions = {v["name"]: (np.cos(2*np.pi*i/len(nodes)), np.sin(2*np.pi*i/len(nodes))) for i, v in enumerate(nodes)}
        for left, right in chart["edges"]:
            axis.annotate("", xy=positions[right], xytext=positions[left], arrowprops={"arrowstyle": "->", "shrinkA": 20, "shrinkB": 20})
        for node in nodes:
            x, y = positions[node["name"]]
            axis.text(x, y, node["name"] + ("\n(unobserved)" if not node["observed"] else ""), ha="center", va="center", bbox={"boxstyle": "round", "facecolor": "#f1f5f8", "edgecolor": "black"})
        axis.set_xlim(-1.5, 1.5); axis.set_ylim(-1.5, 1.5); axis.axis("off")
    else:
        axis.axis("off")
        axis.text(.03, .85, panel["status_label"], transform=axis.transAxes, fontsize=12, weight="bold")
        import textwrap
        axis.text(.03, .68, textwrap.fill(panel["comparison"], 90), transform=axis.transAxes, va="top", fontsize=10)
        axis.text(.03, .35, textwrap.fill(panel["interpretation"], 90), transform=axis.transAxes, va="top", fontsize=10)
    figure.suptitle(panel["title"], fontsize=13)
    figure.supxlabel(f"n={panel['n'] if panel['n'] is not None else 'not assessed'} | {panel['split']} | purpose: {panel['purpose']}\n{panel['status_label']}", fontsize=7)
    output = BytesIO()
    figure.savefig(output, format=format, dpi=130, metadata={"Creator": "model-evidence 0.1.0 synthetic dashboard"})
    figure.clear()
    return output.getvalue()
