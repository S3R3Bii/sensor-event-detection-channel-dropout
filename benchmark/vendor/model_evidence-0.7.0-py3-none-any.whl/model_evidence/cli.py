"""Explicit local CLI with default figure/table reports; no network integration."""
import argparse
import json
import math
from pathlib import Path
from .registry import list_methods,describe_requirements
from .report import validate_report,explain_report,to_json

MAX_REPORT_BYTES=2_097_152


def _strict_report_json(raw):
    """Bounded local JSON; longer generated DAG text is not an MCP response."""
    if len(raw)>MAX_REPORT_BYTES: raise ValueError("Report exceeds local input limit")
    def unique(pairs):
        result={}
        for key,value in pairs:
            if key in result: raise ValueError("Duplicate JSON keys are forbidden")
            result[key]=value
        return result
    def nonfinite(_): raise ValueError("Nonfinite JSON numbers are forbidden")
    try:
        value=json.loads(raw.decode("utf-8"),object_pairs_hook=unique,parse_constant=nonfinite)
    except (UnicodeError,json.JSONDecodeError,RecursionError) as exc:
        raise ValueError("Malformed report JSON") from exc
    pending=[(value,0)]; count=0
    while pending:
        item,depth=pending.pop(); count+=1
        if count>20_000 or depth>24: raise ValueError("Report structure exceeds local limits")
        if isinstance(item,dict):
            if any(len(key)>256 for key in item): raise ValueError("Report key exceeds local limit")
            pending.extend((part,depth+1) for part in item.values())
        elif isinstance(item,list): pending.extend((part,depth+1) for part in item)
        elif isinstance(item,str) and len(item)>65_536: raise ValueError("Report text exceeds local limit")
        elif type(item) in {int,float} and (abs(item)>10**100 or not math.isfinite(item)):
            raise ValueError("Nonfinite or oversized report number")
    return value


def _validated_report(report):
    """Validate a supported contract before any explanation or local write."""
    if not isinstance(report,dict):
        raise ValueError("A report must be a JSON object")
    if report.get("kind")=="ols_covariance_comparison":
        from .corrections import validate_correction_report,correction_to_json,explain_correction_report
        validate_correction_report(report)
        text=correction_to_json(report)
        explain=explain_correction_report
    elif "claim" in report and "matrix" in report:
        from .causal import validate_causal_audit,causal_to_json,explain_causal_audit
        validate_causal_audit(report)
        text=causal_to_json(report)
        explain=explain_causal_audit
    elif "old_spec" in report and "new_spec" in report:
        from .code_plan import validate_code_plan,code_plan_to_json,explain_code_plan
        validate_code_plan(report)
        text=code_plan_to_json(report)
        explain=explain_code_plan
    else:
        validate_report(report)
        text=to_json(report)
        explain=explain_report
    # Reuse canonical export decisions, including recomputed core claim gates.
    canonical=json.loads(text)
    return canonical,text,explain


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__); sub=p.add_subparsers(dest="command",required=True)
    sub.add_parser("list")
    d=sub.add_parser("describe"); d.add_argument("method"); d.add_argument("purpose")
    for name in ("validate","explain","report"):
        s=sub.add_parser(name); s.add_argument("report",type=Path)
        if name!="validate":
            s.add_argument("--output-dir",type=Path,default=Path("model-evidence-reports"),
                help="local artifact root (default: model-evidence-reports)")
        if name=="explain":
            s.add_argument("--text-only",action="store_true",help="print explanation without writing report artifacts")
    args=p.parse_args(argv)
    try:
        if args.command=="list": print(json.dumps(list_methods(),indent=2))
        elif args.command=="describe": print(json.dumps(describe_requirements(args.method,args.purpose),indent=2))
        else:
            with args.report.open("rb") as f: r=_strict_report_json(f.read(MAX_REPORT_BYTES+1))
            canonical,text,explain=_validated_report(r)
            if args.command=="validate":
                print(text,end="" if text.endswith("\n") else "\n")
            else:
                narrative=explain(canonical)
                if args.command=="explain" and args.text_only:
                    print(narrative)
                else:
                    from .render import render_report
                    artifacts=render_report(canonical,args.output_dir)
                    print(narrative)
                    print("\nLocal report (figure and key-metrics/evidence table): "+artifacts["html"])
    except FileNotFoundError:
        p.exit(2,"Invalid or unreadable local input/output: a required file does not exist. Choose an existing exported report JSON and a writable local output root.\n")
    except OSError:
        p.exit(2,"Invalid or unreadable local input/output. Check local file permissions and choose an empty writable output directory.\n")
    except (ValueError,TypeError,KeyError,OverflowError,RecursionError) as exc:
        reason="".join(c if c.isprintable() else " " for c in str(exc))[:180]
        p.exit(2,"Invalid report or arguments: "+(reason or "unsupported structure")+". Use 'list'/'describe' for supported methods; export a valid core, causal, code-plan or correction report. No generated code was executed.\n")

if __name__=="__main__": main()
