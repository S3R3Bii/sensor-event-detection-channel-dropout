"""Review supplied MCMC summary evidence; never compute or certify a posterior.

This bounded workflow does not ingest draws, run a sampler, recalculate Rhat/ESS,
execute model code or authenticate a supplied summary. Its method stays manual.
"""
from copy import deepcopy
import math

from .diagnostics import _complete
from .model_visuals import _bars, _finish, status_panel
from .report import evidence, make_report

FIELDS={'chains','draws_per_chain','rhat_max','ess_bulk_min','ess_tail_min','divergences',
        'sampler','diagnostic_method','warmup_excluded','all_monitored_parameters'}
METADATA={'source_reference'}
LIMITS=[
    'These are caller-supplied scalar summaries, not recalculated chain diagnostics or authenticated sampler output.',
    'Good Rhat/ESS and zero reported divergences do not prove convergence, model correctness, prior adequacy, identification or external validity.',
    'MCMC thresholds do not validate variational, Laplace, optimization or independent-draw approximations.'
]


def audit_bayesian_summary(summary, *, purpose='description', metadata=None,
                           attestations=None, split_role='unknown'):
    """Return a manual-only evidence report from an explicit MCMC summary.

    Default screening configuration: rank-normalized folded split Rhat<1.01,
    >=4 chains, bulk/tail ESS>=100*chains and zero reported HMC divergences.
    These are review heuristics, not universal sufficiency criteria. A missing
    scope/method/warmup declaration leaves the scalar screen unresolved.
    """
    if purpose!='description':raise ValueError('Bayesian summary evidence review supports description only')
    if not isinstance(split_role,str) or split_role not in {'unknown','training','validation','evaluation','final_holdout'}:raise ValueError('Unknown split role')
    if not isinstance(summary,dict) or set(summary)-FIELDS:raise ValueError('Only bounded documented Bayesian summary fields are accepted; no code, paths or draws')
    metadata={} if metadata is None else metadata
    if not isinstance(metadata,dict) or set(metadata)-METADATA:raise ValueError('Bayesian review metadata accepts only source_reference text')
    reference=metadata.get('source_reference')
    if reference is not None and (not isinstance(reference,str) or not 1<=len(reference.strip())<=1024):raise ValueError('source_reference must be bounded nonempty citation text')
    values=deepcopy(summary)
    for key in ('chains','draws_per_chain','divergences'):
        if key in values and (type(values[key]) is not int or not 0<=values[key]<=1_000_000):raise ValueError(key+' must be a bounded nonnegative integer')
    for key in ('chains','draws_per_chain'):
        if key in values and values[key]<1:raise ValueError(key+' must be positive when supplied')
    for key in ('rhat_max','ess_bulk_min','ess_tail_min'):
        if key in values:
            value=values[key]
            if type(value) not in {int,float} or not math.isfinite(value) or not 0<value<=1e9:raise ValueError(key+' must be a bounded finite positive scalar')
            values[key]=float(value)
    for key in ('warmup_excluded','all_monitored_parameters'):
        if key in values and type(values[key]) is not bool:raise ValueError(key+' must be an explicit boolean declaration')
    if 'sampler' in values and (not isinstance(values['sampler'],str) or values['sampler'] not in {'hmc','nuts','other_mcmc'}):raise ValueError('Only MCMC supplied-summary review is supported; no automatic approximation equivalence')
    if 'diagnostic_method' in values and values['diagnostic_method']!='rank_normalized_folded_split':raise ValueError('Rhat/ESS review requires the declared rank_normalized_folded_split diagnostic convention')
    chains=values.get('chains');draws=values.get('draws_per_chain')
    total=chains*draws if chains is not None and draws is not None else None
    if total is not None and total>1_000_000_000:raise ValueError('Reported total retained draws exceeds bounded report size')
    if total is not None and values.get('divergences',0)>total:raise ValueError('Reported divergences exceed retained draws')
    needed=set(FIELDS)
    if values.get('sampler')=='other_mcmc':needed.discard('divergences')
    missing=sorted(needed-set(values))
    comparisons=[]
    if chains is not None:comparisons.append({'metric':'chains','value':chains,'operator':'>=','reference':4,'units':'chains','concern':chains<4})
    if 'rhat_max' in values:comparisons.append({'metric':'rhat_max','value':values['rhat_max'],'operator':'<','reference':1.01,'units':'dimensionless','concern':values['rhat_max']>=1.01})
    if chains is not None:
        for key in ('ess_bulk_min','ess_tail_min'):
            if key in values:comparisons.append({'metric':key,'value':values[key],'operator':'>=','reference':100*chains,'units':'effective draws','concern':values[key]<100*chains})
    if values.get('sampler') in {'hmc','nuts'} and 'divergences' in values:comparisons.append({'metric':'divergences','value':values['divergences'],'operator':'==','reference':0,'units':'transitions after warmup','concern':values['divergences']>0})
    declaration_concerns=[key for key in ('warmup_excluded','all_monitored_parameters') if key in values and not values[key]]
    concerns=[row['metric'] for row in comparisons if row['concern']]+declaration_concerns
    status='warning' if concerns else 'not_checked' if missing else 'no_issue_detected'
    observed={'supplied_comparisons':comparisons,'missing_fields':missing,'declaration_concerns':declaration_concerns,
              'scope':'threshold review of supplied scalar summaries only; no draws examined'}
    ev=[evidence('convergence',status,'Compared the supplied MCMC scalar summaries with the explicitly stated review heuristics; no chain diagnostic was recomputed.',
        sample_size=total,observed=observed,thresholds={'rhat_upper_exclusive':1.01,'minimum_chains':4,'minimum_bulk_and_tail_ess_per_chain':100,'reported_hmc_divergences':0},
        limitations=LIMITS,remedies=['Inspect original chain/energy/divergence/treedepth/MCSE diagnostics, monitored parameters and sampler output; resolve concerns before posterior interpretation.'],
        provenance={'implementation':'supplied-summary-review/0.6.0','computation':'scalar comparisons only','source_reference':reference or 'not supplied'})]
    ev=_complete('bayesian_posterior_review',purpose,ev,attestations)
    n=total or 0
    panels=[status_panel('bayesian_unverified_posterior','Bayesian posterior evidence remains unresolved',n=n,source_split=split_role,role='main_result',
        message='No posterior estimate, interval or predictive distribution was computed. Original draws, model, priors and likelihood have not been validated.',
        interpretation='Use the supplied summary screen alongside a documented Bayesian workflow; this manual-only adapter cannot certify posterior interpretation.',limitations=LIMITS)]
    for row in comparisons:
        if n==0:
            panels.append(status_panel('bayesian_'+row['metric'],'Supplied '+row['metric']+'; draw denominator unavailable',n=0,source_split=split_role,requirement='convergence',
                message='Supplied value '+str(row['value'])+'; review reference '+row['operator']+' '+str(row['reference'])+'. Retained draw count is unknown; no numerical chart with an invented denominator is produced.',
                comparison='Supplied scalar review only; source draws and scope unverified',limitations=LIMITS))
            continue
        panels.append(_bars('bayesian_'+row['metric'],'Supplied '+row['metric'],['supplied value','review reference'],[row['value'],row['reference']],n,split_role,
            role='diagnostic',requirement='convergence',units=row['units'],comparison='Supplied '+row['metric']+' '+row['operator']+' '+str(row['reference'])+' (review heuristic)',
            threshold=row['operator']+' '+str(row['reference'])+' (review heuristic)',interpretation='Observed concern in supplied summary' if row['concern'] else 'No threshold concern in this supplied scalar; convergence is not established.',limitations=LIMITS))
    estimates={'bayesian_review':{'review_status':status,'supplied_summary':values,'comparisons':comparisons,'missing_fields':missing,
        'draws_examined':False,'rhat_computed':False,'ess_computed':False,'sampler_run':False,'source_reference':reference,
        'unimplemented':['chain-level rank-normalized Rhat','bulk/tail ESS recomputation','MCSE','energy/BFMI/treedepth','posterior predictive calculation','prior sensitivity calculation']},
        'visual_evidence':_finish(n,split_role,panels)}
    return make_report('bayesian_posterior_review',purpose,ev,{'reported_chains':chains or 0,'reported_retained_draws':n},estimates,LIMITS)
