"""Model Evidence: deterministic diagnostic evidence and guarded interpretations."""
from .diagnostics import audit_ols, audit_logistic, audit_prediction, audit_split, audit_pca, audit_clustering
from .registry import list_methods, describe_requirements, load_registry
from .report import evidence, make_report, validate_report, gate_claims, explain_report, main_findings, requirement_coverage, to_json
from .causal import (causal_requirements, assess_causal_claim, validate_causal_audit,
    explain_causal_audit, causal_to_json, balance_overlap)
from .dag import validate_assumed_dag, assess_assumed_dag
from .code_plan import (generate_code_plan, validate_code_plan, code_plan_to_json,
    code_plan_freshness, explain_code_plan)
from .corrections import (compare_ols_covariance, propose_correction, validate_correction_report,
    correction_to_json, explain_correction_report)
from .adapters import audit_fitted, audit_report
from .multiclass import audit_multiclass
from .calibration import audit_calibration
from .ordered_diagnostics import ols_diagnostics
from .render import render_report
from .statistical_tests import audit_test
from .multiplicity import adjust_pvalues, validate_multiplicity_result
from .forecasting import audit_forecast
from .survival import audit_survival
from .mixed_models import audit_mixed_model
from .causal_estimators import audit_ipw
from .bayesian_review import audit_bayesian_summary
from .architecture_audit import audit_supplied_architecture
from .clustering_audits import audit_fitted_clustering
from .registry import validate_registry, family_coverage
from ._version import VERSION as __version__
