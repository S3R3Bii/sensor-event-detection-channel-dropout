"""Bounded existing-fit agglomerative/DBSCAN summaries; never fit or assign rows."""
from __future__ import annotations

import hashlib
import json
import math
import re
import warnings

import numpy as np
import scipy.sparse as sparse
import sklearn
from sklearn.cluster import AgglomerativeClustering, DBSCAN
from sklearn.metrics import silhouette_score

from .diagnostics import _common, _complete
from .report import evidence, make_report
from . import model_visuals as visuals

MAX_CELLS = 2_000_000
MAX_ROWS = 100_000
MAX_FEATURES = 2048
MAX_PAIRWISE_CELLS = 1_000_000
SILHOUETTE_LIMIT = 1000
SILHOUETTE_SEED = 2026
SOURCES = {
    "hierarchical_clustering": "https://scikit-learn.org/stable/modules/generated/sklearn.cluster.AgglomerativeClustering.html",
    "dbscan": "https://scikit-learn.org/stable/modules/generated/sklearn.cluster.DBSCAN.html",
    "silhouette": "https://scikit-learn.org/stable/modules/generated/sklearn.metrics.silhouette_score.html",
}
_LIMITS = [
    "Stored labels describe the original fit only; this adapter neither fits nor assigns clusters to new observations.",
    "Human declarations and caller-recorded fingerprints are editable evidence, not authenticated fit provenance.",
    "Stored labels/core state and current parameters are editable after fit; their original values are not authenticated or recoverable without independent records.",
    "Distance scaling, measurement validity, domain usefulness, natural classes and resampling stability are not established by these summaries.",
    "Counts and silhouettes are unweighted. DBSCAN fit-time sample weights are not retained by the stock estimator and cannot be reconstructed.",
    "Aggregate counts, binned coordinates, parameter values and even fingerprints may still be sensitive; aggregate-only is not anonymization.",
]


def _integer(value, name, maximum=MAX_ROWS, minimum=1):
    if type(value) not in {int, np.int32, np.int64} or not minimum <= value <= maximum:
        raise ValueError(name + " must be a bounded integer")
    return int(value)


def _numeric(value, name, ndim):
    if type(value) in {list, tuple}:
        budget = [0]
        def check(item, depth=0):
            if depth > 3:
                raise ValueError(name + " exceeds supported array nesting")
            if type(item) in {list, tuple}:
                if len(item) > MAX_CELLS:
                    raise ValueError(name + " exceeds bounded element count")
                for nested in item:
                    check(nested, depth+1)
            elif type(item) not in {int, float, np.int32, np.int64, np.float32, np.float64}:
                raise ValueError(name + " rejects custom objects, booleans, text, complex and masked values")
            else:
                budget[0] += 1
                if budget[0] > MAX_CELLS:
                    raise ValueError(name + " exceeds bounded element count")
        check(value)
        try:
            raw = np.asarray(value)
        except (ValueError, TypeError) as exc:
            raise ValueError(name + " requires a rectangular numeric array") from exc
    elif type(value) is np.ndarray:
        raw = value
    else:
        raise ValueError(name + " requires a plain dense numeric array/list; custom objects and array subclasses are unsupported")
    if raw.ndim != ndim or raw.dtype.kind not in "iuf" or raw.size > MAX_CELLS:
        raise ValueError(name + " has an unsupported shape/type or exceeds two million cells")
    result = np.array(raw, dtype=float, copy=True)
    if not np.isfinite(result).all() or np.any(np.abs(result) > 1e12):
        raise ValueError(name + " requires finite real values with absolute magnitude <=1e12; no rows are removed")
    return result


def _input(X):
    names = None
    if type(X) not in {np.ndarray, list, tuple}:
        try:
            import pandas as pd
        except ImportError as exc:
            raise ValueError("Use dense NumPy input, or install pandas for a stock DataFrame") from exc
        if type(X) is not pd.DataFrame or any(not isinstance(dtype, np.dtype) or dtype.kind not in "iuf" for dtype in X.dtypes):
            raise ValueError("Only a stock numeric pandas DataFrame is supported; sparse, extension/custom or masked values need explicit handling")
        names = list(X.columns)
        if any(type(name) is not str or not name or len(name) > 128 or any(ord(c) < 32 for c in name) for name in names) or len(set(names)) != len(names):
            raise ValueError("DataFrame feature names must be distinct bounded printable strings")
        values = _numeric(X.to_numpy(), "X", 2)
    else:
        values = _numeric(X, "X", 2)
    if not 2 <= len(values) <= MAX_ROWS or not 1 <= values.shape[1] <= MAX_FEATURES:
        raise ValueError("X requires 2..100000 original fit rows and 1..2048 features")
    return values, names


def _fingerprint(values, names):
    digest = hashlib.sha256()
    digest.update(json.dumps({"shape": list(values.shape), "columns": names}, sort_keys=True).encode())
    digest.update(np.asarray(values, dtype="<f8").tobytes(order="C"))
    return digest.hexdigest()


def clustering_input_fingerprint(X):
    """Hash supplied ordered values/column names; cannot authenticate any fit.

    Record this alongside the actual fit outside the audit. Index/entity IDs are
    not included; identical duplicated rows cannot establish entity identity.
    The audit never emits this digest in its agent-facing report by default.
    """
    values, names = _input(X)
    return _fingerprint(values, names)


def _fit_context(context, values, names):
    if context is None:
        return False, False, None, None
    allowed = {"same_rows_and_order", "same_representation", "same_fit_configuration", "reviewer", "basis", "fit_data_sha256"}
    if type(context) is not dict or set(context) - allowed or not {"same_rows_and_order", "same_representation", "reviewer", "basis"} <= set(context):
        raise ValueError("fit_evidence needs same_rows_and_order, same_representation, reviewer and basis; unknown keys are rejected")
    for key in ("same_rows_and_order", "same_representation", "same_fit_configuration"):
        if key in context and type(context[key]) is not bool:
            raise ValueError("Fit-association declarations must be literal booleans")
    if any(type(context[k]) is not str or not context[k].strip() or len(context[k]) > 4096 for k in ("reviewer", "basis")):
        raise ValueError("fit_evidence requires a bounded nonempty reviewer and basis")
    matched = None
    if "fit_data_sha256" in context:
        supplied = context["fit_data_sha256"]
        if type(supplied) is not str or re.fullmatch(r"[0-9a-f]{64}", supplied) is None:
            raise ValueError("fit_data_sha256 must be a lowercase SHA256 hex digest recorded by the caller")
        matched = supplied == _fingerprint(values, names)
    associated = context["same_rows_and_order"] and context["same_representation"] and matched is not False
    return associated, associated and context.get("same_fit_configuration", False), matched, context


def _configuration(model, state, n):
    metric = state.get("metric")
    if type(metric) is not str or metric not in {"euclidean", "l2", "manhattan", "l1", "cityblock", "cosine", "minkowski"}:
        raise ValueError("Only explicit Euclidean/manhattan/cosine metrics (DBSCAN also Minkowski p>=1) are supported; callable/precomputed/custom metrics are never executed")
    if type(model) is AgglomerativeClustering:
        linkage = state.get("linkage")
        if type(linkage) is not str or linkage not in {"ward", "complete", "average", "single"} or metric in {"minkowski", "cityblock"}:
            raise ValueError("Unsupported agglomerative linkage/metric")
        if linkage == "ward" and metric != "euclidean":
            raise ValueError("Ward linkage requires Euclidean metric, not an arbitrary distance")
        connectivity = state.get("connectivity")
        if connectivity is None:
            connection = {"kind": "none", "nonzero_entries": None}
        elif type(connectivity) in {sparse.csr_matrix, sparse.csc_matrix, sparse.coo_matrix}:
            if connectivity.shape != (n, n) or connectivity.nnz > MAX_CELLS or connectivity.dtype.kind not in "iufb" or not np.isfinite(connectivity.data).all():
                raise ValueError("Stored sparse connectivity has an invalid/excessive shape or nonfinite values")
            # count_nonzero() can canonicalize/mutate a sparse matrix; only
            # inspect its stored structural entry count, including duplicates.
            connection = {"kind": "stock_sparse_matrix", "stored_entries_including_explicit_zeros": int(connectivity.nnz)}
        elif type(connectivity) is np.ndarray:
            matrix = _numeric(connectivity, "connectivity", 2)
            if matrix.shape != (n, n):
                raise ValueError("Connectivity shape must match the original fit rows")
            connection = {"kind": "dense_matrix", "nonzero_entries": int(np.count_nonzero(matrix))}
        else:
            raise ValueError("Callable/custom connectivity is unsupported and is never executed")
        leaves = _integer(state.get("n_leaves_"), "n_leaves_")
        k = _integer(state.get("n_clusters_"), "n_clusters_")
        if leaves != n or k > n:
            raise ValueError("Stored agglomerative leaf/cluster count does not match labels")
        return {"metric": metric, "linkage": linkage, "connectivity": connection,
                "stored_connected_components": _integer(state.get("n_connected_components_"), "n_connected_components_"),
                "parameter_provenance": "current_editable_estimator_state; not verified fit-time configuration"}, {}
    if state.get("metric_params") is not None:
        raise ValueError("DBSCAN metric_params are not supported by this bounded adapter; no custom arguments are executed")
    eps = state.get("eps")
    if type(eps) not in {float, int, np.float64, np.float32} or not math.isfinite(float(eps)) or not 0 < eps <= 1e12:
        raise ValueError("Stored DBSCAN eps must be finite and positive <=1e12")
    minimum = _integer(state.get("min_samples"), "min_samples", maximum=1_000_000_000)
    kw = {}
    p = state.get("p")
    if metric == "minkowski":
        if type(p) not in {float, int, np.float64, np.float32} or not math.isfinite(float(p)) or not 1 <= p <= 100:
            raise ValueError("Minkowski DBSCAN requires explicit finite p in [1,100]")
        kw["p"] = float(p)
    return {"metric": metric, "eps": float(eps), "min_samples": minimum,
            "minkowski_p": kw.get("p"), "fit_sample_weights": "not_recoverable; summaries unweighted",
            "parameter_provenance": "current_editable_estimator_state; not verified fit-time configuration"}, kw


def _silhouette(X, labels, *, allowed, metric, metric_kw):
    eligible = labels != -1
    available = X[eligible]
    groups = labels[eligible]
    count = min(len(groups), SILHOUETTE_LIMIT, math.isqrt(MAX_PAIRWISE_CELLS))
    # A deterministic fixed subset limits pairwise memory. Never reuse holdouts
    # to tune eps/linkage/cluster count and never drop noise without reporting it.
    chosen = np.random.default_rng(SILHOUETTE_SEED).choice(len(groups), size=count, replace=False) if count < len(groups) else np.arange(count)
    sampled = groups[chosen]
    k = len(np.unique(sampled))
    result = {"silhouette": None, "silhouette_n": 0, "silhouette_eligible_n": len(groups),
              "silhouette_requested_n": count,
              "silhouette_excluded_noise_count": int(np.sum(~eligible)), "silhouette_sample_cluster_count": k,
              "silhouette_sample_limit": SILHOUETTE_LIMIT, "silhouette_pairwise_cell_cap": MAX_PAIRWISE_CELLS,
              "silhouette_sample_seed": SILHOUETTE_SEED, "silhouette_metric": metric,
              "silhouette_status": "not_checked", "silhouette_unavailable_reason": None}
    if not allowed:
        result["silhouette_unavailable_reason"] = "Explicit fit row/representation/configuration association is unresolved or contradicted"
    elif not 2 <= k <= count - 1:
        result["silhouette_unavailable_reason"] = "Non-noise fixed sample needs 2..sample_n-1 clusters; no undefined value is replaced by zero"
    else:
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                value = float(silhouette_score(available[chosen], sampled, metric=metric, **metric_kw))
            if caught or not math.isfinite(value) or not -1 <= value <= 1:
                result["silhouette_unavailable_reason"] = "Native silhouette emitted a numerical warning or nonfinite/out-of-range value"
            else:
                result.update(silhouette=value, silhouette_n=count, silhouette_status="computed")
        except (ValueError, FloatingPointError, OverflowError):
            result["silhouette_unavailable_reason"] = "Native silhouette was undefined/unstable for the supplied representation and declared metric"
    return result


def _visuals(X, labels, ids, counts, *, associated, core_n, detail, split):
    n, p = X.shape
    limits = list(_LIMITS)
    panels = []
    if len(ids) <= 32:
        panels.append(visuals._panel("cluster_sizes", "Stored fit cluster and noise sizes", "bars", n, split,
            {"labels": ["noise (-1)" if i == -1 else "cluster " + str(i) for i in ids], "values": counts},
            role="main_result", units="observations (counts)", comparison="Stored fitted labels; counts sum to all original fit rows including DBSCAN noise",
            interpretation="These are original-fit assignment counts, not predictions for new rows, true classes or stability evidence.", limitations=limits))
    else:
        panels.append(visuals.status_panel("cluster_sizes", "Stored fit cluster and noise sizes", n=n, source_split=split,
            role="main_result", message="More than 32 assignment categories exceed the bounded figure; full counts remain in the report table, without silently merging clusters.", limitations=limits))
    if core_n is not None:
        nonnoise = int(np.sum(labels != -1))
        panels.append(visuals._panel("density_roles", "Stored DBSCAN core, border and noise counts", "bars", n, split,
            {"labels": ["core", "border", "noise (-1)"], "values": [core_n, nonnoise-core_n, n-nonnoise]},
            role="descriptive", units="observations (counts)", comparison="Stored core indices versus stored non-noise labels; denominator includes every fitted row",
            interpretation="Core/border/noise are algorithmic roles at the original fit settings, not verified scientific outlier labels.", limitations=limits))
    if associated and p >= 2:
        panels.append(visuals.histogram2d_panel("cluster_geometry", "Original fit representation: first two input positions", X[:, 0], X[:, 1],
            role="descriptive", requirement="distance_geometry", source_split=split, units="observations per count cell",
            comparison="All caller-attested original rows, including noise; no new projection is fitted", bins=12,
            interpretation="This bounded coordinate projection is conditional on the caller's fit association and can conceal higher-dimensional structure.",
            limitations=limits, axes={"x": "Fitted input position 1 (original supplied units)", "y": "Fitted input position 2 (original supplied units)"}))
    else:
        panels.append(visuals.status_panel("cluster_geometry", "Original fit representation geometry", n=n, source_split=split,
            message="Paired fit representation is unresolved/contradicted, or only one input dimension is available; no second coordinate or association is invented.",
            requirement="fit_association", limitations=limits))
    if detail["silhouette"] is not None:
        panels.append(visuals._panel("cluster_silhouette", "Conditional non-noise internal silhouette", "bars", detail["silhouette_n"], split,
            {"labels": ["mean silhouette"], "values": [detail["silhouette"]]}, role="diagnostic", requirement="cluster_stability",
            units="dimensionless silhouette [-1,1]", comparison="Native metric on a fixed bounded subset; excludes all DBSCAN noise; subset n shown",
            threshold="No universal adequacy threshold; silhouette is not a stability test",
            interpretation="This summarizes within-versus-nearest-other-group distances among selected non-noise rows. It does not prove natural classes or stable clusters.", limitations=limits))
    else:
        panels.append(visuals.status_panel("cluster_silhouette", "Conditional non-noise internal silhouette", n=n, source_split=split,
            message=detail["silhouette_unavailable_reason"], requirement="cluster_stability", limitations=limits))
    payload = {"schema_version": visuals.SCHEMA_VERSION, "source_split": split, "n": n, "privacy": visuals.PRIVACY, "panels": panels}
    visuals.validate_visual_evidence(payload)
    return payload


def audit_fitted_clustering(model, X, *, purpose="clustering", metadata=None, attestations=None,
                            split_role="training", fit_evidence=None):
    """Audit stock fitted AgglomerativeClustering/DBSCAN on their original rows.

    ``fit_evidence`` explicitly declares same_rows_and_order/same_representation
    and reviewer/basis. Optional same_fit_configuration=True also permits a
    conditional native-metric silhouette. Optional fit_data_sha256 must match a
    caller-recorded input digest, but cannot authenticate a fit or entity IDs.
    Missing evidence leaves paired geometry and silhouette not checked.
    """
    if type(model) not in {AgglomerativeClustering, DBSCAN}:
        raise ValueError("Only exact stock fitted AgglomerativeClustering/DBSCAN are supported; Pipelines/custom estimators need a verified adapter")
    if type(purpose) is not str or type(split_role) is not str or purpose != "clustering" or split_role not in {"training", "unknown"}:
        raise ValueError("These fit-label audits require purpose='clustering' and training/unknown original-fit rows; no held-out/new-row assignment is implemented")
    if metadata is not None and type(metadata) is not dict:
        raise ValueError("metadata must be a plain mapping of the standard common audit fields")
    if attestations is not None and type(attestations) is not dict:
        raise ValueError("attestations must be a plain requirement mapping")
    values, names = _input(X)
    n, p = values.shape
    state = vars(model)
    fitted_p = _integer(state.get("n_features_in_"), "n_features_in_", MAX_FEATURES)
    if p != fitted_p:
        raise ValueError("Input feature count differs from the fitted representation")
    fitted_names = state.get("feature_names_in_")
    if fitted_names is not None:
        if (type(fitted_names) is not np.ndarray or fitted_names.ndim != 1 or fitted_names.dtype.kind not in "OU" or
                any(type(item) not in {str, np.str_} for item in fitted_names) or names is None or list(fitted_names) != names):
            raise ValueError("Supply the original named feature representation in exactly the stored feature order")
    raw_labels = _numeric(state.get("labels_"), "stored labels_", 1)
    if len(raw_labels) != n or np.any(raw_labels != np.floor(raw_labels)) or np.any(raw_labels < (-1 if type(model) is DBSCAN else 0)):
        raise ValueError("Stored labels must be integer assignments matching all original fit rows; DBSCAN noise is -1")
    labels = raw_labels.astype(np.int64)
    if np.any(labels >= n):
        raise ValueError("Stored cluster labels exceed the bounded original-row range")
    ids_array, counts_array = np.unique(labels, return_counts=True)
    ids, counts = ids_array.tolist(), counts_array.tolist()
    if len(ids) > 2048:
        raise ValueError("More than 2048 assignment categories exceed the bounded report; no cluster counts are silently dropped")
    method = "hierarchical_clustering" if type(model) is AgglomerativeClustering else "dbscan"
    configuration, metric_kw = _configuration(model, state, n)
    k = len([i for i in ids if i != -1])
    if [i for i in ids if i != -1] != list(range(k)):
        raise ValueError("Stored stock-estimator labels must use contiguous nonnegative cluster IDs, with DBSCAN noise -1")
    if type(model) is AgglomerativeClustering and state["n_clusters_"] != k:
        raise ValueError("Stored agglomerative n_clusters_ contradicts stored labels")
    associated, configured, hash_match, context = _fit_context(fit_evidence, values, names)
    core_n, core_match = None, None
    if type(model) is DBSCAN:
        core = _numeric(state.get("core_sample_indices_"), "stored core_sample_indices_", 1)
        if np.any(core != np.floor(core)) or np.any(core < 0) or np.any(core >= n) or len(np.unique(core)) != len(core):
            raise ValueError("Stored DBSCAN core indices must be unique in-range original-fit row positions")
        core = core.astype(int)
        components = _numeric(state.get("components_"), "stored components_", 2)
        if components.shape != (len(core), p) or np.any(labels[core] == -1):
            raise ValueError("Stored DBSCAN core components/labels have contradictory shapes or noise membership")
        core_n = len(core)
        core_match = bool(np.array_equal(values[core], components))
        associated = associated and core_match
        configured = configured and core_match
    rows = _common(values, None, metadata)
    observed = {"supplied_rows": n, "stored_label_rows": len(labels), "feature_count": p,
                "caller_fingerprint_matches_supplied_values": hash_match, "stored_dbscan_core_rows_match": core_match,
                "paired_geometry_permitted_conditionally": associated, "native_metric_silhouette_permitted_conditionally": configured}
    contradicted = hash_match is False or core_match is False
    rows.append(evidence("fit_association", "fail" if contradicted else "not_checked",
        "Original-fit row/representation association; equal shape or matching core rows cannot certify all fit rows",
        observed=observed, sample_size=n, limitations=[_LIMITS[1],
            "A stored DBSCAN core-row match covers only core positions; border/noise identity and entity order remain unverified.",
            "Fingerprints exclude entity IDs; matching values and shapes do not authenticate fit association."],
        remedies=["Supply the original ordered representation and independent fit records; use explicit fit_evidence without claiming authentication."]))
    if context is not None:
        if attestations is not None and "fit_association" in attestations:
            raise ValueError("Use a single fit_association declaration via fit_evidence; do not supply a duplicate attestation")
        rows.append(evidence("fit_association", "no_issue_detected" if associated else "fail", "Caller attests original ordered rows and representation; assertion, not proof", source="human",
            observed={"same_rows_and_order": context["same_rows_and_order"], "same_representation": context["same_representation"],
                      "same_fit_configuration": context.get("same_fit_configuration", False)},
            sample_size=n, limitations=[_LIMITS[1], _LIMITS[2]],
            provenance={"reviewer": context["reviewer"], "basis": context["basis"]}))
    rows.append(evidence("distance_geometry", "not_checked", "Current metric/linkage/density configuration; suitability and scaling require human justification",
        observed=configuration, sample_size=n, thresholds={"universal_adequacy_threshold": None}, limitations=[_LIMITS[2], _LIMITS[3]],
        remedies=["Review measurement units, distance geometry, linkage/connectivity or eps/min_samples using training-only evidence; any changed fit is a separate action."]))
    detail = _silhouette(values, labels, allowed=configured, metric=configuration["metric"], metric_kw=metric_kw)
    rows.append(evidence("cluster_stability", "not_checked", "Conditional bounded internal silhouette; no resampling/external stability assessment",
        observed=detail, sample_size=n, thresholds={"silhouette_range": [-1, 1], "adequacy_cutoff": None, "pairwise_cell_cap": MAX_PAIRWISE_CELLS},
        limitations=["Noise exclusion changes the target subset. Fixed sampling can omit rare clusters; undefined comparisons remain unavailable.",
                     "Silhouette describes distance separation and favors some geometries; it does not test cluster stability or true natural classes."],
        remedies=["Use prespecified domain review and resampling/external stability evidence; do not tune clustering on an untouched final evaluation set."],
        provenance={"implementation": "clustering-audits", "primary_source": SOURCES["silhouette"]}))
    noise_n = int(np.sum(labels == -1))
    estimates = {"adapter_status": "supported_fit_association_audit", "adapter": {
        "estimator_type": type(model).__name__, "sklearn_version": sklearn.__version__, "source_split": split_role,
        "model_refit": False, "new_row_assignment": False, "raw_records_retained": False,
        "feature_alignment": "stored named order checked" if fitted_names is not None else "positional; original meaning not recovered",
        "row_alignment": "caller-attested conditional association" if associated else "unresolved or contradicted",
        "preprocessing_owner": "caller supplies original fit representation; no transform, scaling or repair performed",
        "primary_source": SOURCES[method]}, "fitted_cluster_count": k,
        "supplied_cluster_ids": ids, "supplied_cluster_sizes": counts,
        "noise_count": noise_n, "noise_fraction": noise_n/n, "core_count": core_n,
        "configuration": configuration, **detail}
    estimates["visual_evidence"] = _visuals(values, labels, ids, counts, associated=associated, core_n=core_n, detail=detail, split=split_role)
    return make_report(method, purpose, _complete(method, purpose, rows, attestations),
                       {"n": n, "p": p, "training_n": n}, estimates, list(_LIMITS))
