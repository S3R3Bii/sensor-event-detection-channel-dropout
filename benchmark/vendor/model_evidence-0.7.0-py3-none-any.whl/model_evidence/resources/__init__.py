"""Copies of the canonical shared versioned contracts."""
