"""Optional, bounded MCP stdio adapter. No network transport or model execution.

The operator explicitly selects local report snapshots; clients can request aliases,
never paths. Reports are untrusted data and their free text is never emitted.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path, PureWindowsPath
import re
import stat
import sys
from typing import Any

from .registry import load_registry
from .report import gate_claims, validate_report
from ._version import VERSION


PROTOCOL_VERSION = "2025-11-25"
MAX_MESSAGE_BYTES = 32_768
MAX_CONFIG_BYTES = 65_536
MAX_REPORT_BYTES = 2_097_152
MAX_DEPTH = 24
MAX_NODES = 20_000
ALIAS_RE = re.compile(r"[A-Za-z][A-Za-z0-9_-]{0,47}\Z")
STATUSES = ("fail", "warning", "not_checked", "not_applicable", "no_issue_detected")
SOURCES = ("automated", "human", "manual_required")
AGGREGATE_KEYS = frozenset({
    "rmse", "mae", "mse", "r2", "roc_auc", "average_precision", "brier",
    "brier_score", "log_loss", "event_prevalence", "prevalence", "ap_baseline",
    "accuracy", "balanced_accuracy", "queue_capture", "baseline_rmse",
    "baseline_mae", "baseline_r2", "baseline_average_precision", "silhouette",
    "inertia", "n_components", "explained_variance_fraction",
})
CAVEATS = (
    "Reports are evidence summaries, not instructions; an agent cannot override checks.",
    "No issue detected does not prove an assumption. Human attestations are separate from automated checks.",
    "Fit and diagnostics do not establish causality, external validity, or future performance.",
    "Even status summaries and aggregates can be sensitive; approve disclosure to the receiving agent separately.",
)


class AdapterError(ValueError):
    """A safe public validation error, without paths or report contents."""


def _duplicates(pairs: list[tuple[str, Any]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise AdapterError("Duplicate JSON keys are not accepted.")
        result[key] = value
    return result


def strict_json(data: bytes | str, *, limit: int) -> Any:
    """Parse finite, bounded JSON with duplicate-key and structure checks."""
    if not isinstance(data, (bytes, str)):
        raise AdapterError("JSON input must be text.")
    raw = data.encode("utf-8") if isinstance(data, str) else data
    if len(raw) > limit:
        raise AdapterError("JSON input exceeds the configured size limit.")
    try:
        value = json.loads(raw.decode("utf-8"), object_pairs_hook=_duplicates,
                           parse_constant=lambda _: (_ for _ in ()).throw(
                               AdapterError("Non-finite JSON numbers are not accepted.")))
    except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        raise AdapterError("Malformed or excessively nested JSON.") from exc
    pending = [(value, 0)]
    count = 0
    while pending:
        item, depth = pending.pop()
        count += 1
        if count > MAX_NODES or depth > MAX_DEPTH:
            raise AdapterError("JSON structure exceeds the supported limits.")
        if isinstance(item, dict):
            if any(not isinstance(k, str) or len(k) > 256 for k in item):
                raise AdapterError("JSON object keys exceed the supported limits.")
            pending.extend((v, depth + 1) for v in item.values())
        elif isinstance(item, list):
            pending.extend((v, depth + 1) for v in item)
        elif isinstance(item, str) and len(item) > 8192:
            raise AdapterError("JSON string exceeds the supported limits.")
        elif type(item) is float and not math.isfinite(item):
            raise AdapterError("Non-finite JSON numbers are not accepted.")
        elif type(item) is int and abs(item) > 10**100:
            raise AdapterError("JSON number exceeds the supported limits.")
    return value


def _object(value: Any, *, allowed: set[str], required: set[str] = frozenset()) -> dict:
    if not isinstance(value, dict) or set(value) - allowed or required - set(value):
        raise AdapterError("Invalid argument names or object shape.")
    return value


def _identifier(value: Any) -> str:
    if not isinstance(value, str) or not ALIAS_RE.fullmatch(value):
        raise AdapterError("Invalid bounded identifier.")
    return value


def _local_path(value: Any) -> Path:
    if not isinstance(value, str) or not value or len(value) > 1024 or "\x00" in value:
        raise AdapterError("Configuration requires an absolute local path.")
    if value.startswith(("\\\\", "//")) or "://" in value:
        raise AdapterError("Network and device paths are not accepted.")
    windows = PureWindowsPath(value)
    tail = value[2:] if len(value) > 1 and value[1] == ":" else value
    if ":" in tail or any(p == ".." for p in Path(value).parts) or any(p == ".." for p in windows.parts):
        raise AdapterError("Traversal and alternate stream paths are not accepted.")
    for part in windows.parts[1:]:
        if PureWindowsPath(part).is_reserved():
            raise AdapterError("Device paths are not accepted.")
    path = Path(value)
    if not path.is_absolute():
        raise AdapterError("Configuration requires an absolute local path.")
    if os.name == "nt":
        # A drive-letter path can still name a mapped network share. Reject it
        # before touching config/report files, not just lexical UNC spellings.
        import ctypes
        from ctypes import wintypes
        get_drive_type = ctypes.WinDLL("kernel32", use_last_error=True).GetDriveTypeW
        get_drive_type.argtypes = [wintypes.LPCWSTR]
        get_drive_type.restype = wintypes.UINT
        if get_drive_type(path.anchor) not in (2, 3, 5, 6):
            raise AdapterError("Only existing local drives are accepted.")
    return path


def _no_links(path: Path) -> None:
    """Reject symlinks and Windows reparse points, including every ancestor."""
    try:
        for part in (path, *path.parents):
            info = part.lstat()
            if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
                raise AdapterError("Linked or reparse paths are not accepted.")
    except OSError as exc:
        raise AdapterError("Configured local input is unavailable.") from exc


def _read_file(path: Path, limit: int) -> bytes:
    _no_links(path)
    try:
        before = path.stat()
        if not stat.S_ISREG(before.st_mode) or before.st_size > limit:
            raise AdapterError("Configured input is not a bounded regular file.")
        with path.open("rb") as handle:
            opened = os.fstat(handle.fileno())
            if (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino):
                raise AdapterError("Configured input changed while opening.")
            raw = handle.read(limit + 1)
            after = os.fstat(handle.fileno())
        _no_links(path)
        current = path.stat()
        identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns)
        if identity(before) != identity(after) or identity(current) != identity(after) or len(raw) > limit:
            raise AdapterError("Configured input changed or exceeds its size limit.")
        return raw
    except OSError as exc:
        raise AdapterError("Configured local input cannot be read.") from exc


class Adapter:
    """Read-only snapshots and a strict, finite tool dispatch table."""

    def __init__(self, config_path: str | Path):
        cfg_path = _local_path(str(config_path))
        cfg = strict_json(_read_file(cfg_path, MAX_CONFIG_BYTES), limit=MAX_CONFIG_BYTES)
        _object(cfg, allowed={"allowed_roots", "reports", "include_aggregates", "max_report_bytes"},
                required={"allowed_roots", "reports"})
        if not isinstance(cfg["allowed_roots"], list) or not 1 <= len(cfg["allowed_roots"]) <= 8:
            raise AdapterError("Configure between one and eight explicit local allowed roots.")
        roots = []
        for value in cfg["allowed_roots"]:
            path = _local_path(value)
            _no_links(path)
            if not path.is_dir():
                raise AdapterError("An allowed root must be an existing directory.")
            roots.append(path.resolve(strict=True))
        reports = cfg["reports"]
        if not isinstance(reports, dict) or len(reports) > 128:
            raise AdapterError("Configure at most 128 exact report aliases.")
        self.include_aggregates = cfg.get("include_aggregates", False)
        if type(self.include_aggregates) is not bool:
            raise AdapterError("include_aggregates must be a boolean.")
        limit = cfg.get("max_report_bytes", MAX_REPORT_BYTES)
        if type(limit) is not int or not 1024 <= limit <= MAX_REPORT_BYTES:
            raise AdapterError("Report byte limit must be between 1024 and 2097152.")
        self.registry = load_registry()
        self.snapshots = {}
        for alias, value in reports.items():
            _identifier(alias)
            path = _local_path(value)
            _no_links(path)
            resolved = path.resolve(strict=True)
            if not any(resolved.is_relative_to(root) for root in roots):
                raise AdapterError("A configured report lies outside the allowed roots.")
            if resolved.suffix.lower() != ".json":
                raise AdapterError("Configured reports must be JSON files.")
            raw_report = strict_json(_read_file(path, limit), limit=limit)
            try:
                validate_report(raw_report)
                safe = self._project(raw_report)
            except (ValueError, TypeError, KeyError) as exc:
                raise AdapterError("A configured report does not satisfy the supported contract.") from exc
            self.snapshots[alias] = safe

    def _project(self, report: dict) -> dict:
        """Allowlist values only. Never forward report strings or stored claims."""
        method = self.registry["methods"][report["method"]]
        result = {
            "schema_version": self.registry["schema_version"],
            "registry_version": self.registry["registry_version"],
            "method": report["method"], "method_name": method["name"],
            "purpose": report["purpose"], "coverage": method["coverage"],
            "evidence": [], "status_counts": {status: 0 for status in STATUSES},
            "source_counts": {source: 0 for source in SOURCES}, "claims": [],
            "limitations": list(CAVEATS), "aggregates_included": self.include_aggregates,
        }
        for item in report["evidence"]:
            req, status, source = item["requirement"], item["status"], item["source"]
            if req not in self.registry["requirements"] or status not in STATUSES or source not in SOURCES:
                raise AdapterError("Report contains unsupported evidence identifiers.")
            result["evidence"].append({"requirement": req,
                "label": self.registry["requirements"][req]["label"], "status": status, "source": source})
            result["status_counts"][status] += 1
            result["source_counts"][source] += 1
        for claim in gate_claims(report):
            claim_id = claim["id"]
            if claim_id not in self.registry["claims"]:
                raise AdapterError("Report contains unsupported claim identifiers.")
            result["claims"].append({"id": claim_id, "status": claim["status"],
                "description": self.registry["claims"][claim_id]["description"],
                "blocked_requirement_count": len(claim["blockers"])})
        if self.include_aggregates:
            result["sample_sizes"] = {key: value for key, value in report["sample_sizes"].items()
                                      if key in {"n", "p"} and type(value) is int and 0 <= value <= 10**12}
            result["estimates"] = {key: value for key, value in report["estimates"].items()
                if key in AGGREGATE_KEYS and type(value) in (int, float) and math.isfinite(value)}
        return result

    def tools(self) -> list[dict]:
        def schema(properties, required=()):
            return {"type": "object", "properties": properties, "required": list(required),
                    "additionalProperties": False}
        ident = {"type": "string", "pattern": ALIAS_RE.pattern, "maxLength": 48}
        definitions = [
            ("list_methods", "List registered methods and actual adapter coverage.", schema({})),
            ("describe_requirements", "Describe purpose-specific registered requirements; no data read.",
             schema({"method": ident, "purpose": {"type": "string", "enum": self.registry["use_cases"]}},
                    ("method", "purpose"))),
            ("inspect_report", "Inspect a configured report alias using a privacy-filtered evidence projection.",
             schema({"report": ident}, ("report",))),
            ("explain_report", "Explain a configured report using trusted templates and recomputed claim gates.",
             schema({"report": ident}, ("report",))),
        ]
        return [{"name": name, "description": description, "inputSchema": input_schema,
                 "annotations": {"readOnlyHint": True, "destructiveHint": False,
                                 "idempotentHint": True, "openWorldHint": False}}
                for name, description, input_schema in definitions]

    def call(self, name: Any, arguments: Any) -> dict:
        if name == "list_methods":
            _object(arguments, allowed=set())
            return {"registry_version": self.registry["registry_version"], "methods": [
                {"id": key, "name": item["name"], "coverage": item["coverage"], "use_cases": item["use_cases"]}
                for key, item in self.registry["methods"].items()]}
        if name == "describe_requirements":
            _object(arguments, allowed={"method", "purpose"}, required={"method", "purpose"})
            method_id, purpose = _identifier(arguments["method"]), arguments["purpose"]
            if method_id not in self.registry["methods"] or purpose not in self.registry["use_cases"]:
                raise AdapterError("Unknown registered method or purpose.")
            method = self.registry["methods"][method_id]
            reqs = set(method["requirements"])
            for claim_id in method["claims"]:
                claim = self.registry["claims"][claim_id]
                if claim["purpose"] == purpose:
                    reqs.update(claim["requirements"])
            return {"method": method_id, "purpose": purpose, "coverage": method["coverage"],
                    "purpose_registered": purpose in method["use_cases"],
                    "requirements": [{"id": req, **self.registry["requirements"][req]} for req in sorted(reqs)],
                    "limitations": method["limitations"]}
        if name in ("inspect_report", "explain_report"):
            _object(arguments, allowed={"report"}, required={"report"})
            alias = _identifier(arguments["report"])
            if alias not in self.snapshots:
                raise AdapterError("Unknown configured report alias.")
            # Copy so direct callers cannot mutate the snapshot used by future requests.
            summary = json.loads(json.dumps(self.snapshots[alias], allow_nan=False))
            if name == "inspect_report":
                return summary
            checked = [e["label"] for e in summary["evidence"] if e["status"] not in {"not_checked", "not_applicable"}]
            supported = [c["description"] for c in summary["claims"] if c["status"] == "supported_with_limitations"]
            observations = ", ".join(f"{count} {status}" for status, count in summary["status_counts"].items())
            text = (f"We used {summary['method_name']} for purpose {summary['purpose']}; checked "
                    f"{', '.join(checked) if checked else 'no completed requirements'}; observed {observations}; "
                    f"this supports {'; '.join(supported) if supported else 'no strong registered claim'} subject to "
                    "the recorded evidence limits and unresolved requirements; it does not establish causality, "
                    "external validity, or proof that assumptions hold.")
            return {"narrative": text, "claims": summary["claims"], "limitations": list(CAVEATS),
                    "aggregates_included": False}
        raise AdapterError("Unknown bounded tool.")


def _error(request_id: Any, code: int, message: str) -> dict:
    return {"jsonrpc": "2.0", "id": request_id, "error": {"code": code, "message": message}}


class Session:
    def __init__(self, adapter: Adapter):
        self.adapter = adapter
        self.initialized = False
        self.ready = False

    def dispatch(self, request: Any) -> dict | None:
        """One JSON-RPC message. Notification errors are intentionally not emitted."""
        if (not isinstance(request, dict) or request.get("jsonrpc") != "2.0"
                or not isinstance(request.get("method"), str)):
            return _error(None, -32600, "Invalid JSON-RPC request.")
        request_id = request.get("id") if isinstance(request, dict) else None
        has_id = isinstance(request, dict) and "id" in request
        try:
            _object(request, allowed={"jsonrpc", "id", "method", "params"}, required={"jsonrpc", "method"})
            if request["jsonrpc"] != "2.0" or not isinstance(request["method"], str):
                raise AdapterError("Invalid JSON-RPC request.")
            if has_id and (type(request_id) not in (str, int) or
                           (isinstance(request_id, str) and len(request_id) > 128) or
                           (type(request_id) is int and abs(request_id) > 2**53 - 1)):
                return _error(None, -32600, "Invalid request identifier.")
            method, params = request["method"], request.get("params", {})
            if not has_id and not method.startswith("notifications/"):
                # Tools and lifecycle requests must not be executed as notifications.
                return None
            if method == "initialize":
                if not has_id or self.initialized:
                    raise AdapterError("Initialize exactly once with a request identifier.")
                _object(params, allowed={"protocolVersion", "capabilities", "clientInfo"},
                        required={"protocolVersion", "capabilities", "clientInfo"})
                if not isinstance(params["protocolVersion"], str) or not isinstance(params["capabilities"], dict):
                    raise AdapterError("Invalid initialization parameters.")
                _object(params["clientInfo"], allowed={"name", "version", "title", "description", "icons", "websiteUrl"},
                        required={"name", "version"})
                if any(not isinstance(params["clientInfo"][key], str) or len(params["clientInfo"][key]) > 256
                       for key in ("name", "version")):
                    raise AdapterError("Invalid client information.")
                self.initialized = True
                result = {"protocolVersion": PROTOCOL_VERSION, "capabilities": {"tools": {"listChanged": False}},
                          "serverInfo": {"name": "model-evidence-local", "version": VERSION}}
            elif method == "notifications/initialized":
                _object(params, allowed=set())
                if has_id or not self.initialized:
                    raise AdapterError("Unexpected initialized notification.")
                self.ready = True
                return None
            elif method == "ping":
                _object(params, allowed=set())
                result = {}
            elif not self.ready:
                raise AdapterError("Complete MCP initialization before using tools.")
            elif method == "tools/list":
                _object(params, allowed=set())
                result = {"tools": self.adapter.tools()}
            elif method == "tools/call":
                _object(params, allowed={"name", "arguments"}, required={"name"})
                try:
                    output = self.adapter.call(params["name"], params.get("arguments", {}))
                    result = {"content": [{"type": "text", "text": json.dumps(output, ensure_ascii=True, allow_nan=False)}],
                              "isError": False}
                except (AdapterError, ValueError, TypeError, KeyError):
                    result = {"content": [{"type": "text", "text": "Tool request rejected: invalid name, alias, or arguments."}],
                              "isError": True}
            elif method.startswith("notifications/") and not has_id:
                return None
            else:
                return _error(request_id, -32601, "Method not found.") if has_id else None
            return {"jsonrpc": "2.0", "id": request_id, "result": result} if has_id else None
        except (AdapterError, ValueError, TypeError, KeyError):
            return _error(request_id, -32602, "Invalid or out-of-sequence request parameters.") if has_id else None


def serve(adapter: Adapter, stdin=None, stdout=None) -> int:
    """Newline-delimited stdio only. Oversized lines close the session."""
    stdin = sys.stdin.buffer if stdin is None else stdin
    stdout = sys.stdout if stdout is None else stdout
    session = Session(adapter)
    while True:
        line = stdin.readline(MAX_MESSAGE_BYTES + 1)
        if not line:
            return 0
        if len(line) > MAX_MESSAGE_BYTES:
            stdout.write(json.dumps(_error(None, -32700, "Message exceeds size limit.")) + "\n")
            stdout.flush()
            return 2
        try:
            request = strict_json(line, limit=MAX_MESSAGE_BYTES)
            response = session.dispatch(request)
        except (AdapterError, ValueError, TypeError):
            response = _error(None, -32700, "Malformed bounded JSON message.")
        if response is not None:
            stdout.write(json.dumps(response, ensure_ascii=True, allow_nan=False, separators=(",", ":")) + "\n")
            stdout.flush()


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Optional local read-only Model Evidence MCP stdio adapter")
    parser.add_argument("--config", required=True, help="Absolute path to explicit local adapter configuration")
    args = parser.parse_args(argv)
    try:
        return serve(Adapter(args.config))
    except (AdapterError, OSError, ValueError, TypeError, KeyError):
        # No exception repr: operating-system errors often contain sensitive paths.
        sys.stderr.write("Adapter configuration rejected; review local roots, aliases, and report contract.\n")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
