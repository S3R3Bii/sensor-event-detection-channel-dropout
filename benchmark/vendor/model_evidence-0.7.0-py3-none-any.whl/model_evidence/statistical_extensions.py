"""Two prespecified, bounded comparisons; numerical results do not verify design.

Welch ANOVA uses the optional statsmodels backend. Exact McNemar uses only
the off-diagonal paired counts and SciPy's two-sided binomial reference.
Neither procedure silently changes tests, deletes observations or repairs data.
"""
import math
from numbers import Real
import warnings

import numpy as np
import scipy
from scipy import stats


METHODS = {"welch_anova", "mcnemar_exact"}
MAX_GROUPS = 32
MAX_GROUP_N = 1_000_000
MAX_TOTAL_N = 2_000_000
MAX_ABS = 1e40
BASE_LIMITATIONS = [
    "A computed statistic and p-value are conditional on the caller-selected design and reference assumptions; they do not verify those assumptions.",
    "These comparisons do not establish causation, external validity, equivalence, absence of a meaningful effect or the probability that the null is true.",
    "No normality pretest, automatic test switch, multiplicity correction, missing-value deletion, data repair or model refit is performed.",
    "Only aggregate summaries are returned; paired counts and group summaries can still be sensitive.",
]


def _scalar(value, name):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, Real):
        raise ValueError(name + " must be a bounded finite real scalar")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(name + " must be a bounded finite real scalar") from exc
    if not math.isfinite(result) or abs(result) > MAX_ABS:
        raise ValueError(name + " must be a bounded finite real scalar")
    return result


def _no_mask(value, name):
    if np.ma.isMaskedArray(value) and np.ma.getmaskarray(value).any():
        raise ValueError(name + " contains masked values; no observations are omitted")


def _sample(value, name):
    _no_mask(value, name)
    index = getattr(value, "index", None)
    if callable(getattr(index, "equals", None)) and not index.is_unique:
        raise ValueError(name + " has duplicate named row indexes; resolve the analysis grain explicitly")
    if isinstance(value, (list, tuple)):
        if not 1 <= len(value) <= MAX_GROUP_N:
            raise ValueError(name + " must be a nonempty bounded one-dimensional sample")
        if any(isinstance(item, (bool, np.bool_)) for item in value):
            raise ValueError(name + " cannot contain boolean observations")
    try:
        raw = np.asarray(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(name + " must be a finite real one-dimensional sample") from exc
    if raw.ndim != 1 or not 1 <= raw.size <= MAX_GROUP_N:
        raise ValueError(name + " must be a nonempty bounded one-dimensional sample")
    if raw.dtype.kind not in "iuf" or (raw.dtype.kind == "f" and raw.dtype.itemsize > 8):
        raise ValueError(name + " must contain real numeric values without object, string or boolean coercion")
    if not np.isfinite(raw).all() or np.any(np.abs(raw.astype(float)) > MAX_ABS):
        raise ValueError(name + " must contain bounded finite values; missing observations are not removed")
    return np.array(raw, dtype=float, copy=True)


def _table(value):
    _no_mask(value, "paired table")
    # Counts carry a fixed binary orientation. Named reversed/ambiguous axes must
    # be resolved explicitly rather than relabeled or reordered behind the caller.
    for key in ("index", "columns"):
        axis = getattr(value, key, None)
        if callable(getattr(axis, "tolist", None)):
            labels = axis.tolist()
            if (len(labels) != 2 or any(isinstance(v, (bool, np.bool_)) or
                    not isinstance(v, (int, np.integer)) for v in labels) or labels != [0, 1]):
                raise ValueError("Named paired-table axes must be ordered integer categories [0, 1]; no automatic reordering")
    if isinstance(value, (list, tuple)):
        if len(value) != 2 or any(not isinstance(row, (list, tuple, np.ndarray)) or
                                 (isinstance(row, np.ndarray) and row.ndim == 0) or
                                 len(row) != 2 for row in value):
            raise ValueError("mcnemar_exact requires exactly one 2-by-2 paired count table")
        if any(isinstance(cell, (bool, np.bool_)) for row in value for cell in row):
            raise ValueError("Paired counts cannot contain booleans")
        for row in value:
            _no_mask(row, "paired table row")
    try:
        raw = np.asarray(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("mcnemar_exact requires a finite numeric 2-by-2 paired count table") from exc
    if raw.shape != (2, 2) or raw.dtype.kind not in "iuf":
        raise ValueError("mcnemar_exact requires a real numeric 2-by-2 paired count table")
    if (raw.dtype.kind == "f" and raw.dtype.itemsize > 8) or not np.isfinite(raw).all():
        raise ValueError("Paired counts must be finite exact integers at the supported precision")
    if np.any(raw < 0) or np.any(raw > MAX_TOTAL_N) or np.any(raw != np.floor(raw)):
        raise ValueError("Paired counts must be nonnegative exact integers within the bounded total")
    table = np.array(raw, dtype=np.int64, copy=True)
    if int(table.sum()) > MAX_TOTAL_N:
        raise ValueError("Total paired observations exceed the bounded size")
    return table


def _finite(value):
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError):
        return None
    return result if math.isfinite(result) and abs(result) <= 1e100 else None


def _base(method, confidence):
    return {"sample_sizes": {}, "statistical_test": {
        "procedure": method, "computational_status": "not_computable",
        "statistic_name": "F" if method == "welch_anova" else "minimum_discordant_count",
        "statistic": None, "p_value": None, "degrees_of_freedom": None,
        "alternative": "two-sided", "null": {"parameter": None, "value": None},
        "effect": {"name": "not_implemented", "estimate": None,
                   "units": "outcome units (not supplied)", "confidence_interval": None},
        "groups": [], "configuration": {
            "confidence_level": confidence, "nan_policy": "raise",
            "test_selection": "caller-specified; no normality or variance pretest",
            "multiplicity_adjustment": "none", "scipy_version": scipy.__version__,
            "null_value_argument_role": "default-zero sentinel; this procedure has a fixed scientific null",
        }, "warnings": [], "limitations": list(BASE_LIMITATIONS)}}


def _not_computable(output, reason):
    test = output["statistical_test"]
    test.update(computational_status="not_computable", statistic=None, p_value=None)
    test["warnings"].append(reason)
    return output


def _load_welch_backend():
    try:
        import statsmodels
        from statsmodels.stats.oneway import anova_oneway
    except ImportError as exc:
        raise ValueError("welch_anova requires the optional statsmodels dependency; install model-evidence[statsmodels] (tested statsmodels 0.14.6). No alternate test was substituted.") from exc
    return anova_oneway, statsmodels.__version__


def _welch(x, confidence):
    _no_mask(x, "Welch groups")
    if (not isinstance(x, (list, tuple, np.ndarray)) or
            (isinstance(x, np.ndarray) and x.ndim == 0) or not 2 <= len(x) <= MAX_GROUPS):
        raise ValueError("welch_anova requires x as a sequence of 2 to 32 independent numeric groups")
    samples = []
    total = 0
    for i, value in enumerate(x):
        sample = _sample(value, "group_" + str(i + 1))
        total += len(sample)
        if total > MAX_TOTAL_N:
            raise ValueError("Total Welch ANOVA observations exceed the bounded size")
        samples.append(sample)
    groups = [{"label": "group_" + str(i + 1), "n": len(sample),
               "mean": float(np.mean(sample)),
               "variance": float(np.var(sample, ddof=1)) if len(sample) > 1 else None}
              for i, sample in enumerate(samples)]
    output = _base("welch_anova", confidence)
    test = output["statistical_test"]
    output["sample_sizes"] = {"n": total, "groups": len(samples),
                              **{"n_group_" + str(i + 1): len(v) for i, v in enumerate(samples)}}
    test["groups"] = groups
    test["null"] = {"parameter": "all_population_means_equal", "value": None}
    test["configuration"].update(
        equal_var=False, welch_correction=True, trim_fraction=0.0,
        sample_variance_ddof=1, native_function="statsmodels.stats.oneway.anova_oneway",
        reference_distribution="approximate F with Welch-Satterthwaite degrees of freedom",
        reference_tail="upper", alternative_hypothesis="at_least_two_population_means_differ",
        alternative_definition="omnibus unequal means; upper-tail F reference, not a doubled-tail F p-value",
        confidence_interval_status="scalar omnibus effect and confidence interval not implemented",
        index_role="each named group index must be unique; independent-group membership and unit identity require design evidence")
    test["limitations"].extend([
        "Welch ANOVA permits unequal population variances; it still requires independent analysis units and an appropriate mean/sampling-distribution approximation. Strong skew, heavy tails and small groups can limit that approximation.",
        "This omnibus comparison does not identify which groups differ. No pairwise effects, eta-squared estimate, scalar omnibus effect or confidence interval is implemented.",
        "Named indexes are not exported or used to infer independence; positional arrays provide no entity, measurement or sampling-design evidence.",
    ])
    if any(g["n"] < 2 for g in groups):
        return _not_computable(output, "Every group requires at least two observations for the supported sample-variance reference; no groups were removed")
    if any(g["variance"] is None or not math.isfinite(g["variance"]) or g["variance"] <= 0 for g in groups):
        return _not_computable(output, "Every group requires positive finite sample variance at working precision for Welch inverse-variance weights; no substitute test was selected")
    with np.errstate(over="ignore", divide="ignore", invalid="ignore"):
        inverse_variance_weights = np.array([g["n"] / g["variance"] for g in groups])
    if not np.isfinite(inverse_variance_weights).all() or not math.isfinite(float(np.sum(inverse_variance_weights))):
        return _not_computable(output, "Welch inverse-variance weights exceed the supported finite precision; no rescaling or substitute reference was applied")
    backend, version = _load_welch_backend()
    test["configuration"]["statsmodels_version"] = version
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        try:
            native = backend(samples, use_var="unequal", welch_correction=True, trim_frac=0)
        except (ValueError, FloatingPointError, OverflowError, ZeroDivisionError):
            return _not_computable(output, "The Welch backend could not produce the requested finite comparison; no alternate test was substituted")
    if caught:
        test["warnings"].append("The Welch backend issued a numerical warning; precision and reference adequacy require review")
    statistic, pvalue = _finite(native.statistic), _finite(native.pvalue)
    df_num, df_denom = _finite(native.df_num), _finite(native.df_denom)
    if (statistic is None or statistic < 0 or pvalue is None or not 0 <= pvalue <= 1 or
            df_num is None or df_num <= 0 or df_denom is None or df_denom <= 0):
        return _not_computable(output, "A finite nonnegative F statistic, probability and positive reference degrees of freedom were unavailable")
    test.update(computational_status="computed", statistic=statistic, p_value=pvalue,
                degrees_of_freedom={"numerator": df_num, "denominator": df_denom})
    if pvalue == 0:
        test["warnings"].append("The backend p-value rounded or underflowed to zero at floating-point precision; this is not a literal zero null-reference probability")
    return output


def _mcnemar(x, confidence):
    table = _table(x)
    a, b, c, d = (int(v) for v in table.flat)
    n, discordant = a + b + c + d, b + c
    output = _base("mcnemar_exact", confidence)
    test = output["statistical_test"]
    output["sample_sizes"] = {"n": n, "pairs": n, "discordant_pairs": discordant,
                              "concordant_pairs": a + d}
    test["groups"] = [{"label": "paired_binary_count_table", "n": n,
                       "observed_counts": table.tolist(), "row_totals": [a + b, c + d],
                       "column_totals": [a + c, b + d],
                       "discordant_0_to_1": b, "discordant_1_to_0": c}]
    test["null"] = {"parameter": "paired_marginal_probability_difference_column1_minus_row1", "value": 0.0}
    test["effect"] = {"name": "paired_marginal_risk_difference_column1_minus_row1",
                      "estimate": (b - c) / n if n else None,
                      "units": "proportion (column category 1 minus row category 1)",
                      "confidence_interval": None}
    test["configuration"].update(
        input_role="aggregate paired same-unit binary counts; not independent groups",
        category_order={"rows": [0, 1], "columns": [0, 1]},
        cell_orientation="[[row0_column0, row0_column1], [row1_column0, row1_column1]]; b=row0_column1, c=row1_column0",
        native_function="scipy.stats.binomtest", exact=True, continuity_correction=False,
        reference_distribution="conditional Binomial(b+c, 0.5) for discordant pairs",
        reference_tail="two-sided probability ordering",
        p_value_definition="two-sided exact binomial probability ordering at fixed discordant total",
        statistic_definition="minimum of the two discordant counts, matching exact McNemar convention",
        conditional_direction_probability_null=0.5,
        discordant_pair_denominator=discordant,
        discordant_0_to_1_proportion=b / discordant if discordant else None,
        discordant_1_to_0_proportion=c / discordant if discordant else None,
        marginal_pair_denominator=n,
        row_category_1_proportion=(c + d) / n if n else None,
        column_category_1_proportion=(b + d) / n if n else None,
        confidence_interval_status="paired marginal risk-difference confidence interval not implemented")
    test["limitations"].extend([
        "Exact McNemar conditions on the discordant-pair total under equal paired binary margins. Same-unit pairing and independence between pairs require design evidence; within-pair measurements are not independent groups.",
        "The paired marginal difference uses all pairs, while the conditional direction proportions and exact p-value use only discordant pairs. Neither is an independent-samples risk difference or a causal effect.",
        "A confidence interval for the paired marginal risk difference is unimplemented. A binomial interval for the discordant direction probability would target a different parameter and is not substituted.",
    ])
    if n == 0:
        return _not_computable(output, "Zero paired observations provide no marginal comparison or effect; no p-value is substituted")
    if discordant == 0:
        test.update(computational_status="computed", statistic=0, p_value=1.0)
        test["warnings"].append("There are zero discordant pairs among " + str(n) + " pairs. The conventional exact p-value is 1, but direction proportions are undefined; this supplies no discordant-direction information and does not establish equality or equivalence")
        return output
    native = stats.binomtest(b, discordant, p=0.5, alternative="two-sided")
    pvalue = _finite(native.pvalue)
    if pvalue is None or not 0 <= pvalue <= 1:
        return _not_computable(output, "No finite exact-binomial probability was available for the discordant counts")
    test.update(computational_status="computed", statistic=min(b, c), p_value=pvalue)
    if pvalue == 0:
        test["warnings"].append("The exact-binomial probability underflowed to zero at floating-point precision; the finite-discordance null-reference probability is positive")
    return output


def compute_extended_test(method, x, y=None, *, null_value=0.0, confidence=0.95):
    """Compute caller-prespecified Welch ANOVA or exact paired-binary McNemar.

    ``welch_anova`` takes x=[group1, group2, ...]. ``mcnemar_exact`` takes
    x=[[a,b],[c,d]], with fixed rows/columns category order [0,1] and paired
    risk difference (b-c)/N = column-1 prevalence minus row-1 prevalence.
    Neither accepts y or a nondefault scientific null. Confidence is validated
    and recorded, but intervals for these procedures are explicitly unavailable.
    """
    if not isinstance(method, str) or method not in METHODS:
        raise ValueError("Unknown extended statistical procedure; choose welch_anova or mcnemar_exact")
    null_value = _scalar(null_value, "null_value")
    confidence = _scalar(confidence, "confidence")
    if not 0 < confidence < 1:
        raise ValueError("confidence must be strictly between zero and one")
    if null_value != 0:
        raise ValueError(method + " has a fixed scientific null; null_value must remain its default-zero sentinel")
    if y is not None:
        raise ValueError(method + " takes all groups or the paired table in x; y must be absent")
    return _welch(x, confidence) if method == "welch_anova" else _mcnemar(x, confidence)
