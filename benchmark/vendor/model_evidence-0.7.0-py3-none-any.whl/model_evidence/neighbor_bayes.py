"""Bounded native KNN/Naive Bayes metadata and predictor-domain evidence.

No fitting, preprocessing replay, neighbor search, probability recomputation or
cached training records are used. Pipeline representations remain unknown.
"""
from __future__ import annotations

import math

import numpy as np
from scipy.sparse import issparse
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.naive_bayes import GaussianNB, MultinomialNB, BernoulliNB, ComplementNB, CategoricalNB
from sklearn.pipeline import Pipeline

from .report import evidence

KNN = {KNeighborsClassifier, KNeighborsRegressor}
NB = {GaussianNB, MultinomialNB, BernoulliNB, ComplementNB, CategoricalNB}
SUPPORTED = KNN | NB
SPLITS = {"unknown", "training", "validation", "evaluation", "final_holdout"}
_PROVENANCE = {"implementation": "neighbor-bayes/0.7.0", "model_refit": False,
               "preprocessing_replayed": False, "fit_warnings_recovered": False}


def _unwrap(model):
    final=model;pipeline=False
    for _ in range(8):
        if not isinstance(final,Pipeline):break
        pipeline=True
        final=final.steps[-1][1]
    if type(final) not in SUPPORTED:
        raise ValueError("Expected exact stock KNeighborsClassifier/Regressor or one of five supported Naive Bayes variants")
    return final,pipeline


def is_neighbor_bayes_candidate(model):
    try:_unwrap(model);return True
    except (ValueError,TypeError,AttributeError,IndexError):return False


def _integer(value,minimum=0):
    if isinstance(value,(int,np.integer)) and not isinstance(value,(bool,np.bool_)) and minimum<=value<=1_000_000_000:
        return int(value)
    return None


def _number(value,*,minimum=None):
    if isinstance(value,(bool,np.bool_)) or not isinstance(value,(int,float,np.integer,np.floating)):return None
    result=float(value)
    if not math.isfinite(result) or abs(result)>1e100 or (minimum is not None and result<minimum):return None
    return result


def _metric_name(value):
    if isinstance(value,str) and len(value)<=80 and value.isascii() and all(c.isalnum() or c in "_-" for c in value):return value
    return "custom_callable_not_inspected" if callable(value) else "unrecognized_not_inspected"


def _feature_count(final):
    count=_integer(getattr(final,"n_features_in_",None),1)
    if count is None or count>2048:raise ValueError("Native fitted predictor count must be a bounded positive integer")
    return count


def describe_neighbor_bayes_fit(model):
    """Read small native state only; never expose cached training arrays or IDs."""
    final,pipeline=_unwrap(model)
    details={"variant":type(final).__name__,"scope":"native prediction plus bounded domain/configuration evidence",
        "estimator_input_feature_count":_feature_count(final),
        "representation":"Pipeline-owned transformed representation; not reconstructed" if pipeline else "supplied rows are direct estimator inputs",
        "estimator_input_known":not pipeline,"training_records_exported":False,
        "training_warnings_available":False,"model_refit":False,"preprocessing_replayed":False}
    if type(final) in KNN:
        k=_integer(getattr(final,"n_neighbors",None),1);fit_n=_integer(getattr(final,"n_samples_fit_",None),1)
        if k is None or fit_n is None:raise ValueError("Native KNN k and fitted-row count must be bounded positive integers")
        weights=getattr(final,"weights",None)
        params=getattr(final,"effective_metric_params_",{})
        if not isinstance(params,dict):raise ValueError("Native effective metric parameters must be a mapping")
        known_parameter_keys=[key for key in ("p","w","V","VI") if key in params]
        details.update(additional_requirements=["predictor_domain","distance_geometry"],n_neighbors=k,n_samples_fit=fit_n,
            fitted_row_count_meaning="native fitting rows, not unique entities or verified independent observations",
            weights="uniform (native None)" if weights is None else weights if isinstance(weights,str) and weights in {"uniform","distance"} else "custom_callable_not_inspected" if callable(weights) else "unrecognized_not_inspected",
            configured_metric=_metric_name(getattr(final,"metric",None)),effective_metric=_metric_name(getattr(final,"effective_metric_",None)),
            effective_metric_parameter_keys=known_parameter_keys,unreported_metric_parameter_keys=len(params)-len(known_parameter_keys),
            configured_minkowski_p=_number(getattr(final,"p",None),minimum=0),
            search_method=getattr(final,"_fit_method",None) if getattr(final,"_fit_method",None) in {"brute","kd_tree","ball_tree"} else "unknown",
            neighbor_search_performed_by_audit=False,
            metric_geometry_assessed=False,training_scaling_selection_assessed=False)
    else:
        details["additional_requirements"]=["predictor_domain","conditional_feature_independence","distributional_approximation"]
        details.update(conditional_feature_independence_assessed=False,
            conditional_likelihood_assessed=False,
            observation_independence_is_distinct=True,
            training_sample_size="not reconstructed; native class_count_ can accumulate weighted/repeated training mass")
        counts=np.asarray(getattr(final,"class_count_",[]))
        if counts.ndim==1 and 2<=counts.size<=32 and counts.dtype.kind in "iuf" and np.isfinite(counts).all() and np.all(counts>=0) and np.all(counts<=1e100):
            details["native_class_mass"]={"classes":int(counts.size),"minimum":float(counts.min()),"maximum":float(counts.max()),
                "meaning":"accumulated native class mass; may reflect sample weights or repeated partial_fit calls, not unique rows"}
        if type(final) is GaussianNB:
            details["likelihood_form"]="Gaussian within each class and predictor; not unconditional feature normality"
            details["configured_var_smoothing"]=_number(getattr(final,"var_smoothing",None),minimum=0)
            details["class_prior_policy"]="explicit configured priors" if getattr(final,"priors",None) is not None else "native empirical class mass"
        else:
            alpha=getattr(final,"alpha",None)
            details["configured_alpha"]=_number(alpha,minimum=0)
            details["alpha_scope"]="configured scalar" if details["configured_alpha"] is not None else "feature-specific or unavailable; values not exported"
            details["force_alpha"]=bool(final.force_alpha) if type(getattr(final,"force_alpha",None)) is bool else None
            details["smoothing_limit"]="Configuration does not reconstruct effective smoothing during fitting; zero smoothing is not silently changed by this audit."
            details["class_prior_policy"]="explicit configured priors" if getattr(final,"class_prior",None) is not None else "uniform configured priors" if getattr(final,"fit_prior",True) is False else "native empirical class mass"
            if type(final) is BernoulliNB:
                threshold=getattr(final,"binarize",None)
                if threshold is not None and _number(threshold) is None:raise ValueError("Native Bernoulli binarization threshold must be finite or None")
                details["native_binarize_threshold"]=None if threshold is None else float(threshold)
                details["likelihood_form"]="binary features after native configured threshold; if binarize=None inputs must already be binary"
            elif type(final) is CategoricalNB:
                categories=np.asarray(getattr(final,"n_categories_",[]))
                if categories.ndim!=1 or len(categories)!=details["estimator_input_feature_count"] or categories.dtype.kind not in "iu" or np.any(categories<1) or np.any(categories>1_000_000_000):
                    raise ValueError("Native categorical support metadata must align with fitted features")
                details["category_support"]={"features":int(categories.size),"minimum_allocated_codes":int(categories.min()),"maximum_allocated_codes":int(categories.max()),
                    "meaning":"allocated per-feature integer code range; vocabulary labels and actually observed categories are not reconstructed"}
                details["likelihood_form"]="categorical conditional likelihood on configured integer code positions"
            elif type(final) is ComplementNB:
                details["native_complement_weight_normalization"]=bool(final.norm)
                details["likelihood_form"]="native complement-class feature weights; probability calibration remains empirical"
            else:details["likelihood_form"]="multinomial-style nonnegative feature mass; fractional values are permitted but measurement meaning needs review"
    return details


def _domain_values(X,p):
    if issparse(X):return None,"Sparse estimator-input inspection is not implemented; no silent densification"
    if np.ma.isMaskedArray(X):return None,"Masked input requires explicit missingness handling; no unmasking"
    try:values=np.asarray(X)
    except (TypeError,ValueError,OverflowError):return None,"Input array shape/type could not be inspected"
    if values.ndim!=2 or not 1<=len(values) or values.shape[1]!=p or values.size>2_000_000:
        raise ValueError("Direct estimator input must have bounded n-by-fitted-feature shape")
    if values.dtype.kind not in "iufb":return None,"Direct input is not an already real numeric/boolean representation; native coercion semantics were not replayed"
    return values,None


def neighbor_bayes_evidence(model,X,*,source_split="unknown"):
    """Return transparent domain and manual-assumption rows without model actions."""
    if not isinstance(source_split,str) or source_split not in SPLITS:raise ValueError("Unknown supplied-row split role")
    final,pipeline=_unwrap(model);details=describe_neighbor_bayes_fit(model)
    try:n=_integer(len(X),1)
    except (TypeError,OverflowError):n=None
    provenance={**_PROVENANCE,"source_split":source_split,"variant":type(final).__name__}
    rows=[]
    limits=["A numerical domain comparison is not proof of measurement meaning, sampling, likelihood adequacy, untouched evaluation or future performance.",
            "Aggregates and fitted-configuration summaries may still be sensitive; no cached training records or row identifiers are exported."]
    def row(req,status,diagnostic,observed=None,thresholds=None,*,manual=False,extra_limits=(),remedies=()):
        return evidence(req,status,diagnostic,source="manual_required" if manual else "automated",sample_size=n,
            observed={"source_split":source_split,"group":"supplied direct estimator inputs" if not pipeline else "Pipeline-owned estimator representation",
                      "variables":["all direct estimator-input feature positions" if not pipeline else "unreconstructed final estimator-input representation"],**(observed or {})},
            thresholds=thresholds or {},limitations=limits+list(extra_limits),remedies=list(remedies),provenance=provenance)
    if type(final) in KNN:
        k=details["n_neighbors"];fit_n=details["n_samples_fit"]
        concerns=k>fit_n
        k_row=row("distance_geometry","fail" if concerns else "no_issue_detected",
            "Configured neighbor count versus native fitting rows; this tests executability only",
            {"configured_neighbors":k,"native_fitting_rows":fit_n,"k_exceeds_fitting_rows":concerns,"configured_metric":details["configured_metric"],"effective_metric":details["effective_metric"],"weights":details["weights"],"representation":details["representation"],"variables":["configured n_neighbors","native n_samples_fit_"]},
            {"comparison":"configured n_neighbors <= native n_samples_fit_; this is an executability condition, not a geometry-validity threshold"},
            extra_limits=["Native fitting rows are not verified independent entities. A successful comparison does not assess scaling, distance meaning, ties, duplicate entities, high-dimensional neighborhoods or training-only k/metric selection."],
            remedies=["Review the metric and representation in the study context; select any scaling/k/metric change on training folds and rerun an untouched evaluation."])
        k_row["sample_size"]=fit_n
        rows.append(k_row)
        rows.append(row("distance_geometry","not_checked",
            "Appropriate neighborhood geometry, predictor scaling and training-only metric/k selection remain unresolved",
            {"metric":details["effective_metric"],"weights":details["weights"],"representation":details["representation"],"geometry_assessed":False},
            {"comparison":"no universal scaling, distance or dimensionality cutoff"},manual=True,
            remedies=["Document meaningful feature units/representation, metric choice, tie behavior and training-only selection; do not treat a k-versus-row-count check as validation of neighborhood meaning."]))
    else:
        rows.append(row("conditional_feature_independence","not_checked",
            "Conditional independence of predictors given class is assumed by Naive Bayes and is not established by this prediction audit",
            {"assessed":False,"conditioning":"given the class variable","distinct_from":"independence of observations"},
            {"comparison":"no universal correlation cutoff or certificate"},manual=True,
            extra_limits=["Feature dependence can affect likelihood/probability interpretation without mechanically making predictive classification useless. Held-out error and calibration metrics remain empirical calculations."],
            remedies=["Document substantive feature-generation assumptions and assess probability behavior on prespecified evaluation data; do not treat a nonsignificant dependence diagnostic as proof."]))
        rows.append(row("distributional_approximation","not_checked",
            "Variant-specific conditional likelihood assumptions and measurement meaning are not verified",
            {"variant":type(final).__name__,"conditional_likelihood":details["likelihood_form"],"assessed":False},
            {"comparison":"no universal predictor normality, goodness-of-fit or automatic model-switching rule"},manual=True,
            extra_limits=["GaussianNB concerns feature distributions within class, not unconditional normality. Other variants do not acquire Gaussian-feature requirements. Native probabilities need empirical calibration assessment."],
            remedies=["Review the specified likelihood, encoding and data collection process; any variant/encoding change requires training-only refitting and a fresh evaluation."]))
    if pipeline:
        rows.append(row("predictor_domain","not_checked",
            "Estimator input domain is unresolved because the supplied fitted Pipeline owns transformations",
            {"estimator_input_known":False,"raw_rows_treated_as_transformed":False,"transforms_replayed":False,"estimator_input_feature_count":details["estimator_input_feature_count"]},
            {"comparison":"raw Pipeline columns are not assumed to equal the final estimator's representation"},manual=True,
            remedies=["Review an explicit training-owned representation/domain record; do not label raw negative, categorical or differently scaled columns as transformed-estimator domain failures."]))
        return rows
    values,unknown=_domain_values(X,details["estimator_input_feature_count"])
    if values is None:
        rows.append(row("predictor_domain","not_checked",unknown,{"estimator_input_known":False,"coercion_replayed":False},manual=True,
            remedies=["Provide a supported explicit bounded estimator-input representation or document its transformation/domain outside the audit."]))
        return rows
    nonfinite=int(np.sum(~np.isfinite(values)))
    comparison={"cells":int(values.size),"rows":int(values.shape[0]),"features":int(values.shape[1]),"nonfinite_cells":nonfinite,"estimator_input_known":True}
    if nonfinite:
        rows.append(row("predictor_domain","fail","Direct estimator inputs contain nonfinite cells",comparison,
            {"maximum_nonfinite_cells":0,"comparison":"all direct estimator inputs must be finite; no rows/cells are removed"}))
        return rows
    outside_report_range=int(np.sum((values>1e100)|(values< -1e100)))
    if outside_report_range:
        comparison["outside_bounded_reporting_cells"]=outside_report_range
    else:comparison.update(minimum=float(values.min()),maximum=float(values.max()))
    violations=0;thresholds={"maximum_nonfinite_cells":0}
    if type(final) in KNN:
        if details["effective_metric"]=="precomputed" or details["configured_metric"]=="precomputed":
            negative=int(np.sum(values<0));comparison.update(negative_distance_cells=negative,representation="supplied precomputed query-to-training distances; not original predictors")
            violations=negative;thresholds.update(minimum_distance=0,comparison="finite nonnegative supplied distances; distance axioms, row/column identity and training-distance construction remain unresolved")
            diagnostic="Precomputed KNN query-distance numeric domain; underlying feature geometry is not assessed"
        else:
            thresholds["comparison"]="finite direct estimator predictor cells; no universal feature-scale or normality threshold"
            diagnostic="Direct KNN predictor finiteness; appropriate metric and scaling require study context"
    elif type(final) in {MultinomialNB,ComplementNB}:
        negative=int(np.sum(values<0));comparison.update(negative_cells=negative,fractional_cells=int(np.sum(values!=np.floor(values))))
        violations=negative;thresholds.update(minimum_feature_mass=0,comparison="every supplied feature value >=0; fractional nonnegative values are not automatically invalid")
        diagnostic="Nonnegative feature-mass domain for the native Naive Bayes variant"
    elif type(final) is BernoulliNB:
        threshold=details["native_binarize_threshold"]
        if threshold is None:
            violations=int(np.sum((values!=0)&(values!=1)));comparison["non_binary_cells"]=violations
            thresholds.update(allowed_values=[0,1],comparison="with native binarize=None, every direct input must already be 0 or 1")
            diagnostic="Already-binary predictor domain with native binarization disabled"
        else:
            comparison.update(native_binarize_threshold=threshold,above_threshold_cells=int(np.sum(values>threshold)),at_or_below_threshold_cells=int(np.sum(values<=threshold)))
            thresholds.update(comparison="native BernoulliNB binarizes using input > configured threshold; negative raw values are not automatically invalid")
            diagnostic="Finite direct inputs under the estimator's native configured Bernoulli binarization"
    elif type(final) is CategoricalNB:
        categories=np.asarray(final.n_categories_)
        negative=int(np.sum(values<0));fractional=int(np.sum(values!=np.floor(values)))
        out_of_range=int(np.sum(values>=categories[None,:]))
        comparison.update(negative_code_cells=negative,fractional_code_cells=fractional,above_allocated_support_cells=out_of_range,
            allocated_category_count_min=int(categories.min()),allocated_category_count_max=int(categories.max()))
        violations=negative+fractional+out_of_range
        thresholds.update(comparison="each direct code must be a nonnegative integer less than that feature's native n_categories_; no silent float-to-integer repair")
        diagnostic="Categorical code integrality and native allocated-support comparison"
    else:
        variance=np.asarray(getattr(final,"var_",[]))
        if variance.ndim!=2 or variance.shape[1]!=values.shape[1] or variance.size>65_536 or variance.dtype.kind not in "iuf":
            raise ValueError("GaussianNB native conditional variances have unsupported shape/type")
        bad_variance=int(np.sum(~np.isfinite(variance)|(variance<=0)))
        comparison.update(native_conditional_variance_cells=int(variance.size),nonpositive_or_nonfinite_native_variance_cells=bad_variance)
        outside_variance=int(np.sum(np.isfinite(variance)&(np.abs(variance)>1e100)))
        if outside_variance:
            rows.append(row("predictor_domain","fail" if bad_variance else "not_checked",
                "Native Gaussian conditional variances exceed the bounded evidence-reporting range",
                {**comparison,"outside_bounded_native_variance_cells":outside_variance},
                {"report_absolute_value_limit":1e100,"comparison":"a contract bound is not a statistical normality or variance-adequacy threshold"},manual=not bool(bad_variance),
                remedies=["Review numerical conditioning and declared units outside the audit; no fitted variances are modified."]))
            return rows
        if np.isfinite(variance).all():
            comparison.update(native_conditional_variance_minimum=float(variance.min()),native_conditional_variance_maximum=float(variance.max()))
        violations=bad_variance
        thresholds.update(minimum_native_variance_exclusive=0,comparison="finite direct predictors and finite strictly positive fitted conditional variances; this does not test class-conditional Gaussian shape")
        diagnostic="Finite GaussianNB inputs and usable native conditional-variance arithmetic"
    if outside_report_range:
        thresholds["report_absolute_value_limit"]=1e100
        diagnostic+="; scalar extrema exceed the bounded evidence-reporting range and are omitted"
    rows.append(row("predictor_domain","fail" if violations else "not_checked" if outside_report_range else "no_issue_detected",diagnostic,comparison,thresholds,
        manual=bool(outside_report_range and not violations),
        extra_limits=["This is only the stated finite/support comparison. It does not verify the conditional feature-independence assumption or the variant's data-generating model."],
        remedies=["If the documented domain is violated, review the intended encoding/variant and propose a training-only refit; no clipping, rounding, binarization change or input repair is applied by this audit."]))
    return rows
