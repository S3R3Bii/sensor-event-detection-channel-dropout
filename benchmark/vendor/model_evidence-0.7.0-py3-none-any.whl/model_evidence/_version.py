"""Distribution version; numerical/report subcontracts are versioned separately."""
VERSION="0.7.0"
