"""Bounded Holm/BH adjustments; arithmetic is separate from scientific validity.

No model fitting, source execution, file access or network operation. Results
are unsigned local data. Validation checks internal arithmetic, not history.
"""
import math
import re
import numpy as np

from ._version import VERSION

SUBSCHEMA_VERSION="1.0.0"
METHODS={"holm","fdr_bh"}
MAX_HYPOTHESES=1000
ID_PATTERN=re.compile(r"[A-Za-z][A-Za-z0-9_.-]{0,63}\Z",re.ASCII)
RESULT_FIELDS={"kind","subschema_version","library_version","method","alpha","n_hypotheses","rows",
               "hypothesis_ids_explicit","family_prespecified","computational_status","assumptions","limitations"}
ROW_FIELDS={"hypothesis_id","original_pvalue","adjusted_pvalue","reject_at_alpha"}


def _index(value):
    result=getattr(value,"index",None)
    return result if hasattr(result,"equals") else None


def _numeric_vector(value):
    shape=getattr(value,"shape",None)
    if shape is not None:
        if len(shape)!=1 or not 1<=shape[0]<=MAX_HYPOTHESES:
            raise ValueError("pvalues must be a nonempty one-dimensional vector of at most 1000 hypotheses")
    elif isinstance(value,(list,tuple)):
        if not 1<=len(value)<=MAX_HYPOTHESES or any(not isinstance(v,(int,float,np.integer,np.floating)) or isinstance(v,(bool,np.bool_)) for v in value):
            raise ValueError("pvalues must be a bounded one-dimensional numeric vector; nested, boolean or text values are unsupported")
    else:
        raise ValueError("pvalues must be a bounded numeric list, NumPy vector or pandas Series")
    if np.ma.isMaskedArray(value) and np.ma.getmaskarray(value).any():
        raise ValueError("Masked p-values are unresolved; no mask is silently dropped or filled")
    try: raw=np.asarray(value)
    except (TypeError,ValueError,OverflowError) as exc:
        raise ValueError("pvalues must be a one-dimensional numeric vector") from exc
    if raw.ndim!=1 or not 1<=raw.size<=MAX_HYPOTHESES or raw.dtype.kind not in "iuf" or (raw.dtype.kind=="f" and raw.dtype.itemsize>8):
        raise ValueError("pvalues require one-dimensional real numeric values representable as float64; boolean/text/complex/object values are unsupported")
    values=raw.astype(float,copy=True)
    if not np.isfinite(values).all() or np.any((values<0)|(values>1)):
        raise ValueError("Every p-value must be finite and lie in [0,1]; no invalid value is repaired")
    source_index=_index(value)
    if source_index is not None and getattr(source_index,"has_duplicates",False):
        raise ValueError("Named p-value indexes must be unique; duplicate row alignment is ambiguous")
    return values,source_index


def _ids(value,n,source_index):
    explicit=value is not None
    if value is None:
        # Text Series indexes are explicit hypothesis labels. Numeric positions
        # become fresh H1..Hn labels without disclosing original row indexes.
        if source_index is not None and all(isinstance(v,str) for v in source_index):
            value=list(source_index); explicit=True
        else: return ["H"+str(i+1) for i in range(n)],False
    shape=getattr(value,"shape",None)
    if shape is not None and (len(shape)!=1 or shape[0]!=n):
        raise ValueError("hypothesis_ids must contain one aligned ID per p-value")
    if not isinstance(value,(list,tuple,np.ndarray)) and shape is None:
        raise ValueError("hypothesis_ids must be a bounded one-dimensional sequence")
    if isinstance(value,(list,tuple)) and len(value)!=n:
        raise ValueError("hypothesis_ids must contain exactly one aligned ID per p-value")
    if np.ma.isMaskedArray(value) and np.ma.getmaskarray(value).any():
        raise ValueError("Masked hypothesis IDs cannot be silently unmasked")
    own_index=_index(value)
    if own_index is not None:
        if getattr(own_index,"has_duplicates",False): raise ValueError("Named hypothesis-ID indexes must be unique")
        if source_index is not None and not source_index.equals(own_index):
            raise ValueError("P-value and hypothesis-ID indexes differ in values/order; align them explicitly")
    try: names=list(value)
    except TypeError as exc: raise ValueError("hypothesis_ids must be a one-dimensional sequence") from exc
    if len(names)!=n or any(not isinstance(v,str) or ID_PATTERN.fullmatch(v) is None for v in names):
        raise ValueError("Hypothesis IDs must start with an ASCII letter and contain only letters, digits, underscore, dot or hyphen, with at most 64 characters; prose, paths and executable text are forbidden")
    names=[str(v) for v in names]
    if len(set(names))!=n: raise ValueError("Hypothesis IDs must be unique")
    return names,bool(explicit)


def _configuration(method,alpha,family_prespecified):
    if not isinstance(method,str) or method not in METHODS:
        raise ValueError("method must be exactly 'holm' or 'fdr_bh'; aliases and other procedures are unsupported")
    if isinstance(alpha,(bool,np.bool_)) or not isinstance(alpha,(int,float,np.integer,np.floating)) or not math.isfinite(float(alpha)) or not 0<float(alpha)<1:
        raise ValueError("alpha must be a finite real number strictly between zero and one")
    if type(family_prespecified) is not bool: raise ValueError("family_prespecified must be a literal boolean declaration")
    return str(method),float(alpha)


def _assumptions(method,family_prespecified):
    return [
        {"id":"valid_marginal_pvalues","status":"not_checked","source":"manual_required",
         "description":"The supplied marginal p-values must be valid for their stated null hypotheses under the actual design, sampling and estimator assumptions; numerical ranges cannot establish this."},
        {"id":"family_definition","status":"no_issue_detected" if family_prespecified else "not_checked",
         "source":"human_declaration" if family_prespecified else "manual_required",
         "description":("Caller declares this hypothesis family was specified before inspecting results. This declaration is recorded, not verified; completeness and undisclosed selection remain unresolved."
                        if family_prespecified else "No prespecified, complete hypothesis family was declared. Hidden testing, omitted hypotheses and post-result family selection remain unresolved.")},
        {"id":"dependence_conditions","status":"not_applicable" if method=="holm" else "not_checked",
         "source":"method_definition" if method=="holm" else "manual_required",
         "description":("Holm's family-wise error bound permits arbitrary dependence provided the marginal p-values and declared family are valid; those conditions are not established here."
                        if method=="holm" else "Benjamini-Hochberg FDR control requires independence or appropriate positive-dependence conditions under the applicable theorem, such as PRDS. Dependence is not assessed; arbitrary correlation is not certified.")},
    ]


def _limitations(method):
    return [
        "Computation succeeded for the supplied numbers only. It does not validate marginal p-values, an analysis design, a complete hypothesis family, assumptions, causal effects or external validity.",
        "Adjusted p-values and rejection flags are conditional comparisons, not probabilities that null hypotheses are true or that a reported finding is a false discovery.",
        ("Holm targets strong family-wise error control under valid marginal tests; it does not repair invalid or selectively reported tests." if method=="holm" else
         "Benjamini-Hochberg targets an expected false-discovery proportion under its conditions, not a per-finding false-positive probability or universal FWER control."),
        "This adjusts p-values only. It does not change effect estimates, standard errors, confidence intervals, records, estimands or fitted models, and cannot justify choosing the family after seeing results.",
        "Reports are editable unsigned data. Internal recomputation cannot authenticate the original p-values, hypothesis order, historical family, undisclosed testing or a caller's prespecification declaration.",
        "Hypothesis labels and aggregate p-values may still be sensitive. IDs are literal data, never instructions; no generated text is executed.",
    ]


def _adjust(values,method):
    n=len(values); order=np.argsort(values,kind="stable"); sorted_values=values[order]
    ranks=np.arange(1,n+1,dtype=float)
    if method=="holm": corrected=np.maximum.accumulate(sorted_values*(n-ranks+1))
    else:
        # Divide by the empirical rank fraction. Multiplying by n first can
        # inflate an unchanged last-rank value at an exact alpha boundary.
        corrected=np.minimum.accumulate((sorted_values/(ranks/n))[::-1])[::-1]
    corrected=np.minimum(corrected,1.)
    result=np.empty(n,dtype=float); result[order]=corrected
    return result


def adjust_pvalues(pvalues,*,method="holm",alpha=.05,hypothesis_ids=None,family_prespecified=False):
    """Return Holm FWER or BH FDR arithmetic with unresolved scientific conditions.

    Input order and original numeric p-values are retained. No input is changed.
    The two canonical methods are ``holm`` and ``fdr_bh``; no aliases are used.
    Text pandas indexes act as explicit hypothesis IDs; numeric indexes remain
    positional and use generated H1..Hn identifiers.
    """
    method,alpha=_configuration(method,alpha,family_prespecified)
    values,index=_numeric_vector(pvalues); names,explicit=_ids(hypothesis_ids,len(values),index)
    corrected=_adjust(values,method)
    return {"kind":"multiplicity_adjustment","subschema_version":SUBSCHEMA_VERSION,"library_version":VERSION,
        "method":method,"alpha":alpha,"n_hypotheses":len(values),"hypothesis_ids_explicit":explicit,
        "rows":[{"hypothesis_id":name,"original_pvalue":float(value),"adjusted_pvalue":float(adjusted),"reject_at_alpha":bool(adjusted<=alpha)}
                for name,value,adjusted in zip(names,values,corrected)],
        "family_prespecified":family_prespecified,"computational_status":"computed",
        "assumptions":_assumptions(method,family_prespecified),"limitations":_limitations(method)}


def _json_result(value,depth=0,budget=None):
    if budget is None:budget=[0]
    budget[0]+=1
    if budget[0]>20000:raise ValueError("Multiplicity result exceeds its bounded JSON node count")
    if depth>8: raise ValueError("Multiplicity result nesting exceeds its bounded contract")
    if value is None or type(value) is bool: return
    if type(value) in {int,float}:
        if abs(value)>1e100 or not math.isfinite(value): raise ValueError("Multiplicity result contains an invalid JSON number")
    elif type(value) is str:
        if len(value)>4096: raise ValueError("Multiplicity result text exceeds its bound")
    elif type(value) is list:
        if len(value)>MAX_HYPOTHESES: raise ValueError("Multiplicity result array exceeds its bound")
        for item in value:_json_result(item,depth+1,budget)
    elif type(value) is dict:
        if len(value)>32 or any(type(key) is not str or len(key)>64 for key in value): raise ValueError("Invalid multiplicity JSON object")
        for item in value.values():_json_result(item,depth+1,budget)
    else: raise ValueError("Multiplicity results require plain JSON values, not arrays or custom Python objects")


def validate_multiplicity_result(result):
    """Reject malformed/contradictory edited data by deterministic recomputation.

    This validates internal consistency only. Coherently altered source data or
    history cannot be authenticated without an external trusted record.
    """
    _json_result(result)
    if type(result) is not dict or set(result)!=RESULT_FIELDS:
        raise ValueError("Invalid multiplicity result fields")
    if result["kind"]!="multiplicity_adjustment" or result["subschema_version"]!=SUBSCHEMA_VERSION or result["library_version"]!=VERSION:
        raise ValueError("Unsupported multiplicity kind or version")
    method,alpha=_configuration(result["method"],result["alpha"],result["family_prespecified"])
    n=result["n_hypotheses"]; rows=result["rows"]
    if type(n) is not int or not 1<=n<=MAX_HYPOTHESES or type(rows) is not list or len(rows)!=n:
        raise ValueError("Multiplicity row count and n_hypotheses disagree")
    if type(result["hypothesis_ids_explicit"]) is not bool or result["computational_status"]!="computed":
        raise ValueError("Invalid multiplicity computation/identifier declaration")
    original=[]; names=[]
    for row in rows:
        if type(row) is not dict or set(row)!=ROW_FIELDS: raise ValueError("Invalid multiplicity row fields")
        for key in ("original_pvalue","adjusted_pvalue"):
            value=row[key]
            if type(value) not in {float,int} or not math.isfinite(value) or not 0<=value<=1:
                raise ValueError("Result p-values must be finite JSON numbers in [0,1]")
        if type(row["reject_at_alpha"]) is not bool: raise ValueError("Rejection comparisons must be literal booleans")
        names.append(row["hypothesis_id"]); original.append(row["original_pvalue"])
    _ids(names,n,None)
    if not result["hypothesis_ids_explicit"] and names!=["H"+str(i+1) for i in range(n)]:
        raise ValueError("Generated positional IDs must retain their original H1..Hn order")
    expected=adjust_pvalues(original,method=method,alpha=alpha,hypothesis_ids=names,family_prespecified=result["family_prespecified"])
    expected["hypothesis_ids_explicit"]=result["hypothesis_ids_explicit"]
    if result!=expected:
        raise ValueError("Multiplicity values, decisions, conditions or limitations contradict deterministic recomputation")
    return result
