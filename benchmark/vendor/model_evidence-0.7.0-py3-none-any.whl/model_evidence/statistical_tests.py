"""Bounded statistical procedures with explicit design and claim boundaries.

Numeric computation is conditional on a selected test. Metadata does not prove
the sampling design; named human evidence is separate. No normality pretest,
test selection, row deletion, imputation, fitting or arbitrary execution occurs.
"""
from copy import deepcopy
import math
import numpy as np
from .diagnostics import _complete
from .registry import describe_requirements, load_registry
from .report import evidence, make_report
from ._version import VERSION

MEAN_METHODS = frozenset({"one_sample_t_test", "welch_t_test", "student_t_test", "paired_t_test", "anova"})
OTHER_METHODS = frozenset({"chi_square", "fisher_exact", "binomial_test", "mann_whitney",
                           "wilcoxon_signed_rank", "kruskal_wallis", "friedman",
                           "pearson_correlation", "spearman_correlation"})
EXTENDED_METHODS = frozenset({"welch_anova", "mcnemar_exact"})
STATISTICAL_METHODS = MEAN_METHODS | OTHER_METHODS | EXTENDED_METHODS
GROUP_METHODS = frozenset({"anova", "kruskal_wallis", "friedman", "welch_anova"})
PAIRED_METHODS = frozenset({"paired_t_test", "wilcoxon_signed_rank", "pearson_correlation", "spearman_correlation"})
SPLITS = frozenset({"unknown", "training", "validation", "evaluation", "final_holdout", "not_applicable"})
RELATIONSHIPS = {
    "one_sample_t_test": "one_sample", "welch_t_test": "independent", "student_t_test": "independent",
    "paired_t_test": "paired", "anova": "independent", "chi_square": "counts", "fisher_exact": "counts",
    "binomial_test": "counts", "mann_whitney": "independent", "wilcoxon_signed_rank": "paired",
    "kruskal_wallis": "independent", "friedman": "repeated", "pearson_correlation": "paired",
    "spearman_correlation": "paired", "welch_anova":"independent", "mcnemar_exact":"paired"}
ESTIMANDS = {
    "one_sample_t_test": "mean", "welch_t_test": "mean_difference", "student_t_test": "mean_difference",
    "paired_t_test": "mean_difference", "anova": "group_mean_equality", "chi_square": "categorical_association",
    "fisher_exact": "odds_ratio", "binomial_test": "proportion", "mann_whitney": "distributional_comparison",
    "wilcoxon_signed_rank": "paired_location_shift", "kruskal_wallis": "rank_based_group_comparison",
    "friedman": "rank_based_group_comparison", "pearson_correlation": "pearson_correlation",
    "spearman_correlation": "spearman_correlation", "welch_anova":"group_mean_equality", "mcnemar_exact":"paired_proportion_difference"}


def _text(value, name, limit=128):
    if not isinstance(value, str) or not value.strip() or len(value) > limit or any(ord(c) < 32 for c in value):
        raise ValueError(name + " must be bounded nonempty plain text")
    return value


def _array(value):
    if np.ma.isMaskedArray(value) and np.ma.getmaskarray(value).any():
        raise ValueError("Masked values require an explicit analysis design; none are silently discarded")
    if np.iscomplexobj(value):
        raise ValueError("Complex measurements are unsupported")
    try:
        arr = np.asarray(value, dtype=float)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("Statistical inputs must be real numeric measurements or count aggregates") from exc
    if not arr.size or arr.size > 1_000_000 or arr.ndim not in {0, 1, 2}:
        raise ValueError("Statistical input shape is empty, unsupported or exceeds the local size bound")
    if not np.isfinite(arr).all() or np.any(np.abs(arr) > 1e100):
        raise ValueError("Nonfinite or oversized values require explicit handling; no rows were removed")
    return arr


def _input_summary(method, x, y):
    values = list(x) if method in GROUP_METHODS and isinstance(x, (list, tuple)) else [x]
    if method in GROUP_METHODS and not 2 <= len(values) <= 32:
        raise ValueError("Grouped procedures require a sequence of two to32 group arrays")
    if y is not None:
        values.append(y)
    arrays = [_array(v) for v in values]
    cells = sum(a.size for a in arrays)
    if cells > 1_000_000:
        raise ValueError("Combined input exceeds the bounded local size")
    alignment = "positional_only; scientific row identity remains unverified"
    aligned_values = values if method == "friedman" else [x, y] if method in PAIRED_METHODS else []
    named = [getattr(v, "index", None) for v in aligned_values]
    named = [index for index in named if index is not None and not callable(index)]
    if named:
        if len(named) != len(aligned_values):
            raise ValueError("Paired/repeated inputs mix named and unnamed rows; supply an explicitly aligned representation")
        if any(not getattr(index, "is_unique", False) for index in named):
            raise ValueError("Paired/repeated row indexes must be unique; repeated units need a reviewed design")
        if any(not named[0].equals(index) for index in named[1:]):
            raise ValueError("Paired/repeated row indexes differ; no sorting or joining was performed")
        alignment = "matching named row indexes; scientific pairing is still a manual assumption"
    return cells, alignment


def _context(method, metadata, split_role):
    if metadata is None:
        metadata = {}
    allowed = {"sample_relationship", "measurement_scale", "estimand", "source_split", "outcome_units"}
    if not isinstance(metadata, dict) or set(metadata) - allowed:
        raise ValueError("Statistical metadata supports sample_relationship, measurement_scale, estimand, source_split and outcome_units")
    data = deepcopy(metadata)
    if not isinstance(split_role,str) or split_role not in SPLITS:
        raise ValueError("Invalid statistical split_role")
    if "source_split" in data:
        if not isinstance(data["source_split"],str) or data["source_split"] not in SPLITS or (split_role != "unknown" and split_role != data["source_split"]):
            raise ValueError("Statistical source_split is invalid or conflicts with split_role")
        split_role = data["source_split"]
    for key in allowed - {"source_split"}:
        if key in data:
            _text(data[key], key)
    scales = ({"categorical"} if method in {"chi_square", "fisher_exact", "mcnemar_exact"} else {"binary"} if method == "binomial_test" else
              {"continuous", "ordinal"} if method in {"mann_whitney", "wilcoxon_signed_rank", "kruskal_wallis", "friedman", "spearman_correlation"} else {"continuous"})
    expected = {"sample_relationship": [RELATIONSHIPS[method]], "measurement_scale": sorted(scales), "estimand": [ESTIMANDS[method]]}
    rows, incompatible = [], []
    for req, accepted in expected.items():
        declared = data.get(req)
        bad = declared is not None and declared not in accepted
        if bad:
            incompatible.append(req)
        rows.append(evidence(req, "fail" if bad else "not_checked",
            "Declared design is incompatible with this bounded procedure" if bad else "Caller context requires named human justification; metadata is not verification",
            source="automated" if bad else "manual_required",
            observed={"declared": declared, "supported_values": accepted, "comparison": "declared context versus implemented design", "group": "supplied study design"},
            thresholds={"configuration": "exact bounded design supported by this adapter"},
            limitations=["This is a compatibility check, not proof of design, scale or estimand truth."],
            remedies=["Use an appropriate procedure/design or supply the missing context and named scientific justification."],
            provenance={"implementation": "model-evidence/"+VERSION, "source_split": split_role}))
    return data, split_role, rows, incompatible


def _uncomputed(method, reason):
    return {"sample_sizes": {"n": 0}, "statistical_test": {
        "procedure": method, "computational_status": "not_computable", "statistic_name": "not computed",
        "statistic": None, "p_value": None, "degrees_of_freedom": None, "alternative": "two-sided",
        "null": {"parameter": "procedure-specific null", "value": None},
        "effect": {"name": "not computed", "estimate": None, "units": "not supplied", "confidence_interval": None},
        "groups": [], "configuration": {"no_data_repair": True}, "warnings": [reason],
        "limitations": ["No numerical result is substituted for an incompatible or invalid analysis."]}}


def audit_test(method, x, y=None, *, purpose="association", metadata=None, attestations=None,
               test_options=None, split_role="unknown"):
    """Audit one prespecified supported procedure, returning a pure core report.

    ``x`` is a sample, a list of group arrays, a count table, or success count;
    ``y`` is the second/paired sample or binomial trial count. Test options are
    null_value, confidence and alpha only. All tests here are two-sided. Missing
    design evidence blocks stronger claims while allowing conditional numbers.
    """
    if not isinstance(method, str) or method not in STATISTICAL_METHODS:
        raise ValueError("Unsupported statistical procedure; inspect list_methods() for explicit implemented coverage")
    if purpose not in load_registry()["use_cases"]:
        raise ValueError("Unknown intended purpose")
    if purpose not in {"association", "description"}:
        raise ValueError("Statistical procedures support association or description; they do not establish causal effects or prediction")
    if test_options is None:
        test_options = {}
    if not isinstance(test_options, dict) or set(test_options) - {"null_value", "confidence", "alpha"}:
        raise ValueError("test_options supports null_value, confidence and alpha; no automatic test selection is supported")
    options = deepcopy(test_options)
    alpha, confidence = options.get("alpha", .05), options.get("confidence", .95)
    for name, value in (("alpha", alpha), ("confidence", confidence)):
        if type(value) not in {int, float} or not 0 < value < 1 or not math.isfinite(value):
            raise ValueError(name + " must be a finite number strictly between zero and one")
    context, role, rows, incompatible = _context(method, metadata, split_role)
    cells, alignment, problem = 0, "not assessed", None
    if not incompatible:
        try:
            cells, alignment = _input_summary(method, x, y)
        except ValueError as exc:
            problem = str(exc)
    if incompatible or problem:
        result = _uncomputed(method, problem or "Declared design/measurement/estimand is outside this procedure's supported scope")
    else:
        null = options.get("null_value", .5 if method == "binomial_test" else 0.)
        try:
            if method in MEAN_METHODS:
                from .statistical_mean import compute_mean_test
                result = compute_mean_test(method, x, y, null_value=null, confidence=confidence)
            elif method in EXTENDED_METHODS:
                from .statistical_extensions import compute_extended_test
                result = compute_extended_test(method, x, y, null_value=null, confidence=confidence)
            else:
                from .statistical_other import compute_other_test
                result = compute_other_test(method, x, y, null_value=null, confidence=confidence)
        except (ValueError, TypeError, OverflowError) as exc:
            result = _uncomputed(method, "Numerical input/reference conditions are unsupported: "+str(exc)[:500])
            problem = "Input/reference validation failed; inspect the recorded bounded reason"
    detail = result["statistical_test"]
    detail.update(source_split=role, row_alignment=alignment, design_context=context,
                  alpha=float(alpha), p_comparison={"comparison": "not computable" if detail["p_value"] is None else
                      "p < alpha" if detail["p_value"] < alpha else "p >= alpha",
                      "alpha": float(alpha), "meaning": "Tail probability under the stated null/reference, not the probability the null is true or an assumption test pass"})
    if context.get("outcome_units") and method in MEAN_METHODS - {"anova"}:
        detail["effect"]["units"] = context["outcome_units"]
    n = result["sample_sizes"].get("n", 0)
    finite_status = "fail" if problem else "no_issue_detected" if cells else "not_checked"
    rows.append(evidence("missingness", finite_status, "Supplied finite inputs; no deletion, imputation or repair" if not problem else problem,
        source="manual_required" if finite_status == "not_checked" else "automated", sample_size=n,
        observed={"inspected_cells": cells, "comparison": "all supplied cells versus finite-value requirement", "source_split": role},
        thresholds={"maximum_nonfinite": 0}, limitations=["Missingness mechanisms and unseen excluded records require separate review."],
        remedies=["Review the source and missingness mechanism; make any handling explicit before rerunning."], provenance={"implementation": "model-evidence/"+VERSION}))
    computed = detail["computational_status"] == "computed"
    rows.append(evidence("target_compatibility", "no_issue_detected" if computed else "fail", "Selected numerical procedure and reference are computable" if computed else "Numerical procedure was not computed",
        sample_size=n, observed={"procedure": method, "computational_status": detail["computational_status"],
            "comparison": "provided numeric support versus bounded procedure requirements", "warnings": detail["warnings"]},
        thresholds={"configuration": detail["configuration"]}, limitations=["Computability does not establish scientific measurement, design or assumption validity."],
        remedies=["Inspect the selected procedure, sample support and intended estimand; never silently switch tests."], provenance={"implementation": "model-evidence/"+VERSION}))
    reqs = describe_requirements(method, purpose)["requirements"]
    if detail["warnings"] and computed:
        req = "distributional_approximation" if "distributional_approximation" in reqs else "target_compatibility"
        if req == "target_compatibility":
            target = rows[-1]
            target["status"] = "warning"
            target["limitations"].extend(detail["warnings"])
        else:
            rows.append(evidence(req, "warning", "Procedure-specific approximation/sample limitations require review", sample_size=n,
                observed={"warnings": detail["warnings"], "comparison": "actual sample/reference conditions versus stated approximation limits"},
                thresholds={"configuration": detail["configuration"]}, limitations=detail["limitations"],
                remedies=["Review the reference distribution, design and sample limitations; no automatic replacement test is chosen."], provenance={"implementation": "model-evidence/"+VERSION}))
    rows = _complete(method, purpose, rows, attestations)
    limitations = ["The procedure was supplied, never selected from diagnostic or outcome p-values.",
        "All p-values and intervals are conditional on their reference model and study design. Non-rejection does not prove a null hypothesis, equivalence or assumptions.",
        "The metadata and source split are caller declarations. Multiplicity, selection, sampling, pairing and scientific assumptions require explicit evidence.",
        "No effect is causal from a test result; absence of significance is not evidence of no important effect."] + detail["limitations"]
    from .statistical_visuals import statistical_visuals
    visuals=statistical_visuals(method,x,y,detail,source_split=role)
    return make_report(method, purpose, rows, result["sample_sizes"], {"statistical_test": detail,"visual_evidence":visuals,
        "adapter_status": "supported_statistical_test" if computed else "failed",
        "adapter": {"library": "SciPy", "procedure": method, "model_refit": False, "source_split": role,
                    "raw_records_returned": False, "row_alignment": alignment}}, limitations)
