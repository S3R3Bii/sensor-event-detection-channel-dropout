"""Bounded right-censored Kaplan-Meier description through statsmodels.

The numeric product-limit calculation does not verify independent censoring,
sampling, an event definition or a time origin. No observations are removed,
no competing-event model is substituted and no event-only prediction loss is
computed. The optional backend is imported only when this adapter is called.
"""
from __future__ import annotations

from copy import deepcopy
import math
import warnings

import numpy as np

from .diagnostics import _complete
from . import model_visuals as visuals
from .registry import load_registry
from .report import evidence, make_report
from ._version import VERSION


MAX_N = 1_000_000
MAX_TIME = 1e40
MAX_RISK_ROWS = 65
MAX_CURVE_EVENTS = 31
SPLITS = frozenset({"unknown", "training", "validation", "evaluation", "final_holdout", "not_applicable"})
LIMITS = [
    "Kaplan-Meier estimates are conditional on an appropriate common time origin, event definition, independent analysis units and noninformative right censoring; arrays cannot verify these conditions.",
    "Censoring is not survival or absence of an event. A survival curve can remain above zero when observation ends without identifying the unobserved tail or a median.",
    "Small risk sets make tail estimates fragile. No sample-size threshold, p-value or visually smooth curve proves adequate information or independent censoring.",
    "This adapter does not implement competing-risk cumulative incidence, left truncation/delayed entry, interval censoring, covariate adjustment, weights, clustered inference or a Cox model.",
    "No pointwise confidence interval or simultaneous confidence band is implemented. Native Greenwood standard errors are retained where defined; they do not validate the censoring design.",
    "Event/censor counts, event times and survival aggregates may still be sensitive. No individual identifiers, input row indexes or original record pairs are exported.",
]


def _text(value, name, maximum=128):
    if not isinstance(value, str) or not value.strip() or len(value) > maximum or any(ord(c) < 32 for c in value):
        raise ValueError(name + " must be bounded nonempty plain text")
    return value


def _vector(value, name, *, event=False):
    if np.ma.isMaskedArray(value) and np.ma.getmaskarray(value).any():
        raise ValueError(name + " contains masked cells; no rows are silently removed")
    index = getattr(value, "index", None)
    named = index is not None and callable(getattr(index, "equals", None))
    if named and not index.is_unique:
        raise ValueError(name + " has duplicate named row indexes; resolve the analysis grain explicitly")
    if isinstance(value, (list, tuple)) and not event and any(isinstance(v, (bool, np.bool_)) for v in value):
        raise ValueError("time cannot contain boolean durations")
    raw = np.asarray(value)
    allowed = "biuf" if event else "iuf"
    if raw.ndim != 1 or not 1 <= raw.size <= MAX_N or raw.dtype.kind not in allowed:
        raise ValueError(name + " must be a nonempty bounded one-dimensional real numeric array without string/object coercion")
    if raw.dtype.kind == "f" and raw.dtype.itemsize > 8:
        raise ValueError(name + " exceeds the supported numeric precision")
    result = np.array(raw, dtype=float, copy=True)
    if not np.isfinite(result).all():
        raise ValueError(name + " contains nonfinite/missing cells; no rows are silently removed")
    if event:
        if not np.isin(result, [0., 1.]).all():
            raise ValueError("event must be binary: 1 observed event, 0 right censoring; competing event codes are unsupported")
    elif np.any(result < 0) or np.any(result > MAX_TIME):
        raise ValueError("time must contain nonnegative finite durations at most 1e40 in a common declared unit")
    return result, index if named else None


def _context(metadata, split_role):
    if metadata is None:
        metadata = {}
    allowed = {"time_units", "time_zero", "event_definition", "censoring_type", "sample_relationship", "estimand", "source_split"}
    if not isinstance(metadata, dict) or set(metadata) - allowed:
        raise ValueError("Survival metadata supports only time_units, time_zero, event_definition, censoring_type, sample_relationship, estimand and source_split; entry, weights, competing risks and covariates are unsupported")
    context = deepcopy(metadata)
    if not isinstance(split_role, str) or split_role not in SPLITS:
        raise ValueError("Invalid survival split_role")
    if "source_split" in context:
        declared = context["source_split"]
        if not isinstance(declared, str) or declared not in SPLITS or (split_role != "unknown" and declared != split_role):
            raise ValueError("source_split is invalid or conflicts with split_role")
        split_role = declared
    for key in allowed - {"source_split"}:
        if key in context:
            _text(context[key], key, 512 if key in {"time_zero", "event_definition"} else 128)
    if context.get("censoring_type", "right") != "right":
        raise ValueError("Only ordinary right censoring is supported; no interval/left/competing-risk estimator was substituted")
    if context.get("sample_relationship", "independent") != "independent":
        raise ValueError("Repeated/clustered survival records require a different reviewed design; no independent-unit analysis is substituted")
    if context.get("estimand", "survival_probability") != "survival_probability":
        raise ValueError("This adapter describes S(t)=P(T>t), not a hazard ratio, competing-risk incidence, causal effect or event-time prediction error")
    return context, split_role


def _backend():
    try:
        import statsmodels
        from statsmodels.duration.survfunc import SurvfuncRight
    except ImportError as exc:
        raise ValueError("Kaplan-Meier requires the optional statsmodels dependency (tested 0.14.6); no alternate estimator was substituted") from exc
    return SurvfuncRight, statsmodels.__version__


def _nullable(value):
    value = float(value)
    return value if math.isfinite(value) else None


def _projection(event_times, survival, max_followup):
    count = len(event_times)
    if count > MAX_CURVE_EVENTS:
        positions = np.unique(np.linspace(0, count - 1, min(count, 65), dtype=int))
        return {"x":[float(event_times[i]) for i in positions],
                "y":[float(survival[i]) for i in positions], "coarsened":True,
                "event_points_shown":len(positions), "event_points_total":count,
                "display_style":"native_points",
                "interpolation":"none: exact native event-time probability points without connectors; intermediate times and omitted jumps are not drawn"}
    positions = np.unique(np.linspace(0, count - 1, min(count, MAX_CURVE_EVENTS), dtype=int)) if count else np.array([], dtype=int)
    x, y = [0.], [1.]
    previous = 1.
    for position in positions:
        point = float(event_times[position])
        current = float(survival[position])
        x.extend([point, point])
        y.extend([previous, current])
        previous = current
    if x[-1] < max_followup:
        x.append(float(max_followup))
        y.append(previous)
    return {"x": x, "y": y, "coarsened": count > MAX_CURVE_EVENTS,
            "event_points_shown": len(positions), "event_points_total": count,
            "display_style":"exact_steps", "interpolation":"exact right-continuous step path through all native event times within observed follow-up"}


def _risk_rows(time, event, native):
    unique, inverse = np.unique(time, return_inverse=True)
    event_counts = np.bincount(inverse, weights=event, minlength=len(unique)).astype(int)
    total_counts = np.bincount(inverse, minlength=len(unique))
    censor_counts = total_counts - event_counts
    risk = len(time) - np.r_[0, np.cumsum(total_counts[:-1])]
    positions = np.unique(np.linspace(0, len(unique) - 1, min(len(unique), MAX_RISK_ROWS), dtype=int))
    rows = []
    for i in positions:
        time_value = float(unique[i])
        j = int(np.searchsorted(native.surv_times, time_value, side="right") - 1)
        survival = 1. if j < 0 else float(native.surv_prob[j])
        standard_error = None if j < 0 else _nullable(native.surv_prob_se[j])
        rows.append({"time": time_value, "n_at_risk_before": int(risk[i]),
                     "events_at_time": int(event_counts[i]), "censored_at_time": int(censor_counts[i]),
                     "survival_probability": survival, "greenwood_standard_error": standard_error,
                     "standard_error_status": "not_available_no_event_by_checkpoint" if j < 0 else "native_undefined_at_boundary" if standard_error is None else "computed_native_greenwood"})
    return rows, len(unique)


def _visuals(detail, n, split_role):
    units = detail["time_units"]
    projected = detail["curve_projection"]
    coarsened = projected["coarsened"]
    projection_limit = ("More than 31 event times: at most 65 exact native event-time probabilities are shown as unconnected points. Omitted times and intermediate steps are not drawn or interpolated."
                        if coarsened else "All native event times are shown as exact steps; flat extension ends at the maximum observed follow-up, not beyond it.")
    panels = [visuals._curve("kaplan_meier_points" if coarsened else "kaplan_meier_curve", "Native Kaplan-Meier estimates at selected event times" if coarsened else "Kaplan-Meier right-censored survival", projected["x"], projected["y"], n, split_role,
        role="main_result", units="x: " + units + "; y: estimated survival probability",
        comparison="Native product of (1 - events / risk set) factors; " + str(projected["event_points_shown"]) + " of " + str(projected["event_points_total"]) + " event times displayed; " + ("unconnected native points; no interpolation" if coarsened else "all exact steps starting at 1"),
        interpretation="S(t) is estimated probability of the event occurring after t under the unverified independent-censoring and sampling design. No causal or external-validity conclusion follows.",
        limitations=[projection_limit, "Pointwise intervals and simultaneous bands are not implemented; no uncertainty band is implied by this curve.", LIMITS[0]],
        axes={"x":"Duration from the assumed time zero (" + units + ")", "y":"Estimated S(t)=P(T>t)"})]
    panels.append(visuals._bars("survival_status_counts", "Observed events and right-censoring", ["observed event", "right censored"],
        [detail["event_count"], detail["censored_count"]], n, split_role, role="descriptive", units="observations (counts)",
        comparison="Recorded event status among all " + str(n) + " supplied units; right censoring is not event-free follow-up forever",
        interpretation="Censoring fraction " + format(detail["censoring_fraction"], ".4g") + " describes observation completeness; it does not test independent censoring.",
        limitations=[LIMITS[0], LIMITS[1]]))
    rows = detail["risk_table"]
    panels.append(visuals._curve("survival_risk_set", "Risk set before observed follow-up checkpoints", [r["time"] for r in rows],
        [r["n_at_risk_before"] for r in rows], n, split_role, role="diagnostic", requirement="event_information",
        units="x: " + units + "; y: units at risk immediately before checkpoint",
        comparison="At-risk count includes events and censorings tied at the checkpoint; " + str(len(rows)) + " of " + str(detail["unique_followup_time_count"]) + " unique follow-up times shown",
        interpretation="Declining risk sets qualify the supported follow-up range. No automatic adequacy threshold or deletion is applied.",
        limitations=["Unconnected points show selected checkpoint counts; omitted times are not interpolated. Risk counts are not independent sample sizes that can be added.", LIMITS[2]],
        axes={"x":"Follow-up checkpoint (" + units + ")", "y":"At-risk units immediately before checkpoint"}))
    panels.append(visuals.status_panel("survival_censoring_assumption", "Independent censoring and time origin", n=n, source_split=split_role,
        requirement="censoring", message="Design requirement, not numerically verified: justify the event definition, common time zero, entry/follow-up process and noninformative right censoring. Any supplied named human assessment appears separately in the evidence checklist.",
        comparison="Observed censor counts versus unobserved post-censor event times; the latter are unavailable",
        interpretation="Neither balanced counts, low censoring nor a completed Kaplan-Meier calculation proves independent censoring.", limitations=[LIMITS[0]]))
    panels.append(visuals.status_panel("survival_interval_coverage", "Survival uncertainty intervals", n=n, source_split=split_role,
        message="Pointwise confidence intervals and simultaneous survival bands are not implemented in this adapter. Native Greenwood standard errors appear in the risk table where defined.",
        interpretation="No interval coverage or confidence-band claim is supported by this release.", limitations=[LIMITS[4]]))
    return visuals._finish(n, split_role, panels)


def audit_survival(time, event, *, purpose="description", metadata=None, attestations=None, split_role="unknown"):
    """Describe a right-censored sample using the native Kaplan-Meier estimator.

    ``event`` is 1 for an observed event and 0 for right censoring. Durations
    must be aligned, nonnegative finite values in one common unit. The pure API
    writes no files. Invalid/unsupported inputs raise ValueError before analysis.
    Metadata declarations do not replace named design attestations or prove them.
    """
    if purpose not in load_registry()["use_cases"] or purpose != "description":
        raise ValueError("Kaplan-Meier supports bounded survival description only; no association, causal-effect or prediction adapter is implied")
    context, role = _context(metadata, split_role)
    durations, time_index = _vector(time, "time")
    events, event_index = _vector(event, "event", event=True)
    if len(durations) != len(events):
        raise ValueError("time and event must have the same length in the same row order")
    if (time_index is None) != (event_index is None):
        raise ValueError("time and event mix named and unnamed rows; supply an explicitly aligned representation")
    if time_index is not None and not time_index.equals(event_index):
        raise ValueError("time and event pandas indexes differ in values or order; no sorting or joining was performed")
    SurvfuncRight, backend_version = _backend()
    with warnings.catch_warnings(record=True) as native_warnings:
        warnings.simplefilter("always")
        native = SurvfuncRight(durations, events)
    n = len(durations)
    event_count = int(events.sum())
    event_times = np.asarray(native.surv_times, dtype=float)
    survival = np.asarray(native.surv_prob, dtype=float)
    if not np.isfinite(event_times).all() or not np.isfinite(survival).all() or np.any((survival < 0) | (survival > 1)):
        raise ValueError("Native survival curve is nonfinite or outside probability bounds; no substitute estimate was produced")
    rows, unique_count = _risk_rows(durations, events, native)
    median = _nullable(native.quantile(.5))
    units = context.get("time_units", "duration units (unspecified)")
    detail = {"adapter_status":"computed", "estimator":"Kaplan-Meier product limit",
        "backend":"statsmodels.duration.survfunc.SurvfuncRight", "backend_version":backend_version,
        "source_split":role, "row_alignment":"matching named index order; scientific identity unverified" if time_index is not None else "positional only; scientific identity unverified",
        "event_count":event_count, "censored_count":n-event_count, "censoring_fraction":(n-event_count)/n,
        "native_event_time_count":len(event_times), "unique_followup_time_count":unique_count,
        "minimum_observed_followup":float(np.min(durations)), "maximum_observed_followup":float(np.max(durations)),
        "time_units":units, "median_survival":median,
        "median_status":"reached under backend strict S(t)<0.5 quantile definition" if median is not None else "not_reached under backend strict S(t)<0.5 quantile definition; not extrapolated",
        "median_definition":"native statsmodels quantile(0.5): earliest native event time with strict computed S(t)<0.5, not <=; native floating-point and exact-half plateau conventions are retained and can differ from other packages",
        "pointwise_interval_status":"not_implemented", "simultaneous_band_status":"not_implemented",
        "native_greenwood_se_undefined_count":int(np.sum(~np.isfinite(native.surv_prob_se))),
        "native_warning_count":len(native_warnings), "risk_table":rows,
        "risk_table_scope":"all unique observed follow-up times" if unique_count <= MAX_RISK_ROWS else "at most 65 selected unique follow-up times; omitted rows are not zero counts and displayed counts must not be summed",
        "omitted_risk_rows":max(0, unique_count-len(rows)),
        "curve_projection":_projection(event_times, survival, float(np.max(durations))),
        "design_context":context, "records_exported":False, "no_data_repair":True,
        "ties":"events and censorings at a common time are both included in the risk set just before that time; events update S(t) before removal for later risk sets"}
    provenance = {"implementation":"model-evidence/"+VERSION, "backend":detail["backend"], "backend_version":backend_version, "source_split":role}
    checks = [evidence("missingness", "no_issue_detected", "All supplied durations and event indicators are finite; no cells or rows removed",
        sample_size=n, observed={"nonfinite_cells":0, "total_cells":2*n, "comparison":"nonfinite cells versus zero", "variables":["duration", "event indicator"]},
        thresholds={"maximum_nonfinite":0, "configuration":"strict finite input; no deletion/imputation"}, limitations=["Sentinel codes and the censoring/selection mechanism remain unverified."], provenance=provenance),
        evidence("target_compatibility", "no_issue_detected", "Nonnegative durations and binary observed-event/right-censor codes match this bounded calculation",
        sample_size=n, observed={"minimum_duration":float(np.min(durations)), "maximum_duration":float(np.max(durations)), "event_count":event_count, "right_censored_count":n-event_count, "comparison":"duration>=0 and status in{0,1}", "variables":["duration", "event indicator"]},
        thresholds={"minimum_duration":0, "supported_event_codes":[0,1], "censoring_type":"right only"}, limitations=["Numeric compatibility does not verify the event definition, time zero, independence or censoring assumptions."], provenance=provenance),
        evidence("event_information", "warning" if event_count == 0 else "no_issue_detected", "No observed events; the curve remains at 1 within observed follow-up and the event-time distribution is unresolved" if event_count == 0 else "Observed events and risk-set denominators are reported; no event-count adequacy certificate",
        sample_size=n, observed={"event_count":event_count, "event_fraction":event_count/n, "censored_count":n-event_count, "native_event_time_count":len(event_times), "last_native_event_risk_set":int(native.n_risk[-1]) if len(event_times) else None, "comparison":"observed events versus zero; tail risk-set count is descriptive"},
        thresholds={"zero_event_warning":0, "minimum_adequate_events":"not established by this diagnostic"}, limitations=[LIMITS[1], LIMITS[2]], remedies=["Review event/follow-up information and tail risk sets; obtain more appropriate follow-up or use a reviewed alternative design rather than inventing the unseen tail."], provenance=provenance),
        evidence("censoring", "not_checked", "Censor counts and compatibility are observed; independent censoring, event definition and common time zero require study evidence",
        source="manual_required", sample_size=n, observed={"censored_count":n-event_count, "censoring_fraction":(n-event_count)/n, "comparison":"recorded right censoring versus unavailable post-censor event times", "variables":["duration", "event indicator"]},
        thresholds={"configuration":"no statistical test can certify independent censoring from these two arrays"}, limitations=[LIMITS[0]], remedies=["Document common time zero, follow-up, loss reasons and noninformative censoring; assess sensitivity to plausible informative loss."], provenance=provenance)]
    checks = _complete("kaplan_meier", purpose, checks, attestations)
    estimates = {"adapter_status":"computed", "survival":detail, "visual_evidence":_visuals(detail, n, role)}
    return make_report("kaplan_meier", purpose, checks, {"n":n, "observed_events":event_count, "right_censored":n-event_count}, estimates, LIMITS)
