"""Pure, bounded mean-comparison calculations with conditional interpretations.

No test selection, missing-value deletion, normality pretest, data repair,
identifier export or model refit occurs here. Design/claim gating belongs to the
report wrapper; a computed p-value is not evidence that its assumptions hold.
"""
import math
from numbers import Real
import warnings

import numpy as np
import scipy
from scipy import stats

METHODS={"one_sample_t_test","welch_t_test","student_t_test","paired_t_test","anova"}
MAX_GROUP_N=1_000_000
MAX_TOTAL_N=2_000_000
BASE_LIMITATIONS=[
    "Computed statistics, p-values and intervals are conditional on the prespecified design, sampling and distributional approximation; they do not verify those conditions.",
    "These calculations do not establish causal effects, equivalence, absence of a meaningful effect, external validity or the probability that the null hypothesis is true.",
    "No multiplicity correction, adaptive test selection, normality pretest, missing-value deletion or automatic remedy is performed.",
    "Only aggregate summaries are returned; even group summaries and differences may be sensitive.",
]


def _number(value,name):
    if isinstance(value,(bool,np.bool_)) or not isinstance(value,Real):
        raise ValueError(name+" must be a finite real number")
    try: value=float(value)
    except (ValueError,TypeError,OverflowError) as exc: raise ValueError(name+" must be a finite real number") from exc
    if not math.isfinite(value) or abs(value)>1e40: raise ValueError(name+" must be finite and bounded")
    return value


def _sample(value,name):
    if np.ma.isMaskedArray(value) and np.ma.getmaskarray(value).any():
        raise ValueError(name+" has masked observations; no values are silently omitted")
    try: raw=np.asarray(value)
    except (ValueError,TypeError) as exc: raise ValueError(name+" must be a finite numeric one-dimensional sample") from exc
    if raw.ndim!=1 or not 1<=raw.size<=MAX_GROUP_N:
        raise ValueError(name+" must be a nonempty bounded one-dimensional sample")
    if isinstance(value,(list,tuple)) and any(isinstance(v,(bool,np.bool_)) for v in value):
        raise ValueError(name+" contains boolean observations; numeric coercion is not performed")
    if raw.dtype.kind=="O":
        if any(isinstance(v,(bool,np.bool_)) or not isinstance(v,Real) for v in raw):
            raise ValueError(name+" must contain real numeric observations, without string/boolean coercion")
    elif raw.dtype.kind not in "iuf":
        raise ValueError(name+" must contain real numeric observations, without string/boolean coercion")
    try: result=np.asarray(raw,dtype=float)
    except (ValueError,TypeError,OverflowError) as exc: raise ValueError(name+" must contain bounded real observations") from exc
    if not np.isfinite(result).all() or np.any(np.abs(result)>1e40):
        raise ValueError(name+" must contain bounded finite values; missing observations are not removed")
    return result


def _paired_alignment(x,y):
    xi,yi=getattr(x,"index",None),getattr(y,"index",None)
    if callable(getattr(xi,"equals",None)) and callable(getattr(yi,"equals",None)):
        if not xi.equals(yi): raise ValueError("Paired sample row indexes differ; align explicitly, no automatic reordering")
        return "supplied_named_indexes_match; true same-unit pairing still requires design evidence"
    return "positional_pairing_only; true same-unit pairing requires design evidence"


def _summary(sample,label):
    n=int(len(sample))
    return {"label":label,"n":n,"mean":float(np.mean(sample)),
        "variance":float(np.var(sample,ddof=1)) if n>1 else None}


def _finite(value):
    if value is None: return None
    try: number=float(value)
    except (ValueError,TypeError,OverflowError): return None
    return number if math.isfinite(number) and abs(number)<=1e100 else None


def _capture(call):
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        result=call()
    labels=[]
    for item in caught:
        message="SciPy issued "+item.category.__name__+"; precision or degeneracy may limit this calculation."
        if message not in labels: labels.append(message)
    return result,labels


def _interval(result,confidence,method):
    interval=result.confidence_interval(confidence_level=confidence)
    low,high=_finite(interval.low),_finite(interval.high)
    if low is None or high is None or low>high: return None
    return {"level":confidence,"lower":low,"upper":high,"method":method}


def _base(method,confidence,null_value,groups,sizes,effect_name,effect_estimate):
    return {"sample_sizes":sizes,"statistical_test":{
        "procedure":method,"computational_status":"not_computable","statistic_name":"F" if method=="anova" else "t",
        "statistic":None,"p_value":None,"degrees_of_freedom":None,"alternative":"two-sided",
        "null":{"parameter":"population_mean" if method=="one_sample_t_test" else "population_mean_difference_x_minus_y","value":null_value},
        "effect":{"name":effect_name,"estimate":_finite(effect_estimate),"units":"dimensionless" if method=="anova" else "outcome units (not supplied)","confidence_interval":None},
        "groups":groups,"configuration":{"confidence_level":confidence,"nan_policy":"raise","sample_variance_ddof":1,
            "test_selection":"caller-specified; no normality or variance pretest","multiplicity_adjustment":"none",
            "reference":"theoretical t" if method!="anova" else "classical one-way independent-groups F",
            "scipy_version":scipy.__version__},"warnings":[],"limitations":list(BASE_LIMITATIONS)}}


def _not_computable(result,message):
    test=result["statistical_test"]
    test["computational_status"]="not_computable"
    test["statistic"]=None;test["p_value"]=None;test["effect"]["confidence_interval"]=None
    test["warnings"].append(message)
    return result


def _finish_t(output,native,confidence,ci_method,extra_warnings=None,*,statistic=None,pvalue=None):
    test=output["statistical_test"]
    test["degrees_of_freedom"]=_finite(native.df)
    statistic=_finite(native.statistic if statistic is None else statistic)
    pvalue=_finite(native.pvalue if pvalue is None else pvalue)
    test["warnings"].extend(extra_warnings or [])
    if statistic is None or pvalue is None or not 0<=pvalue<=1 or test["degrees_of_freedom"] is None or test["degrees_of_freedom"]<=0:
        return _not_computable(output,"No finite positive-df t reference result was available; no infinite statistic or substitute p-value is emitted.")
    ci=_interval(native,confidence,ci_method)
    if ci is None:
        return _not_computable(output,"A finite confidence interval was unavailable at the requested level; no finite-looking interval was substituted.")
    test.update(statistic=statistic,p_value=pvalue,computational_status="computed")
    test["effect"]["confidence_interval"]=ci
    return output


def _anova(x,y,null_value,confidence):
    if y is not None: raise ValueError("anova takes a sequence of groups in x; y must be absent")
    if null_value!=0.: raise ValueError("anova tests equality of population means, not a supplied common mean; null_value must remain its default zero")
    if np.ma.isMaskedArray(x) and np.ma.getmaskarray(x).any(): raise ValueError("ANOVA groups contain masked observations")
    if not isinstance(x,(list,tuple,np.ndarray)) or (isinstance(x,np.ndarray) and x.ndim==0) or not 2<=len(x)<=32:
        raise ValueError("anova requires a sequence of 2 to 32 numeric groups")
    samples=[];total=0
    for i,value in enumerate(x):
        sample=_sample(value,"group_"+str(i+1));total+=len(sample)
        if total>MAX_TOTAL_N: raise ValueError("Total ANOVA observations exceed the bounded size")
        samples.append(sample)
    summaries=[_summary(value,"group_"+str(i+1)) for i,value in enumerate(samples)]
    k=len(samples);grand=float(sum(len(v)*float(np.mean(v)) for v in samples)/total)
    between=float(sum(len(v)*(float(np.mean(v))-grand)**2 for v in samples))
    within=float(sum(np.sum((v-np.mean(v))**2) for v in samples));total_ss=between+within
    eta=between/total_ss if total_ss>0 else None
    sizes={"n":total,"groups":k,**{"n_group_"+str(i+1):len(v) for i,v in enumerate(samples)}}
    output=_base("anova",confidence,None,summaries,sizes,"eta_squared",eta);test=output["statistical_test"]
    test["null"]={"parameter":"all_population_means_equal","value":None}
    test["degrees_of_freedom"]={"numerator":k-1,"denominator":total-k}
    test["configuration"].update(equal_var=True,native_function="scipy.stats.f_oneway",
        alternative_definition="omnibus unequal means; F uses its upper-tail reference, not a doubled-tail F p-value",
        effect_definition="observed between-group sum of squares / total sum of squares",
        sum_of_squares={"between":between,"within":within,"total":total_ss},
        confidence_interval_status="eta-squared confidence interval not implemented")
    test["limitations"].extend(["Classical one-way ANOVA requires independent observations and an appropriate common-variance/error-distribution approximation; equal variances are not verified here.",
        "The omnibus F comparison does not identify which groups differ. Eta squared is an observed descriptive fraction, not a causal effect; its confidence interval is unimplemented."])
    if any(len(v)<2 for v in samples):
        return _not_computable(output,"This implementation requires at least two observations in every group for sample variances and its classical ANOVA reference.")
    if within<=0 or total_ss<=0:
        return _not_computable(output,"Observed within-group variance is zero; a finite classical F statistic/reference is unavailable. Descriptive means and any defined eta squared are retained.")
    native,warn=_capture(lambda:stats.f_oneway(*samples,nan_policy="raise"))
    statistic,pvalue=_finite(native.statistic),_finite(native.pvalue)
    test["warnings"].extend(warn)
    if any(s["variance"]==0 for s in summaries):
        test["warnings"].append("At least one group has zero observed sample variance; common-variance/reference conditions require review.")
    if statistic is None or pvalue is None or not 0<=pvalue<=1:
        return _not_computable(output,"SciPy did not return a finite classical F result; no infinite statistic or substitute p-value is emitted.")
    test.update(statistic=statistic,p_value=pvalue,computational_status="computed")
    return output


def compute_mean_test(method,x,y=None,*,null_value=0.0,confidence=0.95):
    """Compute a prespecified two-sided t comparison or classical one-way ANOVA.

    Effects/intervals use the original outcome units: a one-sample population
    mean, an independent/paired population mean difference x-y, or ANOVA's
    descriptive eta squared (without a CI). Pairing is positional unless matching
    named indexes are supplied; true study pairing still needs design evidence.
    """
    if not isinstance(method,str) or method not in METHODS: raise ValueError("Unknown supported mean-test procedure")
    null_value=_number(null_value,"null_value");confidence=_number(confidence,"confidence")
    if not 0<confidence<1: raise ValueError("confidence must be strictly between zero and one")
    if method=="anova": return _anova(x,y,null_value,confidence)
    if method=="one_sample_t_test" and y is not None: raise ValueError("one_sample_t_test accepts only x")
    if method!="one_sample_t_test" and y is None: raise ValueError(method+" requires two samples")
    alignment=_paired_alignment(x,y) if method=="paired_t_test" else None
    a=_sample(x,"x");b=None if y is None else _sample(y,"y")
    if b is not None and len(a)+len(b)>MAX_TOTAL_N: raise ValueError("Total observations exceed the bounded size")
    groups=[_summary(a,"x")]
    if b is not None: groups.append(_summary(b,"y"))
    if method=="paired_t_test":
        if len(a)!=len(b): raise ValueError("paired_t_test requires equal-length aligned samples")
        difference=a-b;groups.append(_summary(difference,"paired_differences_x_minus_y"))
        sizes={"n":len(a),"pairs":len(a),"n_x":len(a),"n_y":len(b),"n_records":2*len(a)}
        effect=float(np.mean(difference));effect_name="paired_mean_difference_x_minus_y"
    elif b is None:
        sizes={"n":len(a),"n_x":len(a),"groups":1};effect=float(np.mean(a));effect_name="mean"
    else:
        sizes={"n":len(a)+len(b),"n_x":len(a),"n_y":len(b),"groups":2}
        effect=float(np.mean(a)-np.mean(b));effect_name="mean_difference_x_minus_y"
    output=_base(method,confidence,null_value,groups,sizes,effect_name,effect);test=output["statistical_test"]
    test["configuration"]["effect_definition"]="raw population mean" if b is None else "raw population mean difference x minus y, not a standardized effect"
    if alignment is not None: test["configuration"]["pairing_alignment"]=alignment
    if b is None or method=="paired_t_test":
        sample=a if b is None else difference
        variance=groups[0 if b is None else 2]["variance"]
        test["degrees_of_freedom"]=len(sample)-1
        test["configuration"].update(equal_var=None,native_function="scipy.stats.ttest_1samp" if b is None or null_value!=0 else "scipy.stats.ttest_rel")
        test["limitations"].append("The t reference concerns the mean of the sample or paired differences, not normal features or independent measurements within a pair; independence between analysis units and the relevant approximation remain unverified.")
        if len(sample)<2: return _not_computable(output,"At least two analysis units are required for sample variance and positive t degrees of freedom.")
        if variance is None or variance<=0:
            return _not_computable(output,"Sample/paired-difference variance is zero at the working numerical precision; t uncertainty is not computable. The observed effect is retained.")
        native,warn=_capture(lambda:stats.ttest_1samp(sample,popmean=null_value,nan_policy="raise",alternative="two-sided") if b is None or null_value!=0 else stats.ttest_rel(a,b,nan_policy="raise",alternative="two-sided"))
        test["configuration"]["standard_error"]=float(math.sqrt(variance/len(sample)))
        return _finish_t(output,native,confidence,"Student t interval for the population mean" if b is None else "Student t interval for the paired population mean difference",warn)
    equal_var=method=="student_t_test"
    test["configuration"].update(equal_var=equal_var,native_function="scipy.stats.ttest_ind")
    test["limitations"].append("Independent-sample t comparisons require independent analysis units and a justified mean/sampling approximation. " +
        ("Student's pooled test additionally assumes equal population variances; no equality test or verification was performed." if equal_var else "Welch does not assume equal population variances; it does not repair dependence, selection or a wrong estimand."))
    if min(len(a),len(b))<2: return _not_computable(output,"Both groups require at least two observations for their sample variances and the supported t reference.")
    va,vb=groups[0]["variance"],groups[1]["variance"]
    if equal_var:
        pooled=((len(a)-1)*va+(len(b)-1)*vb)/(len(a)+len(b)-2)
        se_squared=pooled*(1/len(a)+1/len(b));test["configuration"]["pooled_variance"]=float(pooled)
        test["degrees_of_freedom"]=len(a)+len(b)-2
    else:
        se_squared=va/len(a)+vb/len(b)
        denominator=(va/len(a))**2/(len(a)-1)+(vb/len(b))**2/(len(b)-1)
        test["degrees_of_freedom"]=_finite(se_squared**2/denominator) if denominator>0 else None
        if se_squared>0 and denominator<=0:
            return _not_computable(output,"Welch reference degrees of freedom underflowed at the working numerical precision; no fallback df or p-value is treated as reliable.")
    if not math.isfinite(se_squared) or se_squared<=0:
        return _not_computable(output,"Observed difference standard error is zero or nonfinite; no finite-looking t statistic, p-value or interval is substituted.")
    native,warn=_capture(lambda:stats.ttest_ind(a,b,equal_var=equal_var,nan_policy="raise",alternative="two-sided"))
    if va==0 or vb==0: warn.append("At least one group has zero observed sample variance; the numerical reference and study assumptions require review.")
    se=math.sqrt(se_squared);test["configuration"]["standard_error"]=float(se)
    if null_value!=0.:
        # Public ttest_ind tests zero difference. Change only the tested contrast,
        # retaining native reference df and its interval for the unshifted effect.
        statistic=(effect-null_value)/se;pvalue=2*float(stats.t.sf(abs(statistic),float(native.df)))
        test["configuration"]["native_function"]="scipy.stats.ttest_ind + scipy.stats.t.sf for the nonzero-null contrast"
        test["configuration"]["nonzero_null_formula"]="(mean(x)-mean(y)-null_value) / prespecified standard error; native df and raw-effect CI retained"
        return _finish_t(output,native,confidence,"Pooled Student t interval for mean difference" if equal_var else "Welch-Satterthwaite t interval for mean difference",warn,statistic=statistic,pvalue=pvalue)
    return _finish_t(output,native,confidence,"Pooled Student t interval for mean difference" if equal_var else "Welch-Satterthwaite t interval for mean difference",warn)
