"""Conditional inverse-propensity weighted contrasts, never identification.

Only supplied numeric scores are accepted. This module does not fit a treatment
or outcome model, clip/trim weights, repair data, infer an assumed causal graph,
or estimate uncertainty for estimated propensities. Reports contain aggregates.
"""
from copy import deepcopy
import math

import numpy as np

from .causal import balance_overlap, validate_causal_audit
from .diagnostics import _complete
from . import model_visuals as _visuals
from .report import evidence, make_report


SPLITS = frozenset({"unknown", "training", "validation", "evaluation", "final_holdout"})
MAX_N = 200000
MAX_OUTCOME = 1e12
MAX_REPORT_NUMBER = 1e100
IMPLEMENTATION = "supplied-propensity-hajek/0.6.0"
LIMITS = [
    "The weighted contrast is conditional arithmetic for supplied scores, not an identified or certified causal effect.",
    "Supplied propensities may be misspecified, in-sample, selected using outcomes or otherwise leaked; their origin is not reconstructed or verified.",
    "Sample overlap, effective sample size and measured balance cannot prove positivity, exchangeability, consistency, no interference or the assumed DAG.",
    "No standard error, confidence interval or p-value is implemented; estimated propensity, clustering, repeated units and design uncertainty need an appropriate prespecified analysis.",
    "No rows, scores or outcomes are removed, imputed, winsorized, clipped or trimmed; input models are never fitted or refitted.",
    "Normalized group means use Hajek weights. Changing ATE to ATT changes the intended target and the weighting formula, not merely a display label.",
    "Local aggregate means, counts, weights and assumed graph summaries can still be sensitive; this output is not anonymization.",
]


def _text(value, name, maximum=256):
    if not isinstance(value, str) or not value.strip() or len(value) > maximum or any(ord(c) < 32 for c in value):
        raise ValueError(name + " must be bounded nonempty plain text")
    return value


def _vector(value, name):
    if np.ma.isMaskedArray(value) and np.ma.getmaskarray(value).any():
        raise ValueError(name + " contains masked cells; no observations are silently removed")
    if np.iscomplexobj(value):
        raise ValueError(name + " must be real numeric values")
    try:
        result = np.asarray(value, dtype=float)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(name + " must be a finite one-dimensional numeric vector") from exc
    if result.ndim != 1 or not 4 <= result.size <= MAX_N or not np.isfinite(result).all():
        raise ValueError(name + " requires 4..200000 finite aligned values; no missing cells are removed")
    return result


def _alignment(values):
    indexes = [getattr(value, "index", None) for value in values]
    indexes = [index if index is not None and not callable(index) else None for index in indexes]
    if any(index is not None for index in indexes):
        if any(index is None for index in indexes):
            raise ValueError("Named and positional rows cannot be mixed; explicitly align all IPW inputs")
        if any(not getattr(index, "is_unique", False) for index in indexes):
            raise ValueError("Named row indexes must be unique; repeated units need a separate reviewed design")
        if any(not indexes[0].equals(index) for index in indexes[1:]):
            raise ValueError("Named IPW row indexes differ in values or order; no joining or sorting was performed")
        return "matching named row indexes; scientific unit identity and independence remain unverified"
    return "positional alignment only; scientific unit identity and independence remain unverified"


def _context(metadata):
    if metadata is None:
        metadata = {}
    allowed = {"outcome_units", "propensity_source", "propensity_fit_split", "propensity_uses_outcome"}
    if not isinstance(metadata, dict) or set(metadata) - allowed:
        raise ValueError("IPW metadata accepts only outcome_units, propensity_source, propensity_fit_split and propensity_uses_outcome")
    result = {"outcome_units": "outcome units", "propensity_source": "not supplied",
              "propensity_fit_split": "unknown", "propensity_uses_outcome": None}
    result.update(deepcopy(metadata))
    _text(result["outcome_units"], "outcome_units", 96)
    _text(result["propensity_source"], "propensity_source")
    if not isinstance(result["propensity_fit_split"], str) or result["propensity_fit_split"] not in {"unknown", "external_known", "training", "same_sample", "cross_fitted"}:
        raise ValueError("Unknown propensity_fit_split; labels are declarations, not verified provenance")
    if result["propensity_uses_outcome"] is not None and not isinstance(result["propensity_uses_outcome"], bool):
        raise ValueError("propensity_uses_outcome must be true, false or null")
    return result


def _bounds(overlap_bounds, ess_fraction_threshold, smd_threshold):
    if not isinstance(overlap_bounds, (list, tuple)) or len(overlap_bounds) != 2:
        raise ValueError("overlap_bounds must contain two finite values strictly inside (0,1)")
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) for v in overlap_bounds):
        raise ValueError("overlap_bounds must contain two finite values strictly inside (0,1)")
    if not 0 < overlap_bounds[0] < overlap_bounds[1] < 1:
        raise ValueError("overlap_bounds must lie strictly inside (0,1)")
    for value, label in ((ess_fraction_threshold, "ess_fraction_threshold"), (smd_threshold, "smd_threshold")):
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
            raise ValueError(label + " must be positive and finite")
    if ess_fraction_threshold > 1:
        raise ValueError("ess_fraction_threshold must not exceed one")
    return tuple(float(v) for v in overlap_bounds), float(ess_fraction_threshold), float(smd_threshold)


def _reported_exp(value):
    """Report a raw aggregate only if representable inside the shared contract."""
    if value > math.log(MAX_REPORT_NUMBER):
        return None
    result = math.exp(value)
    return result if math.isfinite(result) and 0 < result <= MAX_REPORT_NUMBER else None


def _group_summary(y, logweights):
    maximum = float(np.max(logweights))
    relative = np.exp(logweights - maximum)
    if not np.isfinite(relative).all() or np.any(relative <= 0):
        raise ValueError("Weight dynamic range cannot be represented without zeroing observations; no silent clipping or removal was performed")
    total = float(np.sum(relative))
    normalized = relative / total
    if np.any(normalized <= 0):
        raise ValueError("Weight normalization would erase a positive contribution; no score was clipped")
    # Scaling by each arm's maximum cancels exactly in normalized arm means and ESS.
    mean = float(np.dot(normalized, y))
    ess = float(1.0 / np.dot(normalized, normalized))
    count = int(len(y))
    raw_sum = _reported_exp(maximum + math.log(total))
    summary = {"raw_count": count, "effective_sample_size": ess,
        "effective_fraction": ess / count, "maximum_normalized_share": float(np.max(normalized)),
        "raw_weight_minimum": _reported_exp(float(np.min(logweights))),
        "raw_weight_maximum": _reported_exp(maximum), "raw_weight_sum": raw_sum,
        "raw_weight_mean": _reported_exp(maximum + math.log(total) - math.log(count)),
        "log_raw_weight_minimum": float(np.min(logweights)), "log_raw_weight_maximum": maximum,
        "raw_summary_unavailable_reason": "An unrepresentable or >1e100 raw weight summary is null; log weights, normalized means and ESS remain calculated without clipping." if any(v is None for v in (raw_sum, _reported_exp(maximum), _reported_exp(float(np.min(logweights))))) else None,
        "normalized_weight_sum": float(np.sum(normalized)),
        "normalization": "Within-arm divide by exp(max log weight), then divide by within-arm sum; invariant Hajek mean/ESS, no row or score changed"}
    return mean, summary, relative


def _causal_context(causal_audit, estimand):
    if causal_audit is None:
        return {"supplied": False, "assumed_dag_status": "missing", "edge_list": [],
                "strong_causal_language": "blocked", "conditional_interpretation": "blocked",
                "critical_blockers": ["assumed_dag", "identification_evidence"],
                "data_mapping_verified": False}
    checked = validate_causal_audit(causal_audit)
    if checked["claim"]["identification_strategy"] != "weighting":
        raise ValueError("A linked causal audit must explicitly assess the weighting identification strategy")
    if checked["claim"]["estimand"] != estimand:
        raise ValueError("The linked causal claim estimand differs from the requested weighting estimand")
    graph = checked["assumed_dag"]
    return {"supplied": True, "review_mode": checked["review_mode"],
        "identification_strategy": "weighting", "estimand": estimand,
        "assumed_dag_status": graph["status"], "edge_list": deepcopy(graph["edge_list"]),
        "exposure": graph["exposure"], "outcome": graph["outcome"],
        "strong_causal_language": "blocked",
        "conditional_interpretation": checked["language_gate"]["conditional_interpretation"],
        "critical_blockers": deepcopy(checked["language_gate"]["blockers"]),
        "data_mapping_verified": False,
        "limitation": "The supplied claim/DAG is an assumption and cited assessment; numerical array-to-question mapping and scientific design are not authenticated."}


def audit_ipw(y, treatment, propensity, *, estimand="ATE", purpose="causal_inference",
              metadata=None, causal_audit=None, attestations=None, split_role="unknown",
              covariates=None, covariate_names=None, overlap_bounds=(0.05, 0.95),
              ess_fraction_threshold=0.25, smd_threshold=0.1):
    """Audit supplied-score Hajek ATE/ATT arithmetic without fitting or repair.

    ATE uses treated 1/p and control 1/(1-p); ATT uses treated 1 and
    control p/(1-p). Each arm is normalized separately. The contrast is treated
    mean minus control mean in outcome units. No effect SE/CI/p-value is returned.
    Optional covariates produce measured balance via ``balance_overlap``; a
    successful screen never establishes exchangeability or causal validity.
    """
    if not isinstance(estimand, str) or estimand not in {"ATE", "ATT"}:
        raise ValueError("The bounded weighting calculation supports exactly ATE or ATT")
    if purpose != "causal_inference":
        raise ValueError("audit_ipw requires purpose='causal_inference'; the contrast remains conditional arithmetic")
    if not isinstance(split_role, str) or split_role not in SPLITS:
        raise ValueError("Unknown split_role")
    context = _context(metadata)
    bounds, ess_screen, smd_screen = _bounds(overlap_bounds, ess_fraction_threshold, smd_threshold)
    scientific = _causal_context(causal_audit, estimand)
    sources = [y, treatment, propensity] + ([] if covariates is None else [covariates])
    alignment = _alignment(sources)
    outcomes, groups, scores = (_vector(value, name) for value, name in ((y, "y"), (treatment, "treatment"), (propensity, "propensity")))
    n = len(outcomes)
    if len(groups) != n or len(scores) != n:
        raise ValueError("IPW inputs must have identical row counts; no joining or sorting was performed")
    if np.any(np.abs(outcomes) > MAX_OUTCOME):
        raise ValueError("Outcome magnitude exceeds the bounded 1e12 numeric scope")
    if not np.isin(groups, (0, 1)).all():
        raise ValueError("Treatment must contain exactly numeric binary 0/1 values")
    sizes = {name: int(np.sum(groups == group)) for name, group in (("control", 0), ("treated", 1))}
    if min(sizes.values()) < 2:
        raise ValueError("At least two supplied units in each treatment arm are required")
    if np.any((scores <= 0) | (scores >= 1)):
        raise ValueError("Propensity scores must lie strictly inside (0,1); zero/one scores are not clipped")
    if covariates is None and covariate_names is not None:
        raise ValueError("covariate_names requires explicitly supplied covariates")
    if estimand == "ATE":
        logweights = np.where(groups == 1, -np.log(scores), -np.log1p(-scores))
        formula = "T/p + (1-T)/(1-p), normalized separately within each arm"
        target = "Declared average contrast for the analysis population, subject to identification and sampling assumptions"
    else:
        logweights = np.where(groups == 1, 0.0, np.log(scores) - np.log1p(-scores))
        formula = "T + (1-T)*p/(1-p), normalized separately within each arm"
        target = "Declared average contrast for the treated target, subject to identification and sampling assumptions"
    means, summaries, stable_weights = {}, {}, np.empty(n)
    for name, group in (("control", 0), ("treated", 1)):
        mask = groups == group
        means[name], summaries[name], stable_weights[mask] = _group_summary(outcomes[mask], logweights[mask])
    contrast = float(means["treated"] - means["control"])
    original_means = {name: float(np.mean(outcomes[groups == group])) for name, group in (("control", 0), ("treated", 1))}
    original_difference = float(original_means["treated"] - original_means["control"])
    ranges = {name: [float(np.min(scores[groups == group])), float(np.max(scores[groups == group]))] for name, group in (("control", 0), ("treated", 1))}
    lo = max(ranges["control"][0], ranges["treated"][0])
    hi = min(ranges["control"][1], ranges["treated"][1])
    extreme_count = int(np.sum((scores < bounds[0]) | (scores > bounds[1])))
    disjoint = bool(lo > hi)
    low_ess = any(row["effective_fraction"] < ess_screen for row in summaries.values())
    overlap_status = "fail" if disjoint else "warning" if extreme_count or low_ess else "no_issue_detected"
    overlap = {"arm_ranges": ranges, "common_range": None if disjoint else [lo, hi],
        "ranges_disjoint": disjoint, "outside_screen_count": extreme_count,
        "outside_screen_fraction": extreme_count / n, "denominator": n,
        "screen_bounds": list(bounds), "effective_fraction_screen": ess_screen,
        "status": overlap_status,
        "interpretation": ("Observed arm score ranges are disjoint. " if disjoint else "Observed arm score ranges intersect. ") +
            str(extreme_count) + " of " + str(n) + " supplied scores are outside the configured bounds; see arm-specific ESS and weight concentration. This cannot establish structural positivity or a correct treatment model."}
    balance = None
    if covariates is not None:
        graph = None if causal_audit is None else causal_audit["dag"]
        balance = balance_overlap(covariates, groups, propensity=scores, weights=stable_weights,
            smd_threshold=smd_screen, overlap_bounds=bounds, dag=graph,
            covariate_names=covariate_names, estimand=estimand)["balance"]
        balance["weight_input_note"] = "Within-arm relative weights are used; scaling cancels in each weighted mean, sample variance and ESS. The raw causal weight summaries are separately reported."
    ipw = {"estimand": estimand, "target": target, "effect_scale": "treated minus control normalized weighted mean",
        "outcome_units": context["outcome_units"], "group_means": means,
        "weighted_contrast": contrast, "unweighted_group_means": original_means,
        "unweighted_difference": original_difference, "weight_formula": formula,
        "weight_summary": summaries, "overlap": overlap, "measured_balance": balance,
        "uncertainty": {"status": "not_implemented", "standard_error": None,
            "confidence_interval": None, "p_value": None,
            "reason": "Supplied-score arithmetic omits propensity estimation, clustering and design uncertainty; no naive fixed-weight interval is substituted."},
        "correction_scope": "Reviewable reweighting changes group contributions and the intended target. It does not correct unmeasured confounding, measurement, missingness or identification. Original observations and the unweighted contrast are retained.",
        "source_split": split_role, "alignment": alignment,
        "propensity_context": context, "causal_context": scientific}
    rows = [
        evidence("missingness", "no_issue_detected", "All supplied outcome, treatment and propensity cells are finite; no cells removed",
            sample_size=n, observed={"nonfinite_cells": 0, "checked_cells": 3*n},
            thresholds={"allowed_nonfinite": 0}, limitations=["Finite cells do not validate missingness mechanisms or excluded source records."]),
        evidence("target_compatibility", "no_issue_detected", "Compared finite numeric outcome, both binary treatment arms and scores strictly in (0,1)",
            sample_size=n, observed={"control_count": sizes["control"], "treated_count": sizes["treated"], "outcome_units": context["outcome_units"]},
            thresholds={"minimum_per_arm": 2, "propensity_lower_exclusive": 0, "propensity_upper_exclusive": 1},
            limitations=["Numeric support does not establish the outcome's scientific meaning or a correct treatment probability."]),
        evidence("positivity", overlap_status, overlap["interpretation"], sample_size=n,
            observed={"group_ranges": ranges, "common_range": overlap["common_range"], "ranges_disjoint": disjoint,
                "outside_screen_count": extreme_count, "score_denominator": n,
                "effective_sample_size": {key: value["effective_sample_size"] for key, value in summaries.items()},
                "effective_fraction": {key: value["effective_fraction"] for key, value in summaries.items()},
                "maximum_normalized_weight_share": {key: value["maximum_normalized_share"] for key, value in summaries.items()}},
            thresholds={"score_screen_bounds": list(bounds), "ess_fraction_screen": ess_screen,
                "rationale": "Prespecified user-configurable descriptive screens, not significance tests or universal identification thresholds"},
            limitations=["Ranges conceal local/multivariate sparsity; measured overlap cannot prove population positivity or treatment-model correctness."],
            remedies=["Inspect score distributions and substantive treatment availability; review any population/estimand-changing redesign before rerunning, without silent trimming."]),
        evidence("error_structure", "not_checked", "Effect uncertainty is not implemented for supplied estimated propensities or dependent units",
            source="manual_required", sample_size=n, observed={"standard_error": None, "confidence_interval": None, "p_value": None},
            limitations=["Fixed-weight naive intervals would omit nuisance estimation and design dependence."],
            remedies=["Prespecify an estimator and variance method appropriate to nuisance fitting, sampling, clustering and the target estimand."]),
        evidence("leakage", "fail" if context["propensity_uses_outcome"] is True else "not_checked",
            "Caller declares outcomes were used for propensity construction; weighting identification is compromised" if context["propensity_uses_outcome"] is True else "Propensity construction, outcome exclusion and selection history are not independently verified",
            source="automated" if context["propensity_uses_outcome"] is True else "manual_required",
            sample_size=n, observed={"declared_propensity_fit_split": context["propensity_fit_split"],
                "declared_uses_outcome": context["propensity_uses_outcome"]},
            limitations=["A provenance label or an assertion that outcomes were not used is not independent evidence of leakage-free construction."]),
    ]
    if balance is not None:
        rows.append(evidence("balance", balance["status"], balance["interpretation"], sample_size=n,
            observed={"comparisons": deepcopy(balance["comparisons"]), "raw_arm_sizes": balance["raw_arm_sizes"],
                "effective_sample_sizes": balance["effective_sample_sizes"]},
            thresholds={"absolute_smd_screen": smd_screen, "rationale": balance["threshold_rationale"]},
            limitations=balance["limitations"], remedies=["Review measured pre-treatment variables and the assumed causal roles; successful balance does not establish exchangeability."]))
    estimates = {"adapter_status": "computed", "adapter": {"implementation": IMPLEMENTATION,
        "model_fit": False, "model_refit": False, "scores_clipped": False, "rows_removed": 0},
        "weighted_contrast": contrast, "unweighted_difference": original_difference, "ipw": ipw}
    panels = [
        _visuals._bars("ipw_weighted_means", "Conditional weighted outcome means", ["Control", "Treated"],
            [means["control"], means["treated"]], n, split_role, role="main_result", units=context["outcome_units"],
            comparison="Normalized supplied-score weighted mean per arm; treated minus control = " + format(contrast, ".8g") + " " + context["outcome_units"],
            interpretation="These are weighted observed means conditional on " + estimand + " weights; no counterfactual outcome or identified causal effect has been verified.", limitations=LIMITS[:4]),
        _visuals._bars("ipw_effective_sample_size", "Weight concentration by arm", ["Control ESS", "Control rows", "Treated ESS", "Treated rows"],
            [summaries["control"]["effective_sample_size"], sizes["control"], summaries["treated"]["effective_sample_size"], sizes["treated"]],
            n, split_role, role="diagnostic", requirement="positivity", units="effective or actual observations",
            comparison="ESS = (sum weights)^2/sum squared weights versus actual arm rows; configured ESS/raw-count concern below " + str(ess_screen),
            threshold="ESS/raw count < " + str(ess_screen) + " is a configurable concern screen, not a significance threshold", interpretation="Concentrated weights reduce effective information; ESS is not an independent-sample count or an uncertainty interval.", limitations=LIMITS[1:4]),
        _visuals.histogram_panel("ipw_propensity_distribution", "Supplied propensity distribution", scores,
            role="descriptive", requirement="positivity", source_split=split_role,
            units="supplied treatment probability", comparison=str(extreme_count) + "/" + str(n) + " scores outside " + str(list(bounds)),
            threshold=None, interpretation="This pooled score distribution is descriptive; arm ranges and ESS are reported separately and population positivity remains unverified.",
            limitations=["A pooled histogram can hide arm separation and local/multivariate lack of support.", "No propensity model was fitted or validated; aggregates can remain sensitive."], bins=12),
        _visuals.status_panel("ipw_identification", "Causal identification and effect uncertainty", n=n, source_split=split_role,
            requirement="causal_design", message="Strong causal language remains blocked; untestable identification conditions and effect uncertainty require a separate reviewed design.",
            comparison="Assumed DAG status: " + scientific["assumed_dag_status"],
            limitations=LIMITS[:4]),
    ]
    estimates["visual_evidence"] = _visuals._finish(n, split_role, panels)
    return make_report("causal_weighting", purpose,
        _complete("causal_weighting", purpose, rows, attestations=attestations),
        {"n": n, "control": sizes["control"], "treated": sizes["treated"]}, estimates, LIMITS)
