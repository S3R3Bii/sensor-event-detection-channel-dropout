"""Descriptive binary calibration with explicit bins, intervals and split scope.

No model is fitted, recalibrated, selected or mutated. Wilson intervals describe
bin-specific event proportions under a binomial approximation; they are not
simultaneous calibration bands or proof of independent observations.
"""
import math

import numpy as np
from scipy.stats import norm

from .report import evidence
from ._version import VERSION


MAX_OBSERVATIONS = 2_000_000
SPLIT_ROLES = {"unknown", "training", "validation", "evaluation", "final_holdout"}


def _vector(value, name):
    if np.ma.isMaskedArray(value) and np.ma.getmaskarray(value).any():
        raise ValueError(name+" contains masked cells; no missing value is silently unmasked or repaired")
    if np.iscomplexobj(value):
        raise ValueError(name+" must contain real numeric values")
    array = np.asarray(value)
    if array.ndim != 1 or not 1 <= array.size <= MAX_OBSERVATIONS:
        raise ValueError(name+" must be a bounded nonempty one-dimensional numeric array")
    if array.dtype.kind not in "biuf" and not all(
        isinstance(x, (bool, int, float, np.integer, np.floating)) for x in array
    ):
        raise ValueError(name+" requires numeric values, with binary outcomes explicitly coded 0/1")
    try:
        array = np.asarray(value, dtype=float)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(name+" must contain finite real numeric values") from exc
    if not np.isfinite(array).all():
        raise ValueError(name+" contains missing or nonfinite values; no rows are dropped or repaired")
    return array


def _wilson(events, count, z):
    rate = events/count
    denominator = 1+z*z/count
    center = (rate+z*z/(2*count))/denominator
    half_width = z*math.sqrt(rate*(1-rate)/count+z*z/(4*count*count))/denominator
    lower = 0.0 if events == 0 else max(0.0, center-half_width)
    upper = 1.0 if events == count else min(1.0, center+half_width)
    return [float(lower), float(upper)]


def audit_calibration(y_true, probabilities, *, split_role="unknown", n_bins=10,
                      confidence=.95, minimum_bin_count=20, minimum_class_count=20):
    """Return calibration evidence and aggregate values without side effects.

    Outcomes must be numeric 0/1 and probabilities must correspond to event 1.
    Matching pandas indexes are checked before conversion; arrays are positional.
    Uniform bins follow sklearn.calibration_curve: the first interval is closed
    at both ends and subsequent intervals are open on the left, closed on the
    right. All bins remain in the output, including explicitly empty bins.

    Without a prespecified adequacy criterion, calibration support remains
    ``not_checked``; computed summaries are not a passed assumption test.
    Sampling/boundary concerns on evaluation rows are ``warning``. There is no
    calibration-gap cutoff.
    Training/unknown roles and a one-class sample remain ``not_checked`` even
    though descriptive numbers can be computed. No interval establishes an
    untouched split, independent sampling or future calibration.
    """
    if not isinstance(split_role, str) or split_role not in SPLIT_ROLES:
        raise ValueError("split_role must be unknown, training, validation, evaluation or final_holdout")
    if type(n_bins) is not int or not 1 <= n_bins <= 50:
        raise ValueError("n_bins must be an integer from 1 to 50")
    if type(minimum_bin_count) is not int or not 1 <= minimum_bin_count <= MAX_OBSERVATIONS:
        raise ValueError("minimum_bin_count must be a positive bounded integer")
    if type(minimum_class_count) is not int or not 1 <= minimum_class_count <= MAX_OBSERVATIONS:
        raise ValueError("minimum_class_count must be a positive bounded integer")
    if isinstance(confidence, (bool, np.bool_)) or not isinstance(confidence, (int, float, np.integer, np.floating)) or not math.isfinite(confidence) or not 0 < confidence < 1:
        raise ValueError("confidence must be a finite number strictly between zero and one")
    # isf avoids rounding (1+confidence)/2 to one for high confidence levels.
    z = float(norm.isf((1-float(confidence))/2))
    if not math.isfinite(z) or z <= 0:
        raise ValueError("confidence is outside representable normal-quantile precision")
    y_index, p_index = getattr(y_true, "index", None), getattr(probabilities, "index", None)
    if y_index is not None and p_index is not None and callable(getattr(y_index, "equals", None)):
        if not y_index.equals(p_index):
            raise ValueError("Outcome and probability pandas indexes differ in values or order; align explicitly")
        alignment = "pandas_index_order_verified; entity identity and dependence remain unverified"
    else:
        alignment = "positional_only; source row identity cannot be independently verified"
    y = _vector(y_true, "y_true")
    p = _vector(probabilities, "probabilities")
    if len(y) != len(p):
        raise ValueError("Outcomes and probabilities must have matching lengths")
    if not np.isin(y, [0., 1.]).all():
        raise ValueError("Binary outcomes must be explicitly coded 0/1")
    if ((p < 0) | (p > 1)).any():
        raise ValueError("Probabilities must lie within [0,1]")
    n = int(len(y)); events = int(y.sum()); nonevents = n-events
    edges = np.linspace(0., 1., n_bins+1)
    assignment = np.searchsorted(edges[1:-1], p, side="left")
    counts = np.bincount(assignment, minlength=n_bins)
    event_counts = np.bincount(assignment, weights=y, minlength=n_bins)
    probability_sums = np.bincount(assignment, weights=p, minlength=n_bins)
    bins = []; ece = 0.; signed_gap = 0.; gaps = []; sparse = 0
    for index in range(n_bins):
        count = int(counts[index]); observed = int(event_counts[index])
        if count:
            mean = float(probability_sums[index]/count); rate = observed/count
            gap = rate-mean; interval = _wilson(observed, count, z)
            ece += count/n*abs(gap); signed_gap += count/n*gap; gaps.append(abs(gap))
            sparse += int(count < minimum_bin_count)
        else:
            mean = rate = gap = interval = None
        bins.append({"bin_index":index, "lower_bound":float(edges[index]), "upper_bound":float(edges[index+1]),
            "left_inclusive":index == 0, "right_inclusive":True, "count":count, "event_count":observed,
            "mean_probability":mean, "event_rate":rate, "observed_minus_predicted":gap,
            "event_rate_wilson_interval":interval, "status":"computed" if count else "not_checked",
            "interval_status":"conditional_binomial_approximation; design not verified" if count else "not_checked"})
    contradictions = int(np.sum(((y == 1) & (p == 0)) | ((y == 0) & (p == 1))))
    epsilon = float(np.finfo(np.float64).eps); clipped = np.clip(p, epsilon, 1-epsilon)
    loss = float(-np.mean(y*np.log(clipped)+(1-y)*np.log1p(-clipped)))
    unclipped_loss = None if contradictions else float(-(np.log(p[y == 1]).sum()+np.log1p(-p[y == 0]).sum())/n)
    limits = [
        "Uniform-bin calibration and ECE depend on the chosen bins and sample; no universal adequacy cutoff or calibration proof is supplied.",
        "Empty bins are explicitly unassessed: no calibration conclusion is supported for probability regions without supplied observations. Small event/non-event counts limit reliability review.",
        "Wilson intervals concern each bin's event proportion under a binomial approximation. They assume independent Bernoulli observations within a bin and are not simultaneous bands, prediction intervals or uncertainty for the bin mean probability.",
        "Do not treat mean predicted probability falling inside an interval as a passed calibration test; model fitting, selection and repeated inspection are not accounted for.",
        "A declared split role and matching row indexes do not verify training/selection history, independence, measurement quality or external validity.",
        "Observed prevalence is a description of these rows, not a prespecified training-derived probability baseline. Calibration is distinct from ranking discrimination.",
        "No recalibration or correction is fitted. Any probability calibration must be learned using separate training/validation or cross-fitting, never these final evaluation outcomes.",
    ]
    if contradictions:
        limits.append("Exact zero/one probabilities contradict "+str(contradictions)+" observed outcomes: ideal unclipped log loss is infinite. JSON stores it as null; the finite reported log loss explicitly clips at float64 epsilon.")
    if split_role in {"training", "unknown"}:
        status = "not_checked"
        scope = "Training or unknown-split summaries do not establish held-out calibration."
    elif not events or not nonevents:
        status = "not_checked"
        scope = "Only one outcome class is observed; probability reliability across both classes remains unresolved."
    else:
        status = "warning" if sparse or contradictions or min(events, nonevents) < minimum_class_count else "not_checked"
        scope = "Descriptive calibration summaries on caller-declared "+split_role+" rows; no adequacy cutoff was evaluated."
    limits.append(scope)
    configuration = {"strategy":"uniform", "n_bins":n_bins,
        "boundary_rule":"first [0,edge1], subsequent (left,right]; internal equality assigned lower bin, matching sklearn.calibration_curve",
        "confidence_level":float(confidence), "interval_method":"Wilson without continuity correction; pointwise binomial approximation",
        "minimum_bin_count_warning":minimum_bin_count,
        "minimum_class_count_warning":minimum_class_count,
        "small_bin_rationale":"Configured precision/review heuristic, not a universal minimum sample or calibration failure test",
        "ece_definition":"sum over nonempty bins of (bin count / all rows) * abs(event rate - mean probability)",
        "signed_gap_definition":"sum of bin weights * (event rate - mean probability); equals observed prevalence minus overall mean probability",
        "calibration_gap_acceptance_threshold":None, "log_loss_clip_epsilon":epsilon,
        "interval_sampling_design_verified":False,
        "log_loss_units":"nats per observation", "other_score_units":"dimensionless"}
    detail = {"sample_size":n, "event_count":events, "nonevent_count":nonevents, "event_prevalence":events/n,
        "mean_probability":float(p.mean()), "bins":bins, "nonempty_bin_count":int(np.count_nonzero(counts)),
        "empty_bin_count":int(np.sum(counts == 0)), "small_nonempty_bin_count":sparse,
        "ece":float(ece), "signed_gap":float(signed_gap), "max_abs_bin_gap":float(max(gaps)),
        "brier":float(np.mean((p-y)**2)), "log_loss":loss, "unclipped_log_loss":unclipped_loss,
        "boundary_contradiction_count":contradictions, "split_role":split_role,
        "adequacy_status":"not_assessed", "diagnostic_computation_status":"computed",
        "row_alignment":alignment, "configuration":configuration,
        "recalibration_fitted":False, "model_selection_performed":False}
    observed = {"group":"binary outcomes versus event-1 probabilities, grouped by fixed uniform bins", "variables":["observed target coded 0/1", "event-1 probability"],
        "comparison":"observed event fraction versus mean probability in each bin; observed minus predicted uses the same bin denominator",
        "source_split":split_role, "sample_size":n, "event_count":events, "nonevent_count":nonevents,
        "event_prevalence":events/n, "mean_probability":detail["mean_probability"], "ece":detail["ece"],
        "signed_gap":detail["signed_gap"], "max_abs_bin_gap":detail["max_abs_bin_gap"], "bins":bins,
        "empty_bin_count":detail["empty_bin_count"], "small_nonempty_bin_count":sparse,
        "boundary_contradiction_count":contradictions, "brier":detail["brier"], "log_loss":loss}
    row = evidence("calibration", status, "Fixed uniform-bin event rates with pointwise Wilson intervals; "+scope,
        sample_size=n, observed=observed, thresholds=configuration, limitations=limits,
        remedies=["Review actual bin counts/gaps and uncertainty with domain decision costs. If a revised model or calibration is justified, fit it using training/calibration data and rerun on a fresh evaluation; do not tune against final outcomes."],
        provenance={"implementation":"model-evidence/"+VERSION, "diagnostic":"binary-calibration/0.3.0", "source_split":split_role})
    return {"evidence":[row], "estimates":{"calibration_detail":detail}, "limitations":limits}
