"""Bounded structural review of an explicitly supplied assumed causal DAG.

No graph is inferred from correlations and no adjustment set is certified. Graph
confirmation records a human attestation, never verification of causal reality.
"""
from copy import deepcopy
import re

_FIELDS = {"nodes", "edges", "exposure", "outcome", "supplied_by", "source", "confirmation_status", "confirmation_basis"}
_OPTIONAL = {"revision", "history", "confirmed_revision"}
_NAME = re.compile(r"[A-Za-z][A-Za-z0-9_. -]{0,63}\Z", re.ASCII)
_TIMINGS = {"pre_treatment", "at_treatment", "post_treatment", "unknown"}
_CONFIRMATIONS = {"unconfirmed", "confirmed", "rejected"}
_LIMITATIONS = [
    "This is a user-supplied assumed graph; confirmation is an attestation, not verification of causal reality.",
    "Roles are structural labels conditional on the supplied graph, timing, and observation metadata; correlations cannot establish these roles.",
    "No backdoor identification, valid adjustment-set search, or causal-effect estimation is implemented here.",
    "A collider label alone does not establish collider bias; paths, conditioning, selection, and the causal question matter.",
    "An unobserved common cause can leave identification unresolved; absence of such a node is not evidence that unmeasured confounding is absent.",
    "Local graph labels, provenance, and aggregate summaries can be sensitive; review before sharing.",
]


def _name(value):
    return isinstance(value, str) and bool(_NAME.fullmatch(value))


def _text(value, *, required=True):
    return isinstance(value, str) and len(value) <= 4096 and (bool(value.strip()) or not required) and all(ord(c) >= 32 or c in "\t\n\r" for c in value)


def _adjacency(nodes, edges):
    children = {n: [] for n in nodes}
    parents = {n: [] for n in nodes}
    for left, right in edges:
        children[left].append(right)
        parents[right].append(left)
    return children, parents


def _reachable(start, adjacency):
    seen, pending = set(), list(adjacency[start])
    while pending:
        node = pending.pop()
        if node not in seen:
            seen.add(node)
            pending.extend(adjacency[node])
    return seen


def validate_assumed_dag(dag):
    """Validate an explicit graph and provenance; return an independent copy.

    Names are deliberately constrained so generated Mermaid cannot contain
    directives, links, HTML, quote termination, or arbitrary graph syntax.
    """
    if not isinstance(dag, dict) or not _FIELDS.issubset(dag) or set(dag) - _FIELDS - _OPTIONAL:
        raise ValueError("DAG fields must match the explicit assumed-graph contract")
    nodes = dag["nodes"]
    if not isinstance(nodes, list) or not 2 <= len(nodes) <= 64:
        raise ValueError("DAG must contain 2..64 nodes")
    names = []
    for node in nodes:
        if not isinstance(node, dict) or set(node) != {"name", "observed", "timing"}:
            raise ValueError("Invalid DAG node fields")
        if not _name(node["name"]) or type(node["observed"]) is not bool or not isinstance(node["timing"], str) or node["timing"] not in _TIMINGS:
            raise ValueError("Invalid DAG node values")
        names.append(node["name"])
    if len(names) != len(set(names)):
        raise ValueError("Duplicate DAG node")
    if not _name(dag["exposure"]) or not _name(dag["outcome"]) or dag["exposure"] not in names or dag["outcome"] not in names or dag["exposure"] == dag["outcome"]:
        raise ValueError("Distinct exposure and outcome must be graph nodes")
    edges = dag["edges"]
    if not isinstance(edges, list) or len(edges) > 256:
        raise ValueError("DAG edges must be a bounded array")
    seen = set()
    for edge in edges:
        if not isinstance(edge, list) or len(edge) != 2 or not all(_name(n) and n in names for n in edge):
            raise ValueError("DAG edges must contain two known node names")
        key = tuple(edge)
        if key[0] == key[1] or key in seen:
            raise ValueError("Self edges and duplicate edges are forbidden")
        seen.add(key)
    if not _text(dag["supplied_by"]) or not _text(dag["source"]):
        raise ValueError("DAG needs explicit supplier and source provenance")
    if not isinstance(dag["confirmation_status"], str) or dag["confirmation_status"] not in _CONFIRMATIONS or not _text(dag["confirmation_basis"], required=dag["confirmation_status"] == "confirmed"):
        raise ValueError("Invalid DAG confirmation or missing confirmation basis")
    revision = dag.get("revision", 0)
    confirmed_revision = dag.get("confirmed_revision", 0 if "revision" not in dag and dag["confirmation_status"] == "confirmed" else None)
    history = dag.get("history", [])
    if type(revision) is not int or revision < 0 or revision > 2147483647:
        raise ValueError("DAG revision must be a bounded nonnegative integer")
    if confirmed_revision is not None and (type(confirmed_revision) is not int or confirmed_revision < 0 or confirmed_revision > 2147483647):
        raise ValueError("Invalid confirmed graph revision")
    if not isinstance(history, list) or len(history) > 128:
        raise ValueError("DAG history must contain at most 128 entries")
    for entry in history:
        if not isinstance(entry, dict) or set(entry) != {"revision", "action", "description"}:
            raise ValueError("Invalid DAG history fields")
        if type(entry["revision"]) is not int or not 0 <= entry["revision"] <= revision:
            raise ValueError("Invalid DAG history revision")
        if not isinstance(entry["action"], str) or not re.fullmatch(r"[a-z][a-z0-9_]{0,63}", entry["action"], re.ASCII) or not _text(entry["description"], required=False):
            raise ValueError("Invalid DAG history action or description")
    children, parents = _adjacency(names, edges)
    # Kahn's algorithm detects all cycles, including disconnected components.
    indegree = {n: len(parents[n]) for n in names}
    pending = [n for n in names if indegree[n] == 0]
    visited = 0
    while pending:
        node = pending.pop()
        visited += 1
        for child in children[node]:
            indegree[child] -= 1
            if indegree[child] == 0:
                pending.append(child)
    if visited != len(names):
        raise ValueError("Assumed causal graph must be acyclic")
    result = deepcopy(dag)
    result.update(revision=revision, confirmed_revision=confirmed_revision, history=deepcopy(history))
    return result


def assess_assumed_dag(dag=None):
    """Return conditional graph roles, confirmation state, and timing concerns.

    A missing or unconfirmed graph requests confirmation. A rejected graph or
    conflict between supplied timing and directed ancestry remains unresolved.
    """
    if dag is None:
        return {"status": "needs_confirmation", "confirmation_status": "not_supplied",
                "supplied_by": None, "source": None, "confirmation_basis": None,
                "nodes": [], "edges": [], "exposure": None, "outcome": None,
                "revision": 0, "confirmed_revision": None, "history": [],
                "edge_list": [], "mermaid": "flowchart LR\n", "roles": {},
                "warnings": ["No assumed DAG was supplied; no variable roles or adjustment set were inferred."],
                "limitations": list(_LIMITATIONS)}
    graph = validate_assumed_dag(dag)
    names = [n["name"] for n in graph["nodes"]]
    children, parents = _adjacency(names, graph["edges"])
    exposure, outcome = graph["exposure"], graph["outcome"]
    descendants = _reachable(exposure, children)
    ancestors_exposure = _reachable(exposure, parents)
    ancestors_outcome = _reachable(outcome, parents)
    stale = graph["confirmation_status"] == "confirmed" and graph["confirmed_revision"] != graph["revision"]
    confirmed = graph["confirmation_status"] == "confirmed" and not stale
    basis = "conditional_on_confirmed_assumed_graph" if confirmed else "conditional_on_unconfirmed_graph"
    warnings, roles, semantic_conflict = [], {}, False
    for node in graph["nodes"]:
        name = node["name"]
        node_roles, node_warnings = [], []
        if name == exposure:
            node_roles.append("exposure")
        if name == outcome:
            node_roles.append("outcome")
        if name in ancestors_exposure and name in ancestors_outcome and name not in descendants:
            node_roles.append("candidate_common_cause")
        if name in descendants:
            node_roles.append("treatment_descendant")
        if name not in {exposure, outcome} and name in descendants and name in ancestors_outcome:
            node_roles.append("mediator_path")
        if len(parents[name]) >= 2:
            node_roles.append("collider")
            node_warnings.append("Two or more incoming arrows form a structural collider; this alone does not establish bias.")
        if not node["observed"]:
            node_roles.append("unobserved")
            if "candidate_common_cause" in node_roles:
                node_warnings.append("An assumed unobserved common cause may leave identification unresolved.")
        if name in descendants and node["timing"] == "pre_treatment":
            node_warnings.append("Timing conflict: a treatment descendant is marked pre_treatment.")
            semantic_conflict = True
        if name == outcome and node["timing"] == "pre_treatment":
            node_warnings.append("Timing conflict: outcome is marked before treatment.")
            semantic_conflict = True
        if name == exposure and node["timing"] not in {"at_treatment", "unknown"}:
            node_warnings.append("Timing conflict: exposure must be at_treatment or explicitly unknown.")
            semantic_conflict = True
        if name in ancestors_exposure and node["timing"] == "post_treatment":
            node_warnings.append("Timing conflict: an exposure ancestor is marked post_treatment.")
            semantic_conflict = True
        if node["timing"] == "unknown":
            node_warnings.append("Timing is unknown and needs subject-matter review.")
            # A graph attestation cannot resolve unspecified temporal order.
            semantic_conflict = True
        roles[name] = {"roles": node_roles, "warnings": node_warnings, "basis": basis}
        warnings.extend(name + ": " + warning for warning in node_warnings)
    if outcome not in descendants:
        warnings.append("The assumed graph contains no directed exposure-to-outcome path; this is an assumption of no directed effect in this graph, not an empirical finding.")
    if stale:
        warnings.append("stale_confirmation: confirmation does not cover the current graph revision; reconfirm before using these roles.")
    if graph["confirmation_status"] == "rejected":
        warnings.append("The supplied assumed graph was rejected; its structural labels must not be used as confirmed causal evidence.")
    elif not confirmed:
        warnings.append("Graph structure and variable roles need explicit human confirmation; all inferred labels are conditional_on_unconfirmed_graph.")
    ids = {name: "n" + str(i) for i, name in enumerate(names)}
    # Safe generated IDs, quoted labels, and the strict ASCII name vocabulary
    # prevent a supplied label from adding a Mermaid directive or HTML link.
    mermaid = "flowchart LR\n" + "\n".join("  " + ids[name] + '["' + name + '"]' for name in names)
    if graph["edges"]:
        mermaid += "\n" + "\n".join("  " + ids[left] + " --> " + ids[right] for left, right in graph["edges"])
    mermaid += "\n"
    status = "unresolved" if semantic_conflict or stale or graph["confirmation_status"] == "rejected" else ("assumed_confirmed" if confirmed else "needs_confirmation")
    # Do not label roles confirmed when timing or revision checks are unresolved.
    if status != "assumed_confirmed":
        role_basis = "conditional_on_unresolved_graph" if status == "unresolved" else "conditional_on_unconfirmed_graph"
        for value in roles.values():
            value["basis"] = role_basis
    return {"status": status, "confirmation_status": graph["confirmation_status"],
            "supplied_by": graph["supplied_by"], "source": graph["source"],
            "confirmation_basis": graph["confirmation_basis"], "nodes": graph["nodes"],
            "revision": graph["revision"], "confirmed_revision": graph["confirmed_revision"], "history": graph["history"],
            "edges": graph["edges"], "exposure": exposure, "outcome": outcome,
            "edge_list": [left + " -> " + right for left, right in graph["edges"]],
            "mermaid": mermaid, "roles": roles, "warnings": warnings,
            "limitations": list(_LIMITATIONS)}
