"""Small fitted-model adapters: prediction ownership stays with the model.

These functions never call fit, clone, feature selection, or model repair. A
supplied prediction Pipeline owns its preprocessing. The explicit fitted-PCA
route delegates its projection to the already fitted PCA object. Raw inputs are
not misrepresented as a Pipeline's transformed training design.
"""
from copy import deepcopy
import math
import warnings
import numpy as np
import sklearn
from scipy.sparse import issparse
from sklearn.base import BaseEstimator, is_classifier, is_regressor
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.ensemble import (GradientBoostingClassifier, GradientBoostingRegressor,
    HistGradientBoostingClassifier, HistGradientBoostingRegressor,
    RandomForestClassifier, RandomForestRegressor)
from sklearn.linear_model import ElasticNet, Lasso, LinearRegression, LogisticRegression, Ridge
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.neural_network import MLPClassifier, MLPRegressor
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.naive_bayes import GaussianNB, MultinomialNB, BernoulliNB, ComplementNB, CategoricalNB
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC, SVR
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.utils.validation import check_is_fitted

from .diagnostics import audit_prediction, _collect_visual
from . import model_visuals as _visuals
from .registry import describe_requirements, load_registry
from .report import evidence, explain_report, gate_claims, make_report, validate_report

MAX_CELLS = 2_000_000
SPLITS = {"unknown", "training", "validation", "evaluation", "final_holdout"}
ADAPTER_VERSION = "standard-fitted/0.6.0"
FAMILIES = {
    LinearRegression: "unpenalized_linear", Ridge: "penalized_linear", Lasso: "penalized_linear", ElasticNet: "penalized_linear",
    LogisticRegression: "logistic", SVC: "support_vector", SVR: "support_vector",
    DecisionTreeRegressor: "tree", DecisionTreeClassifier: "tree",
    RandomForestRegressor: "forest", RandomForestClassifier: "forest",
    GradientBoostingRegressor: "boosting", GradientBoostingClassifier: "boosting",
    HistGradientBoostingRegressor: "histogram_boosting", HistGradientBoostingClassifier: "histogram_boosting",
    MLPRegressor: "feedforward_mlp", MLPClassifier: "feedforward_mlp",
    KNeighborsClassifier: "nearest_neighbors", KNeighborsRegressor: "nearest_neighbors",
    GaussianNB: "naive_bayes", MultinomialNB: "naive_bayes", BernoulliNB: "naive_bayes",
    ComplementNB: "naive_bayes", CategoricalNB: "naive_bayes",
}
FAMILY_LIMITS = {
    "unpenalized_linear": "This prediction adapter does not supply OLS coefficient inference or residual/design diagnostics.",
    "penalized_linear": "Penalized coefficients are not ordinary unpenalized OLS inference. Scaling and tuning must use training data only.",
    "logistic": "The original fitting design, separation and convergence are not certified here. Regularized logistic coefficients are not ordinary unpenalized MLE inference.",
    "support_vector": "Kernel/scaling/tuning history is not recovered. Decision-function margins are ranking scores, not probabilities; no normal-feature assumption is imposed.",
    "tree": "No universal predictor-normality or homoskedastic-error requirement is imposed for tree prediction. Tree complexity and training selection remain unassessed.",
    "forest": "No universal predictor-normality or homoskedastic-error requirement is imposed for forest prediction. Ensemble stability and training selection remain unassessed.",
    "boosting": "No universal predictor-normality or homoskedastic-error requirement is imposed for boosting prediction. Tuning, stopping and training selection remain unassessed.",
    "histogram_boosting": "No universal predictor-normality or homoskedastic-error requirement is imposed for boosting prediction. Native missing-value support does not establish a missingness mechanism.",
    "feedforward_mlp": "This exact-stock feedforward MLP route assesses supplied predictions and recorded training state, not general deep-network validity. Scaling, tuning, training warnings, group/time-safe internal validation, out-of-distribution behavior, fairness and adversarial robustness are not established. Training loss/internal-validation scores are not untouched evaluation results; no predictor-normality assumption is imposed.",
    "nearest_neighbors": "Native neighbor predictions retain the supplied metric, weighting and representation. Geometry, scaling, training-only neighbor/metric selection and source independence remain unresolved; a valid k-versus-fitting-row comparison does not prove appropriate neighborhoods. No universal predictor-normality or scaling threshold is imposed.",
    "naive_bayes": "Native Naive Bayes predictions do not verify conditional feature independence or the variant's likelihood model. Domain checks use actual estimator inputs only; Pipeline-transformed predictor domains remain unresolved. Feature dependence need not make prediction useless, and classification accuracy does not certify probabilities or causal effects.",
    "generic_prediction_only": "This family has not received the representative v0.2 family acceptance tests. Only supplied prediction compatibility/metrics are evaluated.",
}


def _native(value):
    if isinstance(value, np.generic): value = value.item()
    if value is None or isinstance(value,bool): return value
    if isinstance(value,str) and len(value)<=4096: return value
    if isinstance(value,int) and abs(value)<=10**100: return value
    if isinstance(value,float) and math.isfinite(value) and abs(value)<=10**100: return value
    raise ValueError("Only bounded finite scalar class labels and simple feature names are supported")


def _input_info(X):
    """Inspect raw shape and names, never replace/transform the prediction input."""
    if issparse(X):
        raise ValueError("Sparse input matrices are unsupported by this bounded raw-input audit; provide an explicitly reviewed bounded dense input rather than silently densifying")
    if np.ma.isMaskedArray(X) and np.ma.getmaskarray(X).any():
        raise ValueError("Masked array inputs require explicit missingness handling outside this audit; masked cells are never silently discarded")
    shape = getattr(X, "shape", None)
    if shape is None: shape = np.asarray(X).shape
    if len(shape) != 2 or not 1 <= shape[0] or not 1 <= shape[1] <= 2048 or shape[0]*shape[1] > MAX_CELLS:
        raise ValueError("X must be a nonempty bounded two-dimensional pandas/NumPy input")
    n,p = map(int,shape)
    columns = getattr(X, "columns", None)
    named = columns is not None
    features = [_native(v) for v in list(columns)] if named else ["x"+str(i+1) for i in range(p)]
    if len({(type(v).__name__,str(v)) for v in features}) != p:
        raise ValueError("Duplicate input column names are ambiguous; supply distinct feature names")
    if any(isinstance(v,str) and (len(v)>128 or not v) for v in features):
        raise ValueError("Feature names must be nonempty and at most 128 characters")
    return n,p,features,named


def _alignment(X, y, n):
    if np.ma.isMaskedArray(y) and np.ma.getmaskarray(y).any():
        raise ValueError("Masked target, prediction, score or baseline cells require explicit missingness handling; no mask is silently discarded")
    values = np.asarray(y)
    if values.ndim != 1 or len(values) != n:
        raise ValueError("y must be a one-dimensional target aligned to every input row")
    xindex,yindex = getattr(X,"index",None),getattr(y,"index",None)
    if xindex is not None and yindex is not None and hasattr(xindex,"equals"):
        if not xindex.equals(yindex):
            raise ValueError("X and y pandas indexes differ in values or order; align them explicitly before auditing")
        return values,"pandas_index_order_verified"
    return values,"positional_only; source entity identity is not verified"


def _unsupported(reason, purpose, *, n=0, p=0, features=None, failed_requirement=None, model_name=None):
    if purpose not in load_registry()["use_cases"]: raise ValueError("Unknown intended purpose")
    requirements = dict(describe_requirements("unsupported_model",purpose)["requirements"])
    if failed_requirement is not None and failed_requirement not in requirements:
        known=load_registry()["requirements"]
        if failed_requirement not in known: raise ValueError("Unknown failed requirement")
        requirements[failed_requirement]=known[failed_requirement]
    rows=[]
    for req in requirements:
        failed = req == failed_requirement
        rows.append(evidence(req,"fail" if failed else "not_checked",reason if failed else "Not assessed for this unsupported fitted-object/input combination",
            source="automated" if failed else "manual_required",sample_size=n or None,
            observed={"comparison":"not computed","group":"supplied input rows","variables":features or []},
            thresholds={"configuration":"no fitted-model computation performed"},
            limitations=["No predictions, metrics, refitting or input repair were performed."],
            remedies=[reason],provenance={"adapter":ADAPTER_VERSION}))
    return make_report("unsupported_model",purpose,rows,{"n":n,"p":p},
        {"adapter_status":"failed" if failed_requirement else "unsupported",
         "adapter":{"reason":reason,"estimator_type":model_name or "unrecognized","input_feature_names":features or [],"model_refit":False}},
        [reason,"Use a supported fitted prediction estimator/Pipeline or an explicitly supported fitted PCA/KMeans route; unsupported objects need an explicit adapter."])


def _raw_missing(X):
    """Summarize raw cells without imposing numeric features on a Pipeline."""
    try:
        import pandas as pd
        missing = np.asarray(pd.isna(X),dtype=bool)
    except ImportError:
        a=np.asarray(X)
        missing=np.asarray([v is None or (isinstance(v,(float,np.floating)) and np.isnan(v)) for v in a.flat]).reshape(a.shape)
    a=np.asarray(X,dtype=object)
    infinity = sum(isinstance(v,(float,np.floating,int,np.integer)) and not isinstance(v,bool) and not math.isfinite(v) and not missing.flat[i]
                   for i,v in enumerate(a.flat))
    return int(missing.sum()),int(infinity),int(a.size)


def _binary(values, classes, positive):
    if not np.isin(values,classes).all(): raise ValueError("Observed/predicted labels must belong to the fitted model's actual class order")
    return (values == positive).astype(int)


def _family_details(model):
    """Read bounded stock-estimator attributes; never infer fitting history."""
    final = model
    for _ in range(8):
        if not isinstance(final, Pipeline): break
        final = final.steps[-1][1]
    family = FAMILIES.get(type(final), "generic_prediction_only")
    details = {"final_estimator_type":type(final).__name__, "model_family":family,
               "representative_family_tested":type(final) in FAMILIES,
               "scope":"prediction metrics only; no method-specific assumption certificate",
               "fit_warnings_from_training_observed":False,
               "family_limitation":FAMILY_LIMITS[family]}
    concerns=[]
    if type(final) not in FAMILIES: return details,concerns
    if hasattr(final,"n_iter_"):
        iterations=np.asarray(final.n_iter_)
        if iterations.dtype.kind in "iuf" and iterations.size and iterations.ndim<=2 and np.isfinite(iterations).all():
            maximum=int(np.max(iterations)); details["recorded_iteration_count_max"]=maximum
            details["recorded_iteration_count_entries"]=int(iterations.size)
            budget=getattr(final,"max_iter",None)
            # For histogram boosting max_iter is boosting capacity, not a solver
            # convergence test. Do not label a completed ensemble as a failure.
            if type(final) in {LogisticRegression,Lasso,ElasticNet,SVC,SVR} and type(budget) is int and budget>0:
                details["configured_solver_max_iter"]=budget
                if maximum>=budget:
                    concerns.append(("Recorded solver iterations reached the configured limit",{"maximum_recorded_iterations":maximum,"configured_max_iter":budget},
                        "Reaching a budget is a concern, not a definitive convergence diagnosis; training warning history and solver tolerances were not supplied."))
    if type(final) in {SVC,SVR}:
        fit_status=int(final.fit_status_); details["recorded_solver_fit_status"]=fit_status
        if fit_status!=0:
            concerns.append(("The fitted libsvm solver recorded a nonzero fit_status_",{"fit_status":fit_status,"success_code":0},
                "This flag concerns solver completion; a zero flag would not prove model validity or assumptions."))
    if type(final) in {DecisionTreeRegressor,DecisionTreeClassifier}:
        details.update(recorded_tree_depth=int(final.tree_.max_depth),recorded_tree_node_count=int(final.tree_.node_count))
    if type(final) in {RandomForestRegressor,RandomForestClassifier}:
        details["recorded_tree_count"]=len(final.estimators_)
    if type(final) in {GradientBoostingRegressor,GradientBoostingClassifier}:
        details["recorded_boosting_stages"]=int(final.n_estimators_)
    if type(final) in {MLPRegressor,MLPClassifier}:
        from .neural_visuals import describe_mlp_fit
        neural_details,neural_concerns=describe_mlp_fit(final)
        details["neural_fit"]=neural_details
        concerns.extend(neural_concerns)
    if type(final) in {KNeighborsClassifier,KNeighborsRegressor,GaussianNB,MultinomialNB,BernoulliNB,ComplementNB,CategoricalNB}:
        from .neighbor_bayes import describe_neighbor_bayes_fit
        neighbor_bayes_details=describe_neighbor_bayes_fit(model)
        details["neighbor_bayes"]=neighbor_bayes_details
        details["additional_requirements"]=neighbor_bayes_details["additional_requirements"]
    return details,concerns


def _ranking_from_margin(result,target,scores,n):
    """Binary scores rank events; no sigmoid or calibration is invented."""
    if not np.array_equal(np.unique(target),[0,1]):
        return
    auc=float(roc_auc_score(target,scores)); ap=float(average_precision_score(target,scores))
    result["estimates"].update(roc_auc=auc,average_precision=ap)
    result["evidence"]=[e for e in result["evidence"] if e["requirement"]!="discrimination"]
    result["evidence"].append(evidence("discrimination","no_issue_detected","ROC AUC/AP from the supplied fitted binary decision_function, oriented toward positive_label",sample_size=n,
        observed={"roc_auc":auc,"average_precision":ap,"event_count":int(target.sum()),"non_event_count":int(n-target.sum()),
                  "prevalence_reference_ap":float(target.mean()),"score_min":float(scores.min()),"score_max":float(scores.max()),
                  "group":"all supplied evaluation rows","variables":["fitted decision score","binary target"]},
        thresholds={"comparison":"ranking metrics only; no adequacy cutoff; no probability interpretation"},
        limitations=["A margin is not a probability. Calibration, Brier score and log loss are not computed from these scores.",
                     "AP depends on event prevalence. Discrimination does not establish calibration, causality or external validity."],
        remedies=["If probabilities are needed, review a prespecified calibration fit on separate training/validation or cross-fit data; never fit calibration on final evaluation outcomes."],
        provenance={"adapter":ADAPTER_VERSION,"score_orientation":"binary decision_function positive scores target fitted classes_[1]; sign reversed when positive_label is classes_[0]"}))


def audit_fitted(model, X=None, y=None, *, purpose="prediction", baseline_predictions=None,
                 positive_label=None, metadata=None, attestations=None, split_role="unknown", test_options=None, analysis_options=None):
    """Audit an existing sklearn estimator/Pipeline or supported statsmodels fit.

    This pure API returns report data and performs no writes. For default local
    HTML+figure+table exports use ``audit_report``. Binary labels other than 0/1
    require an explicit positive_label; multiclass reports retain all classes.
    Fitted stock PCA/KMeans require y=None and purpose description/clustering.
    Statsmodels original-fit extraction accepts X=y=None; coefficient purposes
    never substitute newly supplied outcomes for original fitting rows.
    Row indexes and named feature order are checked without silent reordering.
    """
    if purpose not in load_registry()["use_cases"]: raise ValueError("Unknown intended purpose")
    if isinstance(model,str):
        if model in {"cnn", "rnn", "transformer", "autoencoder"}:
            if test_options is not None or analysis_options is not None:
                raise ValueError("Supplied architecture outputs use their explicit bounded payload, not fitting/test execution options")
            from .architecture_audit import audit_supplied_architecture
            return audit_supplied_architecture(model, X, y, purpose=purpose, metadata=metadata, attestations=attestations,
                split_role=split_role, baseline_predictions=baseline_predictions, positive_label=positive_label)
        if model in {"kaplan_meier","bayesian_posterior_review","causal_weighting"}:
            if baseline_predictions is not None or positive_label is not None or test_options is not None:
                raise ValueError("This analysis route does not accept classification, prediction-reference or statistical-test options")
            if model=="kaplan_meier":
                if analysis_options is not None:raise ValueError("Kaplan-Meier options belong in documented metadata; no automatic alternate survival design")
                from .survival import audit_survival
                return audit_survival(X,y,purpose=purpose,metadata=metadata,attestations=attestations,split_role=split_role)
            if model=="bayesian_posterior_review":
                if y is not None or analysis_options is not None:raise ValueError("Bayesian evidence review accepts one supplied summary mapping only")
                from .bayesian_review import audit_bayesian_summary
                return audit_bayesian_summary(X,purpose=purpose,metadata=metadata,attestations=attestations,split_role=split_role)
            if y is not None:raise ValueError("Causal weighting takes one mapping with outcome, treatment and propensity")
            columns=getattr(X,"columns",None)
            if isinstance(X,dict):keys=set(X)
            elif columns is not None:keys=set(columns)
            else:raise ValueError("Causal weighting requires a mapping or DataFrame with outcome, treatment and propensity")
            if keys!={"outcome","treatment","propensity"}:raise ValueError("Causal weighting requires exactly outcome, treatment and propensity; no source code or paths")
            options={} if analysis_options is None else analysis_options
            if not isinstance(options,dict) or set(options)-{"estimand"}:raise ValueError("Causal weighting analysis_options accepts only a prespecified estimand ATE or ATT")
            from .causal_estimators import audit_ipw
            return audit_ipw(X["outcome"],X["treatment"],X["propensity"],purpose=purpose,estimand=options.get("estimand","ATE"),
                metadata=metadata,attestations=attestations,split_role=split_role)
        if analysis_options is not None:raise ValueError("analysis_options applies only to the documented causal weighting route")
        from .statistical_tests import STATISTICAL_METHODS, audit_test
        if model not in STATISTICAL_METHODS:
            return _unsupported("Unknown statistical procedure. Inspect list_methods(); catalogue-only entries require an implemented adapter.",purpose,model_name="procedure name")
        if baseline_predictions is not None or positive_label is not None:
            raise ValueError("Statistical procedures do not accept prediction baselines or class-label options")
        return audit_test(model,X,y,purpose=purpose,metadata=metadata,attestations=attestations,
                          split_role=split_role,test_options=test_options)
    if test_options is not None:
        raise ValueError("test_options applies only to a supported statistical procedure name, not a fitted model")
    from sklearn.cluster import AgglomerativeClustering, DBSCAN
    if type(model) in {AgglomerativeClustering, DBSCAN}:
        if y is not None or baseline_predictions is not None or positive_label is not None:
            raise ValueError("Existing fitted clustering consumes its stored labels and original representation, not supervised targets or prediction options")
        options = {} if analysis_options is None else analysis_options
        if not isinstance(options, dict) or set(options) - {"fit_evidence"}:
            raise ValueError("Fitted clustering analysis_options only supports explicit fit_evidence")
        from .clustering_audits import audit_fitted_clustering
        try:
            return audit_fitted_clustering(model, X, purpose=purpose, metadata=metadata, attestations=attestations,
                split_role=split_role, fit_evidence=options.get("fit_evidence"))
        except (ValueError, TypeError, OverflowError) as exc:
            return _unsupported("Existing clustering audit could not proceed: " + str(exc)[:1000], purpose,
                model_name=type(model).__name__, failed_requirement="fit_association")
    if analysis_options is not None:raise ValueError("analysis_options applies only to the documented causal weighting route")
    if not isinstance(split_role,str) or split_role not in SPLITS: raise ValueError("split_role must be unknown/training/validation/evaluation/final_holdout")
    from .forecasting import is_forecast_candidate, audit_forecast
    if is_forecast_candidate(model):
        if X is not None or positive_label is not None:raise ValueError("Existing ARIMA forecasting accepts observed future outcomes as y and explicit time metadata; no replacement design/class label")
        return audit_forecast(model,y,purpose=purpose,baseline_predictions=baseline_predictions,metadata=metadata,attestations=attestations,split_role=split_role)
    from .mixed_models import is_mixed_model_candidate, audit_mixed_model
    if is_mixed_model_candidate(model):
        if baseline_predictions is not None or positive_label is not None:raise ValueError("Existing random-intercept extraction does not accept prediction baselines or class-label options")
        return audit_mixed_model(model,X,y,purpose=purpose,metadata=metadata,attestations=attestations,split_role=split_role)
    from .statsmodels_adapter import is_statsmodels_candidate, audit_statsmodels
    if is_statsmodels_candidate(model):
        return audit_statsmodels(model,X,y,purpose=purpose,baseline_predictions=baseline_predictions,
            positive_label=positive_label,metadata=metadata,attestations=attestations,split_role=split_role)
    n=p=0; features=[]
    try:
        n,p,features,named=_input_info(X)
    except (ValueError,TypeError,OverflowError) as exc:
        return _unsupported(str(exc),purpose,n=n,p=p,features=features,failed_requirement="split_integrity")
    name=type(model).__name__
    if purpose in {"description","clustering"}:
        if y is not None or baseline_predictions is not None or positive_label is not None:
            return _unsupported("Fitted exploration requires y=None and no classification/baseline arguments; cluster labels are obtained from the supported fitted model.",purpose,n=n,p=p,features=features,model_name=name)
        if type(model) not in {PCA,KMeans} or (type(model) is PCA and purpose!="description") or (type(model) is KMeans and purpose!="clustering"):
            return _unsupported("Fitted exploration supports exact stock PCA for description and KMeans for clustering. Exploration Pipelines and other estimators are unsupported because their coordinate ownership is not recovered.",purpose,n=n,p=p,features=features,model_name=name)
        try:
            from .fitted_exploration import audit_fitted_exploration
            return audit_fitted_exploration(model,X,purpose=purpose,metadata=metadata,attestations=attestations,split_role=split_role)
        except (ValueError,TypeError,OverflowError) as exc:
            return _unsupported("Fitted exploration audit could not proceed: "+str(exc)[:1000],purpose,n=n,p=p,features=features,model_name=name,failed_requirement="distance_geometry")
    if y is None:
        return _unsupported("Prediction and supervised purposes require an observed y aligned to every input row; provide y explicitly.",purpose,n=n,p=p,features=features,model_name=name,failed_requirement="target_compatibility")
    try:
        target,alignment=_alignment(X,y,n)
    except (ValueError,TypeError,OverflowError) as exc:
        return _unsupported(str(exc),purpose,n=n,p=p,features=features,model_name=name,failed_requirement="split_integrity")
    if not isinstance(model,BaseEstimator):
        detail="This fitted-object type has no supported adapter; expected a fitted sklearn regressor/classifier, Pipeline or explicitly supported statsmodels fitted result."
        return _unsupported(detail,purpose,n=n,p=p,features=features,model_name=name)
    if purpose != "prediction":
        return _unsupported("The sklearn fitted-object adapter evaluates predictions only; it does not interpret coefficients or establish causal/design assumptions.",purpose,n=n,p=p,features=features,model_name=name)
    try:
        task="classification" if is_classifier(model) else "regression" if is_regressor(model) else None
        if task is None or not callable(getattr(model,"predict",None)):
            return _unsupported("Only single-target regressors/classifiers with predict are supported; preprocessing-only, clustering and other estimator roles require a different adapter.",purpose,n=n,p=p,features=features,model_name=name)
        check_is_fitted(model)
    except (ValueError,TypeError,AttributeError) as exc:
        return _unsupported("The supplied estimator is not demonstrably fitted. Fit it outside this audit using training-only preprocessing/selection, then pass it again.",purpose,n=n,p=p,features=features,model_name=name)
    try:
        trained_names=getattr(model,"feature_names_in_",None)
        trained_p=getattr(model,"n_features_in_",None)
        trained_features=None
        if trained_p is not None:
            if isinstance(trained_p,(bool,np.bool_)) or not isinstance(trained_p,(int,np.integer)) or not 1<=int(trained_p)<=2048:
                raise ValueError("Fitted n_features_in_ must be a bounded positive integer")
            if int(trained_p)!=p:
                raise ValueError("Input feature count differs from the fitted estimator; provide its original prediction input without hidden transformations.")
        if trained_names is not None:
            names_array=np.asarray(trained_names,dtype=object)
            if names_array.ndim!=1 or len(names_array)!=p:
                raise ValueError("Fitted feature_names_in_ must contain one scalar name per original input column")
            trained_features=[_native(value) for value in names_array]
            if named and trained_features!=features:
                raise ValueError("Named input features differ from fitted feature_names_in_ in names or order; explicitly reconstruct the original input order rather than silently reorder.")
    except (ValueError,TypeError,OverflowError) as exc:
        return _unsupported(str(exc),purpose,n=n,p=p,features=features,model_name=name,failed_requirement="target_compatibility")
    if metadata is not None and (not isinstance(metadata,dict) or set(metadata)-{"entity_ids","feature_available_times","prediction_times","split_evidence"}):
        return _unsupported("Unknown split/timing metadata fields; supported keys are entity_ids, feature_available_times, prediction_times and split_evidence.",purpose,n=n,p=p,features=features,model_name=name)
    supplied=deepcopy(metadata or {})
    feature_time=supplied.pop("feature_available_times",None); prediction_time=supplied.pop("prediction_times",None)
    if (feature_time is None)!=(prediction_time is None):
        return _unsupported("Feature availability and prediction cutoff metadata must be supplied together.",purpose,n=n,p=p,features=features,model_name=name,failed_requirement="timing")
    timing_row=None
    if feature_time is not None:
        try:
            if np.iscomplexobj(feature_time) or np.iscomplexobj(prediction_time): raise ValueError()
            ft=np.asarray(feature_time,dtype=float); pt=np.asarray(prediction_time,dtype=float)
            if ft.shape!=(n,p) or pt.shape!=(n,) or not np.isfinite(ft).all() or not np.isfinite(pt).all(): raise ValueError()
            late=int(np.sum(ft>pt[:,None]))
            timing_row=evidence("timing","fail" if late else "no_issue_detected","Raw feature availability versus row prediction cutoff",sample_size=n,
                observed={"late_cells":late,"availability_comparisons":int(ft.size),"late_fraction":late/ft.size,"variables":features,"group":"raw feature cells versus row cutoffs"},
                thresholds={"maximum_late_cells":0,"comparison":"feature availability <= prediction cutoff; common caller-defined time units"},
                limitations=["Metadata accuracy and label availability are not verified."],provenance={"adapter":ADAPTER_VERSION})
        except (ValueError,TypeError,OverflowError):
            return _unsupported("Finite timing metadata must match the raw input n-by-p shape and one cutoff per row.",purpose,n=n,p=p,features=features,model_name=name,failed_requirement="timing")
    final_for_scope=model
    for _ in range(8):
        if not isinstance(final_for_scope,Pipeline): break
        final_for_scope=final_for_scope.steps[-1][1]
    if type(final_for_scope) in {KNeighborsClassifier,KNeighborsRegressor} and any(callable(getattr(final_for_scope,key,None)) for key in ("metric","effective_metric_","weights")):
        return _unsupported("Callable KNN metric/weight functions are outside this bounded adapter. Supply externally computed predictions for a conditional output audit; no callback was executed here.",purpose,n=n,p=p,features=features,model_name=name,failed_requirement="predictor_domain")
    try:
        with warnings.catch_warnings(record=True) as captured:
            warnings.simplefilter("always")
            predictions,_=_alignment(X,model.predict(X),n)
            if predictions.ndim!=1 or len(predictions)!=n: raise ValueError("Only one predicted outcome per input row is supported")
            probabilities=None; classes=[]; positive=None; decision_scores=None; score_source="not_available"
            baseline=baseline_predictions
            if baseline is not None:
                baseline,_=_alignment(X,baseline,n)
            if task=="classification":
                raw_classes=np.asarray(getattr(model,"classes_",[]))
                if raw_classes.ndim!=1 or not 2<=len(raw_classes)<=32: raise ValueError("Fitted classification requires 2..32 explicit single-target classes")
                classes=[_native(v) for v in raw_classes]
                if len(classes)>2 and positive_label is not None:
                    raise ValueError("positive_label is binary-only; multiclass reports retain every fitted class without choosing a privileged event")
                if len(classes)>2:
                    positive=None
                elif positive_label is None:
                    if set(classes)=={0,1}: positive=raw_classes[list(classes).index(1)]
                    else: raise ValueError("Set positive_label explicitly for binary labels other than 0/1")
                else:
                    matching=[i for i,c in enumerate(classes) if c==positive_label]
                    if len(matching)!=1: raise ValueError("positive_label must match exactly one fitted class")
                    positive=raw_classes[matching[0]]
                if callable(getattr(model,"predict_proba",None)):
                    raw_probability=model.predict_proba(X)
                    if np.ma.isMaskedArray(raw_probability) and np.ma.getmaskarray(raw_probability).any():
                        raise ValueError("Masked predict_proba cells require explicit missingness handling; probabilities are not silently unmasked")
                    if np.iscomplexobj(raw_probability): raise ValueError("predict_proba must return real probabilities")
                    probability_columns=getattr(raw_probability,"columns",None)
                    if probability_columns is not None and list(probability_columns)!=list(raw_classes):
                        raise ValueError("Named predict_proba columns must match actual classes_ values and order; no silent reordering")
                    probability_index=getattr(raw_probability,"index",None); input_index=getattr(X,"index",None)
                    if probability_index is not None and input_index is not None and hasattr(input_index,"equals") and not input_index.equals(probability_index):
                        raise ValueError("Named predict_proba rows must match input indexes in values and order")
                    raw_prob=np.asarray(raw_probability,dtype=float)
                    if raw_prob.shape!=(n,len(classes)) or not np.isfinite(raw_prob).all() or np.any((raw_prob<0)|(raw_prob>1)) or not np.allclose(raw_prob.sum(axis=1),1.,atol=1e-6):
                        raise ValueError("predict_proba must return finite normalized probabilities in actual classes_ order")
                    if len(classes)>2: probabilities=raw_probability
                    else:
                        column=int(np.where(raw_classes==positive)[0][0]); probabilities=raw_prob[:,column]
                    score_source="predict_proba"
                elif len(classes)==2 and callable(getattr(model,"decision_function",None)):
                    raw_score=model.decision_function(X)
                    if np.iscomplexobj(raw_score): raise ValueError("decision_function must supply real binary scores")
                    raw_score,_=_alignment(X,raw_score,n)
                    decision_scores=np.asarray(raw_score,dtype=float)
                    if decision_scores.shape!=(n,) or not np.isfinite(decision_scores).all() or np.any(np.abs(decision_scores)>10**100):
                        raise ValueError("Binary decision_function must supply one bounded finite score per row")
                    if positive==raw_classes[0]: decision_scores=-decision_scores
                    score_source="binary_decision_function"
                if len(classes)==2:
                    target=_binary(target,raw_classes,positive); predictions=_binary(predictions,raw_classes,positive)
                    if baseline is not None: baseline=_binary(baseline,raw_classes,positive)
            if task=="classification" and len(classes)>2:
                from .multiclass import audit_multiclass
                result=audit_multiclass(target,predictions,classes=classes,probabilities=probabilities,
                    baseline_predictions=baseline,metadata=supplied,attestations=attestations)
            else:
                result=audit_prediction(target,predictions,task=task,probabilities=probabilities,baseline_predictions=baseline,
                                        metadata=supplied,attestations=attestations,split_role=split_role)
                if decision_scores is not None: _ranking_from_margin(result,target,decision_scores,n)
            if task=="classification" and (len(classes)>2 or decision_scores is not None):
                result["estimates"]["visual_evidence"]=_collect_visual(_visuals.classification_visual_evidence,
                    target,predictions,classes=classes if len(classes)>2 else [0,1],
                    probabilities=probabilities,scores=decision_scores,n=n,source_split=split_role)
            family_details,fit_concerns=_family_details(model)
        missing,infinite,cells=_raw_missing(X)
    except (ValueError,TypeError,AttributeError,OverflowError,IndexError) as exc:
        return _unsupported("Prediction audit could not proceed: "+str(exc)[:1000],purpose,n=n,p=p,features=features,model_name=name,failed_requirement="target_compatibility")
    result["sample_sizes"]["p"]=p
    result["estimates"]["adapter_status"]="supported_prediction"
    result["estimates"]["adapter"]={"library":"scikit-learn","library_version":sklearn.__version__,"estimator_type":name,
        "input_feature_names":features,"fitted_input_feature_names":trained_features or [],
        "class_order":classes,"positive_label":None if positive is None else _native(positive),"row_alignment":alignment,
        "score_source":score_source,"probability_metrics_available":probabilities is not None,
        "source_split":split_role,"preprocessing_owner":"supplied estimator/Pipeline; no transform or fit called by adapter",
        "model_refit":False,"prediction_warning_count":len(captured),"training_design_assessed":False,
        **family_details}
    for row in result["evidence"]:
        if row["requirement"]=="missingness" and row["source"]=="automated":
            row["observed"].update({"raw_input_missing_cells":missing,"raw_input_infinite_cells":infinite,"raw_input_cell_denominator":cells,
                                     "raw_input_feature_names":features,"source_split":split_role})
            if (missing or infinite) and row["status"]!="fail": row["status"]="warning"
            row["limitations"].append("Raw missing values may be handled by the supplied fitted Pipeline; prediction success does not validate missingness mechanisms or the transformed training design.")
        row["provenance"]["source_split"]=split_role
    if timing_row is not None: result["evidence"].append(timing_row)
    if fit_concerns:
        result["evidence"].append(evidence("convergence","warning","Recorded fitted-estimator solver completion concerns",sample_size=None if family_details.get("model_family")=="feedforward_mlp" else n,
            observed={"checks":[{"comparison":title,**values} for title,values,_ in fit_concerns],"group":"supplied fitted estimator state","variables":[family_details["final_estimator_type"]]},
            thresholds={"comparison":"recorded iterations versus configured solver limit; nonzero libsvm status versus success code zero"},
            limitations=[limit for _,_,limit in fit_concerns]+["No training is rerun. These flags do not certify the correctness of a fitted model or its assumptions."],
            remedies=["Review the original training warnings and solver settings using training data; any refit requires a fresh, appropriately held-out evaluation."],
            provenance={"adapter":ADAPTER_VERSION,"source_split":split_role}))
    if family_details.get("model_family")=="feedforward_mlp":
        from .neural_visuals import neural_training_visual_evidence
        history=neural_training_visual_evidence(family_details)
        existing=result["estimates"].get("visual_evidence")
        if existing is not None:
            merged={**existing,"source_split":"mixed","n":max(existing["n"],history["n"]),"panels":existing["panels"]+history["panels"]}
            _visuals.validate_visual_evidence(merged)
            result["estimates"]["visual_evidence"]=merged
        if not fit_concerns:
            result["evidence"].append(evidence("convergence","not_checked","Native MLP iteration/history state is recorded, but original optimizer warnings and termination evidence are not certified.",
                source="manual_required",limitations=["A finite loss curve, early-stopping score or iteration count is not proof of convergence."],
                remedies=["Review native training warnings, stopping settings and training-only validation history."],provenance={"adapter":ADAPTER_VERSION,"source_split":"training"}))
    if trained_names is not None and not named:
        result["evidence"].append(evidence("data_grain","warning","Named fitted features received an unnamed array; feature order cannot be independently verified",source="automated",sample_size=n,
            observed={"variables":features,"comparison":"positional input only"},limitations=["Use an explicitly ordered DataFrame to verify named columns."],provenance={"adapter":ADAPTER_VERSION}))
    result["limitations"].extend([
        "The model was supplied already fitted. No fit, clone, preprocessing transform, feature selection or correction was invoked by this adapter.",
        "Only prediction metrics are evaluated; input feature names refer to raw prediction inputs, not the fitted transformed design.",
        "Visual prediction axes summarize existing outcomes, predicted labels/probabilities or oriented decision scores. No raw feature is labeled as a Pipeline's transformed design axis.",
        "Split role is caller-declared. Held-out provenance, training-only selection and baseline selection cannot be recovered from a fitted object.",
        "Prediction warnings are counted without copying warning text or raw records into the report.",
        family_details["family_limitation"]])
    if split_role in {"training","unknown"}:
        result["limitations"].append("These inputs are training or unknown-split data; their metrics must not be called untouched held-out performance.")
        result["evidence"].append(evidence("evaluation_protocol","warning","No untouched evaluation role is established for these supplied rows",source="automated",sample_size=n,
            observed={"source_split":split_role,"group":"supplied prediction rows"},limitations=["A human attestation cannot override this recorded role concern."],provenance={"adapter":ADAPTER_VERSION}))
    if family_details.get("model_family") in {"nearest_neighbors","naive_bayes"}:
        from .neighbor_bayes import neighbor_bayes_evidence
        try:
            result["evidence"].extend(neighbor_bayes_evidence(model,X,source_split=split_role))
            result["estimates"]["adapter"]["neighbor_bayes_evidence_built"]=True
        except (ValueError,TypeError,AttributeError,OverflowError,KeyError,IndexError) as exc:
            result["estimates"]["adapter"]["neighbor_bayes_evidence_built"]=False
            for requirement in family_details["additional_requirements"]:
                result["evidence"].append(evidence(requirement,"not_checked",
                    "The bounded neighbor/Naive Bayes evidence collector could not complete; no successful domain or assumption verdict is inferred.",
                    source="manual_required",sample_size=n,observed={"collector_error_type":type(exc).__name__,"source_split":split_role},
                    limitations=["Native predictions may have been computed, but these method-specific requirements remain unresolved. No collector error text or training records are copied into the report."],
                    remedies=["Review the documented supported native state and estimator-input representation before relying on this model's interpretation."],
                    provenance={"adapter":ADAPTER_VERSION,"source_split":split_role}))
    from .report import complete_adapter_requirements
    complete_adapter_requirements(result)
    result["claims"]=gate_claims(result); validate_report(result)
    return result


def audit_report(model, X=None, y=None, *, purpose="prediction", output_dir="model-evidence-reports",
                 baseline_predictions=None, positive_label=None, metadata=None,
                 attestations=None, split_role="unknown", test_options=None, analysis_options=None):
    """One fitted-model call producing report data, figure, table and explanation.

    All files are local. No web UI, DAG or agent is needed for prediction.
    Outputs use the renderer's protected deterministic content-hash directory.
    """
    from .render import render_report
    report=audit_fitted(model,X,y,purpose=purpose,baseline_predictions=baseline_predictions,
        positive_label=positive_label,metadata=metadata,attestations=attestations,split_role=split_role,test_options=test_options,analysis_options=analysis_options)
    return {"report":report,"artifacts":render_report(report,output_dir),"explanation":explain_report(report)}
