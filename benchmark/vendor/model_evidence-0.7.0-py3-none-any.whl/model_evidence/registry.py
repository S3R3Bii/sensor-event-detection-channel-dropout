"""Versioned registry: method coverage is data, never executable instructions."""
from copy import deepcopy
from functools import lru_cache
from importlib.resources import files
import json
import re

_VERSIONS = {"0.1.0", "0.2.0", "0.3.0", "0.4.0", "0.5.0", "0.6.0", "0.7.0"}
_COVERAGE = {"executable", "partial", "manual_only"}


def _names(value, *, allow_empty=False):
    return (isinstance(value, list) and len(value) <= 256 and
            (allow_empty or bool(value)) and all(isinstance(x, str) and
            re.fullmatch(r"[a-z][a-z0-9_]{0,79}", x) for x in value) and
            len(value) == len(set(value)))


def _texts(value, *, allow_empty=False):
    return (isinstance(value, list) and len(value) <= 256 and
            (allow_empty or bool(value)) and all(isinstance(x, str) and
            bool(x.strip()) and len(x) <= 8192 for x in value))


def _text(value):
    return isinstance(value, str) and bool(value.strip()) and len(value) <= 8192


def validate_registry(registry):
    """Validate bounded data-only registry metadata; never resolve or run code.

    A declared coverage label is not a verified numerical implementation. New
    checks still require explicit adapter code, tests and execution evidence.
    Unknown fields and references fail rather than becoming implicit success.
    """
    top = {"registry_version", "schema_version", "use_cases", "requirements", "claims", "methods", "family_coverage"}
    if not isinstance(registry, dict) or set(registry) != top:
        raise ValueError("Invalid registry fields")
    if not isinstance(registry["registry_version"], str) or registry["registry_version"] not in _VERSIONS or registry["schema_version"] != "1.1.0":
        raise ValueError("Unsupported registry version")
    if not _names(registry["use_cases"]):
        raise ValueError("Invalid registry use cases")
    for key in ("requirements", "claims", "methods", "family_coverage"):
        value = registry[key]
        if not isinstance(value, dict) or not value or len(value) > 256 or not _names(list(value)):
            raise ValueError("Invalid registry mapping")
    requirements = registry["requirements"]
    for value in requirements.values():
        if (not isinstance(value, dict) or set(value) != {"label", "description", "remedies"}
                or not _text(value["label"]) or not _text(value["description"])
                or not _texts(value["remedies"])):
            raise ValueError("Invalid registry requirement")
    for value in registry["claims"].values():
        if (not isinstance(value, dict) or set(value) - {"purpose", "requirements", "description", "method_requirements"}
                or not {"purpose", "requirements", "description"} <= set(value)
                or value["purpose"] not in registry["use_cases"] or not _text(value["description"])
                or not _names(value["requirements"]) or not set(value["requirements"]) <= set(requirements)
                or ("method_requirements" in value and type(value["method_requirements"]) is not bool)):
            raise ValueError("Invalid registry claim")
    for value in registry["methods"].values():
        fields = {"name", "family", "coverage", "use_cases", "requirements", "claims", "limitations", "sources"}
        if not isinstance(value, dict) or not fields <= set(value) or set(value) - fields - {"introduced_in", "implementation_introduced_in", "is_method"}:
            raise ValueError("Invalid registry method fields")
        if (not _text(value["name"]) or not _text(value["family"]) or not isinstance(value["coverage"], str) or value["coverage"] not in _COVERAGE
                or not _names(value["use_cases"]) or not set(value["use_cases"]) <= set(registry["use_cases"])
                or not _names(value["requirements"]) or not set(value["requirements"]) <= set(requirements)
                or not _names(value["claims"], allow_empty=True) or not set(value["claims"]) <= set(registry["claims"])
                or not _texts(value["limitations"]) or not _texts(value["sources"], allow_empty=True)):
            raise ValueError("Invalid registry method metadata")
        if any(not source.startswith("https://") or any(c.isspace() for c in source) for source in value["sources"]):
            raise ValueError("Registry sources must be bounded HTTPS documentation references")
        introduced = value.get("introduced_in", "0.1.0")
        if (not isinstance(introduced, str) or introduced not in _VERSIONS
                or tuple(map(int, introduced.split("."))) > tuple(map(int, registry["registry_version"].split(".")))):
            raise ValueError("Invalid method introduction version")
        implemented = value.get("implementation_introduced_in", introduced)
        if (not isinstance(implemented, str) or implemented not in _VERSIONS
                or tuple(map(int, implemented.split("."))) < tuple(map(int, introduced.split(".")))
                or tuple(map(int, implemented.split("."))) > tuple(map(int, registry["registry_version"].split(".")))):
            raise ValueError("Invalid implementation introduction version")
        if "is_method" in value and type(value["is_method"]) is not bool:
            raise ValueError("Invalid scientific-method marker")
        if any(registry["claims"][claim]["purpose"] not in value["use_cases"] for claim in value["claims"]):
            raise ValueError("Claim purpose is unsupported by its method")
    for value in registry["family_coverage"].values():
        if (not isinstance(value, dict) or set(value) != {"label", "coverage", "methods", "supported", "not_implemented"}
                or not _text(value["label"]) or not isinstance(value["coverage"], str) or value["coverage"] not in _COVERAGE
                or not _names(value["methods"], allow_empty=True) or not set(value["methods"]) <= set(registry["methods"])
                or not _texts(value["supported"], allow_empty=True) or not _texts(value["not_implemented"])):
            raise ValueError("Invalid family coverage metadata")
        if value["coverage"] == "manual_only" and value["supported"]:
            raise ValueError("Manual-only family cannot claim numerical support")
    return registry

@lru_cache(maxsize=1)
def _registry():
    return validate_registry(json.loads(files("model_evidence.resources").joinpath("registry.json").read_text(encoding="utf-8")))

def load_registry():
    return deepcopy(_registry())

def method_spec(method):
    if not isinstance(method, str) or method not in _registry()["methods"]:
        raise ValueError("Unknown method")
    return deepcopy(_registry()["methods"][method])

def list_methods():
    return [{"id": k, **deepcopy(v)} for k, v in _registry()["methods"].items()]

def family_coverage(family=None):
    """Copy the declared family map; metadata cannot create numerical adapters."""
    values = _registry()["family_coverage"]
    if family is not None:
        if not isinstance(family, str) or family not in values:
            raise ValueError("Unknown coverage family")
        return deepcopy(values[family])
    return deepcopy(values)

def describe_requirements(method, purpose):
    spec = method_spec(method)
    if purpose not in _registry()["use_cases"]:
        raise ValueError("Unknown purpose")
    relevant = {k:v for k,v in _registry()["claims"].items() if v["purpose"] == purpose}
    claims = {k:v for k,v in relevant.items() if k in spec["claims"]} or relevant
    ids = set(spec["requirements"])
    for value in claims.values():
        ids.update(value["requirements"])
        if value.get("method_requirements", False): ids.update(spec["requirements"])
    if "coefficient_association" in claims:
        ids.add("exogeneity")
        if method=="logistic": ids.update(["convergence","separation","event_information"])
    return {"method": method, "purpose": purpose, "coverage": spec["coverage"],
            "purpose_supported": purpose in spec["use_cases"], "claims": claims,
            "requirements": {k:deepcopy(_registry()["requirements"][k]) for k in sorted(ids)}}
