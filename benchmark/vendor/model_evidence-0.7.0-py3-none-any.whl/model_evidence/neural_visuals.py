"""Bounded recorded sklearn MLP training state; no fit, weights or row export.

Loss and internal-validation histories describe native training, not prediction
on the separately supplied audit rows. The histories can span warm/partial fits.
"""
from __future__ import annotations

import math

import numpy as np
from sklearn.neural_network import MLPClassifier, MLPRegressor

from .model_visuals import PRIVACY, SCHEMA_VERSION, _curve, status_panel, validate_visual_evidence

MAX_HISTORY_RECORDS = 1_000_000
MAX_RETAINED_POINTS = 65
_STATE_LIMITS = [
    "The fitted object does not retain complete training warning, preprocessing, tuning or split provenance. Recorded stopping state cannot prove convergence or generalization.",
    "Native loss can include regularization and half-loss scaling; it is not held-out MSE, log loss or calibration error and cannot be compared numerically across objectives.",
    "With early stopping, final weights can be restored from the best internal-validation epoch. The last recorded loss need not describe those restored weights.",
    "Retained history may span warm_start/partial_fit calls. Neither unique training sample size nor independent validation membership is reconstructed.",
    "Internal validation used during stopping is model-selection data, not untouched final evaluation. Random internal splitting need not respect group/time structure.",
]


def _integer(value, low=0):
    if isinstance(value, (int, np.integer)) and not isinstance(value, (bool, np.bool_)) and low <= value <= 1_000_000_000:
        return int(value)
    return None


def _scalar(value, *, nonnegative=False):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, float, np.integer, np.floating)):
        return None
    value = float(value)
    if not math.isfinite(value) or abs(value) > 1e40 or (nonnegative and value < 0):
        return None
    return value


def _history(value, *, nonnegative=False, probability=False):
    result = {"status": "not_available", "records": 0, "retained_positions": [], "retained_values": [],
              "sampling": "At most 65 deterministic equally spaced native history positions, including first and last; no smoothing or missing-value deletion."}
    if value is None:
        return result
    if np.ma.isMaskedArray(value):
        result["status"] = "invalid"
        return result
    if isinstance(value, (list, tuple)) and any(isinstance(item, (bool, np.bool_, complex, np.complexfloating, str)) for item in value):
        result["status"] = "invalid"
        return result
    try:
        raw = np.asarray(value)
    except (ValueError, TypeError, OverflowError):
        result["status"] = "invalid"
        return result
    if raw.ndim != 1 or raw.size == 0 or raw.size > MAX_HISTORY_RECORDS or raw.dtype.kind not in "iuf":
        result["status"] = "invalid"
        return result
    result["records"] = int(raw.size)
    values = np.asarray(raw, dtype=float)
    if not np.isfinite(values).all() or np.any(np.abs(values) > 1e40) or (nonnegative and np.any(values < 0)) or (probability and np.any((values < 0) | (values > 1))):
        result["status"] = "invalid"
        return result
    positions = np.unique(np.linspace(0, values.size - 1, min(MAX_RETAINED_POINTS, values.size), dtype=int))
    result.update(status="recorded", retained_positions=(positions + 1).tolist(), retained_values=values[positions].tolist())
    return result


def describe_mlp_fit(model):
    """Return bounded exact-stock native state plus concerns for adapter evidence.

    Unsupported objectives fail explicitly rather than being relabeled as a
    validated neural family. No loss is derived from network weights or inputs.
    """
    if type(model) not in {MLPRegressor, MLPClassifier}:
        raise ValueError("Recorded MLP state requires exact stock MLPRegressor/MLPClassifier")
    classifier = type(model) is MLPClassifier
    if not classifier and getattr(model, "loss", "squared_error") != "squared_error":
        raise ValueError("This bounded MLPRegressor adapter supports squared_error loss only; other objectives need an explicit tested adapter")
    solver = getattr(model, "solver", None)
    if solver not in {"adam", "sgd", "lbfgs"}:
        raise ValueError("Unrecognized fitted MLP solver")
    early = getattr(model, "early_stopping", None)
    if type(early) is not bool:
        raise ValueError("Fitted MLP early_stopping state must be boolean")
    n_iter = _integer(getattr(model, "n_iter_", None), 1)
    budget = _integer(getattr(model, "max_iter", None), 1)
    if n_iter is None or budget is None:
        raise ValueError("Fitted MLP iteration count and budget must be bounded positive integers")
    layers = _integer(getattr(model, "n_layers_", None), 2)
    if layers is None or layers > 128:
        raise ValueError("Fitted MLP has unsupported/excessive layer metadata")
    native_loss = _scalar(getattr(model, "loss_", None), nonnegative=True)
    loss_history = _history(getattr(model, "loss_curve_", None), nonnegative=True)
    validation_history = _history(getattr(model, "validation_scores_", None), probability=classifier)
    if solver == "lbfgs":
        # LBFGS does not use sklearn's stochastic early-stopping validation
        # mechanism, even when the constructor flag is True.
        active_internal_validation = False
    else:
        active_internal_validation = early
    details = {
        "scope": "Exact-stock sklearn feedforward MLP; supplied prediction assessment plus recorded training-state review",
        "solver": solver, "recorded_iterations": n_iter, "configured_max_iter": budget,
        "configured_early_stopping": early, "internal_validation_active_for_solver": active_internal_validation,
        "internal_validation_metric": "accuracy" if classifier else "R_squared",
        "internal_validation_source": "native training-owned selection split; not externally verified or untouched final evaluation",
        "training_sample_size": "unknown; unique training rows are not reconstructed from retained state",
        "history_denominator": "recorded epoch/history positions, not independent observations",
        "n_layers_including_input_output": layers,
        "recorded_terminal_training_loss": native_loss,
        "native_loss_semantics": "native penalized log loss" if classifier else "native half squared error plus regularization term",
        "native_best_training_loss": _scalar(getattr(model, "best_loss_", None), nonnegative=True),
        "native_best_internal_validation_score": _scalar(getattr(model, "best_validation_score_", None)),
        "loss_history": loss_history, "internal_validation_history": validation_history,
        "training_warnings_available": False, "optimizer_convergence_certified": False,
        "limits": list(_STATE_LIMITS),
    }
    if active_internal_validation:
        fraction = _scalar(getattr(model, "validation_fraction", None))
        if fraction is None or not 0 < fraction < 1:
            raise ValueError("Native active internal-validation fraction must be strictly between 0 and 1")
        details["configured_internal_validation_fraction"] = fraction
    if solver == "lbfgs":
        details["configured_max_fun"] = _integer(getattr(model, "max_fun", None), 1)
    concerns = []
    if n_iter >= budget:
        concerns.append(("Recorded MLP iterations reached/exceeded the configured budget",
            {"recorded_iterations": n_iter, "configured_max_iter": budget, "solver": solver},
            "Budget exhaustion is a review concern, not proof of failed convergence. Original warnings, tolerance/solver termination and training provenance are unavailable; a lower count would not certify convergence."))
    if native_loss is None:
        concerns.append(("Native fitted MLP loss is absent or invalid", {"loss_available": False},
            "Predictions may still be calculable, but an invalid/absent loss cannot become a successful optimization diagnostic."))
    for name, history in (("loss", loss_history), ("internal_validation", validation_history)):
        if history["status"] == "invalid":
            concerns.append(("Native MLP history contains unsupported/nonfinite records",
                {"history": name, "records": history["records"], "status": history["status"]},
                "No nonfinite history entries are deleted, interpolated or silently replaced; the corresponding diagnostic panel stays unassessed."))
    if active_internal_validation and validation_history["status"] != "recorded":
        concerns.append(("Active MLP internal-validation history is unavailable",
            {"solver": solver, "validation_history_status": validation_history["status"]},
            "The stopping/selection history cannot be reviewed. The caller's separately supplied audit rows remain a distinct source."))
    return details, concerns


def neural_training_visual_evidence(adapter_details):
    """Build diagnostic-only training-history panels from bounded native state.

    Panel n counts history records, not observations. Merge with prediction
    evidence as mixed-source data, retaining this explicit denominator warning.
    This helper neither reads a model nor takes any action from report content.
    """
    state = adapter_details.get("neural_fit") if isinstance(adapter_details, dict) else None
    if not isinstance(state, dict):
        raise ValueError("Neural history visuals require bounded neural_fit adapter details")
    panels = []
    for key, identifier, title, unit, split in (
        ("loss_history", "mlp_training_loss", "Native MLP training objective history", "Native penalized training objective", "training"),
        ("internal_validation_history", "mlp_internal_validation", "Native MLP internal validation used for stopping", state["internal_validation_metric"], "validation"),
    ):
        history = state[key]
        record_count = history["records"]
        comparison = "Denominator n counts retained native history records/epochs, NOT unique training or validation observations; fixed recorded positions only."
        limits = list(_STATE_LIMITS) + [history["sampling"]]
        if history["status"] == "recorded" and (key == "loss_history" or state["internal_validation_active_for_solver"]):
            panels.append(_curve(identifier, title, history["retained_positions"], history["retained_values"], record_count, split,
                role="diagnostic", requirement="convergence", units=unit, comparison=comparison,
                threshold="No success cutoff: objective/score history does not prove convergence, calibration or generalization.",
                interpretation="Review the recorded optimizer/selection history alongside the separately labeled supplied-row prediction results. A decreasing loss or favorable selected validation score is not untouched evaluation performance.",
                limitations=limits, axes={"x": "Native recorded history position (epochs; may span warm/partial fits)", "y": unit}))
        else:
            inactive = key == "internal_validation_history" and not state["internal_validation_active_for_solver"]
            message = "Internal stopping validation is not active for this solver/configuration." if inactive else "The native history is unavailable or invalid; no curve is invented or repaired."
            panels.append(status_panel(identifier, title, n=0, source_split=split, requirement="convergence",
                status="not_applicable" if inactive else "not_checked", message=message, comparison=comparison,
                interpretation=message + " This does not assess external evaluation or convergence.", limitations=limits))
    n = max((panel["n"] for panel in panels), default=0)
    result = {"schema_version": SCHEMA_VERSION, "source_split": "mixed", "n": n, "privacy": PRIVACY, "panels": panels}
    validate_visual_evidence(result)
    return result
