"""Bounded OLS residual diagnostics, never a primary-model refit or repair.

Ordering is explicit input: supplied row order alone is not time/design evidence.
The optional statsmodels dependency owns the numerical diagnostic implementations.
"""
import math
import warnings
import numpy as np

from ._version import VERSION
from .report import evidence

MAX_CELLS=2_000_000
SPLITS={"training","unknown","validation","evaluation","final_holdout","final_evaluation"}
LIMITS=[
    "Diagnostic observations do not prove independence, constant variance, a correct conditional mean, exogeneity or causal identification.",
    "Reference distributions are conditional approximations. Dependence and mean misspecification can invalidate their p-value interpretation.",
    "No primary model is fitted, rows sorted/deleted, values repaired, covariance selected or numerical correction applied.",
    "Ordering/spacing metadata are caller declarations, not independently authenticated design evidence. Aggregates can remain sensitive.",
]


def _array(value,ndim,name):
    if np.ma.isMaskedArray(value) and np.ma.getmaskarray(value).any():
        raise ValueError(name+" contains masked cells; missingness is not silently discarded")
    if np.iscomplexobj(value): raise ValueError(name+" must be real")
    try: result=np.asarray(value,dtype=float)
    except (ValueError,TypeError,OverflowError) as exc: raise ValueError(name+" must be numeric") from exc
    if result.ndim!=ndim or not result.size or result.size>MAX_CELLS:
        raise ValueError(name+" has an invalid shape or exceeds the bounded size")
    if not np.isfinite(result).all() or np.any(np.abs(result)>1e40):
        raise ValueError(name+" must contain bounded finite real values")
    return result


def _order_metadata(order,n,max_lag):
    if order is None: return None
    if not isinstance(order,dict) or set(order)-{"times","single_series","regular_spacing","fit_df"}:
        raise ValueError("residual order accepts only times, single_series, regular_spacing and fit_df")
    if not {"times","single_series","regular_spacing"}<=set(order):
        raise ValueError("Residual order needs explicit times, single_series and regular_spacing declarations")
    if type(order["single_series"]) is not bool or order["single_series"] is not True:
        raise ValueError("Only an explicitly declared single residual series is supported; panels/groups need another design")
    if type(order["regular_spacing"]) is not bool:
        raise ValueError("regular_spacing must be an explicit boolean")
    times=_array(order["times"],1,"order.times")
    if len(times)!=n: raise ValueError("Order times must align to every residual row")
    gaps=np.diff(times)
    if not len(gaps) or np.any(gaps<=0):
        raise ValueError("Order times must already be unique and strictly increasing; no automatic sorting")
    if order["regular_spacing"] and not np.allclose(gaps,gaps[0],rtol=1e-7,atol=0.):
        raise ValueError("regular_spacing=True conflicts with the supplied time differences")
    model_df=order.get("fit_df",0)
    if type(model_df) is not int or model_df<0 or model_df>=max_lag:
        raise ValueError("fit_df must be a nonnegative integer smaller than max_lag")
    actual_lag=min(max_lag,n//5)
    if order["regular_spacing"] and actual_lag>0 and model_df>=actual_lag:
        raise ValueError("fit_df must be smaller than the effective sample-size-bounded Ljung-Box lag")
    return {"regular_spacing":order["regular_spacing"],"model_df":model_df,"lag":actual_lag,
        "time_gap_minimum":float(gaps.min()),"time_gap_maximum":float(gaps.max()),
        "time_units":"caller-defined ordered-time units; absolute timestamps withheld"}


def _row(req,status,diagnostic,n,observed,thresholds,limits,remedy,source_split,coverage="computed"):
    return evidence(req,status,diagnostic,sample_size=n,observed=observed,thresholds=thresholds,
        limitations=limits,remedies=[remedy],provenance={"implementation":"model-evidence/"+VERSION,
            "adapter":"ordered-ols-diagnostics/0.3.0","source_split":source_split,
            "implementation_coverage":coverage,"primary_model_refit":False})


def _unresolved(n,reason,source_split,*,observed=None):
    common={"n_residuals":n,"comparison":"not computed",**(observed or {})}
    rows=[_row(req,"not_checked",reason,n,dict(common),
        {"configuration":"no numerical result generated"},list(LIMITS),
        "Supply a supported nondegenerate training OLS fit and the required diagnostic/design metadata.",source_split,"not_run")
        for req in ("error_structure","independence","functional_form")]
    return {"evidence":rows,"estimates":{},"limitations":list(LIMITS)}


def _functions():
    from statsmodels.stats.diagnostic import acorr_ljungbox,het_breuschpagan
    from statsmodels.stats.stattools import durbin_watson
    return het_breuschpagan,durbin_watson,acorr_ljungbox


def _named_alignment(residuals,design,fitted_values,order):
    """Do not discard conflicting row ownership that a named input discloses."""
    values=[("residuals",residuals),("design",design),("fitted_values",fitted_values)]
    if isinstance(order,dict) and "times" in order: values.append(("order.times",order["times"]))
    named=[]
    for name,value in values:
        index=getattr(value,"index",None)
        if index is not None and callable(getattr(index,"equals",None)): named.append((name,index))
    if len(named)>1:
        for name,index in named[1:]:
            if not named[0][1].equals(index):
                raise ValueError(name+" named row index differs from "+named[0][0]+"; align explicitly, no automatic reordering")
        return "supplied_named_indexes_match; entity identity is not authenticated"
    return "positional_only; source row identity cannot be verified from arrays"


def ols_diagnostics(residuals,design,fitted_values,*,order=None,source_split="training",alpha=.05,max_lag=10):
    """Inspect supplied training OLS residuals; return evidence and aggregates.

    ``design`` is the actual fitted matrix, including any existing intercept;
    it is never rebuilt from raw features. ``order`` is either absent or a map
    with aligned strictly increasing ``times``, ``single_series=True``, explicit
    ``regular_spacing`` and optional ``fit_df=0``. A regular single series is
    necessary for Ljung-Box. ``fit_df`` is a caller-specified portmanteau reference
    adjustment, NOT automatically the number of regression coefficients.

    BP uses statsmodels' robust Koenker version and a prespecified auxiliary-F
    p-value concern threshold. DW is descriptive and has no universal pass band.
    Ljung-Box reports one prespecified/sample-size-bounded joint lag and an
    approximate chi-square reference. No p-value certifies an assumption.
    """
    if not isinstance(source_split,str) or source_split not in SPLITS: raise ValueError("Unknown residual source_split")
    if type(alpha) not in {int,float} or not math.isfinite(alpha) or not 0<alpha<1:
        raise ValueError("alpha must be a finite number strictly between zero and one")
    if type(max_lag) is not int or not 1<=max_lag<=100: raise ValueError("max_lag must be an integer from 1 to 100")
    alignment=_named_alignment(residuals,design,fitted_values,order)
    residuals=_array(residuals,1,"residuals"); design=_array(design,2,"design")
    fitted_values=_array(fitted_values,1,"fitted_values")
    n=len(residuals); p=design.shape[1]
    if len(fitted_values)!=n or design.shape[0]!=n or n<3 or p>256:
        raise ValueError("Residuals/design/fitted values need matching rows, n>=3 and at most 256 fitted columns")
    ordered=_order_metadata(order,n,max_lag)
    if source_split!="training":
        return _unresolved(n,"Training-fit residual diagnostics were not run on non-training or unknown-split outcomes",source_split)
    rank=int(np.linalg.matrix_rank(design))
    if rank!=p or n<=p+1:
        return _unresolved(n,"Rank-deficient design or insufficient residual degrees of freedom; reference tests were not run",source_split,
            observed={"design_rank":rank,"fitted_columns":p,"residual_df":n-rank})
    if not np.any(residuals) or float(np.var(residuals))==0.:
        return _unresolved(n,"Degenerate residual variation; variance/dependence tests are undefined or uninformative",source_split)
    try: bp,dw,lb=_functions()
    except ImportError:
        return _unresolved(n,"Optional statsmodels diagnostics dependency is unavailable; no diagnostic result was invented",source_split)
    base={"n_residuals":n,"fitted_columns":p,"design_rank":rank,"residual_df":n-rank,
        "group":"supplied OLS training residuals","variables":"actual fitted design and residuals; row order retained","row_alignment":alignment}
    rows=[]; estimates={}
    constant=np.ptp(design,axis=0)==0
    nonzero_constant=constant & (design[0]!=0)
    if p<2 or int(nonzero_constant.sum())!=1:
        rows.append(_row("error_structure","not_checked","Koenker/Breusch-Pagan requires one existing nonzero intercept and at least one varying fitted column",n,
            {**base,"comparison":"not computed"},{"required_intercepts":1,"minimum_fitted_columns":2},list(LIMITS),
            "Review the actual fitted specification; no intercept or variable is inserted automatically.",source_split,"not_run"))
    else:
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("error",RuntimeWarning)
                values=bp(residuals,design,robust=True)
            lm,lm_p,fvalue,f_p=map(float,values)
            if not all(math.isfinite(v) and 0<=v<=1e100 for v in (lm,lm_p,fvalue,f_p)) or not 0<=lm_p<=1 or not 0<=f_p<=1:
                raise ValueError("Nonfinite or out-of-range auxiliary regression result")
            result={"lm_statistic":lm,"lm_pvalue":lm_p,"f_statistic":fvalue,"f_pvalue":f_p,
                "lm_df":p-1,"numerator_df":p-1,"denominator_df":n-p,
                "reference_distribution":"Koenker LM approximate chi-square; auxiliary F comparison is conditional, not exact assumption proof"}
            estimates["koenker_breusch_pagan"]=result
            rows.append(_row("error_structure","warning" if f_p<alpha else "no_issue_detected",
                "Koenker/Breusch-Pagan residual-variance association with the actual fitted design",n,
                {**base,**result,"comparison":"auxiliary F p-value versus prespecified alpha; squared residuals versus fitted design"},
                {"alpha":float(alpha),"comparison":"f_pvalue < alpha flags a concern","test":"robust=True Koenker version",
                    "rationale":"Prespecified auxiliary-F comparison; no selection between conventional/robust inference from a pretest"},
                list(LIMITS)+["The robust version relaxes the normal-error form of the original BP test; it still needs appropriate independent-error/reference conditions and correct mean context.",
                    "Failure to reject variance association does not establish homoskedasticity. Small samples and dependent residuals can invalidate p-values."],
                "Review variance and mean/dependence assumptions. Prespecify a justified covariance policy; HC3 does not repair dependence or confounding.",source_split))
        except (ValueError,RuntimeWarning,ArithmeticError,np.linalg.LinAlgError) as exc:
            rows.append(_row("error_structure","not_checked","Koenker/Breusch-Pagan auxiliary calculation unavailable for these supplied residuals/design",n,
                {**base,"comparison":"not computed","reason":type(exc).__name__},
                {"configuration":"no finite auxiliary test returned"},list(LIMITS),
                "Review residual variation, rank and specification; no numerical value was substituted.",source_split,"not_run"))
    if ordered is None:
        rows.append(_row("independence","not_checked","No explicit residual-order metadata: row order was not assumed to define a series",n,
            {**base,"comparison":"not computed"},{"required_metadata":"times, single_series=True, explicit regular_spacing; optional fit_df"},
            list(LIMITS),"Document dependence design and a justified ordering. Grouped/panel data need appropriate methods; HC3 is insufficient.",source_split,"not_run"))
    else:
        ordered_values={**ordered,"durbin_watson":float(dw(residuals)),"ljung_box":None}
        if not math.isfinite(ordered_values["durbin_watson"]):
            return _unresolved(n,"Ordered residual statistic is nonfinite; no success was inferred",source_split)
        status="not_checked"
        if not ordered["regular_spacing"]:
            explanation="Durbin-Watson is descriptive in the declared order; Ljung-Box was not run for irregular time spacing"
        elif n<20:
            explanation="Durbin-Watson is descriptive; Ljung-Box omitted below this implementation's n=20 guard"
        else:
            lag=ordered["lag"]
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("error",RuntimeWarning)
                    result=lb(residuals,lags=[lag],model_df=ordered["model_df"],return_df=True,auto_lag=False)
                stat=float(result["lb_stat"].iloc[0]); pvalue=float(result["lb_pvalue"].iloc[0])
                if not math.isfinite(stat) or not math.isfinite(pvalue) or not 0<=stat<=1e100 or not 0<=pvalue<=1:
                    raise ValueError("Nonfinite or invalid Ljung-Box result")
                ordered_values["ljung_box"]={"lag":lag,"statistic":stat,"pvalue":pvalue,
                    "reference_df":lag-ordered["model_df"],"model_df":ordered["model_df"],
                    "reference_distribution":"approximate chi-square; caller/default fit_df adjustment, not OLS residual-variance df"}
                status="warning" if pvalue<alpha else "no_issue_detected"
                explanation="Ordered-residual Durbin-Watson description and one prespecified Ljung-Box joint-lag autocorrelation screen"
            except (ValueError,RuntimeWarning,ArithmeticError,np.linalg.LinAlgError):
                explanation="Durbin-Watson is descriptive; no finite Ljung-Box reference test was available"
        estimates["ordered_residuals"]=ordered_values
        rows.append(_row("independence",status,explanation,n,
            {**base,**ordered_values,"comparison":"Ljung-Box p-value versus alpha, when available; Durbin-Watson has no configured pass band"},
            {"alpha":float(alpha),"requested_max_lag":max_lag,"effective_lag_rule":"min(max_lag,n//5)",
                "minimum_ljung_box_n":20,"rationale":"Fixed lag/sample-size engineering guard, not outcome-selected lag or universal sample-size guarantee",
                "durbin_watson_cutoff":None},
            list(LIMITS)+["Ljung-Box uses demeaned residual autocorrelations. Its approximate p-value is conditional on the supplied regular single-series design and chosen reference adjustment.",
                "fit_df is caller-specified/default zero; it is not automatically the regression parameter count or a claim of correct ARMA degrees of freedom.",
                "A nonsignificant serial-correlation screen does not establish independent observations, correct sampling, stationarity or absence of group dependence."],
            "Review the dependence design and suitable covariance/evaluation methods; do not choose HAC/cluster settings from a diagnostic alone.",source_split,
            "computed" if ordered_values["ljung_box"] is not None else "descriptive_only"))
    rows.append(_row("functional_form","not_checked","RESET and general conditional-mean specification tests are not implemented by this bounded residual helper",n,
        {**base,"comparison":"not computed"},{"implementation":"no functional-form test or automatic transformation"},
        list(LIMITS)+["Residual variance and serial-correlation screens do not establish a correct functional form."],
        "Review training residual plots and scientific specification; any revised model needs a reviewed training-only refit and suitable evaluation.",source_split,"not_implemented"))
    return {"evidence":rows,"estimates":estimates,"limitations":list(LIMITS)}
