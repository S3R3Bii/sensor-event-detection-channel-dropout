"""Bounded, aggregate-only visual evidence for prespecified statistical tests.

This collector never selects or runs a hypothesis test. A chart marked computed
means its aggregate was computed, not that a scientific assumption was met.
Call only with the numerical detail and inputs from the same analysis revision.
"""
import math

import numpy as np
from scipy import stats

from .statistical_other import _integer_count, _table, _vector


METHODS = frozenset({"one_sample_t_test", "welch_t_test", "student_t_test", "paired_t_test", "anova",
    "chi_square", "fisher_exact", "binomial_test", "mann_whitney", "wilcoxon_signed_rank",
    "kruskal_wallis", "friedman", "pearson_correlation", "spearman_correlation",
    "welch_anova", "mcnemar_exact"})
SPLITS = frozenset({"unknown", "training", "validation", "evaluation", "final_holdout", "not_applicable"})
GROUPED = frozenset({"anova", "welch_anova", "kruskal_wallis", "friedman"})
PAIRED = frozenset({"paired_t_test", "wilcoxon_signed_rank", "pearson_correlation", "spearman_correlation"})
MEAN = frozenset({"one_sample_t_test", "welch_t_test", "student_t_test", "paired_t_test", "anova", "welch_anova"})
MAX_TOTAL = 2_000_000
MAX_GROUPS = 32
MAX_VISUAL_GROUPS = 10
BINS = 12
PRIVACY = "aggregate_only_no_row_pairs"
GENERAL_LIMITS = [
    "Computed describes the displayed aggregate, never a passed assumption or a validated sampling design.",
    "Binning hides within-bin shape and unusual observations; no universal visual pass threshold is applied.",
    "Only aggregates and generic group positions are returned. Small cells, bin edges and summaries may still reveal sensitive information; this is not anonymization.",
]


def _finite(value, name, *, allow_none=False):
    if value is None and allow_none:
        return None
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, float, np.integer, np.floating)):
        raise ValueError(name + " must be a finite numeric scalar")
    try:
        result = float(value)
    except (ValueError, OverflowError) as exc:
        raise ValueError(name + " exceeds the finite numeric range") from exc
    if not math.isfinite(result):
        raise ValueError(name + " must be finite; no infinity is converted to a plotted value")
    return result


def _sample(value, name):
    result = _vector(value, name)
    raw = np.asarray(value, dtype=object)
    if any(isinstance(v, (bool, np.bool_)) for v in raw):
        raise ValueError(name + " must be numeric measurements, not boolean observations")
    if not len(result):
        raise ValueError(name + " is empty; no sample distribution is invented")
    return result


def _alignment(values):
    indexes = [getattr(value, "index", None) for value in values]
    named = [i for i in indexes if callable(getattr(i, "equals", None))]
    if named:
        if len(named) != len(values):
            raise ValueError("Paired/repeated samples mix named and unnamed rows; align explicitly")
        if any(not bool(getattr(i, "is_unique", False)) for i in named):
            raise ValueError("Paired/repeated indexes must be unique; identifiers are not exported")
        if any(not named[0].equals(i) for i in named[1:]):
            raise ValueError("Paired/repeated indexes differ; no sorting, joining or reordering is performed")


def _panel(identifier, title, kind, role, n, split, data, *, requirement=None,
           status="computed", units="count", comparison="", threshold=None,
           interpretation="", limitations=(), axes=None):
    output = {"id": identifier, "title": title, "kind": kind, "role": role,
        "requirement": requirement, "status": status, "n": int(n), "source_split": split,
        "units": units, "comparison": comparison, "threshold": threshold,
        "interpretation": interpretation, "limitations": list(limitations), "data": data}
    if kind != "status":
        output["axes"] = axes or {"x": "generic supplied group/category position", "y": units}
    return output


def _status(identifier, title, n, split, message, *, requirement=None, role="manual", status="not_checked"):
    return _panel(identifier, title, "status", role, n, split, {"message": message},
        requirement=requirement, status=status, units="not applicable",
        comparison="Reported computation versus unresolved scientific requirements",
        interpretation=message, limitations=GENERAL_LIMITS[:1])


def _edges(values):
    try:
        edges = np.histogram_bin_edges(values, bins=BINS)
    except (ValueError, FloatingPointError):
        return False
    return edges if np.isfinite(edges).all() and np.all(np.diff(edges) > 0) else False


def _hist(identifier, title, values, n, split, interpretation, *, requirement=None, edges=None):
    if edges is None:
        edges = _edges(values)
    if edges is False:
        return _status(identifier, title + " not drawn", n, split,
            "Twelve distinct finite bin edges are unavailable at the input's working precision; no range widening, rounding or synthetic distribution is substituted.",
            requirement=requirement, role="descriptive")
    counts, edges = np.histogram(values, bins=edges)
    if int(counts.sum()) != n:
        raise ValueError("Histogram counts do not match the supplied sample size")
    return _panel(identifier, title, "hist1d", "descriptive", n, split,
        {"edges": edges.tolist(), "counts": counts.astype(int).tolist()}, requirement=requirement,
        units="observation count",
        comparison="Counts in 12 fixed equal-width bins across the supplied range; final bin includes its right edge",
        threshold="No distribution-shape pass threshold; bin count fixed at 12 before inspecting results",
        interpretation=interpretation, limitations=GENERAL_LIMITS,
        axes={"x": title + " (outcome units)", "y": "observation count"})


def _bars(identifier, title, labels, values, n, split, *, role="descriptive", requirement=None,
          units="count", comparison="", interpretation="", threshold=None, limitations=()):
    return _panel(identifier, title, "bars", role, n, split,
        {"labels": labels, "values": values}, requirement=requirement, units=units,
        comparison=comparison, threshold=threshold, interpretation=interpretation,
        limitations=limitations)


def _detail_n(method, detail):
    groups = detail.get("groups", [])
    if not isinstance(groups, list) or len(groups) > MAX_GROUPS:
        raise ValueError("Numerical detail groups must be a bounded list of aggregates")
    if not groups:
        return 0
    counts = []
    for group in groups:
        if not isinstance(group, dict):
            raise ValueError("Numerical detail group summaries must be objects")
        count = group.get("n", 0)
        counts.append(_integer_count(count, "detail group n"))
    n = sum(counts) if method in {"welch_t_test", "student_t_test", "mann_whitney", "anova", "welch_anova", "kruskal_wallis"} else counts[0]
    if n > MAX_TOTAL:
        raise ValueError("Numerical detail exceeds the aggregate observation bound")
    return n


def _main(detail, n, split):
    p = _finite(detail.get("p_value"), "detail p_value")
    if not 0 <= p <= 1:
        raise ValueError("Numerical detail p_value must lie in [0, 1]")
    statistic = _finite(detail.get("statistic"), "detail statistic", allow_none=True)
    effect = detail.get("effect", {})
    if not isinstance(effect, dict):
        raise ValueError("Numerical detail effect must be an object")
    estimate = _finite(effect.get("estimate"), "detail effect estimate", allow_none=True)
    ci = effect.get("confidence_interval")
    message = "Conditional two-sided numerical result: p=" + format(p, ".8g")
    if statistic is not None:
        message += "; statistic=" + format(statistic, ".8g")
    message += "; effect estimate=" + (format(estimate, ".8g") if estimate is not None else "not implemented or undefined")
    interval_values = None
    if ci is not None:
        if not isinstance(ci, dict):
            raise ValueError("Numerical detail confidence interval must be an object or null")
        low, high = _finite(ci.get("lower"), "CI lower"), _finite(ci.get("upper"), "CI upper")
        level = _finite(ci.get("level"), "CI level")
        if not 0 < level < 1 or low > high:
            raise ValueError("Numerical detail confidence interval has invalid bounds or level")
        interval_values = [low, high]
        message += "; " + format(100*level, ".6g") + "% interval=[" + format(low, ".8g") + ", " + format(high, ".8g") + "]"
    else:
        message += "; effect confidence interval not implemented or unavailable"
    message += ". Interpret against the original procedure, estimand and units in the key-metrics table; no assumption was certified by this result."
    if estimate is not None:
        labels, values = ["effect estimate"], [estimate]
        if interval_values is not None:
            labels += ["interval lower bound", "interval upper bound"]
            values += interval_values
        method = detail["procedure"]
        units = "outcome units" if method in MEAN - {"anova", "welch_anova"} else "proportion" if method in {"binomial_test", "mcnemar_exact"} else "probability" if method == "mann_whitney" else "dimensionless effect"
        return _bars("conditional_result", "Conditional effect and interval", labels, values, n, split,
            role="main_result", units=units,
            comparison="The original effect and any interval endpoints; endpoints are uncertainty bounds, not independent effects",
            interpretation=message,
            limitations=["Interpret effect name, units and reference conditions using the original key-metrics table. The displayed interval bounds are not separate parameter estimates and no assumption is verified by their values."])
    if statistic is not None:
        return _bars("conditional_result", "Conditional test statistic (effect unavailable)", ["test statistic"], [statistic], n, split,
            role="main_result", units="dimensionless test statistic",
            comparison="Original prespecified test statistic; effect magnitude and effect confidence interval remain unimplemented or undefined",
            interpretation=message, limitations=["A test statistic is not an effect magnitude, scientific importance, causal estimate or assumption certificate."])
    return _status("conditional_result", "Computed p-value; effect not plotted", n, split,
        "The numerical p-value was computed, but no finite effect or statistic is available to plot. " + message, role="main_result")


def _groups(method, x, y):
    if method in GROUPED:
        if y is not None:
            raise ValueError("Grouped/repeated procedures use x as a sequence of groups and y=None")
        if not isinstance(x, (list, tuple, np.ndarray)) or (isinstance(x, np.ndarray) and x.ndim == 0):
            raise ValueError("Grouped procedure requires a bounded sequence of samples")
        minimum = 3 if method == "friedman" else 2
        if not minimum <= len(x) <= MAX_GROUPS:
            raise ValueError("Grouped procedure requires " + str(minimum) + "..32 samples")
        if method == "friedman":
            _alignment(list(x))
        samples = [_sample(v, "group_"+str(i+1)) for i, v in enumerate(x)]
    else:
        if method == "one_sample_t_test":
            if y is not None:
                raise ValueError("One-sample procedure accepts x only")
            samples = [_sample(x, "x")]
        else:
            if y is None:
                raise ValueError("Selected two-sample procedure requires y")
            if method in PAIRED:
                _alignment([x, y])
            samples = [_sample(x, "x"), _sample(y, "y")]
    if sum(len(v) for v in samples) > MAX_TOTAL:
        raise ValueError("Combined input exceeds 2,000,000 observations")
    if method in PAIRED | {"friedman"} and len({len(v) for v in samples}) != 1:
        raise ValueError("Paired/repeated samples must have equal lengths; no rows are dropped")
    return samples


def _tie_panel(values, n, split, prefix="pooled"):
    count = int(len(values)); distinct = int(len(np.unique(values)))
    return _bars(prefix+"_ties", "Observed ties (descriptive)",
        ["distinct values", "additional tied observations"], [distinct, count-distinct], n, split,
        requirement="distributional_approximation", comparison="Distinct values plus additional ties = " + str(count) + " supplied values",
        interpretation=str(count-distinct) + " of " + str(count) + " values repeat an earlier distinct value. Tie counts describe the data; they neither fail nor certify a rank-test reference.",
        limitations=["Exact equality is used; no rounding or tolerance is applied. Tied rank groups can have different sizes even with the same summary count."])


def _variance_panel(samples, n, split, method):
    values = [float(np.var(v, ddof=1)) if len(v) > 1 else None for v in samples]
    if any(v is None or not math.isfinite(v) for v in values):
        return _status("sample_variances", "Sample variance comparison", n, split,
            "Sample variances need at least two finite measurements per group; no substitute variance is drawn.", requirement="equal_variance")
    positive = min(values) > 0
    ratio = max(values)/min(values) if positive else None
    ratio_text = "undefined because a sample variance is zero" if ratio is None else format(ratio, ".8g") if math.isfinite(ratio) else "not representable at the working precision"
    text = "Observed largest/smallest sample variance ratio=" + ratio_text + ". "
    text += "Equal population variances remain unverified; no test or model was selected from this plot." if method in {"student_t_test", "anova"} else "This procedure does not require equal population variances; observed dispersion still affects uncertainty and scientific interpretation."
    return _bars("sample_variances", "Observed sample variances", ["group_"+str(i+1) for i in range(len(samples))],
        values, n, split, role="diagnostic", requirement="equal_variance" if method in {"student_t_test", "anova"} else None,
        units="squared outcome units", comparison="Unbiased sample variance in each supplied group (denominator n_group-1)",
        threshold="No universal variance-ratio cutoff; no variance pretest or automatic test selection", interpretation=text,
        limitations=["Sample variance is an estimate, not a verification of population variance equality. Welch methods do not repair dependence or a wrong estimand."])


def _count_panels(method, table, n, split):
    panels = []
    rows, columns = table.shape
    labels = {"rows": ["row_"+str(i+1) for i in range(rows)], "columns": ["column_"+str(i+1) for i in range(columns)]}
    if max(table.shape) <= 12:
        panels.append(_panel("observed_counts", "Observed count table", "matrix", "descriptive", n, split,
            {"labels": labels, "values": table.astype(int).tolist()}, units="observed count",
            comparison="All " + str(n) + " supplied counts across " + str(rows*columns) + " ordered cells",
            interpretation="Generic row/column positions preserve input order; no categories were merged or removed.",
            limitations=GENERAL_LIMITS[2:], axes={"x": "supplied column position", "y": "supplied row position"}))
        if method != "mcnemar_exact":
            expected = np.outer(table.sum(axis=1), table.sum(axis=0))/n
            sparse = int(np.sum(expected < 5))
            chi = method == "chi_square"
            text = str(sparse) + " of " + str(expected.size) + " expected cells are below five (minimum=" + format(float(expected.min()), ".8g") + "). "
            text += "This is a review heuristic for the chi-square approximation, not a universal adequacy guarantee." if chi else "Fisher's exact fixed-margin reference does not require expected cells at least five; this matrix is a descriptive independence reference only."
            panels.append(_panel("expected_counts", "Expected counts under independence", "matrix", "diagnostic" if chi else "descriptive", n, split,
                {"labels": labels, "values": expected.tolist()}, requirement="distributional_approximation" if chi else None,
                units="expected count", comparison="row total * column total / grand total under the independence null",
                threshold="Expected count below 5 is a review heuristic, not a universal adequacy test" if chi else None,
                interpretation=text, limitations=["Observed sampling design is not established by counts. Expected counts are a null-model comparison, not measured observations."] + GENERAL_LIMITS[2:],
                axes={"x": "supplied column position", "y": "supplied row position"}))
    else:
        panels.append(_status("count_matrix_limit", "Count matrix not drawn", n, split,
            "The supplied table exceeds the 12-by-12 display bound. Marginal counts are shown; cells were not combined, deleted or fabricated.", role="descriptive"))
        for axis, axis_name in ((1, "row"), (0, "column")):
            values = table.sum(axis=axis).astype(int).tolist()
            panels.append(_bars(axis_name+"_totals", "Observed " + axis_name + " totals", [axis_name+"_"+str(i+1) for i in range(len(values))],
                values, n, split, comparison="All supplied cell counts summed over the other table dimension",
                interpretation="Marginal totals conceal cell-level association and sparse expected cells; the full matrix remains unassessed visually."))
    if method == "mcnemar_exact":
        b, c = int(table[0, 1]), int(table[1, 0])
        panels.append(_bars("paired_discordance", "Paired binary discordance", ["row 0 / column 1", "row 1 / column 0", "concordant"], [b, c, int(table[0, 0]+table[1, 1])],
            n, split, role="diagnostic", requirement="pairing", units="pair count",
            comparison="Discordant directions b versus c; exact conditional reference uses b+c=" + str(b+c) + " discordant pairs; marginal risk difference uses all N=" + str(n) + " pairs",
            threshold="Conditional null: P(0 to 1 | discordant)=0.5; this is distinct from an unconditional risk difference",
            interpretation="McNemar compares paired binary classifications, not independent groups. " + ("No discordant pairs: the exact p=1 result is uninformative about a nonzero change probability." if b+c == 0 else "Discordance counts preserve the supplied row/column coding; true pairing and independent analysis units remain unverified."),
            limitations=["No independence expected-count heatmap is substituted for this paired test. Row/column order is not evidence of temporal order; coding and pairing require design evidence."]))
    return panels


def statistical_visuals(method, x, y, detail, *, source_split="unknown"):
    """Collect bounded visual aggregates from one already-computed test.

    ``detail`` is the ``statistical_test`` dictionary from a numerical helper or
    audit report. Not-computable or missing detail yields status-only panels:
    no raw input is inspected and no diagnostic or hypothesis test is run.
    A computed detail must be paired with the exact same inputs and revision;
    sample-size checks cannot authenticate equal-size replacement datasets.
    No data, detail, model or scientific claim is modified by this function.
    """
    if not isinstance(method, str) or method not in METHODS:
        raise ValueError("Unsupported statistical visual method; no arbitrary procedure is executed")
    if not isinstance(source_split, str) or source_split not in SPLITS:
        raise ValueError("source_split must be a supported explicit split role")
    if detail is None:
        detail = {"procedure": method, "computational_status": "not_computable", "groups": []}
    if not isinstance(detail, dict) or detail.get("procedure") != method:
        raise ValueError("Numerical detail must match the selected method")
    computational_status = detail.get("computational_status")
    if computational_status not in {"computed", "not_computable"}:
        raise ValueError("Numerical detail must explicitly declare computed or not_computable")
    declared_split = detail.get("source_split", "unknown")
    if not isinstance(declared_split, str) or declared_split not in SPLITS or (source_split != "unknown" and declared_split != "unknown" and declared_split != source_split):
        raise ValueError("Numerical detail and visual split roles conflict or are invalid")
    if source_split == "unknown":
        source_split = declared_split
    n_hint = _detail_n(method, detail)
    output = {"schema_version": "1.0.0", "source_split": source_split, "n": n_hint,
        "privacy": PRIVACY, "panels": []}
    if computational_status != "computed":
        output["panels"].append(_status("conditional_result", "No computed main result", n_hint, source_split,
            "Numerical result is missing or not computable. Source samples were not inspected for additional visual diagnostics; resolve the reported context or numerical blocker first.", role="main_result"))
        output["panels"].append(_status("diagnostics_unassessed", "Diagnostics not assessed", n_hint, source_split,
            "No assumption check is marked successful and no numerical correction or replacement test is invented.", requirement="target_compatibility"))
        return output

    if method in {"chi_square", "fisher_exact", "mcnemar_exact"}:
        if y is not None:
            raise ValueError("Count-table procedures accept x only")
        table = _table(x, "fisher_exact" if method == "mcnemar_exact" else method)
        if any(isinstance(v, (bool, np.bool_)) for v in np.asarray(x, dtype=object).flat):
            raise ValueError("Boolean observations are not accepted as aggregate count frequencies")
        n = int(table.sum())
        if not n:
            raise ValueError("A computed count result cannot have zero total observations")
        panels = _count_panels(method, table, n, source_split)
    elif method == "binomial_test":
        successes, n = _integer_count(x, "successes"), _integer_count(y, "trials")
        if not n or successes > n:
            raise ValueError("Computed binomial data need 0 <= successes <= positive trials")
        null = detail.get("null", {})
        if not isinstance(null, dict):
            raise ValueError("Computed binomial detail needs its prespecified null")
        p0 = _finite(null.get("value"), "binomial null probability")
        if not 0 <= p0 <= 1:
            raise ValueError("Binomial null probability must lie in [0, 1]")
        panels = [_bars("binomial_counts", "Observed versus null-expected counts",
            ["observed success", "observed failure", "null-expected success", "null-expected failure"],
            [successes, n-successes, float(n*p0), float(n*(1-p0))], n, source_split,
            comparison="Observed successes/trials=" + str(successes) + "/" + str(n) + " versus prespecified p0=" + format(p0, ".8g"),
            interpretation="Observed proportion=" + format(successes/n, ".8g") + "; null-expected counts are model expectations, not extra observed trials.",
            limitations=["Exact binomial inference still requires independent Bernoulli trials with a common probability; this plot cannot verify those design assumptions."])]
    else:
        samples = _groups(method, x, y)
        n = len(samples[0]) if method in PAIRED | {"friedman"} else sum(len(v) for v in samples)
        panels = []
        if method in {"pearson_correlation", "spearman_correlation"}:
            first, second = samples
            ranks = method == "spearman_correlation"
            if ranks:
                first, second = stats.rankdata(first, method="average"), stats.rankdata(second, method="average")
            xe, ye = _edges(first), _edges(second)
            if xe is False or ye is False:
                panels.append(_status("association_density", "Association density not drawn", n, source_split,
                    "Twelve distinct finite bin edges are unavailable at the working precision. No raw scatter, range widening or artificial density is substituted.", role="descriptive"))
            else:
                counts, xe, ye = np.histogram2d(first, second, bins=[xe, ye])
                if int(counts.sum()) != n:
                    raise ValueError("Association density counts do not match aligned pair count")
                panels.append(_panel("association_density", "Rank association density" if ranks else "Observed association density", "hist2d", "descriptive", n, source_split,
                {"x_edges": xe.tolist(), "y_edges": ye.tolist(), "counts": counts.astype(int).tolist()},
                units="paired count per cell",
                comparison="All " + str(n) + " aligned pairs in a 12-by-12 histogram; counts[x_bin][y_bin], not raw record pairs",
                threshold="No visual pass threshold; no causal direction or valid sampling model is inferred",
                interpretation="Spearman describes monotonic rank association; ties use average ranks. This is not an exact or permutation inference." if ranks else "Pearson describes linear association. Curvature, outliers and nonlinear association can be hidden by binning; a small r need not imply no relationship.",
                limitations=["No point-level scatter or fitted curve is exported. Binning cannot validate bivariate normality, linearity, independence or external validity."] + GENERAL_LIMITS[2:],
                    axes={"x": "x average rank (rank)" if ranks else "x (outcome units)", "y": "y average rank (rank)" if ranks else "y (outcome units)"}))
            if ranks:
                for i, values in enumerate(samples):
                    panels.append(_tie_panel(values, n, source_split, "sample_"+str(i+1)))
        elif method in {"paired_t_test", "wilcoxon_signed_rank"}:
            differences = samples[0]-samples[1]
            if method == "wilcoxon_signed_rank":
                null = detail.get("null", {})
                if not isinstance(null, dict):
                    raise ValueError("Signed-rank detail must contain the prespecified null")
                differences = differences-_finite(null.get("value"), "signed-rank null")
            panels.append(_hist("paired_differences", "Paired x minus y" + (" minus null" if method == "wilcoxon_signed_rank" else ""), differences, n, source_split,
                "Each value is a within-unit difference, not an observation from two independent groups. " + ("The t approximation concerns the mean difference; a histogram does not verify its sampling reference." if method == "paired_t_test" else "Signed-rank inference needs an appropriate symmetric paired-difference distribution about the null; it is not an arbitrary paired-median test."), requirement="distributional_approximation"))
            if method == "wilcoxon_signed_rank":
                nonzero = differences[differences != 0]
                ranks = stats.rankdata(np.abs(nonzero), method="average")
                positive = float(ranks[nonzero > 0].sum()); negative = float(ranks[nonzero < 0].sum())
                panels.append(_bars("signed_rank_sums", "Signed-rank contributions", ["positive rank sum", "negative rank sum"], [positive, negative], n, source_split,
                    requirement="distributional_approximation", units="sum of average absolute-difference ranks",
                    comparison="Positive versus negative ranks among " + str(len(nonzero)) + " nonzero differences; " + str(n-len(nonzero)) + " zero differences excluded by the prespecified wilcox convention",
                    interpretation="Rank contributions describe the fixed signed-rank computation; zeros remain counted in the original paired sample size.",
                    limitations=["No automatic rounding, normality pretest, exact inference or removal from source data occurs. Floating-point subtraction can create near-ties."]))
                panels.append(_tie_panel(np.abs(nonzero), n, source_split, "nonzero_absolute_difference"))
        elif method == "friedman":
            if len(samples) <= MAX_VISUAL_GROUPS:
                differences = [values-samples[0] for values in samples[1:]]
                edges = _edges(np.concatenate(differences))
                for i, values in enumerate(differences, start=2):
                    panels.append(_hist("condition_"+str(i)+"_minus_1", "Condition " + str(i) + " minus condition 1", values, n, source_split,
                        "A descriptive within-block contrast to condition 1, not a separately tested contrast or a post-hoc p-value. Friedman uses ranks within each block; blocks must be correctly aligned and independently sampled.", requirement="pairing", edges=edges))
                tied_blocks = int(np.sum([len(np.unique(row)) < len(samples) for row in np.column_stack(samples)]))
                panels.append(_bars("within_block_ties", "Blocks containing tied conditions", ["with ties", "without ties"], [tied_blocks, n-tied_blocks], n, source_split,
                    comparison=str(tied_blocks) + " of " + str(n) + " aligned blocks contain at least one exactly tied condition",
                    interpretation="Within-block ties are descriptive and affect rank correction; their presence does not establish or refute block independence.",
                    limitations=["No post-hoc multiple-comparison or exact/permutation procedure is computed."]))
            else:
                panels.append(_status("group_display_limit", "Repeated distributions not drawn", n, source_split,
                    "More than ten conditions exceed the bounded distribution display. No conditions are silently selected or merged.", role="descriptive"))
        else:
            pooled = np.concatenate(samples)
            if len(samples) <= MAX_VISUAL_GROUPS:
                edges = _edges(pooled)
                for i, values in enumerate(samples):
                    panels.append(_hist("group_"+str(i+1)+"_distribution", "Observed group " + str(i+1) + " distribution", values, len(values), source_split,
                        "Observed group shape is descriptive. " + ("The mean comparison needs a justified error/mean sampling approximation; this chart does not test normality or verify independence." if method in MEAN else "Rank comparisons concern distributions, not automatically only medians. A location interpretation needs additional shape/scale assumptions."),
                        requirement="distributional_approximation", edges=edges))
            else:
                panels.append(_status("group_display_limit", "Group distributions not drawn", n, source_split,
                    "More than ten groups exceed the bounded distribution display. Group counts are shown; no group is silently selected or merged.", role="descriptive"))
            if len(samples) > 1 and method in MEAN:
                panels.append(_variance_panel(samples, n, source_split, method))
            if method in {"mann_whitney", "kruskal_wallis"}:
                panels.append(_tie_panel(pooled, n, source_split))
        if method in GROUPED or method in {"student_t_test", "welch_t_test", "mann_whitney"}:
            panels.insert(0, _bars("sample_counts", "Supplied sample sizes", ["condition_"+str(i+1) if method == "friedman" else "group_"+str(i+1) for i in range(len(samples))],
                [len(v) for v in samples], n, source_split, requirement="data_grain", units="aligned block count per condition" if method == "friedman" else "observation count per group",
                comparison="Each condition contains the same " + str(n) + " blocks; repeated measurements are not independent units" if method == "friedman" else "Group counts sum to total n=" + str(n),
                interpretation="Counts describe supplied records, not representativeness or independent unit identity."))
    if n_hint and n != n_hint:
        raise ValueError("Numerical detail and visual inputs disagree in sample size; recompute rather than reuse stale results")
    panels.insert(0, _main(detail, n, source_split))
    panels.append(_status("design_unresolved", "Scientific assumptions remain unresolved", n, source_split,
        "Measurement, independent sampling units, selection, multiplicity, prespecification and any required pairing or distributional reference need separate evidence. These plots do not grant causal interpretation or certify all assumptions.", requirement="independence"))
    if source_split in {"unknown", "training", "final_holdout"}:
        text = "The source split is unknown; do not describe these as held-out findings." if source_split == "unknown" else "Training data are not held-out evidence." if source_split == "training" else "Final-holdout plots are descriptive evaluation; using them to select tests, transformations or models contaminates final evaluation and requires a new untouched evaluation."
        panels.append(_status("split_scope", "Source and selection boundary", n, source_split, text, requirement="test_prespecification"))
    if len(panels) > 16:
        raise ValueError("Aggregate visual panel count exceeds the fixed bound; no panels were silently omitted")
    output.update(n=int(n), panels=panels)
    return output
