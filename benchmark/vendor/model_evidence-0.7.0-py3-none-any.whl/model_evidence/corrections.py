"""Bounded assumption-impact comparisons; never universal metric repair.

The executable case changes covariance on one intercept OLS fit. It does not
change records, coefficients, predictions, estimands, or training metrics.
"""
from copy import deepcopy
import hashlib
import json
import math
import re
import numpy as np
from scipy import stats

SCHEMA_VERSION="1.0.0"
from ._version import VERSION
CONDITIONS={
    "independence":"Errors/observations are independent in the actual sampling design; HC3 does not handle clustered or serially dependent errors.",
    "mean_specification":"The chosen linear conditional mean and features are substantively justified; covariance changes do not fix nonlinearity or omitted structure.",
    "exogeneity":"Conditional mean-zero errors and the scientific interpretation need substantive justification; HC3 cannot remove confounding or endogeneity.",
}
LIMITATIONS=[
    "The conditional_inference gate concerns the HC3 comparison only; it does not validate the additional homoskedastic/normal-error conditions for conventional exact Student-t inference.",
    "This is a same-fit uncertainty comparison, not an automatic decision that HC3 is scientifically justified.",
    "HC3 does not fix confounding, misspecified/nonlinear means, dependent errors, selection bias, outcome measurement, or prediction calibration.",
    "The Student-t reference with residual degrees of freedom is a finite-sample approximation for HC3, not an exact robust pivot; the normal option is asymptotic.",
    "Conventional Student-t inference additionally relies on its usual homoskedastic normal-error model for exact finite-sample interpretation; normal-reference conventional inference is asymptotic.",
    "Small samples and high leverage can make robust inference unreliable. Wider or narrower intervals are possible; robust SE need not exceed conventional SE.",
    "Review multiple testing and analysis selection separately; individual p-values are unadjusted two-sided tests of coefficient=0.",
    "No covariance choice establishes causality, external validity, or predictive performance on unseen data.",
    "Reports are editable, unsigned local data; attestations, split declarations and fingerprints do not authenticate analysis history. Aggregates and hashes can still be sensitive.",
]
CHANGED=["covariance","standard_errors","test_statistics","confidence_intervals","p_values"]
UNCHANGED=["coefficients","fitted_predictions","training_mae","training_rmse","training_r2","records","design_matrix","estimand"]
POLICIES={"comparison_only","prespecified_hc3","selected_by_pretest"}
SPLITS={"training","validation","final_evaluation","test","unknown"}
REPORT_FIELDS={"schema_version","library_version","kind","status","method","sample_sizes","source_split","configuration","requirements","original","revised","comparison_rows","what_changes","changed_fields","unchanged_fields","blockers","warnings","gates","provenance","limitations"}


def _canonical(value):
    return json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=True,allow_nan=False)


def _conditions(values):
    if values is None: values={}
    if not isinstance(values,dict) or set(values)-set(CONDITIONS): raise ValueError("Unknown correction condition")
    result=[]
    for name,description in CONDITIONS.items():
        row=values.get(name)
        if row is None:
            result.append({"id":name,"status":"not_checked","source":"manual_required","reviewer":None,"basis":None,"requirement":description})
            continue
        if not isinstance(row,dict) or set(row)!={"status","reviewer","basis"}: raise ValueError("Correction conditions need status, reviewer and basis")
        if not isinstance(row["status"],str) or row["status"] not in {"no_issue_detected","warning","fail","not_checked","not_applicable"}: raise ValueError("Invalid correction condition status")
        if any(not isinstance(row[k],str) or not row[k].strip() or len(row[k])>2048 for k in ("reviewer","basis")): raise ValueError("Human conditions need bounded reviewer and basis")
        result.append({"id":name,"status":row["status"],"source":"human","reviewer":row["reviewer"],"basis":row["basis"],"requirement":description})
    return result


def _inputs(X,y):
    if any(np.ma.isMaskedArray(value) and np.ma.getmaskarray(value).any() for value in (X,y)): raise ValueError("Masked values require explicit handling; no correction silently drops a mask")
    if np.iscomplexobj(X) or np.iscomplexobj(y): raise ValueError("Real numeric inputs required")
    try: X=np.asarray(X,dtype=float); y=np.asarray(y,dtype=float)
    except (TypeError,ValueError,OverflowError) as exc: raise ValueError("Numeric inputs required") from exc
    if X.ndim!=2 or y.ndim!=1 or len(X)!=len(y) or len(y)<3 or not 1<=X.shape[1]<=128 or X.size>2_000_000: raise ValueError("Aligned bounded X/y with at least three rows and 1..128 predictors required")
    return X,y


def _inference(coef,cov,reference,df,confidence,covariance_type):
    """No clipping/flooring of covariance, variances or zero SE."""
    if not np.isfinite(cov).all(): raise ValueError("Covariance contains nonfinite entries")
    if not np.allclose(cov,cov.T,rtol=1e-10,atol=1e-14): raise ValueError("Covariance is not numerically symmetric")
    diagonal=np.diag(cov)
    if np.any(diagonal<=0): raise ValueError("Zero or negative coefficient variance prevents this uncertainty comparison")
    eig=np.linalg.eigvalsh(cov)
    tolerance=1e-10*max(float(np.max(diagonal)),np.finfo(float).tiny)
    if float(eig.min()) < -tolerance: raise ValueError("Covariance is not positive semidefinite within tolerance")
    se=np.sqrt(diagonal); statistic=coef/se
    distribution=stats.t(df) if reference=="t" else stats.norm()
    critical=float(distribution.ppf((1+confidence)/2)); p=2*distribution.sf(np.abs(statistic))
    ci=np.column_stack([coef-critical*se,coef+critical*se])
    if not all(np.isfinite(a).all() for a in (se,statistic,p,ci)): raise ValueError("Inference calculation is numerically nonfinite")
    return {"covariance_type":covariance_type,"covariance":cov.tolist(),"standard_errors":se.tolist(),
        "statistics":statistic.tolist(),"confidence_intervals":ci.tolist(),"p_values":p.tolist(),
        "reference_distribution":"student_t" if reference=="t" else "standard_normal",
        "reference_df":int(df) if reference=="t" else None,"confidence_level":float(confidence),
        "critical_value":critical,"null_hypothesis":"each coefficient = 0; unadjusted two-sided tests"}


def _base(n,p,confidence,reference,policy,source_split,requirements):
    return {"schema_version":SCHEMA_VERSION,"library_version":VERSION,"kind":"ols_covariance_comparison",
        "status":"blocked","method":"ols","sample_sizes":{"n":n,"p":p,"parameters":p+1,"residual_df":None},
        "source_split":source_split,"configuration":{"confidence_level":float(confidence),"reference_distribution":reference,"policy":policy,
            "condition_number_limit":1e12,"hc3_minimum_one_minus_leverage":1e-12},
        "requirements":requirements,"original":None,"revised":None,"comparison_rows":[],"what_changes":[],
        "changed_fields":[],"unchanged_fields":list(UNCHANGED),"blockers":[],"warnings":[],
        "gates":{"conditional_inference":"blocked","causal_interpretation":"blocked","deployment_claim":"blocked"},
        "provenance":{"implementation":"model-evidence/0.2.0","numpy_version":np.__version__,"source_split":"caller declaration, not independently verified",
            "formulas":{"conventional":"SSE/(n-rank(A)) * P @ P.T; P=pinv(A)","hc3":"(P * (residual/(1-leverage))**2) @ P.T","interval":"coefficient +/- reference_quantile * standard_error"},
            "data_repaired":False,"model_refit_for_correction":False,"holdout_selection_performed":False},"limitations":list(LIMITATIONS)}


def compare_ols_covariance(X,y,*,confidence_level=.95,reference_distribution="t",policy="comparison_only",conditions=None,source_split="training"):
    """Compare conventional and HC3 covariance while retaining one OLS fit.

    The method adds an intercept. Arrays remain unchanged. Unknown/failed human
    conditions block inferential interpretation even when arithmetic is possible.
    Final-evaluation/validation/test/unknown split declarations block computation:
    no final holdout is used to choose a correction. The history cannot be audited
    from arrays, so a caller's false training declaration cannot be detected.
    """
    if isinstance(confidence_level,bool) or not isinstance(confidence_level,(float,int)) or not math.isfinite(confidence_level) or not 0<confidence_level<1: raise ValueError("confidence_level must lie in (0,1)")
    if not isinstance(reference_distribution,str) or reference_distribution not in {"t","normal"}: raise ValueError("Reference must be t or normal")
    if not isinstance(policy,str) or policy not in POLICIES: raise ValueError("Unknown covariance policy")
    if not isinstance(source_split,str): raise ValueError("Source split must be training, validation, final_evaluation/final_holdout/evaluation, test or unknown")
    declared_split=source_split
    source_split={"final_holdout":"final_evaluation","evaluation":"final_evaluation"}.get(source_split,source_split)
    if source_split not in SPLITS: raise ValueError("Source split must be training, validation, final_evaluation/final_holdout/evaluation, test or unknown")
    X,y=_inputs(X,y); n,p=X.shape; requirements=_conditions(conditions)
    result=_base(n,p,confidence_level,reference_distribution,policy,source_split,requirements)
    if declared_split!=source_split:
        result["provenance"]["source_split"]="Caller declaration "+declared_split+"; stored canonical split "+source_split+"; not independently verified. No holdout is used for correction."
    if policy=="selected_by_pretest": result["warnings"].append("Caller selected HC3 after a diagnostic pretest. This is data-dependent inference; nominal intervals/p-values do not account for that selection. Prefer a prespecified policy; no selection adjustment is implemented.")
    if policy=="comparison_only": result["warnings"].append("Both uncertainty calculations are displayed for comparison. No diagnostic pretest selects a preferred result.")
    if n<50: result["warnings"].append("Small sample (n<50): this illustrative warning is not a validity threshold; HC3/reference approximations can be unreliable.")
    if source_split!="training":
        result["blockers"].append("Only explicitly declared training data may be used for this correction comparison; holdout/validation use or unknown role is blocked.")
        return result
    if not np.isfinite(X).all() or not np.isfinite(y).all():
        result["blockers"].append("Nonfinite inputs: no deletion, imputation or repair was performed."); return result
    if max(float(np.max(np.abs(X))),float(np.max(np.abs(y))))>1e12:
        result["blockers"].append("Magnitude exceeds this bounded implementation's numerical range (absolute value > 1e12); review units explicitly."); return result
    A=np.column_stack([np.ones(n),X])
    try:
        rank=int(np.linalg.matrix_rank(A)); df=n-rank; condition=float(np.linalg.cond(A))
    except np.linalg.LinAlgError:
        result["blockers"].append("Linear algebra did not converge; no correction computed."); return result
    result["sample_sizes"]["residual_df"]=int(df)
    result["provenance"]["design_rank"]=rank
    result["provenance"]["condition_number"]=condition if np.isfinite(condition) else None
    if rank!=p+1 or df<=0:
        result["blockers"].append("Full column rank and positive residual degrees of freedom are required; no unique classical coefficient inference is supplied."); return result
    if not np.isfinite(condition) or condition>1e12:
        result["blockers"].append("Design conditioning exceeds this implementation's numerical limit; no unstable covariance correction is reported."); return result
    try:
        coef=np.linalg.lstsq(A,y,rcond=None)[0]; fitted=A@coef; residual=y-fitted
        projection=np.linalg.pinv(A); leverage=np.sum(A*projection.T,axis=1)
        sse=float(residual@residual); tss=float(np.sum((y-y.mean())**2))
        metrics={"mae":float(np.mean(np.abs(residual))),"rmse":float(np.sqrt(sse/n)),"r2":float(1-sse/tss) if tss>0 else None}
        fit={"coefficients":coef.tolist(),"coefficient_terms":["intercept"]+["x"+str(i+1) for i in range(p)],"training_metrics":metrics,
            "prediction_fingerprint":hashlib.sha256(np.ascontiguousarray(fitted).tobytes()).hexdigest(),
            "coefficient_units":"intercept in response units; slopes in response units per supplied design unit; measurement units not inferred"}
        result["original"]={"fit":deepcopy(fit),"inference":None}
        result["provenance"].update({"maximum_leverage":float(leverage.max()),"minimum_one_minus_leverage":float((1-leverage).min()),"sse":sse,
            "fit_fingerprint":hashlib.sha256(_canonical(fit).encode()).hexdigest()})
        exact_tolerance=float(64*np.finfo(float).eps**2*max(float(y@y),np.finfo(float).tiny)*n)
        result["provenance"]["residual_degeneracy_tolerance"]=exact_tolerance
        if not np.isfinite(sse) or sse<=exact_tolerance:
            result["blockers"].append("Residual variance is zero or numerically degenerate; uncertainty is undefined here, not reported as zero-width certain inference."); return result
        conventional=(sse/df)*(projection@projection.T)
        original=_inference(coef,conventional,reference_distribution,df,confidence_level,"conventional")
        result["original"]["inference"]=original
        if np.any(1-leverage<=1e-12):
            result["blockers"].append("HC3 undefined or numerically unreliable at leverage one/near one; denominator is not floored or repaired."); return result
        hc3=(projection*((residual/(1-leverage))**2))@projection.T
        robust=_inference(coef,hc3,reference_distribution,df,confidence_level,"HC3")
    except (ValueError,np.linalg.LinAlgError,FloatingPointError) as exc:
        result["blockers"].append(str(exc)); return result
    result["revised"]={"fit":deepcopy(fit),"inference":robust}
    result["status"]="computed_comparison"; result["changed_fields"]=list(CHANGED)
    unresolved=[r["id"] for r in requirements if r["status"]!="no_issue_detected"]
    if not unresolved and policy!="selected_by_pretest": result["gates"]["conditional_inference"]="conditional_on_attested_assumptions"
    result["provenance"]["unresolved_inference_conditions"]=unresolved
    for i,term in enumerate(fit["coefficient_terms"]):
        result["comparison_rows"].append({"term":term,"estimate":float(coef[i]),"conventional_se":original["standard_errors"][i],"hc3_se":robust["standard_errors"][i],
            "conventional_ci":original["confidence_intervals"][i],"hc3_ci":robust["confidence_intervals"][i],"conventional_p":original["p_values"][i],"hc3_p":robust["p_values"][i],
            "se_difference":robust["standard_errors"][i]-original["standard_errors"][i],"units":"coefficient units; p-values dimensionless"})
    result["what_changes"]=[{"issue":"heteroskedasticity","remedy":"HC3 covariance on the same fitted OLS model","status":"computed_comparison",
        "applicability":"Conditional on independent errors, justified mean/exogeneity and adequate asymptotic behavior; not verified by this arithmetic.",
        "reason":"Heteroskedasticity can make conventional homoskedastic standard errors misleading. HC3 reweights squared residuals by (1-h)^-2 without changing the fitted coefficients.",
        "changed_fields":list(CHANGED),"unchanged_fields":list(UNCHANGED),"original_metrics":deepcopy(metrics),"revised_metrics":deepcopy(metrics),
        "metric_units":{"mae":"supplied response units","rmse":"supplied response units","r2":"dimensionless"},
        "uncertainty_units":"SE/CI are coefficient units; p-values are dimensionless probabilities",
        "conclusion":"Uncertainty changes, not the estimated coefficients, fitted predictions or training fit. An altered p-value does not repair confounding or make the coefficient causal.",
        "remaining_assumptions":list(CONDITIONS.values()),"automatic_data_or_model_change":False}]
    return result


REMEDIES={
 "hc3":("Same-fit heteroskedasticity-robust covariance","No fit or estimand change; only uncertainty fields change.","Use compare_ols_covariance with a documented policy and independent-error/mean/exogeneity review."),
 "cluster":("Cluster-robust covariance","May change uncertainty; does not fix a wrong mean or confounding.","Requires justified dependence groups, sufficient independent clusters and an appropriate small-sample method; no implementation is supplied."),
 "hac":("HAC covariance","May change uncertainty; does not fix misspecification, nonstationarity or confounding.","Requires a justified time order, dependence/horizon/bandwidth context and suitable asymptotics; no implementation is supplied."),
 "multicollinearity":("Review variance/stability; consider training-only ridge or feature revision","Coefficient variance/stability can be poor without automatic forecast failure. Ridge or dropping variables changes the fitted model, coefficient target/estimand and predictions; it is not a scalar metric correction.","Review scientific variables, units and stability; prespecify/refit within training folds, then use a new untouched evaluation. No automatic feature removal."),
 "separation":("Review a different finite-estimate logistic estimator","A penalty or bias-reduced estimator changes coefficient estimation; its coefficients cannot silently receive ordinary unpenalized-MLE inference.","Choose and document an appropriate estimator and uncertainty procedure; this release does not implement that correction."),
 "calibration":("Fit a calibration model using separate training/validation or cross-fitting","Probability metrics may change even when ranking stays unchanged; new evaluation is required.","Never fit calibration on final holdout outcomes; preserve final evaluation and document any ranking/probability changes. No calibration fitting is implemented."),
 "extreme_weights":("Review weighting/trimming and the target population","Trimming or dropping support can change the target population and estimand, in addition to uncertainty.","Document overlap, weight variability/effective sample size, target-population change and effect uncertainty; no weights are trimmed here."),
 "confounding":("No numerical repair from fit or a DAG drawing","Causal interpretation remains blocked; changing covariance cannot remove unmeasured confounding.","Review identification/design evidence and plausible alternative DAGs; any bounded sensitivity scenario must be explicitly hypothetical."),
 "missingness":("Review a documented missing-data strategy","Deletion or imputation can change the analyzed population, feature distribution, uncertainty and sometimes the estimand.","Assess missingness mechanisms and selection; fit any imputation inside training folds. No automatic deletion or imputation."),
 "outliers":("Review influence and measurement validity","Deleting or winsorizing observations changes the data, fit and possibly target question.","Investigate measurement and prespecify a defensible strategy; no automatic deletion, winsorization or tuning on holdout outcomes."),
}


def propose_correction(issue,*,context=None):
    """Return a review card, never execute a data/model-changing remedy."""
    if not isinstance(issue,str) or not re.fullmatch(r"[a-z][a-z0-9_]{0,47}",issue): raise ValueError("Bounded correction issue identifier required")
    context={} if context is None else context
    allowed={"data_role","calibration_fit_role","dependence_metadata"}
    if not isinstance(context,dict) or set(context)-allowed or any(not isinstance(v,str) or len(v)>512 for v in context.values()): raise ValueError("Invalid bounded correction context")
    roles={"training","validation","crossfit","final_evaluation","final_holdout","test","unknown"}
    if any(context[k] not in roles for k in ("data_role","calibration_fit_role") if k in context): raise ValueError("Unknown correction data role")
    if issue not in REMEDIES:
        return {"issue":issue,"status":"blocked","implemented":False,"revised_values":None,"reason":"No supported correction is defined for this issue.","automatic_execution":False}
    remedy,impact,requirements=REMEDIES[issue]
    blocked=(context.get("data_role") in {"final_evaluation","final_holdout","test"} or context.get("calibration_fit_role") in {"final_evaluation","final_holdout","test"} or issue=="confounding" or (issue=="hc3" and context.get("data_role","training")!="training"))
    return {"issue":issue,"status":"blocked" if blocked else "proposed","implemented":issue=="hc3","remedy":remedy,"reason":requirements,
        "estimator_estimand_effect":impact,"revised_values":None,"required_conditions":requirements,
        "next_step":"Review conditions and explicitly rerun a supported implementation; no old numerical results are reused.",
        "automatic_execution":False,"original_results_preserved":True,"context":deepcopy(context),
        "remaining_assumptions":"Identification, mean specification, dependence, selection, measurement and evaluation provenance need separate evidence."}


def validate_correction_report(report):
    """Structural/invariant validation; no input reanalysis or truth authentication."""
    if not isinstance(report,dict) or set(report)!=REPORT_FIELDS or report.get("schema_version")!=SCHEMA_VERSION or not isinstance(report.get("library_version"),str) or report.get("library_version") not in {"0.1.0","0.2.0","0.3.0","0.4.0","0.5.0","0.6.0",VERSION} or report.get("kind")!="ols_covariance_comparison": raise ValueError("Unknown correction report")
    if not isinstance(report.get("status"),str) or report["status"] not in {"computed_comparison","blocked"}: raise ValueError("Invalid correction status")
    from .report import _json_data
    _json_data(report)
    try:
        if report["method"]!="ols" or report["source_split"] not in SPLITS: raise ValueError("Invalid correction method/split")
        gates=report["gates"]
        if set(gates)!={"conditional_inference","causal_interpretation","deployment_claim"} or gates["causal_interpretation"]!="blocked" or gates["deployment_claim"]!="blocked": raise ValueError("Covariance comparison cannot authorize causal/deployment claims")
        rows=report["requirements"]
        if not isinstance(rows,list) or len(rows)!=len(CONDITIONS) or {r["id"] for r in rows}!=set(CONDITIONS): raise ValueError("Correction condition rows are missing or duplicated")
        supplied={}
        for row in rows:
            if set(row)!={"id","status","source","reviewer","basis","requirement"}: raise ValueError("Invalid correction condition fields")
            if row["source"]=="human": supplied[row["id"]]={k:row[k] for k in ("status","reviewer","basis")}
            elif row["source"]!="manual_required" or row["status"]!="not_checked" or row["reviewer"] is not None or row["basis"] is not None: raise ValueError("Unassessed conditions cannot assert success")
        if _canonical(rows)!=_canonical(_conditions(supplied)): raise ValueError("Correction condition provenance does not match contract")
        config=report["configuration"]
        if config["policy"] not in POLICIES or config["reference_distribution"] not in {"t","normal"} or type(config["confidence_level"]) not in {int,float} or not 0<config["confidence_level"]<1: raise ValueError("Invalid correction configuration")
        if report["unchanged_fields"]!=UNCHANGED: raise ValueError("Unexpected unchanged-fit declaration")
        if report["status"]=="blocked":
            if gates["conditional_inference"]!="blocked" or report["revised"] is not None or report["comparison_rows"] or report["changed_fields"] or not report["blockers"]: raise ValueError("Blocked correction must not contain revised inference")
            return report
        if not isinstance(report["original"],dict) or not isinstance(report["revised"],dict): raise ValueError("Missing same-fit results")
        if _canonical(report["original"]["fit"])!=_canonical(report["revised"]["fit"]): raise ValueError("Covariance correction must preserve the original fit")
        if report["changed_fields"]!=CHANGED or report["source_split"]!="training" or report["blockers"]: raise ValueError("Unexpected changed fields or evaluation reuse")
        fit=report["original"]["fit"]; coef=np.asarray(fit["coefficients"],dtype=float)
        n=report["sample_sizes"]["n"]; p=report["sample_sizes"]["p"]; df=report["sample_sizes"]["residual_df"]
        if type(n) is not int or type(p) is not int or type(df) is not int or df!=n-p-1 or df<=0 or report["sample_sizes"]["parameters"]!=p+1 or len(coef)!=p+1: raise ValueError("Invalid correction dimensions or degrees of freedom")
        if fit["coefficient_terms"]!=["intercept"]+["x"+str(i+1) for i in range(p)]: raise ValueError("Coefficient term mismatch")
        if report["provenance"]["fit_fingerprint"]!=hashlib.sha256(_canonical(fit).encode()).hexdigest(): raise ValueError("Original fit fingerprint mismatch")
        missing=[r["id"] for r in rows if r["status"]!="no_issue_detected"]
        expected_gate="blocked" if missing or config["policy"]=="selected_by_pretest" else "conditional_on_attested_assumptions"
        if gates["conditional_inference"]!=expected_gate: raise ValueError("Condition gate does not match evidence")
        for index,cov_type in (("original","conventional"),("revised","HC3")):
            inf=report[index]["inference"]
            if not isinstance(inf,dict): raise ValueError("Missing inference")
            cov=np.asarray(inf["covariance"],dtype=float)
            if cov.shape!=(p+1,p+1): raise ValueError("Invalid covariance dimensions")
            expected_inf=_inference(coef,cov,config["reference_distribution"],df,config["confidence_level"],cov_type)
            if _canonical(inf)!=_canonical(expected_inf): raise ValueError("Inference values disagree with covariance/reference distribution")
        original=report["original"]["inference"]; robust=report["revised"]["inference"]
        expected_rows=[]
        for i,term in enumerate(fit["coefficient_terms"]):
            expected_rows.append({"term":term,"estimate":float(coef[i]),"conventional_se":original["standard_errors"][i],"hc3_se":robust["standard_errors"][i],
                "conventional_ci":original["confidence_intervals"][i],"hc3_ci":robust["confidence_intervals"][i],"conventional_p":original["p_values"][i],"hc3_p":robust["p_values"][i],
                "se_difference":robust["standard_errors"][i]-original["standard_errors"][i],"units":"coefficient units; p-values dimensionless"})
        if _canonical(expected_rows)!=_canonical(report["comparison_rows"]): raise ValueError("Comparison rows disagree with original/revised inference")
        if len(report["what_changes"])!=1 or any(_canonical(report["what_changes"][0][k])!=_canonical(fit["training_metrics"]) for k in ("original_metrics","revised_metrics")): raise ValueError("Impact card cannot change training metrics")
    except (KeyError,TypeError,OverflowError,IndexError,np.linalg.LinAlgError) as exc:
        raise ValueError("Malformed correction report") from exc
    return report


def correction_to_json(report):
    return json.dumps(validate_correction_report(report),indent=2,ensure_ascii=True,allow_nan=False)+"\n"


def explain_correction_report(report):
    validate_correction_report(report)
    if report["status"]=="blocked":
        return "No supported HC3 comparison was computed: "+" ".join(report["blockers"])+" Original records and any available fitted results were preserved. No repair, refit or causal claim was made."
    ref=report["original"]["inference"]
    text=(f"We fitted one intercept OLS model to {report['sample_sizes']['n']} declared training rows and compared conventional covariance with HC3. "
        f"Both use {ref['reference_distribution']} reference"+(f" with {ref['reference_df']} residual degrees of freedom" if ref["reference_df"] is not None else "")+
        f" and {100*ref['confidence_level']:.1f}% intervals. The HC3 reference is approximate; assumptions are not proved.\n")
    for row in report["comparison_rows"]:
        text+=(f"{row['term']}: estimate {row['estimate']:.6g} unchanged; SE {row['conventional_se']:.6g} -> {row['hc3_se']:.6g}; "
            f"CI {row['conventional_ci']} -> {row['hc3_ci']}; two-sided unadjusted p {row['conventional_p']:.6g} -> {row['hc3_p']:.6g}.\n")
    text+=("Coefficients, fitted predictions, training MAE/RMSE/R2, records and estimand did not change. "
        "This changes reported uncertainty, not predictive accuracy or causal identification. "
        "HC3 conditional inference gate: "+report["gates"]["conditional_inference"]+"; conventional exact-inference assumptions remain unassessed. "+" ".join(report["warnings"])+" "+" ".join(report["limitations"]))
    return text
