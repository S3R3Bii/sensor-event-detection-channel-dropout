"""Bounded aggregate visual evidence from already computed model values.

Collectors never fit, refit, select or transform a model. ``computed`` describes
an aggregate computation, not a passed assumption. Class and feature names are
deliberately replaced by positions; aggregate summaries can still be sensitive.
"""
from __future__ import annotations

import math
import re

import numpy as np
from scipy.stats import norm
from sklearn.metrics import confusion_matrix, precision_recall_curve, roc_curve

from .calibration import audit_calibration


SCHEMA_VERSION = "1.0.0"
PRIVACY = "aggregate_only_no_row_pairs"
SPLITS = {"unknown", "training", "validation", "evaluation", "final_holdout", "not_applicable"}
ROLES = {"main_result", "diagnostic", "descriptive", "manual"}
KINDS = {"hist1d", "hist2d", "curve", "bars", "matrix", "status"}
MAX_ELEMENTS = 4_000_000
_COMMON_LIMITS = [
    "Computed panels summarize supplied rows; they do not certify assumptions, sampling, untouched evaluation or external validity.",
    "Aggregates, small cell counts, quantiles and model parameters can still disclose sensitive information; aggregate-only is not anonymization.",
    "Binning and bounded projections can conceal local structure; no automatic repair or model selection is performed.",
]


def _split(value):
    if not isinstance(value, str) or value not in SPLITS:
        raise ValueError("source_split must be unknown, training, validation, evaluation, final_holdout or not_applicable")
    return value


def _bins(value):
    if type(value) is not int or not 12 <= value <= 20:
        raise ValueError("bins must be an integer from 12 to 20")
    return value


def _numeric(value, name, ndim=1):
    if np.ma.isMaskedArray(value):
        raise ValueError(name + " must not be masked; handle missingness explicitly")
    if isinstance(value,(list,tuple)):
        uncoerced=np.asarray(value,dtype=object)
        if uncoerced.size > MAX_ELEMENTS or any(isinstance(item,(bool,np.bool_,complex,np.complexfloating,str)) for item in uncoerced.flat):
            raise ValueError(name + " must not silently coerce booleans, complex values or text")
    raw = np.asarray(value)
    if raw.ndim != ndim or raw.size == 0 or raw.size > MAX_ELEMENTS:
        raise ValueError(name + " has an empty, unsupported or excessive shape")
    if raw.dtype.kind not in "iuf" or raw.dtype.kind == "b":
        raise ValueError(name + " must contain real numeric values, not booleans or strings")
    result = np.array(raw, dtype=float, copy=True)
    if not np.isfinite(result).all() or np.any(np.abs(result) > 1e40):
        raise ValueError(name + " must be finite with absolute values at most 1e40; no rows are silently removed")
    return result


def _align(*values):
    indexes = [getattr(v, "index", None) for v in values if v is not None]
    indexes = [i for i in indexes if i is not None and callable(getattr(i, "equals", None))]
    if indexes and any(not indexes[0].equals(index) for index in indexes[1:]):
        raise ValueError("Input pandas indexes differ in values or order; align explicitly")


def _same_length(*arrays):
    if len({len(a) for a in arrays}) != 1:
        raise ValueError("Inputs must have identical row counts in the same declared order")


def _edges(x, bins):
    low, high = float(np.min(x)), float(np.max(x))
    if high == low or high-low < max(abs(low), abs(high))*1e-10:
        padding = max(abs(low), abs(high), 1.)*.01
        low -= padding
        high += padding
    result = np.linspace(low, high, bins+1)
    if not np.isfinite(result).all() or not np.all(np.diff(result) > 0):
        raise ValueError("Histogram edges cannot be represented safely")
    return result


def _panel(identifier, title, kind, n, source_split, data, *, role="diagnostic", requirement=None,
           status="computed", units="dimensionless", comparison="Descriptive supplied values",
           threshold=None, interpretation="Descriptive aggregate only.", limitations=None, axes=None):
    result = {"id":identifier, "title":title, "kind":kind, "role":role,
        "requirement":requirement, "status":status, "n":int(n), "source_split":_split(source_split),
        "units":units, "comparison":comparison, "threshold":threshold,
        "interpretation":interpretation, "limitations":list(limitations or []), "data":data}
    if kind != "status":
        if axes is None:
            if kind in {"curve", "hist2d"} and units.startswith("x: ") and "; y: " in units:
                xunit, yunit = units[3:].split("; y: ", 1)
                yunit = yunit.split("; cell: ", 1)[0]
                axes = {"x":xunit, "y":yunit}
                if kind == "hist2d":
                    result["units"] = "observations per count cell"
            elif kind == "hist1d":
                axes = {"x":units.split("; count:",1)[0], "y":"Number of observations"}
                result["units"] = "observations per histogram bin"
            elif kind == "matrix":
                axes = {"x":"Column positions (see column labels)", "y":"Row positions (see row labels)"}
            elif kind == "bars":
                axes = {"x":"Category positions (see labels)", "y":units}
            else:
                raise ValueError("Numeric panels require explicit axes")
        result["axes"] = dict(axes)
    return result


def status_panel(identifier, title, *, n, source_split, message, role="manual", requirement=None,
                 status="not_checked", units="not assessed", comparison="Required information unavailable",
                 threshold=None, interpretation=None, limitations=None):
    """Construct an explicit unassessed or inapplicable panel; never numerical data."""
    result = _panel(identifier, title, "status", n, source_split, {"message":message},
        role=role, requirement=requirement, status=status, units=units, comparison=comparison,
        threshold=threshold, interpretation=interpretation or message, limitations=limitations)
    if status not in {"not_checked", "not_applicable"}:
        raise ValueError("status_panel requires not_checked or not_applicable")
    return result


def histogram_panel(identifier, title, x, *, role, requirement, source_split, units, comparison,
                    interpretation, limitations, bins=16, threshold=None, axes=None):
    """Count every supplied finite value using bounded NumPy histogram bins."""
    _bins(bins)
    values = _numeric(x, "histogram values")
    edges = _edges(values, bins)
    counts, _ = np.histogram(values, bins=edges)
    return _panel(identifier, title, "hist1d", len(values), source_split,
        {"edges":edges.tolist(), "counts":counts.tolist()}, role=role, requirement=requirement,
        units=units, comparison=comparison, threshold=threshold, interpretation=interpretation,
        limitations=limitations, axes=axes)


def histogram2d_panel(identifier, title, x, y, *, role, requirement, source_split, units,
                      comparison, interpretation, limitations, bins=16, threshold=None, axes=None):
    """Count pairs into cells, returning no original row pairs.

    ``counts[x_bin][y_bin]`` is NumPy's histogram2d orientation.
    """
    _bins(bins)
    _align(x, y)
    x = _numeric(x, "histogram x")
    y = _numeric(y, "histogram y")
    _same_length(x, y)
    counts, xe, ye = np.histogram2d(x, y, bins=(_edges(x, bins), _edges(y, bins)))
    return _panel(identifier, title, "hist2d", len(x), source_split,
        {"x_edges":xe.tolist(), "y_edges":ye.tolist(), "counts":counts.astype(int).tolist()},
        role=role, requirement=requirement, units=units, comparison=comparison, threshold=threshold,
        interpretation=interpretation, limitations=limitations, axes=axes)


def _bars(identifier, title, labels, values, n, split, **kwargs):
    return _panel(identifier, title, "bars", n, split,
        {"labels":list(labels), "values":[float(v) for v in values]}, **kwargs)


def _matrix(identifier, title, rows, columns, values, n, split, **kwargs):
    return _panel(identifier, title, "matrix", n, split,
        {"labels":{"rows":list(rows), "columns":list(columns)},
         "values":np.asarray(values).tolist()}, **kwargs)


def _curve(identifier, title, x, y, n, split, **kwargs):
    return _panel(identifier, title, "curve", n, split,
        {"x":[float(v) for v in x], "y":[float(v) for v in y]}, **kwargs)


def _finish(n, source_split, panels):
    result = {"schema_version":SCHEMA_VERSION, "source_split":_split(source_split),
        "n":int(n), "privacy":PRIVACY, "panels":panels}
    validate_visual_evidence(result)
    return result


def regression_visual_evidence(y_true, predictions, *, source_split="unknown", bins=16):
    """Observed/predicted and error counts; held-out errors are not training residuals."""
    _split(source_split); _bins(bins); _align(y_true, predictions)
    y = _numeric(y_true, "y_true"); p = _numeric(predictions, "predictions")
    _same_length(y, p)
    error = y-p
    label = "Training prediction error" if source_split == "training" else "Predictive error"
    limits = _COMMON_LIMITS + [
        "Error is observed outcome minus supplied prediction in outcome units. This does not require normally distributed predictors.",
        "Prediction errors on evaluation rows are not stored fitted-model residuals and do not establish OLS inferential assumptions.",
        "Evaluation labels are caller declarations; these panels do not verify selection history, independent rows or future performance."]
    panels = [histogram2d_panel("observed_predicted", "Observed versus predicted outcome", p, y,
        role="main_result", requirement=None, source_split=source_split,
        units="x: predicted outcome; y: observed outcome; cell: observations",
        comparison="Observed outcome versus prediction on identical supplied rows; identity is the descriptive reference",
        interpretation="Concentration near equal observed and predicted values describes agreement on these rows, not external validity.",
        limitations=limits, bins=bins),
      histogram_panel("prediction_error", label+" distribution", error, role="diagnostic",
        requirement=None, source_split=source_split, units="observed minus predicted, outcome units; count: observations",
        comparison="Signed error relative to zero; no universal distributional cutoff",
        interpretation="The sign shows underprediction or overprediction; spread describes observed error, not a validated prediction interval.",
        limitations=limits, bins=bins),
      histogram2d_panel("error_predicted", label+" versus prediction", p, error,
        role="diagnostic", requirement=None, source_split=source_split,
        units="x: predicted outcome; y: observed minus predicted; cell: observations",
        comparison="Error distribution across predicted levels; zero is a descriptive reference",
        interpretation="Visible patterns can motivate prespecified model review; this chart neither tests a universal assumption nor authorizes holdout-driven selection.",
        limitations=limits, bins=bins)]
    return _finish(len(y), source_split, panels)


def _class_key(value):
    if isinstance(value, (bool, np.bool_)):
        raise ValueError("Class labels must be numeric or text, not boolean")
    if isinstance(value, (int, float, np.integer, np.floating)):
        if not math.isfinite(float(value)):
            raise ValueError("Class labels must be finite")
        return ("number", float(value))
    if isinstance(value, str) and 0 < len(value) <= 128:
        return ("text", value)
    raise ValueError("Class labels must be finite numbers or nonempty strings of at most 128 characters")


def _class_vector(value, name):
    if np.ma.isMaskedArray(value):
        raise ValueError(name+" must not be masked")
    values = np.asarray(value, dtype=object)
    if values.ndim != 1 or not 1 <= len(values) <= MAX_ELEMENTS:
        raise ValueError(name+" must be a nonempty bounded one-dimensional sequence")
    keys = [_class_key(v) for v in values]
    if len({k[0] for k in keys}) != 1:
        raise ValueError(name+" must not mix text and numeric labels")
    return keys


def _sample_native_curve(x, y):
    indices = np.unique(np.rint(np.linspace(0, len(x)-1, min(65, len(x)))).astype(int))
    return np.asarray(x)[indices], np.asarray(y)[indices]


def classification_visual_evidence(y_true, predictions, *, classes, probabilities=None,
                                   scores=None, source_split="unknown", bins=16):
    """Explicit class order; binary scores/probability vectors concern classes[1].

    Probability matrices must have one column per supplied class in exactly that
    order. Scores are binary decision scores, not probabilities. Predicted labels
    are supplied independently; no decision threshold is inferred or applied.
    """
    _split(source_split); _bins(bins); _align(y_true, predictions, probabilities, scores)
    ck = _class_vector(classes, "classes")
    if not 2 <= len(ck) <= 256 or len(set(ck)) != len(ck):
        raise ValueError("classes requires 2..256 unique ordered labels")
    mapping = {key:i for i,key in enumerate(ck)}
    def encode(value, name):
        keys = _class_vector(value, name)
        if any(key not in mapping for key in keys):
            raise ValueError(name+" contains labels absent from the explicit class order")
        return np.array([mapping[key] for key in keys], dtype=int)
    y = encode(y_true, "y_true"); predicted = encode(predictions, "predictions")
    _same_length(y, predicted)
    n, k = len(y), len(ck)
    if probabilities is not None and scores is not None:
        raise ValueError("Supply probabilities or binary scores, not both")
    p = None; binary_score = None
    if probabilities is not None:
        if getattr(probabilities, "columns", None) is not None:
            supplied_columns = [_class_key(v) for v in probabilities.columns]
            if supplied_columns != ck:
                raise ValueError("Probability column labels/order differ from explicit classes")
        raw = np.asarray(probabilities)
        if raw.ndim == 1 and k == 2:
            positive = _numeric(probabilities, "probabilities")
            p = np.column_stack([1-positive, positive])
        else:
            p = _numeric(probabilities, "probabilities", ndim=2)
        if p.shape != (n, k) or np.any((p < 0) | (p > 1)) or not np.allclose(p.sum(axis=1), 1., rtol=0, atol=1e-8):
            raise ValueError("Probabilities must be n-by-class, within [0,1], summing to one in declared class order")
        if k == 2:
            binary_score = p[:, 1]
    elif scores is not None:
        if k != 2:
            raise ValueError("Decision scores are supported only for explicit binary class order")
        binary_score = _numeric(scores, "scores")
        _same_length(y, binary_score)
    limits = _COMMON_LIMITS + [
        "Class positions follow the explicitly supplied order; original class names are withheld. Binary event is class position 2.",
        "Confusion counts depend on the supplied decision policy and class prevalence; they are not probability calibration.",
        "Ranking, probability calibration and decision utility are different quantities; a capacity or queue-capture rate is not accuracy.",
        "No normal-feature assumption, decision threshold selection, recalibration or refitting is performed."]
    panels = []
    if k <= 12:
        counts = confusion_matrix(y, predicted, labels=np.arange(k))
        panels.append(_matrix("confusion", "Observed versus predicted class counts",
            ["observed class "+str(i+1) for i in range(k)], ["predicted class "+str(i+1) for i in range(k)],
            counts, n, source_split, role="main_result", units="observations (counts)",
            comparison="Rows: observed class positions; columns: supplied predicted class positions; denominator all supplied rows",
            interpretation="Diagonal cells count correct supplied labels; off-diagonal cells identify observed error types under the supplied policy.", limitations=limits))
    else:
        panels.append(status_panel("confusion", "Class confusion matrix", n=n, source_split=source_split,
            message="More than 12 classes exceed this visual matrix bound; no class counts were silently merged.", limitations=limits))
    if k <= 32:
        panels.append(_bars("class_prevalence", "Observed class counts", ["class "+str(i+1) for i in range(k)],
            np.bincount(y, minlength=k), n, source_split, role="descriptive", units="observations (counts)",
            comparison="Count per supplied class position; denominator all supplied rows",
            interpretation="Unequal observed counts show prevalence imbalance in this sample, not future prevalence or a model defect by themselves.", limitations=limits))
    else:
        panels.append(status_panel("class_prevalence", "Observed class counts", n=n, source_split=source_split,
            message="More than 32 classes exceed the bounded count display; no categories were merged.", limitations=limits))
    if k == 2:
        if binary_score is None or len(np.unique(y)) != 2:
            message = "ROC and precision-recall require supplied scores and both observed classes; labels alone cannot define ranking curves."
            for identifier,title in [("roc", "ROC ranking curve"), ("precision_recall", "Precision-recall ranking curve")]:
                panels.append(status_panel(identifier, title, n=n, source_split=source_split, message=message, limitations=limits))
        else:
            fpr, tpr, _ = roc_curve(y, binary_score, pos_label=1, drop_intermediate=False)
            precision, recall, _ = precision_recall_curve(y, binary_score, pos_label=1, drop_intermediate=False)
            xroc, yroc = _sample_native_curve(fpr,tpr); xpr, ypr = _sample_native_curve(recall,precision)
            curve_limits = limits + ["At most 65 actual native curve points are retained by ordered threshold-position quantiles; no interpolation is invented. Displayed segments may omit steps.",
                "No confidence bands or independent-sampling claim are supplied. Precision-recall depends on event prevalence; the observed prevalence reference is descriptive."]
            panels.append(_curve("roc", "ROC ranking curve", xroc, yroc, n, source_split,
                role="main_result", requirement="discrimination", units="x: false-positive rate; y: true-positive rate",
                comparison="Actual event-2 ranking rates across native score thresholds; diagonal is descriptive chance-ranking reference",
                interpretation="Rates describe discrimination on these rows; favorable ranking does not establish calibration or useful decisions.", limitations=curve_limits))
            panels.append(_curve("precision_recall", "Precision-recall ranking curve", xpr, ypr, n, source_split,
                role="main_result", requirement="discrimination", units="x: recall; y: precision",
                comparison="Native event-2 recall versus precision; observed event prevalence = "+format(float(y.mean()), ".6g"),
                interpretation="Precision concerns event yield among score-selected rows; it is prevalence-sensitive and is not queue capacity or overall accuracy.", limitations=curve_limits))
    else:
        panels.append(status_panel("ranking", "Multiclass ranking curves", n=n, source_split=source_split,
            status="not_checked", message="This bounded collector does not implement multiclass ROC or precision-recall aggregation; confusion and probability summaries are separate evidence.", limitations=limits))
    if p is None:
        panels.append(status_panel("reliability", "Probability reliability", n=n, source_split=source_split,
            requirement="calibration", message="Calibrated-probability review requires supplied probabilities; labels or unbounded decision scores are insufficient.", limitations=limits))
    elif k == 2:
        detail = audit_calibration(y.astype(float), p[:,1], split_role=source_split if source_split != "not_applicable" else "unknown", n_bins=bins)["estimates"]["calibration_detail"]
        nonempty = [b for b in detail["bins"] if b["count"]]
        reliability_limits = limits + ["Fixed uniform bins use [0,edge1] then (left,right]; empty bins have no reliability estimate.",
            "Reliability is descriptive; no adequacy threshold, simultaneous uncertainty band or proof of calibration is supplied. Training summaries are optimistic for generalization."]
        panels.append(_curve("reliability", "Event probability reliability", [b["mean_probability"] for b in nonempty],
            [b["event_rate"] for b in nonempty], n, source_split, requirement="calibration",
            units="x: mean event-2 probability; y: observed event-2 fraction",
            comparison="Each nonempty fixed-bin observed fraction versus mean probability; identity is descriptive reference; bin denominators are shown separately",
            interpretation="Gaps describe probability disagreement in these bins and rows; discrimination can remain unchanged while probabilities are miscalibrated.", limitations=reliability_limits))
        panels.append(_bars("probability_bin_counts", "Reliability bin denominators", ["probability bin "+str(i+1) for i in range(bins)],
            [b["count"] for b in detail["bins"]], n, source_split, role="descriptive", units="observations (counts)",
            comparison="Equal-width probability bins from zero to one; empty bins explicitly have zero observations",
            interpretation="Small or empty bins limit reliability assessment; counts sum to the complete supplied sample.", limitations=reliability_limits))
    else:
        confidence = np.max(p, axis=1); correct = (np.argmax(p,axis=1) == y).astype(float)
        assignment = np.searchsorted(np.linspace(0,1,bins+1)[1:-1], confidence, side="left")
        counts = np.bincount(assignment,minlength=bins)
        nonempty = np.flatnonzero(counts)
        mean_confidence = [float(confidence[assignment == i].mean()) for i in nonempty]
        accuracy = [float(correct[assignment == i].mean()) for i in nonempty]
        multiclass_limits = limits + ["This is top-probability reliability of the probability argmax, which may differ from supplied predicted labels. It is not classwise or full-distribution calibration.",
            "Empty confidence bins are unassessed. No acceptance cutoff or confidence band is evaluated."]
        panels.append(_curve("reliability", "Top-probability reliability", mean_confidence, accuracy, n, source_split,
            requirement="calibration", units="x: mean maximum class probability; y: probability-argmax accuracy",
            comparison="Nonempty fixed confidence bins; correct means probability-argmax matches observed class; identity is descriptive reference",
            interpretation="The comparison concerns confidence in the most probable class; it does not certify probabilities for every class.", limitations=multiclass_limits))
        panels.append(_bars("probability_bin_counts", "Confidence bin denominators", ["confidence bin "+str(i+1) for i in range(bins)],
            counts, n, source_split, role="descriptive", units="observations (counts)",
            comparison="Equal-width maximum-probability bins from zero to one; denominator all supplied rows",
            interpretation="Counts identify supported confidence regions; zeros mean unassessed regions.", limitations=multiclass_limits))
    return _finish(n, source_split, panels)


def ols_visual_evidence(fitted_values, residuals, design, *, source_split="training", feature_names=None,
                        leverage=None, cooks_distance=None, vif=None, residual_scale=None, bins=16):
    """Stored OLS training diagnostics, using native influence/VIF values if supplied.

    ``design`` is the actual fitted design (including intercept/transforms), not
    assumed original features. No leverage, VIF or fit is reconstructed.
    """
    _split(source_split); _bins(bins)
    _align(fitted_values,residuals,design,leverage,cooks_distance)
    f = _numeric(fitted_values,"fitted_values"); r = _numeric(residuals,"residuals"); d = _numeric(design,"design",ndim=2)
    _same_length(f,r,d); n,p = d.shape
    if feature_names is not None and len(feature_names) != p:
        raise ValueError("feature_names must match actual design columns; names are not emitted")
    if source_split != "training":
        return _finish(n,source_split,[status_panel("ols_training_diagnostics","Stored OLS training diagnostics",n=n,source_split=source_split,
            message="Stored-fit OLS residual diagnostics require source_split='training'; held-out errors must use the regression collector.",limitations=_COMMON_LIMITS)])
    limits = _COMMON_LIMITS + ["Actual stored training design/residuals are supplied; transformed design columns are not original raw features.",
        "These plots do not establish independent errors, absence of confounding or a correct mean specification. HC3 covariance does not fix dependent errors or nonlinearity.",
        "Normally distributed predictors are not required. A residual normal-reference plot concerns conditional error approximations for some inference purposes, not OLS prediction validity."]
    panels = [histogram2d_panel("ols_residual_fitted","Stored OLS residual versus fitted value",f,r,
        role="diagnostic",requirement="functional_form",source_split=source_split,
        units="x: fitted outcome; y: training residual; cell: observations",comparison="Training residual (observed minus fitted) versus fitted level; zero is descriptive reference",
        interpretation="Patterns can suggest mean-form concerns; an apparently flat plot cannot prove the functional form.",limitations=limits,bins=bins),
      histogram_panel("ols_residual_distribution","Stored OLS residual distribution",r,role="diagnostic",requirement="error_structure",source_split=source_split,
        units="training residual in outcome units; count: observations",comparison="Distribution around zero; no normality acceptance cutoff",
        interpretation="Tail and spread patterns describe these training residuals; normal errors are not required for ordinary point prediction.",limitations=limits,bins=bins)]
    if n >= 20 and float(np.std(r,ddof=1)) > 0:
        probabilities = np.linspace(.025,.975,33)
        panels.append(_curve("ols_qq","Residual normal-reference quantiles",norm.ppf(probabilities),np.quantile(r,probabilities),n,source_split,
            requirement="error_structure",units="x: standard-normal quantile; y: residual quantile in outcome units",
            comparison="33 empirical residual quantiles at probabilities 0.025..0.975 versus standard-normal quantiles; no line is fitted",
            interpretation="Curvature or asymmetry can motivate conditional inference review. No test passed, no normal-feature requirement, and extreme 2.5% tails are outside this bounded display.",limitations=limits))
    else:
        panels.append(status_panel("ols_qq","Residual normal-reference quantiles",n=n,source_split=source_split,requirement="error_structure",
            message="At least 20 rows and nonconstant residuals are required for this bounded quantile display; no normality result is inferred.",limitations=limits))
    if residual_scale is None:
        scale = 1.; scale_units = "sqrt(abs(raw residual)), sqrt(outcome units)"
        scale_note = "No native residual scale supplied: this uses raw residual magnitude, not standardized/studentized residuals."
    else:
        if isinstance(residual_scale,(bool,np.bool_)) or not isinstance(residual_scale,(int,float,np.integer,np.floating)) or not math.isfinite(float(residual_scale)) or not 0 < residual_scale <= 1e40:
            raise ValueError("residual_scale must be a positive finite supplied native scale")
        scale = float(residual_scale); scale_units = "sqrt(abs(residual / supplied native scale)), dimensionless"
        scale_note = "Supplied native residual scale is used; these are not leverage-adjusted studentized residuals."
    panels.append(histogram2d_panel("ols_scale_location","OLS residual scale-location",f,np.sqrt(np.abs(r/scale)),
        role="diagnostic",requirement="error_structure",source_split=source_split,
        units="x: fitted outcome; y: "+scale_units+"; cell: observations",comparison="Residual magnitude across fitted levels; constant spread is descriptive reference",
        interpretation="Changing spread can motivate prespecified covariance or model review; no remedy is selected by this display.",limitations=limits+[scale_note],bins=bins))
    varying = np.flatnonzero(np.ptp(d,axis=0) > 0)
    selected = varying[:12]
    design_limits = limits + [str(p-len(varying))+" constant design columns are explicitly omitted from correlation/VIF display; actual positions are retained.",
        "At most the first 12 varying design columns are displayed; "+str(max(0,len(varying)-12))+" additional varying columns are outside this bounded visual.",
        "Correlation and VIF concern coefficient collinearity/stability; they do not automatically imply poor forecasts or justify deleting variables."]
    if len(selected) >= 2:
        corr = np.corrcoef(d[:,selected],rowvar=False)
        if np.isfinite(corr).all():
            labels = ["design position "+str(i+1) for i in selected]
            panels.append(_matrix("ols_design_correlation","Actual design-column correlation",labels,labels,corr,n,source_split,
                requirement="collinearity",units="Pearson correlation, dimensionless",comparison="Pairwise correlation of supplied varying fitted-design columns; no universal adequacy cutoff",
                interpretation="Large pairwise correlations can signal unstable coefficient allocation; pairwise correlation alone does not capture every multicollinearity pattern.",limitations=design_limits))
        else:
            panels.append(status_panel("ols_design_correlation","Actual design-column correlation",n=n,source_split=source_split,requirement="collinearity",
                message="Correlation is numerically undefined for this supplied design; no numeric matrix is invented.",limitations=design_limits))
    else:
        panels.append(status_panel("ols_design_correlation","Actual design-column correlation",n=n,source_split=source_split,requirement="collinearity",status="not_applicable",
            message="Fewer than two varying design columns: no pairwise design correlation matrix is applicable.",limitations=design_limits))
    if vif is not None:
        if np.ma.isMaskedArray(vif) or np.asarray(vif,dtype=object).ndim != 1 or len(vif) != p:
            raise ValueError("vif must match all actual design columns, using None for undefined values")
        supplied = list(vif)
        for value in supplied:
            if value is not None and (isinstance(value,(bool,np.bool_)) or not isinstance(value,(int,float,np.integer,np.floating)) or not math.isfinite(float(value)) or not 1-1e-10 <= value <= 1e40):
                raise ValueError("vif values must be finite and at least one, or explicitly None")
    else:
        supplied = [None]*p
    if len(selected) and all(supplied[i] is not None for i in selected):
        panels.append(_bars("ols_vif","Supplied native variance inflation factors",["design position "+str(i+1) for i in selected],
            [supplied[i] for i in selected],n,source_split,requirement="collinearity",units="variance inflation factor, dimensionless",
            comparison="Supplied native VIF for displayed varying design positions; reference one, no universal failure cutoff",
            interpretation="VIF describes coefficient-variance inflation conditional on the supplied model; any feature-removal or ridge remedy changes the fit and requires training-only review.",limitations=design_limits))
    else:
        panels.append(status_panel("ols_vif","Supplied native variance inflation factors",n=n,source_split=source_split,requirement="collinearity",
            message="Native VIF was not supplied or is undefined for a displayed varying column; no auxiliary model was fitted by this collector.",limitations=design_limits))
    for identifier,title,value,unit in [("ols_leverage","Supplied native leverage",leverage,"hat diagonal, dimensionless"),
                                      ("ols_cooks_distance","Supplied native Cook distance",cooks_distance,"Cook distance, dimensionless")]:
        if value is None:
            panels.append(status_panel(identifier,title,n=n,source_split=source_split,requirement="error_structure",
                message="Native fitted-model influence values were not supplied; influence is not assessed.",limitations=limits))
        else:
            a = _numeric(value,identifier); _same_length(r,a)
            if np.any(a < 0) or (identifier == "ols_leverage" and np.any(a > 1+1e-10)):
                raise ValueError(identifier+" has values outside its valid native range")
            panels.append(histogram_panel(identifier,title,a,role="diagnostic",requirement="error_structure",source_split=source_split,units=unit+"; count: observations",
                comparison="Distribution of supplied native influence values; no universal deletion cutoff",
                interpretation="Large values can motivate provenance review and prespecified sensitivity analysis; they do not authorize silent removal of observations.",limitations=limits,bins=bins))
    return _finish(n,source_split,panels)


def pca_visual_evidence(scores, components, explained_variance_ratio, *, source_split="unknown", bins=16):
    """Native supplied scores and components (component-by-input-feature), no transform."""
    _split(source_split); _bins(bins)
    s = _numeric(scores,"scores",ndim=2); c = _numeric(components,"components",ndim=2)
    evr = _numeric(explained_variance_ratio,"explained_variance_ratio")
    if s.shape[1] != c.shape[0] or len(evr) != c.shape[0] or np.any(evr<0) or np.any(evr>1) or float(evr.sum()) > 1+1e-8:
        raise ValueError("PCA score/component dimensions and variance ratios must agree; ratios must be nonnegative with sum at most one")
    n,q = s.shape
    limits = _COMMON_LIMITS + ["Scores, loadings and ratios are supplied from an existing fit; no preprocessing, centering or projection is reconstructed.",
        "Components refer to the actual fitted input representation. Scaling choices and omitted directions affect geometry; high explained variance does not establish scientific validity or a predictive signal.",
        "PCA sign conventions are arbitrary; loading signs do not identify causal directions. Two-dimensional projection can conceal structure."]
    values = evr.tolist(); labels = ["component "+str(i+1) for i in range(q)]
    if q > 32:
        values = values[:31]+[float(evr[31:].sum())]; labels = labels[:31]+["remaining component ratios summed"]
    panels = [_bars("pca_variance","Supplied PCA explained variance",labels,values,n,source_split,role="main_result",units="fraction of fitted-input variance",
        comparison="Per-component native explained-variance ratio, with any bounded remainder explicitly summed",
        interpretation="Fractions describe retained variance under fitted preprocessing; they do not measure out-of-sample prediction or causal importance.",limitations=limits)]
    if q >= 2:
        panels.append(histogram2d_panel("pca_scores","Supplied PCA score geometry",s[:,0],s[:,1],role="descriptive",requirement=None,source_split=source_split,
            units="x: component-1 score; y: component-2 score; cell: observations",comparison="First two actual supplied score coordinates, aggregated into count cells",
            interpretation="Visible score geometry describes this projection; no clustering or stability proof follows.",limitations=limits,bins=bins))
    else:
        panels.append(histogram_panel("pca_scores","Supplied first-component score distribution",s[:,0],role="descriptive",requirement=None,source_split=source_split,
            units="component-1 score; count: observations",comparison="One actual supplied component; no second axis is invented",
            interpretation="The supplied fit has one component; only its score distribution is displayed.",limitations=limits,bins=bins))
    panels.append(_matrix("pca_loadings","Supplied PCA component coefficients",["component "+str(i+1) for i in range(min(2,q))],
        ["input position "+str(i+1) for i in range(min(12,c.shape[1]))],c[:2,:12],n,source_split,role="descriptive",units="native component coefficient, representation dependent",
        comparison="First two native components and first 12 fitted-input positions; coefficients beyond the display are not assessed here",
        interpretation="Coefficients describe fitted component orientation, not feature causality or coefficients in an outcome model.",limitations=limits+[str(max(0,c.shape[1]-12))+" fitted-input positions are omitted from this bounded coefficient display."]))
    return _finish(n,source_split,panels)


def kmeans_visual_evidence(X, labels, centers, *, source_split="unknown", bins=16):
    """Geometry in the actual fitted input coordinates; no predict/transform/refit."""
    _split(source_split); _bins(bins); _align(X,labels)
    x = _numeric(X,"X",ndim=2); c = _numeric(centers,"centers",ndim=2)
    assignment = _numeric(labels,"labels")
    _same_length(x,assignment)
    n,p = x.shape; k = c.shape[0]
    if c.shape[1] != p or np.any(assignment != np.floor(assignment)) or np.any((assignment<0)|(assignment>=k)):
        raise ValueError("KMeans centers must match fitted-input columns and labels must be integer center positions")
    assignment = assignment.astype(int)
    distance = np.sqrt(np.sum((x-c[assignment])**2,axis=1))
    limits = _COMMON_LIMITS + ["Coordinates are the actual supplied fitted-input representation; original feature names and row identifiers are not returned.",
        "Cluster labels are arbitrary center positions. Separation in two displayed axes and distance to an assigned center do not establish stability, optimal cluster count or meaningful populations.",
        "Euclidean geometry depends on scaling and preprocessing. No predictor-normality assumption, causal claim or new clustering fit is made."]
    panels = []
    if k <= 32:
        panels.append(_bars("cluster_sizes","Assigned cluster sizes",["center "+str(i+1) for i in range(k)],np.bincount(assignment,minlength=k),n,source_split,
            role="main_result",units="observations (counts)",comparison="Supplied assignment count per center position; denominator all supplied rows",
            interpretation="Counts describe this supplied partition; empty centers remain explicit zeros.",limitations=limits))
    else:
        panels.append(status_panel("cluster_sizes","Assigned cluster sizes",n=n,source_split=source_split,
            message="More than 32 centers exceed the count-display bound; no centers were silently merged.",limitations=limits))
    panels.append(histogram_panel("cluster_distance","Distance to supplied assigned center",distance,role="descriptive",requirement=None,source_split=source_split,
        units="Euclidean distance in fitted-input units; count: observations",comparison="Distance to each row's supplied assigned center using all fitted-input dimensions",
        interpretation="Large distances identify broad dispersion in this representation; distance is not a validated outlier, membership probability or stability score.",limitations=limits,bins=bins))
    if p >= 2:
        panels.append(histogram2d_panel("cluster_geometry","First-two-input coordinate geometry",x[:,0],x[:,1],role="descriptive",requirement=None,source_split=source_split,
            units="x: fitted-input position 1; y: fitted-input position 2; cell: observations",comparison="All supplied rows in the first two actual fitted-input coordinates",
            interpretation="This is a bounded input projection, not a new embedding; higher-dimensional separation can differ.",limitations=limits,bins=bins))
        if k <= 8:
            for i in range(k):
                subset = x[assignment == i]
                if len(subset):
                    overall=panels[-1]["data"] if panels[-1]["id"]=="cluster_geometry" else next(panel["data"] for panel in panels if panel["id"]=="cluster_geometry")
                    counts,_,_=np.histogram2d(subset[:,0],subset[:,1],bins=(overall["x_edges"],overall["y_edges"]))
                    panels.append(_panel("cluster_geometry_"+str(i+1),"Assigned center "+str(i+1)+" geometry","hist2d",len(subset),source_split,
                        {"x_edges":list(overall["x_edges"]),"y_edges":list(overall["y_edges"]),"counts":counts.astype(int).tolist()},
                        role="descriptive",requirement=None,
                        units="x: fitted-input position 1; y: fitted-input position 2; cell: assigned observations",
                        comparison="Only rows assigned to center position "+str(i+1)+"; subset denominator shown by panel n; all centers share the overall count-grid edges",
                        interpretation="Subset geometry is descriptive; shared axes support comparison but cannot establish meaningful or stable clusters.",limitations=limits))
                else:
                    panels.append(status_panel("cluster_geometry_"+str(i+1),"Assigned center "+str(i+1)+" geometry",n=0,source_split=source_split,
                        message="No supplied rows are assigned to this center; no geometry is invented.",limitations=limits))
        else:
            panels.append(status_panel("cluster_group_geometry","Per-center coordinate geometry",n=n,source_split=source_split,
                message="More than eight centers exceed the bounded per-center projection display; overall geometry is shown without silently merging assignments.",limitations=limits))
    else:
        panels.append(status_panel("cluster_geometry","First-two-input coordinate geometry",n=n,source_split=source_split,status="not_applicable",
            message="Only one fitted-input dimension is supplied; no second coordinate is invented.",limitations=limits))
    if k <= 12:
        panels.append(_matrix("cluster_centers","Supplied center coordinates",["center "+str(i+1) for i in range(k)],
            ["input position "+str(i+1) for i in range(min(2,p))],c[:,:2],n,source_split,role="descriptive",units="native fitted-input units",
            comparison="Actual fitted center coordinates in the first two input positions; model parameters, not raw row pairs",
            interpretation="Centers summarize a fit in its chosen representation and may still be sensitive; they do not verify assignment stability.",limitations=limits))
    else:
        panels.append(status_panel("cluster_centers","Supplied center coordinates",n=n,source_split=source_split,
            message="More than 12 centers exceed the bounded center matrix display.",limitations=limits))
    return _finish(n,source_split,panels)


def _text(value, name, *, empty=False):
    if not isinstance(value,str) or (not value and not empty) or len(value)>2000 or any(ord(c)<32 for c in value):
        raise ValueError(name+" must be a bounded printable string")


def _number(value):
    return type(value) in {int,float} and abs(value)<=1e100 and math.isfinite(value)


def _number_list(values,name,minimum=1,maximum=65):
    if type(values) is not list or not minimum<=len(values)<=maximum or any(not _number(x) for x in values):
        raise ValueError(name+" must be a bounded list of finite JSON numbers")


def _count(value):
    return type(value) is int and 0<=value<=MAX_ELEMENTS


def _edge_list(values,name):
    _number_list(values,name,minimum=13,maximum=21)
    if any(b<=a for a,b in zip(values,values[1:])):
        raise ValueError(name+" must be strictly increasing")


def validate_visual_evidence(payload):
    """Validate the exact bounded JSON contract, including histogram count sums.

    Returns True; raises ValueError on unknown fields, malformed data, nonfinite
    values, excess sizes, duplicate panel ids or mismatched denominators.
    """
    top={"schema_version","source_split","n","privacy","panels"}
    if type(payload) is not dict or set(payload)!=top or payload["schema_version"]!=SCHEMA_VERSION or payload["privacy"]!=PRIVACY:
        raise ValueError("Invalid visual-evidence header or unknown fields")
    if not isinstance(payload["source_split"],str):
        raise ValueError("Visual-evidence source_split must be a string")
    if payload["source_split"] != "mixed":
        _split(payload["source_split"])
    if not _count(payload["n"]):
        raise ValueError("Visual-evidence n must be a positive bounded integer")
    panels=payload["panels"]
    if type(panels) is not list or not 1<=len(panels)<=16:
        raise ValueError("Visual evidence requires 1..16 panels")
    keys={"id","title","kind","role","requirement","status","n","source_split","units","comparison","threshold","interpretation","limitations","data"}
    ids=set()
    for panel in panels:
        if type(panel) is not dict or set(panel) not in (keys, keys|{"axes"}):
            raise ValueError("Invalid panel fields")
        identifier=panel["id"]
        if not isinstance(identifier,str) or not re.fullmatch(r"[a-z][a-z0-9_]{0,79}",identifier) or identifier in ids:
            raise ValueError("Panel ids must be unique bounded identifiers")
        ids.add(identifier)
        if not isinstance(panel["kind"],str) or panel["kind"] not in KINDS or not isinstance(panel["role"],str) or panel["role"] not in ROLES or not isinstance(panel["status"],str) or panel["status"] not in {"computed","not_checked","not_applicable"}:
            raise ValueError("Invalid panel kind, role or computation status")
        if not _count(panel["n"]) or panel["n"]>payload["n"]:
            raise ValueError("Panel n must be bounded by the report denominator")
        if _split(panel["source_split"])!=payload["source_split"] and payload["source_split"]!="mixed":
            raise ValueError("Panel split must match this collector's source_split")
        for name in ["title","units","comparison","interpretation"]:
            _text(panel[name],name)
        if panel["requirement"] is not None and (not isinstance(panel["requirement"],str) or not re.fullmatch(r"[a-z][a-z0-9_]{0,79}",panel["requirement"])):
            raise ValueError("Invalid requirement id")
        if panel["threshold"] is not None:
            _text(panel["threshold"],"threshold")
        if type(panel["limitations"]) is not list or len(panel["limitations"])>32:
            raise ValueError("Invalid limitations list")
        for limit in panel["limitations"]:
            _text(limit,"limitation")
        data=panel["data"]; kind=panel["kind"]
        if "axes" in panel:
            if type(panel["axes"]) is not dict or set(panel["axes"])!={"x","y"}:
                raise ValueError("Panel axes require exactly x and y labels")
            for label in panel["axes"].values(): _text(label,"axis label")
        if type(data) is not dict:
            raise ValueError("Panel data must be an object")
        if kind=="status":
            if panel["status"]=="computed" or set(data)!={"message"}:
                raise ValueError("Status panels require explicit unresolved/inapplicable message")
            _text(data["message"],"message")
            continue
        if panel["status"]!="computed" or panel["n"]==0:
            raise ValueError("Numerical panels require computed data and positive n")
        if "axes" not in panel:
            raise ValueError("Numeric panels require explicit axes")
        if kind=="hist1d":
            if set(data)!={"edges","counts"}: raise ValueError("Invalid hist1d data fields")
            _edge_list(data["edges"],"edges")
            if type(data["counts"]) is not list or len(data["counts"])!=len(data["edges"])-1 or any(not _count(v) for v in data["counts"]) or sum(data["counts"])!=panel["n"]:
                raise ValueError("Histogram counts must conserve panel n")
        elif kind=="hist2d":
            if set(data)!={"x_edges","y_edges","counts"}: raise ValueError("Invalid hist2d data fields")
            _edge_list(data["x_edges"],"x_edges"); _edge_list(data["y_edges"],"y_edges")
            counts=data["counts"]
            if type(counts) is not list or len(counts)!=len(data["x_edges"])-1 or any(type(row) is not list or len(row)!=len(data["y_edges"])-1 or any(not _count(v) for v in row) for row in counts) or sum(sum(row) for row in counts)!=panel["n"]:
                raise ValueError("Two-dimensional histogram counts must conserve panel n")
        elif kind=="curve":
            if set(data)!={"x","y"}: raise ValueError("Invalid curve fields")
            _number_list(data["x"],"curve x"); _number_list(data["y"],"curve y")
            if len(data["x"])!=len(data["y"]): raise ValueError("Curve lengths differ")
        elif kind=="bars":
            if set(data)!={"labels","values"} or type(data["labels"]) is not list: raise ValueError("Invalid bars fields")
            _number_list(data["values"],"bar values",maximum=32)
            for label in data["labels"]: _text(label,"bar label")
            if len(data["labels"])!=len(data["values"]) or len(set(data["labels"]))!=len(data["labels"]): raise ValueError("Bar labels must be unique and align with values")
            if panel["units"]=="observations (counts)" and (any(v<0 or int(v)!=v for v in data["values"]) or sum(data["values"])!=panel["n"]):
                raise ValueError("Count bars must conserve panel n")
        elif kind=="matrix":
            if set(data)!={"labels","values"} or type(data["labels"]) is not dict or set(data["labels"])!={"rows","columns"}: raise ValueError("Invalid matrix fields")
            rows,columns=data["labels"]["rows"],data["labels"]["columns"]
            for labels in [rows,columns]:
                if type(labels) is not list or not 1<=len(labels)<=12: raise ValueError("Matrix axes must have 1..12 labels")
                for label in labels: _text(label,"matrix label")
                if len(set(labels))!=len(labels): raise ValueError("Matrix axis labels must be unique")
            values=data["values"]
            if type(values) is not list or len(values)!=len(rows): raise ValueError("Matrix row count mismatch")
            for row in values:
                _number_list(row,"matrix values",maximum=12)
                if len(row)!=len(columns): raise ValueError("Matrix column count mismatch")
            if panel["units"]=="observations (counts)" and (any(v<0 or int(v)!=v for row in values for v in row) or sum(sum(row) for row in values)!=panel["n"]):
                raise ValueError("Count matrix must conserve panel n")
    return True
