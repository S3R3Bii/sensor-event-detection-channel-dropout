"""Bounded count, rank and correlation computations; no design certification.

Only two-sided tests are exposed. Inputs are finite observations or aggregate
integer counts, never a fitted pickle, formula or executable source string.
All numerical results are conditional on the procedure's sampling assumptions.
"""
import math
import warnings as _warnings

import numpy as np
import scipy
from scipy import stats


METHODS = {"chi_square", "fisher_exact", "binomial_test", "mann_whitney",
           "wilcoxon_signed_rank", "kruskal_wallis", "friedman",
           "pearson_correlation", "spearman_correlation"}
MAX_OBSERVATIONS = 2_000_000
MAX_GROUPS = 20
MAX_ABS = 1e40


def _scalar(value, name):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, float, np.integer, np.floating)):
        raise ValueError(name+" must be a finite real scalar")
    try:
        result = float(value)
    except (ValueError, OverflowError) as exc:
        raise ValueError(name+" must lie within the supported finite numeric range") from exc
    if not math.isfinite(result) or abs(result) > MAX_ABS:
        raise ValueError(name+" must be finite and within the supported numeric bound")
    return result


def _no_mask(value, name):
    if np.ma.isMaskedArray(value) and np.ma.getmaskarray(value).any():
        raise ValueError(name+" contains masked values; no mask, record or missing value is silently removed")


def _vector(value, name):
    _no_mask(value, name)
    if np.iscomplexobj(value):
        raise ValueError(name+" must contain real numeric observations")
    try:
        array = np.asarray(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(name+" must be a one-dimensional numeric sample") from exc
    if array.ndim != 1 or array.size > MAX_OBSERVATIONS:
        raise ValueError(name+" must be one-dimensional and within the local observation bound")
    original = np.asarray(value, dtype=object)
    if any(isinstance(v, (bool, np.bool_)) for v in original):
        raise ValueError(name+" contains Boolean observations; numeric coercion is not performed")
    if array.dtype.kind not in "biuf" and not all(isinstance(v, (bool, int, float, np.integer, np.floating)) for v in array):
        raise ValueError(name+" must contain numeric observations; labels are not silently encoded")
    for v in array:
        if isinstance(v, (int, np.integer)) and not isinstance(v, (bool, np.bool_)):
            if abs(int(v)) > MAX_ABS:
                raise ValueError(name+" exceeds the supported numeric magnitude bound")
            if int(v) != int(float(v)):
                raise ValueError(name+" contains integer observations that cannot be represented exactly as float64; use an explicitly reviewed numeric representation rather than silently creating ties")
    try:
        array = np.asarray(value, dtype=float)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError(name+" must contain finite numeric observations") from exc
    if not np.isfinite(array).all() or np.any(np.abs(array) > MAX_ABS):
        raise ValueError(name+" contains missing, nonfinite or unsupported extreme values; no rows are dropped or repaired")
    return array


def _aligned(values):
    """Verify named pairing when available, without returning identifiers."""
    indexes = [getattr(value, "index", None) for value in values]
    named = [index for index in indexes if callable(getattr(index, "equals", None))]
    if not named:
        return "positional_only; original unit correspondence requires separate evidence"
    for index in named:
        if not bool(getattr(index, "is_unique", True)):
            raise ValueError("Paired named samples need unique row indexes; duplicated identifiers require an explicitly reviewed unit representation")
    if any(not named[0].equals(index) for index in named[1:]):
        raise ValueError("Paired sample indexes differ in values or order; align them explicitly without silently reordering")
    if len(named) != len(values):
        return "partially_named_positional; unnamed sample correspondence remains unverified"
    return "named_index_values_and_order_verified; identifier truth and dependence remain unverified"


def _summary(values, label):
    n = int(len(values))
    return {"group":label, "n":n,
            "mean":float(np.mean(values)) if n else None,
            "standard_deviation":float(np.std(values, ddof=1)) if n > 1 else None,
            "median":float(np.median(values)) if n else None,
            "minimum":float(np.min(values)) if n else None,
            "maximum":float(np.max(values)) if n else None}


def _table(value, method):
    _no_mask(value, "count table")
    if np.iscomplexobj(value):
        raise ValueError("Count tables require nonnegative integer frequencies")
    try:
        raw = np.asarray(value)
    except (TypeError, ValueError) as exc:
        raise ValueError("Count table must be a rectangular two-dimensional array") from exc
    if raw.ndim != 2 or min(raw.shape) < 2 or max(raw.shape) > MAX_GROUPS:
        raise ValueError("Count table must have 2..20 rows and columns")
    if method == "fisher_exact" and raw.shape != (2, 2):
        raise ValueError("This Fisher exact adapter supports only an explicit 2-by-2 table")
    if raw.dtype.kind == "b" or any(isinstance(v, (bool, np.bool_)) for v in np.asarray(value, dtype=object).flat):
        raise ValueError("Boolean indicators are not accepted as aggregate count frequencies")
    if raw.dtype.kind not in "iuf" and not all(isinstance(v, (int, float, np.integer, np.floating)) for v in raw.flat):
        raise ValueError("Count frequencies must be numeric integers; strings are not converted")
    try:
        array = np.asarray(value, dtype=float)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("Count frequencies must be finite nonnegative integers") from exc
    if not np.isfinite(array).all() or np.any(array < 0) or np.any(array != np.floor(array)) or np.any(array > MAX_OBSERVATIONS) or array.sum() > MAX_OBSERVATIONS:
        raise ValueError("Count frequencies must be nonnegative integers with total at most 2,000,000; no rounding or truncation is performed")
    return array.astype(np.int64)


def _integer_count(value, name):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)):
        raise ValueError(name+" must be an integer count, not a Boolean or rounded measurement")
    value = int(value)
    if not 0 <= value <= MAX_OBSERVATIONS:
        raise ValueError(name+" must lie from zero to 2,000,000")
    return value


def _effect(name, estimate=None, units="dimensionless", interval=None):
    return {"name":name, "estimate":estimate, "units":units, "confidence_interval":interval}


def _base(method, confidence):
    return {"sample_sizes":{}, "statistical_test":{
        "procedure":method, "computational_status":"not_computable", "statistic_name":"not_computed",
        "statistic":None, "p_value":None, "degrees_of_freedom":None, "alternative":"two-sided",
        "null":{"parameter":"not_specified", "value":None}, "effect":_effect("not_implemented"), "groups":[],
        "configuration":{"backend":"scipy", "backend_version":scipy.__version__, "implementation":"statistical-other/0.4.0",
                         "confidence_level":confidence, "data_handling":"No missing observations, groups, columns or categories are silently deleted, imputed, rounded or selected",
                         "hypothesis_selection":"Requested method and two-sided alternative fixed before computation; no method is selected from a preliminary test"},
        "warnings":[], "limitations":[
            "Numerical computation does not establish appropriate measurement, sampling, independence/pairing, prespecification, multiplicity control or external validity. Separate design evidence is required.",
            "A p-value is conditional on the stated null and reference distribution; it is not the probability the null is true, an effect's importance or evidence of causality. Non-rejection is not equivalence or assumption proof.",
            "Only aggregate summaries are returned, but small-cell counts and aggregates can still be sensitive.",
        ]}}


def _uncomputable(test, reason):
    test["computational_status"] = "not_computable"
    test["p_value"] = None
    test["warnings"].append(reason)
    test["limitations"].append("No supported numerical test result: "+reason)


def _native(test, function):
    with _warnings.catch_warnings(record=True) as caught:
        _warnings.simplefilter("always")
        try:
            result = function()
        except (ValueError, ArithmeticError, FloatingPointError) as exc:
            _uncomputable(test, "Established-library computation could not supply a finite reference result ("+type(exc).__name__+"); inspect the explicit input and procedure conditions")
            return None
    categories = sorted({warning.category.__name__ for warning in caught})
    test["configuration"]["native_warning_categories"] = categories
    test["warnings"].extend("SciPy reported "+category+"; no input values or raw warning text are copied" for category in categories)
    return result


def _finish(test, result):
    if result is None:
        return False
    statistic, p = float(result.statistic), float(result.pvalue)
    nonnegative = {"Pearson_chi_square", "Kruskal_Wallis_H", "Friedman_chi_square", "Mann_Whitney_U_x", "Wilcoxon_min_signed_rank_sum", "observed_success_proportion"}
    if math.isfinite(statistic) and statistic < 0 and test["statistic_name"] in nonnegative:
        test["configuration"]["native_invalid_statistic"] = statistic
        _uncomputable(test, "The native procedure returned a negative statistic for a nonnegative comparison, possibly from floating-point cancellation; no silent zero-clipping or replacement p-value was applied")
        return False
    if not math.isfinite(statistic) or not math.isfinite(p) or not 0 <= p <= 1:
        if math.isfinite(statistic):
            test["statistic"] = statistic
        _uncomputable(test, "The selected procedure returned an undefined statistic or p-value; no finite substitute was invented")
        return False
    test.update(computational_status="computed", statistic=statistic, p_value=p)
    return True


def compute_other_test(method, x, y=None, *, null_value=0.0, confidence=.95):
    """Compute one bounded canonical two-sided test, without choosing a design.

    Counts use ``x=table``; binomial uses ``x=successes, y=trials`` and
    ``null_value=p0``. Grouped tests use ``x=[group1, group2, ...]``. Pairwise
    sample/rank/correlation tests use ``x`` and ``y``. Wilcoxon tests symmetry of
    ``x-y`` about null_value; other non-binomial tests have their fixed native
    null and accept only the generic zero sentinel. No alternative, continuity
    policy, exact/approximate method or correction is selected from the data.
    """
    if not isinstance(method, str) or method not in METHODS:
        raise ValueError("Unknown canonical count, rank or correlation method")
    null = _scalar(null_value, "null_value")
    confidence = _scalar(confidence, "confidence")
    if not 0 < confidence < 1:
        raise ValueError("confidence must lie strictly between zero and one")
    if method not in {"binomial_test", "wilcoxon_signed_rank"} and null != 0:
        raise ValueError("This procedure has a fixed native null; only the generic null_value=0 sentinel is accepted")
    report = _base(method, confidence); test = report["statistical_test"]

    if method in {"chi_square", "fisher_exact"}:
        if y is not None:
            raise ValueError("Count-table procedures require x=table and y=None")
        table = _table(x, method); n = int(table.sum()); rows, columns = table.shape
        report["sample_sizes"] = {"n":n, "rows":rows, "columns":columns}
        test["groups"] = [{"group":"aggregate contingency table", "observed_counts":table.tolist(),
                           "row_totals":table.sum(axis=1).tolist(), "column_totals":table.sum(axis=0).tolist(), "n":n}]
        test["configuration"].update(input_role="aggregate observed integer frequencies", category_order="caller-supplied row/column order, no label values exported")
        if method == "chi_square":
            test.update(statistic_name="Pearson_chi_square", degrees_of_freedom=int((rows-1)*(columns-1)),
                        null={"parameter":"row_and_column_variables_independent", "value":True}, effect=_effect("Cramers_V"))
            test["configuration"].update(continuity_correction=False, power_divergence="Pearson", reference_distribution="asymptotic chi-square")
            test["limitations"].append("Uncorrected Pearson chi-square was requested in advance. Sparse expected counts can invalidate its asymptotic approximation; no automatic switch to Fisher, category merging or resampling is made.")
        else:
            test.update(statistic_name="sample_odds_ratio", null={"parameter":"population_odds_ratio_conditional_on_fixed_margins", "value":1.0}, effect=_effect("sample_odds_ratio"))
            test["configuration"].update(reference_distribution="fixed-margin hypergeometric", p_value_definition="SciPy two-sided sum of null table probabilities no greater than the observed table probability",
                                         odds_ratio_estimator="unconditional sample a*d/(b*c)", null_value_argument_role="zero sentinel; the scientific odds-ratio null is fixed at one")
            test["limitations"].extend([
                "Fisher's p-value conditions on the observed margins. Its reported sample odds ratio is an unconditional estimate; R fisher.test uses a conditional maximum-likelihood estimate and can report a different effect estimate.",
                "No odds-ratio confidence interval is implemented. A conditional exact interval must not be silently attached to this unconditional sample estimator."])
        if not n or np.any(table.sum(axis=0) == 0) or np.any(table.sum(axis=1) == 0):
            _uncomputable(test, "Zero total or zero row/column margin makes the requested comparison degenerate; no categories were removed")
            return report
        if method == "chi_square":
            result = _native(test, lambda:stats.chi2_contingency(table, correction=False))
            if result is not None:
                expected = np.asarray(result.expected_freq, dtype=float)
                test["configuration"].update(expected_counts=expected.tolist(), minimum_expected_count=float(expected.min()),
                    cells_expected_below_five=int(np.sum(expected < 5)), expected_cell_denominator=int(expected.size))
                if np.any(expected < 5):
                    test["warnings"].append(str(int(np.sum(expected < 5)))+" of "+str(expected.size)+" expected cells are below five; this review heuristic is not a universal adequacy test")
                if _finish(test, result):
                    test["effect"]["estimate"] = float(math.sqrt(test["statistic"]/(n*min(rows-1, columns-1))))
                test["limitations"].append("Cramer's V is an uncorrected descriptive association magnitude; no confidence interval or small-sample bias correction is implemented.")
        else:
            result = _native(test, lambda:stats.fisher_exact(table, alternative="two-sided"))
            if result is not None:
                p = float(result.pvalue); ratio = float(result.statistic)
                if math.isfinite(p) and 0 <= p <= 1:
                    test.update(computational_status="computed", p_value=p)
                    if math.isfinite(ratio):
                        test["statistic"] = ratio; test["effect"]["estimate"] = ratio
                        if ratio == 0:
                            test["warnings"].append("Sample odds ratio is at the zero boundary; no odds-ratio interval is supplied")
                    else:
                        test["configuration"]["effect_boundary_reason"] = "Sample odds ratio is positive infinity because its denominator is zero with a positive numerator; encoded as null, not as a finite effect"
                        test["warnings"].append(test["configuration"]["effect_boundary_reason"])
                else:
                    _uncomputable(test, "Fixed-margin Fisher p-value is undefined for this table")
        return report

    if method == "binomial_test":
        successes = _integer_count(x, "success count"); trials = _integer_count(y, "trial count")
        if successes > trials:
            raise ValueError("Success count cannot exceed trial count")
        if not 0 <= null <= 1:
            raise ValueError("Binomial null_value is the prespecified success probability p0 and must lie in [0,1]")
        report["sample_sizes"] = {"n":trials, "successes":successes, "failures":trials-successes}
        test.update(statistic_name="observed_success_proportion", null={"parameter":"Bernoulli_success_probability", "value":null}, effect=_effect("observed_success_proportion"))
        test["groups"] = [{"group":"binary aggregate outcomes", "n":trials, "successes":successes, "failures":trials-successes,
                           "observed_proportion":successes/trials if trials else None}]
        test["configuration"].update(p_value_method="SciPy exact two-sided binomial probability ordering", confidence_interval_method="Clopper-Pearson exact equal-tailed", null_value_argument_role="prespecified p0, not estimated from the same trials")
        test["limitations"].extend(["Exact binomial inference assumes independent Bernoulli trials with the stated common success probability; 'exact' does not certify those design conditions.",
                                    "The Clopper-Pearson interval can be conservative. No repeated-testing, clustering, overdispersion or multiple-comparison adjustment is applied."])
        if not trials:
            _uncomputable(test, "Zero trials provide no observed success proportion or binomial comparison")
            return report
        result = _native(test, lambda:stats.binomtest(successes, trials, p=null, alternative="two-sided"))
        if _finish(test, result):
            interval = result.proportion_ci(confidence_level=confidence, method="exact")
            test["effect"] = _effect("observed_success_proportion", test["statistic"], interval={"level":confidence, "lower":float(interval.low), "upper":float(interval.high), "method":"Clopper-Pearson exact equal-tailed"})
        return report

    if method in {"kruskal_wallis", "friedman"}:
        if y is not None or not isinstance(x, (list, tuple, np.ndarray)):
            raise ValueError("Grouped procedures require x=[group1, group2, ...] and y=None")
        _no_mask(x, "grouped samples")
        minimum = 3 if method == "friedman" else 2
        try:
            group_count = len(x)
        except TypeError as exc:
            raise ValueError("Grouped input must be a sequence of explicit one-dimensional samples") from exc
        if not minimum <= group_count <= MAX_GROUPS:
            raise ValueError("This procedure requires "+str(minimum)+"..20 explicitly supplied groups/conditions")
        samples = [_vector(value, "group "+str(i+1)) for i, value in enumerate(x)]
        if sum(len(value) for value in samples) > MAX_OBSERVATIONS:
            raise ValueError("Combined supplied observations exceed the local bound")
        sizes = [len(value) for value in samples]
        test["groups"] = [_summary(value, "condition_"+str(i+1) if method == "friedman" else "group_"+str(i+1)) for i, value in enumerate(samples)]
        test["effect"] = _effect("omnibus_rank_effect_not_implemented")
        test["limitations"].append("No omnibus rank effect-size estimator or interval is implemented; no eta/epsilon-squared quantity is invented. Omnibus rejection does not identify which groups differ; post hoc choices need prespecification and multiplicity review.")
        test["degrees_of_freedom"] = len(samples)-1
        if method == "kruskal_wallis":
            report["sample_sizes"] = {"n":sum(sizes), "groups":len(samples)}
            test.update(statistic_name="Kruskal_Wallis_H", null={"parameter":"underlying_group_distributions_equal", "value":True})
            test["configuration"].update(reference_distribution="tie-corrected asymptotic chi-square", input_relationship="independent groups; not established by arrays")
            test["limitations"].append("The rank comparison is not automatically a test only of medians: interpreting a location/median difference requires appropriate common-shape and scale conditions. Unequal variances or shapes can affect ranks.")
            if any(size < 5 for size in sizes):
                test["warnings"].append("At least one group has fewer than five observations; the chi-square approximation may be unreliable")
            if not all(sizes) or np.ptp(np.concatenate(samples)) == 0:
                _uncomputable(test, "An empty group or all pooled observations tied leaves no supported Kruskal-Wallis comparison")
            else:
                _finish(test, _native(test, lambda:stats.kruskal(*samples, nan_policy="raise")))
        else:
            if len(set(sizes)) != 1:
                raise ValueError("Friedman conditions must have the same number of aligned repeated units")
            alignment = _aligned(list(x))
            n = sizes[0]; report["sample_sizes"] = {"n":n, "conditions":len(samples), "measurements":sum(sizes)}
            test.update(statistic_name="Friedman_chi_square", null={"parameter":"repeated_condition_distributions_equal", "value":True})
            test["configuration"].update(reference_distribution="within-block tie-corrected asymptotic chi-square", pairing=alignment,
                                          input_relationship="same units across conditions; independent blocks require separate design evidence")
            test["limitations"].append("Within-unit repeated observations are paired, not independent samples. Block independence, correct correspondence and the repeated-condition comparison require design evidence; order alone cannot establish them.")
            if n <= 10 or len(samples) <= 6:
                test["warnings"].append("The usual chi-square approximation is particularly limited with ten or fewer blocks or six or fewer conditions; no exact/permutation alternative is silently substituted")
            if n < 2 or np.all(np.ptp(np.column_stack(samples), axis=1) == 0):
                _uncomputable(test, "Fewer than two repeated units or no within-unit condition variation leaves a degenerate Friedman comparison")
            else:
                _finish(test, _native(test, lambda:stats.friedmanchisquare(*samples, nan_policy="raise")))
        return report

    if y is None:
        raise ValueError("This procedure requires two explicit samples x and y")
    first, second = _vector(x, "x"), _vector(y, "y")
    if len(first)+len(second) > MAX_OBSERVATIONS:
        raise ValueError("Combined supplied observations exceed the local bound")
    test["groups"] = [_summary(first, "x"), _summary(second, "y")]
    if method == "mann_whitney":
        report["sample_sizes"] = {"n":int(len(first)+len(second)), "n_x":int(len(first)), "n_y":int(len(second))}
        test.update(statistic_name="Mann_Whitney_U_x", null={"parameter":"underlying_x_y_distributions_equal", "value":True}, effect=_effect("P_X_greater_than_Y_plus_half_tie_probability"))
        test["configuration"].update(p_value_method="asymptotic", continuity_correction=True, tie_correction=True,
                                      effect_definition="U_x/(n_x*n_y) = observed P(X>Y) + 0.5*P(X=Y)")
        test["limitations"].extend(["Two independent sampling groups are required; array membership alone does not establish independence.",
                                    "The null compares underlying distributions, not automatically just medians. A location interpretation needs additional shape/scale conditions. The probability-of-superiority estimate is descriptive, with no interval implemented.",
                                    "Tie-corrected asymptotic inference with continuity correction was fixed in advance; no data-dependent switch to an exact test is made."])
        if min(len(first), len(second)) < 8:
            test["warnings"].append("At least one independent sample has fewer than eight observations; the fixed asymptotic approximation can be poor")
        if not len(first) or not len(second):
            _uncomputable(test, "Both independent samples need observations")
        elif np.ptp(np.r_[first, second]) == 0:
            test["statistic"] = len(first)*len(second)/2
            test["effect"]["estimate"] = .5
            _uncomputable(test, "All pooled values are tied: asymptotic rank variance is zero; descriptive half-tie superiority does not supply an informative test")
        elif _finish(test, _native(test, lambda:stats.mannwhitneyu(first, second, alternative="two-sided", method="asymptotic", use_continuity=True, nan_policy="raise"))):
            test["effect"]["estimate"] = test["statistic"]/(len(first)*len(second))
            pooled = np.r_[first, second]
            test["configuration"]["tied_observations_beyond_unique_values"] = int(len(pooled)-len(np.unique(pooled)))
        return report

    if len(first) != len(second):
        raise ValueError("Paired/correlation samples must have the same number of observations")
    alignment = _aligned([x, y]); n = len(first)
    report["sample_sizes"] = {"n":int(n), "n_x":int(n), "n_y":int(n)}
    test["configuration"]["pairing"] = alignment
    if method == "wilcoxon_signed_rank":
        difference = first-second-null
        nonzero = difference[difference != 0]; count = len(nonzero); zeros = n-count
        report["sample_sizes"]["nonzero_pairs"] = int(count)
        test["groups"].append(_summary(difference, "paired_x_minus_y_minus_null"))
        test.update(statistic_name="Wilcoxon_min_signed_rank_sum", null={"parameter":"center_of_symmetric_paired_difference_distribution", "value":null}, effect=_effect("matched_pairs_rank_biserial_relative_to_null"))
        test["configuration"].update(p_value_method="approx", zero_method="wilcox", continuity_correction=True,
            zero_difference_count=int(zeros), effect_definition="(positive rank sum - negative rank sum) / total nonzero absolute-difference rank sum",
            effect_reference="ranks of x-y-null_value; zero differences excluded by the declared wilcox convention", automatic_rounding=False)
        test["limitations"].extend([
            "The signed-rank null requires an appropriate symmetric distribution of paired differences about the stated value, not merely equality of arbitrary paired medians.",
            "The fixed normal approximation uses wilcox zero handling and continuity correction. Zero differences are explicitly excluded from its ranks, not silently deleted from original sample summaries; ties affect its reference variance.",
            "Subtracting floating-point paired values can create artificial near-ties. No automatic rounding is applied; any scientifically justified precision decision belongs to a reviewed analysis plan.",
            "The matched-pairs rank-biserial effect is descriptive relative to the specified null; its confidence interval is unimplemented."])
        if count < 20:
            test["warnings"].append("Fewer than twenty nonzero paired differences; the fixed normal approximation may be unreliable")
        if zeros:
            test["warnings"].append(str(zeros)+" of "+str(n)+" paired differences equal the null and are excluded from ranks by zero_method='wilcox'")
        if count:
            ranks = stats.rankdata(np.abs(nonzero), method="average")
            positive = float(ranks[nonzero > 0].sum()); negative = float(ranks[nonzero < 0].sum())
            test["configuration"].update(positive_rank_sum=positive, negative_rank_sum=negative,
                tied_absolute_differences_beyond_unique_values=int(count-len(np.unique(np.abs(nonzero)))))
            test["effect"]["estimate"] = (positive-negative)/(positive+negative)
            _finish(test, _native(test, lambda:stats.wilcoxon(difference, zero_method="wilcox", correction=True, alternative="two-sided", method="approx", nan_policy="raise")))
        else:
            _uncomputable(test, "No nonzero paired differences remain under the declared zero convention; no signed-rank statistic, p-value or rank effect is invented")
        return report

    pearson = method == "pearson_correlation"
    test.update(statistic_name="Pearson_r" if pearson else "Spearman_rho",
                null={"parameter":"population_Pearson_correlation" if pearson else "population_Spearman_rank_correlation", "value":0.0},
                effect=_effect("Pearson_r" if pearson else "Spearman_rho"))
    test["degrees_of_freedom"] = int(n-2) if n >= 2 else None
    test["limitations"].append("Pairs represent joint observations; their identity, sampling, repeated-unit dependence and scientific meaning require independent evidence. Correlation does not establish a causal effect.")
    if pearson:
        test["configuration"].update(p_value_method="SciPy default exact beta distribution under the independent bivariate-normal zero-correlation null", confidence_interval_method="native Fisher z transform when n>3")
        test["limitations"].append("The Pearson p-value uses its zero-correlation reference distribution under independent bivariate-normal sampling. The Fisher-transform interval is approximate and needs appropriate sampling; normal features are not a universal requirement for other procedures.")
    else:
        test["configuration"].update(p_value_method="SciPy asymptotic t approximation; no permutation/exact method", rank_tie_method="average ranks", confidence_interval_method="not_implemented")
        test["limitations"].append("Spearman measures monotonic rank association. Its p-value is an asymptotic approximation, not an exact small-sample or distribution-free guarantee; no confidence interval is implemented.")
        if n <= 500:
            test["warnings"].append("Spearman's asymptotic p-value can be inaccurate with 500 or fewer observations; a prespecified permutation design is not implemented here")
    if n < 2 or np.ptp(first) == 0 or np.ptp(second) == 0:
        _uncomputable(test, "Fewer than two pairs or a constant input makes the requested correlation undefined")
        return report
    result = _native(test, lambda:stats.pearsonr(first, second, alternative="two-sided") if pearson else stats.spearmanr(first, second, alternative="two-sided", nan_policy="raise"))
    if _finish(test, result):
        test["effect"]["estimate"] = test["statistic"]
        if pearson and n > 3:
            interval = result.confidence_interval(confidence_level=confidence)
            if math.isfinite(float(interval.low)) and math.isfinite(float(interval.high)):
                test["effect"]["confidence_interval"] = {"level":confidence, "lower":float(interval.low), "upper":float(interval.high), "method":"native Fisher z transform (approximate)"}
            else:
                test["warnings"].append("Native Fisher interval is nonfinite; no finite interval was substituted")
        elif pearson:
            test["limitations"].append("Fisher-transform confidence interval is unimplemented for n<=3 because its usual standard error needs n>3; no artificial narrow interval is supplied.")
    elif result is not None and math.isfinite(float(result.statistic)):
        test["effect"]["estimate"] = float(result.statistic)
    return report
