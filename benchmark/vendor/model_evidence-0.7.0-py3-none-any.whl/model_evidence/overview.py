"""Offline coordinated result/check views from bounded aggregate evidence.

No model calls, selection, repair, remote assets or raw row pairs are used here.
Computed is a calculation status, never an assumption-pass label.
"""
from html import escape
import csv
import io
import json
import textwrap

import numpy as np
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib import rc_context
from matplotlib.text import Text

from .model_visuals import validate_visual_evidence


def _text(value, width=64):
    return "\n".join(textwrap.wrap(str(value), width=width))


def _draw(ax, panel, compact=False, interval=None):
    data=panel['data']; kind=panel['kind']
    ax.set_title(_text(panel['title'][:180],55)+f"\n{panel['role']} | n={panel['n']} | {panel['source_split']}", fontsize=10, loc='left')
    if interval is not None:
        point,low,high,level,units,null=interval
        ax.plot([low,high],[0,0],color='#246b85',linewidth=3)
        ax.plot([point],[0],marker='o',color='#17364b',markersize=7)
        ax.plot([low,low],[-.10,.10],color='#246b85');ax.plot([high,high],[-.10,.10],color='#246b85')
        ax.set_ylim(-.5,.5);ax.set_yticks([])
        ax.set_title(_text(panel['title'][:140],55)+f"\n{100*level:g}% conditional interval | n={panel['n']} | {panel['source_split']}",fontsize=10,loc='left')
        ax.set_xlabel(_text(units,55),fontsize=8);ax.set_ylabel('One estimated effect',fontsize=8)
        if type(null) in {int,float}:
            ax.axvline(null,color='#986000',linestyle='--',linewidth=1,label='Specified null: '+format(null,'.5g'))
            ax.legend(fontsize=7,loc='upper right')
    elif kind=='hist1d':
        edges=np.asarray(data['edges']);ax.bar(edges[:-1],data['counts'],width=np.diff(edges),align='edge',color='#246b85',edgecolor='white')
    elif kind=='hist2d':
        mesh=ax.pcolormesh(data['x_edges'],data['y_edges'],np.asarray(data['counts']).T,cmap='Blues',shading='flat')
        ax.figure.colorbar(mesh,ax=ax,label='Observations per cell',shrink=.75)
    elif kind=='curve':
        if panel['id'] in {'kaplan_meier_points','survival_risk_set'}:ax.scatter(data['x'],data['y'],color='#246b85',s=16)
        else:ax.plot(data['x'],data['y'],color='#246b85',linewidth=1.8)
    elif kind=='bars':
        pos=np.arange(len(data['labels']));ax.bar(pos,data['values'],color='#246b85')
        ax.set_xticks(pos, [_text(label[:80],20) for label in data['labels']],rotation=35,ha='right',fontsize=7)
    elif kind=='matrix':
        values=np.asarray(data['values']);mesh=ax.imshow(values,aspect='auto',cmap='Blues')
        ax.figure.colorbar(mesh,ax=ax,label=panel['units'],shrink=.75)
        ax.set_xticks(range(len(data['labels']['columns'])),[_text(label[:80],20) for label in data['labels']['columns']],rotation=40,ha='right',fontsize=7)
        ax.set_yticks(range(len(data['labels']['rows'])),[_text(label[:80],20) for label in data['labels']['rows']],fontsize=7)
        if values.size<=36:
            for (i,j),value in np.ndenumerate(values):ax.text(j,i,format(float(value),'.3g'),ha='center',va='center',fontsize=8,color='black',bbox={'facecolor':'white','alpha':.65,'edgecolor':'none','pad':1})
    else:
        ax.axis('off');ax.text(.01,.8,_text(data['message'][:600],54),transform=ax.transAxes,va='top',fontsize=10)
    if kind!='status' and interval is None:
        ax.set_xlabel(_text(panel['axes']['x'][:180],55),fontsize=8);ax.set_ylabel(_text(panel['axes']['y'][:180],55),fontsize=8);ax.tick_params(labelsize=7)
    if not compact:
        ax.text(0,-.40,_text(('Comparison: '+panel['comparison']+' | Threshold/config: '+str(panel['threshold'])+' | '+panel['interpretation'])[:1000],100),transform=ax.transAxes,va='top',fontsize=8)


def _export(fig, description, png=False):
    out=io.BytesIO()
    for item in fig.findobj(Text):
        item.set_usetex(False);item.set_parse_math(False)
    with rc_context({'svg.hashsalt':'model-evidence-overview-0.5','svg.fonttype':'none','text.usetex':False,'text.parse_math':False}):
        fig.savefig(out,format='png' if png else 'svg',dpi=120,metadata={'Software':'Model Evidence'} if png else {'Description':description,'Date':None},bbox_inches='tight')
    return out.getvalue() if png else out.getvalue().decode('utf-8')


def _csv_cell(value):
    if isinstance(value,(int,float)):return value
    text=str(value)
    return "'"+text if text.startswith(('=','+','-','@','\t','\r')) else text


def _coherence(report, evidence):
    """Reject contradictions for direct values retained in the core result.

    This verifies arithmetic identity, not authentication or raw-data provenance.
    Binned distributions cannot be reconstructed from the retained summaries.
    """
    estimates=report.get('estimates',{});detail=estimates.get('statistical_test');intervals={}
    provided=estimates.get('visual_evidence') is not None
    main_profiles={
        'ols':{'observed_predicted':'hist2d'},'prediction_regression':{'observed_predicted':'hist2d'},
        'poisson_glm':{'observed_predicted':'hist2d'},
        'logistic':{'confusion':'matrix','roc':'curve','precision_recall':'curve'},
        'prediction_classification':{'confusion':'matrix','roc':'curve','precision_recall':'curve'},
        'prediction_multiclass':{'confusion':'matrix','roc':'curve','precision_recall':'curve'},
        'pca':{'pca_variance':'bars'},'kmeans':{'cluster_sizes':'bars'},
        'hierarchical_clustering':{'cluster_sizes':'bars'},'dbscan':{'cluster_sizes':'bars'},
        'architecture_output_review':{'observed_predicted':'hist2d','confusion':'matrix','roc':'curve','precision_recall':'curve','reconstruction_metrics':'bars'},
        'arima':{'forecast_error_metrics':'bars'},
        'kaplan_meier':{'kaplan_meier_curve':'curve','kaplan_meier_points':'curve'},
        'gaussian_mixed_intercept':{'mixed_fixed_effects':'bars'},
        'causal_weighting':{'ipw_weighted_means':'bars'}}
    allowed={'conditional_result':'bars'} if detail is not None else main_profiles.get(report.get('method'),{})
    method=report.get('method')
    special={
        'arima':('forecast_error_metrics','bars') if 'mae' in estimates else None,
        'kaplan_meier':('kaplan_meier_points' if estimates.get('survival',{}).get('curve_projection',{}).get('display_style')=='native_points' else 'kaplan_meier_curve','curve') if estimates.get('survival',{}).get('curve_projection',{}).get('x') else None,
        'gaussian_mixed_intercept':('mixed_fixed_effects','bars') if estimates.get('mixed_model',{}).get('fixed_effects') else None,
        'causal_weighting':('ipw_weighted_means','bars') if estimates.get('ipw',{}).get('group_means') else None,
        'bayesian_posterior_review':('bayesian_unverified_posterior','status'),
    }
    if provided and special.get(method) is not None:
        expected_id,expected_kind=special[method];first=evidence['panels'][0]
        if (first['id'],first['kind'],first['role'])!=(expected_id,expected_kind,'main_result'):
            raise ValueError('Canonical method-specific main-result identity, kind and role must match the retained calculation')
    if provided and detail is not None:
        first=evidence['panels'][0]
        numeric=(detail.get('computational_status')=='computed' and (detail.get('effect',{}).get('estimate') is not None or detail.get('statistic') is not None))
        expected_kind='bars' if numeric else 'status'
        if first['id']!='conditional_result' or first['role']!='main_result' or first['kind']!=expected_kind:
            raise ValueError('Canonical statistical main-result identity, kind and role must match the core result')
    for panel in evidence['panels']:
        key=panel['id'];data=panel['data']
        if panel['role']=='main_result' and panel['kind']!='status' and allowed.get(key)!=panel['kind']:
            raise ValueError('Unsupported or renamed main-result visual profile; no custom direct result is inferred')
        if key in {'conditional_result','confusion','pca_variance','cluster_sizes'} and panel['kind'] not in {allowed.get(key),'status'}:
            raise ValueError('Canonical direct-result panel kind does not match this method')
        if key=='conditional_result' and panel['kind']=='bars':
            if not isinstance(detail,dict) or detail.get('computational_status')!='computed':
                raise ValueError('Conditional result panel lacks its computed core statistical result')
            effect=detail['effect'];point=effect.get('estimate');ci=effect.get('confidence_interval')
            if point is not None:
                labels=['effect estimate'];values=[point]
                if ci is not None:
                    labels+=['interval lower bound','interval upper bound'];values += [ci['lower'],ci['upper']]
                    intervals[key]=(point,ci['lower'],ci['upper'],ci['level'],effect['units'],detail.get('null',{}).get('value'))
            else:labels=['test statistic'];values=[detail['statistic']]
            if data!={'labels':labels,'values':values}:
                raise ValueError('Visual main result contradicts the core statistical effect, statistic or interval')
        if key=='confusion' and panel['kind']=='matrix':
            values=data['values'];matrix=estimates.get('confusion_matrix')
            if matrix is not None and values!=matrix:raise ValueError('Visual confusion counts contradict the core confusion matrix')
            accuracy=estimates.get('accuracy')
            if accuracy is not None and abs(sum(row[i] for i,row in enumerate(values))/panel['n']-accuracy)>1e-12:
                raise ValueError('Visual confusion counts contradict core accuracy')
        if key=='class_prevalence' and panel['kind']=='bars' and 'class_support' in estimates:
            if data['values']!=estimates['class_support']:raise ValueError('Visual class counts contradict core class support')
        if key=='pca_variance' and panel['kind']=='bars':
            expected=estimates.get('training_explained_variance_ratio',estimates.get('explained_variance_ratio'))
            if expected is not None:
                expected=expected if len(expected)<=32 else expected[:31]+[float(np.sum(expected[31:]))]
                if data['values']!=expected:raise ValueError('Visual PCA variance contradicts the retained fitted variance ratios')
        if key=='cluster_sizes' and panel['kind']=='bars' and 'supplied_cluster_sizes' in estimates:
            if data['values']!=estimates['supplied_cluster_sizes']:raise ValueError('Visual cluster counts contradict retained supplied-row counts')
            if method in {'hierarchical_clustering','dbscan'} and data['labels']!=['noise (-1)' if v==-1 else 'cluster '+str(v) for v in estimates['supplied_cluster_ids']]:
                raise ValueError('Visual cluster/noise category labels contradict retained label identities')
        if key=='reconstruction_metrics' and panel['kind']=='bars':
            core=estimates.get('reconstruction',{})
            labels=['reconstruction MAE','reconstruction RMSE'];values=[core.get('mae'),core.get('rmse')]
            if 'baseline_mae' in core:
                labels+=['reference MAE','reference RMSE'];values += [core['baseline_mae'],core['baseline_rmse']]
            if data!={'labels':labels,'values':values} or panel['n']!=report['sample_sizes']['n']:
                raise ValueError('Reconstruction figure contradicts retained cell-weighted errors or row denominator')
        if key=='forecast_error_metrics' and panel['kind']=='bars':
            expected={'labels':['model MAE','model RMSE','reference MAE','reference RMSE'],'values':[estimates[k] for k in ('mae','rmse','baseline_mae','baseline_rmse')]}
            if data!=expected:raise ValueError('Forecast figure contradicts the retained model/reference losses')
        if key in {'kaplan_meier_curve','kaplan_meier_points'} and panel['kind']=='curve':
            curve=estimates.get('survival',{}).get('curve_projection',{})
            if data!={'x':curve.get('x'),'y':curve.get('y')}:raise ValueError('Survival figure contradicts retained native curve projection')
        if key=='mixed_fixed_effects' and panel['kind']=='bars':
            rows=estimates.get('mixed_model',{}).get('fixed_effects',[])
            expected={'labels':[r['term'] for r in rows],'values':[r['estimate'] for r in rows]}
            if data!=expected:raise ValueError('Mixed-model figure contradicts retained native fixed-effect estimates')
        if key=='mixed_variances' and panel['kind']=='bars':
            native=estimates.get('mixed_model',{})
            expected={'labels':['random-intercept variance','residual variance'],'values':[native.get('random_intercept_variance'),native.get('residual_variance')]}
            if data!=expected:raise ValueError('Mixed-model variance figure contradicts retained native covariance/scale')
        if key=='ipw_weighted_means' and panel['kind']=='bars':
            means=estimates.get('ipw',{}).get('group_means',{})
            if data!={'labels':['Control','Treated'],'values':[means.get('control'),means.get('treated')]}:raise ValueError('Weighting figure contradicts retained weighted group means')
        if key=='forecast_interval_coverage' and panel['kind']=='bars':
            if data!={'labels':['observed coverage','native nominal level'],'values':[estimates.get('forecast_interval_coverage'),estimates.get('forecast_interval_level')]}:raise ValueError('Forecast coverage figure contradicts retained conditional coverage summaries')
    adapter=estimates.get('adapter',{})
    if isinstance(adapter,dict) and adapter.get('model_family')=='feedforward_mlp' and provided:
        from .neural_visuals import neural_training_visual_evidence
        expected=neural_training_visual_evidence(adapter)
        actual={p['id']:p for p in evidence['panels']}
        for panel in expected['panels']:
            if actual.get(panel['id'])!=panel:raise ValueError('MLP history figures contradict retained native training/internal-validation summaries')
    return intervals


def _compact_key(row):
    """Short figure labels; exact precision/configuration stays in HTML/CSV."""
    def show(value):
        if type(value) in {int,float}:return format(value,'.6g')
        if isinstance(value,list) and all(type(v) in {int,float} for v in value):return '['+', '.join(format(v,'.6g') for v in value)+']'
        return str(value)[:120]
    result=row['label'][:140]+': '+show(row['original'])+' '+row['units'][:120]
    if row.get('revised') is not None:result+='; reference/revised='+show(row['revised'])
    threshold=row.get('threshold')
    if isinstance(threshold,dict):
        level=threshold.get('level',threshold.get('confidence_level'))
        if level is not None:result+='; confidence='+format(100*level,'.6g')+'%'
        if 'alpha' in threshold:result+='; prespecified alpha='+show(threshold['alpha'])
    return result


def _table_rows(panel):
    data=panel['data']; kind=panel['kind']
    if kind=='hist1d':return [{'bin_lower':data['edges'][i],'bin_upper':data['edges'][i+1],'observations':v} for i,v in enumerate(data['counts'])]
    if kind=='hist2d':return [{'x_lower':data['x_edges'][i],'x_upper':data['x_edges'][i+1],'y_lower':data['y_edges'][j],'y_upper':data['y_edges'][j+1],'observations':v} for i,row in enumerate(data['counts']) for j,v in enumerate(row)]
    if kind=='curve':return [{'x':x,'y':y} for x,y in zip(data['x'],data['y'])]
    if kind=='bars':return [{'category':k,'value':v} for k,v in zip(data['labels'],data['values'])]
    if kind=='matrix':return [{'row':data['labels']['rows'][i],'column':data['labels']['columns'][j],'value':v} for i,row in enumerate(data['values']) for j,v in enumerate(row)]
    return [{'message':data['message']}]


def coordinated_artifacts(model):
    """Return flat export files and accessible HTML, validated before rendering."""
    evidence=model['report'].get('estimates',{}).get('visual_evidence')
    context=model['context'];rows=model['rows']
    if evidence is None:
        from .model_visuals import status_panel
        panel=status_panel('visual_unassessed','Numerical visual evidence not implemented',n=context.get('n') or 0,source_split='unknown',message='No compatible aggregate plotting payload was supplied for this report. Inspect the result table and every unresolved requirement; no numerical chart is fabricated.')
        evidence={'schema_version':'1.0.0','source_split':'unknown','n':context.get('n') or 0,'privacy':'aggregate_only_no_row_pairs','panels':[panel]}
    validate_visual_evidence(evidence)
    intervals=_coherence(model['report'],evidence)
    panels=evidence['panels'];files={};records=[];html=[]
    # First main results and first applicable checks appear simultaneously. All
    # remaining panels and exact values are retained below, never discarded.
    main=[p for p in panels if p['role']=='main_result']
    checks=[p for p in panels if p['role']!='main_result']
    selected=(main[:2]+checks[:max(0,4-len(main[:2]))])[:4]
    for p in panels:
        table=_table_rows(p);records.append({'panel':p,'values':table})
        fig=Figure(figsize=(8,5.8),layout='constrained');FigureCanvasAgg(fig)
        _draw(fig.subplots(),p,interval=intervals.get(p['id']));name='support-'+p['id']+'.svg';svg=_export(fig,json.dumps(p,sort_keys=True));files[name]=svg
        buf=io.StringIO(newline='');writer=csv.DictWriter(buf,fieldnames=list(table[0]),lineterminator='\n');writer.writeheader();writer.writerows({k:_csv_cell(v) for k,v in item.items()} for item in table)
        files['support-'+p['id']+'.csv']=buf.getvalue()
        label={'computed':'Calculated; assumptions still require review','not_checked':'Unresolved / not assessed','not_applicable':'Not applicable'}[p['status']]
        small='<p>'+escape(p['role']+' | '+label+f" | n={p['n']} | split={p['source_split']}")+'</p>'
        info='<p><strong>Comparison:</strong> '+escape(p['comparison'])+' <strong>Threshold/configuration:</strong> '+escape(str(p['threshold']))+'. Units: '+escape(p['units'])+'</p><p>'+escape(p['interpretation'])+'</p><p class="small">Limits: '+escape('; '.join(p['limitations']))+'</p>'
        heads=list(table[0]);value_table='<div class="table"><table><caption>Exact aggregate values: '+escape(p['title'])+'</caption><thead><tr>'+''.join('<th scope="col">'+escape(k)+'</th>' for k in heads)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+escape(str(v[k]))+'</td>' for k in heads)+'</tr>' for v in table)+'</tbody></table></div>'
        card='<article class="evidence-card" id="panel-'+p['id']+'"><h3>'+escape(p['title'])+'</h3>'+small+'<div class="panel-svg">'+svg+'</div>'+info+'<details><summary>Exact supporting values and exports</summary><a href="'+name+'">Full SVG</a> · <a href="support-'+p['id']+'.csv">Values CSV</a>'+value_table+'</details></article>'
        html.append((p['id'],card))
    fig=Figure(figsize=(14,12),layout='constrained');FigureCanvasAgg(fig);axes=fig.subplots(3,2).ravel()
    for ax,p in zip(axes,selected):_draw(ax,p,compact=True,interval=intervals.get(p['id']))
    for ax in axes[len(selected):4]:ax.axis('off')
    from .render import _key_rows,_display
    key=_key_rows(model)[0][:6]
    axes[4].axis('off');axes[4].set_title('Key values — full table in HTML/CSV',loc='left',fontsize=10)
    axes[4].text(0,.95,'\n\n'.join(_text(_compact_key(r),60) for r in key) or 'See the conditional results and evidence table.',va='top',fontsize=9)
    from .render import _priority_findings
    concern=_priority_findings(model)[:3]
    axes[5].axis('off');axes[5].set_title('Interpretation boundaries / next review',loc='left',fontsize=10)
    axes[5].text(0,.95,'\n\n'.join(_text(r['status_label']+': '+r['label']+'. '+str(r.get('remedy','Review the evidence.')),56) for r in concern) or 'Review all recorded conditions. No chart certifies assumptions.',va='top',fontsize=9)
    fig.suptitle(context['method']+' | purpose='+context['purpose']+' | split='+context['split']+' | n='+str(context.get('n'))+'\nMain results and supporting checks — aggregate views; full evidence retained offline',fontsize=13)
    files['overview.svg']=_export(fig,json.dumps({'context':context,'selected_panel_ids':[p['id'] for p in selected],'key_rows':key,'concerns':concern},sort_keys=True))
    files['overview.png']=_export(fig,'',png=True)
    files['visuals.json']=json.dumps({'context':context,'visual_evidence':evidence,'tables':records},indent=2,allow_nan=False)+'\n'
    ids={p['id'] for p in selected};first=''.join(card for ident,card in html if ident in ids);rest=''.join(card for ident,card in html if ident not in ids)
    section='<style>.overview-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.evidence-card{min-width:0;background:white;padding:16px;border:1px solid #b7cbd7}.evidence-card p{overflow-wrap:anywhere}.panel-svg svg{width:100%;height:auto;display:block}.overview-grid details{margin:8px 0;padding:5px}.overview-grid table{font-size:13px}@media(max-width:760px){main{padding:12px!important}.overview-grid{grid-template-columns:1fr}.evidence-card{padding:10px}}</style><section id="coordinated-overview"><h2>Main results and applicable checks together</h2><p>Each panel states its source split and denominator. Descriptive plots do not test assumptions. Calculated does not mean passed. Generic variable/class positions protect names; aggregates can still be sensitive. Up to four main/supporting panels appear here; all '+str(len(panels))+' supplied panels and every registry requirement remain below. Direct retained main-result values are cross-checked, but editable reports are not authenticated and binned plots cannot revalidate unseen source data.</p><p><a href="overview.svg">Overview SVG</a> · <a href="overview.png">Overview PNG</a> · <a href="visuals.json">All visual values JSON</a></p><div class="overview-grid">'+first+'</div>'+('<details><summary>All remaining method-specific figures and supporting values</summary><div class="overview-grid">'+rest+'</div></details>' if rest else '')+'</section>'
    return files,section
