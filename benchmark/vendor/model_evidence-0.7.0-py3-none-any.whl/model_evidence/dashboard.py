"""Optional explicitly launched dashboard for fixed synthetic diagnostic examples.

Only IPv4 loopback is supported. No file/data upload, model selection, arbitrary
code, user-source editing, external asset, or remote service is exposed. The DAG
editor shares this process's bounded in-memory state at /dag.
"""
from __future__ import annotations
import argparse
from copy import deepcopy
from importlib.resources import files
import json
import re
from urllib.parse import parse_qs,urlsplit

from .dag_editor import EditorServer,EditorHandler,MAX_BODY,_object
from .mcp_adapter import strict_json

PRESETS={"clean","problematic"}
PURPOSES={"prediction","association"}
PANEL_ID=re.compile(r"[a-z][a-z0-9_]{0,63}\Z")

def _build_data(preset,purpose,*,evaluation_contaminated,dag):
    from .dashboard_data import build_dashboard_data
    return build_dashboard_data(preset,purpose,evaluation_contaminated=evaluation_contaminated,dag=dag)

def _render_figure(data,panel_id,format):
    from .dashboard_data import render_panel_figure
    return render_panel_figure(data,panel_id,format=format)

def validate_options(value):
    _object(value,{"preset","purpose","evaluation_contaminated"})
    if not isinstance(value["preset"],str) or value["preset"] not in PRESETS:
        raise ValueError("Choose the clean or problematic fixed synthetic preset")
    if not isinstance(value["purpose"],str) or value["purpose"] not in PURPOSES:
        raise ValueError("Choose prediction or association; causal panels retain their explicit design purpose")
    if type(value["evaluation_contaminated"]) is not bool:
        raise ValueError("Evaluation contamination must be an explicit boolean declaration")
    return deepcopy(value)

class DashboardServer(EditorServer):
    def __init__(self,address=("127.0.0.1",0),state=None):
        super().__init__(address,state=state)
        self.RequestHandlerClass=DashboardHandler
        self.options={"preset":"clean","purpose":"prediction","evaluation_contaminated":False}
        self.dashboard_revision=0
        self._data_key=None; self._data=None; self._figures={}

    def dashboard_data(self):
        """Called under the inherited lock; graph changes refresh context only."""
        key=(self.options["preset"],self.options["purpose"],self.options["evaluation_contaminated"],
             json.dumps(self.state.graph,sort_keys=True,ensure_ascii=True,allow_nan=False))
        if key!=self._data_key:
            result=_build_data(**self.options,dag=deepcopy(self.state.graph))
            if not isinstance(result,dict) or not isinstance(result.get("panels"),list) or not isinstance(result.get("stages"),list):
                raise ValueError("Diagnostic provider returned an unsupported panel contract")
            self.dashboard_revision+=1
            result=deepcopy(result)
            result["evaluation_contaminated"]=self.options["evaluation_contaminated"]
            result["dashboard_context"]={"dashboard_revision":self.dashboard_revision,
                "graph_revision":self.state.revision,"graph_confirmation":self.state.graph["confirmation_status"],
                "graph_explanation":"Graph edits update conditional warnings; no causal effect is estimated or numerically adjusted by drawing arrows.",
                "controls":"Fixed synthetic presets are separate teaching examples, not holdout-driven model selection."}
            self._data=result; self._data_key=key; self._figures={}
        return deepcopy(self._data)

    def set_options(self,value):
        checked=validate_options(value)
        # Build before committing so an invalid provider result cannot corrupt state.
        previous=deepcopy(self.options)
        try:
            self.options=checked
            result=self.dashboard_data()
        except Exception:
            self.options=previous
            raise
        return result

    def figure(self,panel_id,format,revision):
        if not isinstance(panel_id,str) or not PANEL_ID.fullmatch(panel_id) or format not in {"svg","png"}:
            raise ValueError("Invalid bounded panel or image format")
        data=self.dashboard_data()
        if type(revision) is not int or revision!=self.dashboard_revision:
            raise ValueError("Stale dashboard view; refresh before requesting this figure")
        if panel_id not in {p.get("id") for p in data["panels"]}: raise ValueError("Unknown panel")
        key=(self.dashboard_revision,panel_id,format)
        if key not in self._figures:
            content=_render_figure(data,panel_id,format)
            if not isinstance(content,bytes) or len(content)>4_194_304: raise ValueError("Unsupported or oversized generated figure")
            self._figures[key]=content
        return self._figures[key]

class DashboardHandler(EditorHandler):
    def _figure_response(self,data,format):
        self.send_response(200)
        self.send_header("Content-Type","image/svg+xml" if format=="svg" else "image/png")
        self.send_header("Content-Length",str(len(data))); self.send_header("Cache-Control","no-store")
        self.send_header("X-Content-Type-Options","nosniff"); self.send_header("Referrer-Policy","no-referrer")
        self.send_header("Content-Security-Policy","default-src 'none'; sandbox")
        self.end_headers(); self.wfile.write(data)

    def do_GET(self):
        if not self._trusted(): self._send(403,{"error":"Local origin/host required"}); return
        url=urlsplit(self.path)
        if url.path=="/" and not url.query:
            html=files("model_evidence.resources").joinpath("dashboard.html").read_text(encoding="utf-8").replace("__EDITOR_TOKEN__",self.server.token)
            self._send(200,html,"text/html; charset=utf-8"); return
        if url.path=="/dag" and not url.query:
            html=files("model_evidence.resources").joinpath("dag_editor.html").read_text(encoding="utf-8").replace("__EDITOR_TOKEN__",self.server.token)
            html=html.replace("<body>",'<body><nav aria-label="Dashboard navigation" style="padding:12px 24px;background:#e0ecef"><a href="/">Return to diagnostic dashboard</a> · Graph edits invalidate prior confirmation and code-plan provenance.</nav>',1)
            self._send(200,html,"text/html; charset=utf-8"); return
        if url.path in {"/api/dashboard","/api/figure"}:
            if not self._trusted(token=True): self._send(403,{"error":"Local editor token required"}); return
            try:
                if url.path=="/api/dashboard":
                    if url.query: raise ValueError("Dashboard controls use only the bounded JSON endpoint")
                    with self.server.lock: result=self.server.dashboard_data()
                    self._send(200,result); return
                query=parse_qs(url.query,keep_blank_values=True,strict_parsing=True)
                if set(query)!={"panel","format","revision"} or any(len(v)!=1 for v in query.values()): raise ValueError("Only a known panel, format and revision may be requested")
                panel=query["panel"][0]; format=query["format"][0]; revision_text=query["revision"][0]
                if not revision_text.isascii() or not revision_text.isdigit() or len(revision_text)>10: raise ValueError("Invalid dashboard revision")
                with self.server.lock: data=self.server.figure(panel,format,int(revision_text))
                self._figure_response(data,format); return
            except (ValueError,TypeError,KeyError) as exc:
                self._send(400,{"error":str(exc)[:512]}); return
        super().do_GET()

    def do_POST(self):
        if self.path!="/api/dashboard": super().do_POST(); return
        if not self._trusted(token=True): self._send(403,{"error":"Local origin and editor token required"}); return
        if self.headers.get("Transfer-Encoding") is not None or self.headers.get("Content-Type","").split(";")[0]!="application/json":
            self._send(415,{"error":"Bounded JSON body required"}); return
        try:
            length=int(self.headers.get("Content-Length","-1"))
            if not 0<length<=4096: raise ValueError("Dashboard controls exceed the 4 KiB limit")
            request=strict_json(self.rfile.read(length),limit=4096)
            with self.server.lock: result=self.server.set_options(request)
        except (ValueError,TypeError,KeyError) as exc:
            self._send(400,{"error":str(exc)[:512]}); return
        self._send(200,result)

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument("--port",type=int,default=0)
    args=parser.parse_args(argv)
    if not 0<=args.port<=65535: parser.error("port must be 0..65535")
    with DashboardServer(("127.0.0.1",args.port)) as server:
        print("Model Evidence local diagnostic dashboard: "+server.origin,flush=True)
        print("Fixed synthetic examples; DAG editor at /dag. Loopback only. Ctrl+C stops the server.",flush=True)
        try: server.serve_forever()
        except KeyboardInterrupt: pass

if __name__=="__main__": main()
