"""Bounded DAG/specification to reviewable code plans; never execute or edit code.

Only a deliberately narrow assumed graph class is supported. A generated plan
is a conditional model-specification template, not a finding of identification,
an estimator certificate, or permission to reuse previous numerical results.
"""
from copy import deepcopy
import difflib
import hashlib
import json
import keyword
import re

from ._version import VERSION
SCHEMA_VERSION = "1.0.0"
SPEC_FIELDS = {"schema_version", "design", "estimator", "exposure", "outcome", "outcome_role",
    "estimand", "effect_type", "treatment_type", "outcome_type", "adjustment_set"}
REQUIRED_SPEC = SPEC_FIELDS - {"schema_version"}
IDENTIFIER = re.compile(r"[A-Za-z][A-Za-z0-9_]{0,47}\Z")
R_RESERVED = {"if", "else", "repeat", "while", "function", "for", "in", "next", "break",
    "TRUE", "FALSE", "NULL", "Inf", "NaN", "NA", "NA_integer_", "NA_real_", "NA_complex_", "NA_character_"}
SUPPORTED = {"design":"observational_adjustment", "estimator":"ols", "outcome_role":"analysis_outcome",
    "estimand":"ATE", "effect_type":"total", "treatment_type":"binary", "outcome_type":"continuous"}
PLAN_FIELDS = {"schema_version", "library_version", "status", "supported_case", "dag", "old_spec", "new_spec",
    "adjustment_change", "formulas", "code", "change_reasons", "unresolved_assumptions", "tests_to_rerun",
    "lineage", "result_state", "permissions", "limitations"}
LIMITATIONS = [
    "The graph is assumed and human-attested, not verified by drawing arrows or by diagnostics.",
    "Only fully observed pre-treatment simple common-cause forks Z->T, Z->Y with T->Y, total ATE, binary exposure, continuous outcome, and additive unpenalized OLS are supported.",
    "This is a graph-conditional model template. It does not establish identification, exchangeability, estimator correctness, or causal validity.",
    "No generalized backdoor, d-separation, mediation, matching, weighting, DiD, RD, IV, or direct-effect identification algorithm is implemented.",
    "No user source is read, modified, written, or executed. The caller reviews the complete diff and decides whether to run it locally.",
    "Old numerical estimates are never imported or reused; graph or specification changes require a new analysis and new evidence.",
    "Human confirmation cannot override failed numerical checks. R code generation does not imply R DAG API parity.",
    "Graphs, variable names, code and provenance can be sensitive; this plan is local data and is not exposed by default MCP tools.",
]
UNRESOLVED = [
    "Substantive correctness and completeness of the assumed DAG; unmeasured confounding and plausible alternative DAGs remain matters for review.",
    "Consistency, interference, measurement, temporality, selection/missingness and population scope require actual study evidence.",
    "Population positivity is not established by the graph or observed overlap.",
    "The additive linear outcome model and constant treatment contrast must suit the stated ATE; nonlinearity, interactions and effect heterogeneity are not handled by this template.",
    "Dependence, uncertainty, sampling and fitted diagnostic failures require review; the template deliberately requests association diagnostics rather than a causal-effect claim.",
]
RERUN = [
    "Review and explicitly confirm the new DAG revision and analysis specification before using this plan.",
    "Recheck grain, target measurement, feature/covariate timing, selection/missingness and leakage on the actual study data.",
    "Refit the outcome model from the intended analysis data; never reuse the old coefficient or uncertainty results.",
    "Rerun balance/overlap comparisons for the selected pre-treatment covariates, with actual treatment-arm denominators and weights where applicable.",
    "Rerun OLS rank, condition, residual, influence, dependence and model-specification checks; review uncertainty appropriate to the design.",
    "Repeat prespecified alternative-DAG and sensitivity assessments without outcome-driven variable selection.",
    "For a future matching/weighting workflow, refit the propensity/matching model and rerun balance, overlap, effective sample size, effect estimation and uncertainty after any covariate change; this release generates no such estimator code.",
    "Record new graph/spec/code fingerprints and newly executed evidence; confirmation by itself does not mark results current.",
]

def _identifier(value):
    if not isinstance(value,str) or not IDENTIFIER.fullmatch(value) or keyword.iskeyword(value) or value in R_RESERVED:
        raise ValueError("Variable names must be bounded identifiers valid in both Python and R; source code is not accepted")
    return value

def _spec(spec):
    if not isinstance(spec,dict) or not REQUIRED_SPEC <= set(spec) or set(spec)-SPEC_FIELDS:
        raise ValueError("Analysis specification fields are missing or unknown")
    result=deepcopy(spec); result.setdefault("schema_version",SCHEMA_VERSION)
    if result["schema_version"]!=SCHEMA_VERSION: raise ValueError("Unknown analysis specification version")
    for field in SPEC_FIELDS-{"schema_version","adjustment_set"}:
        if not isinstance(result[field],str) or not result[field] or len(result[field])>80: raise ValueError("Invalid bounded analysis specification text")
    _identifier(result["exposure"]); _identifier(result["outcome"])
    if result["exposure"]==result["outcome"]: raise ValueError("Exposure and outcome must differ")
    values=result["adjustment_set"]
    if not isinstance(values,list) or len(values)>32: raise ValueError("Adjustment set must be a bounded identifier list")
    for value in values: _identifier(value)
    if len(set(values))!=len(values): raise ValueError("Duplicate adjustment variable")
    if {result["exposure"],result["outcome"]}&set(values): raise ValueError("Exposure and outcome cannot be adjustment covariates")
    result["adjustment_set"]=sorted(values)
    return result

def _canonical(value):
    return json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=True,allow_nan=False)

def _fingerprint(value):
    return hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()

def _graph_semantics(dag):
    return {"nodes":sorted(dag["nodes"],key=lambda n:n["name"]), "edges":sorted(dag["edges"]),
        "exposure":dag["exposure"],"outcome":dag["outcome"]}

def _descendants(edges,node):
    result=set(); pending=[node]
    while pending:
        current=pending.pop()
        for start,end in edges:
            if start==current and end not in result: result.add(end); pending.append(end)
    return result

def _graph_case(dag,new_spec):
    nodes={n["name"]:n for n in dag["nodes"]}; edges={tuple(e) for e in dag["edges"]}
    t=dag["exposure"]; y=dag["outcome"]; covariates=sorted(set(nodes)-{t,y}); reasons=[]
    if any(not n["observed"] for n in nodes.values()):
        reasons.append("An unobserved node is present; this narrow generator cannot resolve latent confounding or justify a covariate-only fix.")
    descendants=_descendants(edges,t)
    incoming={name:{start for start,end in edges if end==name} for name in nodes}
    for value in new_spec["adjustment_set"]:
        if value not in nodes:
            reasons.append("Proposed adjustment variable "+value+" is not in the supplied DAG."); continue
        if value in descendants:
            reasons.append("Proposed adjustment "+value+" is a treatment descendant; it may block part of a total effect or induce bias.")
        if len(incoming[value])>=2:
            reasons.append("Proposed adjustment "+value+" is a structural collider in the assumed graph; conditioning can open a path.")
        if nodes[value]["timing"]!="pre_treatment":
            reasons.append("Proposed adjustment "+value+" is not explicitly pre-treatment.")
    expected={(t,y)}|{(z,t) for z in covariates}|{(z,y) for z in covariates}
    if edges!=expected:
        reasons.append("The supplied graph is outside the supported simple-fork class; no generalized identification or direct-effect correction is attempted.")
    if any(nodes[z]["timing"]!="pre_treatment" for z in covariates):
        reasons.append("Every common cause in the supported class must be explicitly pre-treatment.")
    if set(new_spec["adjustment_set"])!=set(covariates):
        reasons.append("For this supported simple-fork class the new adjustment set must be exactly the observed pre-treatment common causes: "+(", ".join(covariates) or "none")+".")
    return covariates,list(dict.fromkeys(reasons))

def _formula(spec):
    return spec["outcome"]+" ~ "+" + ".join([spec["exposure"]]+spec["adjustment_set"])

def _code(spec,language):
    x=[spec["exposure"]]+spec["adjustment_set"]; y=spec["outcome"]; cols=x+[y]
    if language=="python":
        return ("# Review-only template for an existing pandas DataFrame named df.\n"
            "# Assumed DAG and analysis specification must be confirmed separately.\n"
            "# Refits model diagnostics; does not establish a causal effect or execute here.\n"
            "from model_evidence import audit_ols\n"
            f"required_columns = {cols!r}\n"
            "analysis = df.loc[:, required_columns]\n"
            f"X = analysis[{x!r}].to_numpy(dtype=float)\n"
            f"y = analysis[{y!r}].to_numpy(dtype=float)\n"
            'report = audit_ols(X, y, purpose="association")\n'
            "# Review all diagnostics and fresh design evidence; do not label coefficients causal.\n")
    quote=lambda values:"c("+", ".join(json.dumps(v) for v in values)+")"
    return ("# Review-only template for an existing data.frame named df.\n"
        "# Assumed DAG and analysis specification must be confirmed separately.\n"
        "# Refits model diagnostics; does not establish a causal effect or execute here.\n"
        "library(modelevidence)\n"
        f"required_columns <- {quote(cols)}\n"
        "analysis <- df[, required_columns, drop = FALSE]\n"
        f"X <- as.matrix(analysis[, {quote(x)}, drop = FALSE])\n"
        f"y <- analysis[[{json.dumps(y)}]]\n"
        'report <- audit_ols(X, y, purpose = "association")\n'
        "# Review all diagnostics and fresh design evidence; do not label coefficients causal.\n")

def generate_code_plan(dag,old_spec,new_spec,*,prior_plan=None):
    """Return a deterministic, non-executing Python/R code correction plan.

    Unsupported graphs/designs return no code. An explicitly confirmed graph
    permits only a conditional template; actual results remain stale/unexecuted.
    """
    from .dag import validate_assumed_dag,assess_assumed_dag
    graph=validate_assumed_dag(dag); assessment=assess_assumed_dag(graph)
    old=_spec(old_spec); new=_spec(new_spec)
    for node in graph["nodes"]: _identifier(node["name"])
    blockers=[]
    for field,expected in SUPPORTED.items():
        if old[field]!=expected or new[field]!=expected: blockers.append("Unsupported "+field+": only "+expected+" is implemented for code generation.")
    if old["exposure"]!=graph["exposure"] or new["exposure"]!=graph["exposure"] or old["outcome"]!=graph["outcome"] or new["outcome"]!=graph["outcome"]:
        blockers.append("Graph and analysis exposure/outcome must match; changing the scientific question requires separate review.")
    covariates,graph_blockers=_graph_case(graph,new); blockers.extend(graph_blockers)
    unknown_old=set(old["adjustment_set"])-{node["name"] for node in graph["nodes"]}
    if unknown_old: blockers.append("The old adjustment set contains variables absent from the supplied graph.")
    confirmed=assessment.get("status")=="assumed_confirmed"
    if assessment.get("status")=="unresolved":
        blockers.append("The assumed DAG assessment is unresolved; review timing, rejection or revision consistency before any conditional code correction. Confirmation alone cannot resolve missing graph facts.")
    if blockers: status="no_supported_correction"
    elif not confirmed: status="needs_confirmation"
    else: status="supported_conditional_template"
    changes={"before":old["adjustment_set"],"after":new["adjustment_set"],
        "added":sorted(set(new["adjustment_set"])-set(old["adjustment_set"])),"removed":sorted(set(old["adjustment_set"])-set(new["adjustment_set"]))}
    graph_fp=_fingerprint(_graph_semantics(graph)); old_fp=_fingerprint(old); new_fp=_fingerprint(new)
    prior_id=None; changed_from_prior=False
    if prior_plan is not None:
        checked=validate_code_plan(prior_plan); prior_id=checked["lineage"]["plan_id"]
        changed_from_prior=checked["lineage"]["graph_fingerprint"]!=graph_fp or checked["lineage"]["new_spec_fingerprint"]!=new_fp
    changed=old_fp!=new_fp or changed_from_prior
    reasons=list(blockers)
    if not confirmed:
        reasons.append("The assumed DAG needs resolved graph metadata and an explicit current human confirmation; no graph-conditional code is supplied before that review.")
        reasons.extend(assessment.get("warnings",[]))
    if status=="supported_conditional_template":
        for z in covariates: reasons.append(f"Under the confirmed assumed graph, {z}->{graph['exposure']} and {z}->{graph['outcome']} form the simple common-cause path {graph['exposure']}<-{z}->{graph['outcome']}; include {z} for the specified total ATE template.")
        if not covariates: reasons.append("Under this restricted assumed graph no additional common cause is represented; this absence is an assumption, not evidence of no confounding.")
        reasons.append("The old formula is shown for comparison only; it is not endorsed. The revised formula is graph-admissible only within the stated assumed class.")
    code={}; formulas={"before":_formula(old),"after":_formula(new)}
    if status=="supported_conditional_template":
        for language,extension in (("python","py"),("r","R")):
            before=_code(old,language); after=_code(new,language)
            diff="".join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile="before."+extension,tofile="after."+extension))
            code[language]={"before":before,"after":after,"diff":diff}
    lineage={"graph_fingerprint":graph_fp,"graph_provenance_fingerprint":_fingerprint(graph),"old_spec_fingerprint":old_fp,
        "new_spec_fingerprint":new_fp,"prior_plan_id":prior_id,"changed_from_prior":changed_from_prior,
        "graph_revision":graph.get("revision",0)}
    identity={"dag":graph,"old_spec":old,"new_spec":new,"prior_plan_id":prior_id}
    lineage["plan_id"]=_fingerprint(identity)
    result={"schema_version":SCHEMA_VERSION,"library_version":VERSION,"status":status,
        "supported_case":"simple_observed_pretreatment_forks_total_ATE_additive_OLS", "dag":graph,"old_spec":old,"new_spec":new,
        "adjustment_change":changes,"formulas":formulas,"code":code,"change_reasons":reasons,
        "unresolved_assumptions":list(UNRESOLVED),"tests_to_rerun":list(RERUN),"lineage":lineage,
        "result_state":{"status":"stale_requires_confirmation_and_rerun" if changed else "not_executed",
            "rerun_required":True,"old_estimates_reusable":False,"graph_confirmed":confirmed,
            "code_executed":False,"strong_causal_language":"blocked"},
        "permissions":{"writes_user_source":False,"executes_code":False,"imports_old_estimates":False},"limitations":list(LIMITATIONS)}
    return result

def validate_code_plan(plan):
    """Rebuild from bounded inputs; reject forged stored code/status/lineage."""
    if not isinstance(plan,dict) or set(plan)!=PLAN_FIELDS: raise ValueError("Invalid code-plan fields")
    if plan.get("schema_version")!=SCHEMA_VERSION or not isinstance(plan.get("library_version"),str) or plan.get("library_version") not in {"0.1.0","0.2.0","0.3.0","0.4.0","0.5.0","0.6.0",VERSION}: raise ValueError("Unknown code-plan version")
    # A parent pointer is provenance only. It cannot authorize code or results.
    lineage=plan.get("lineage")
    if not isinstance(lineage,dict): raise ValueError("Invalid code-plan lineage")
    prior_id=lineage.get("prior_plan_id")
    if prior_id is not None and (not isinstance(prior_id,str) or not re.fullmatch(r"[0-9a-f]{64}",prior_id)): raise ValueError("Invalid prior-plan identifier")
    rebuilt=generate_code_plan(plan.get("dag"),plan.get("old_spec"),plan.get("new_spec"))
    rebuilt["library_version"]=plan["library_version"]
    # Restore the recorded predecessor pointer, but independently recompute code,
    # the current graph/spec fingerprints, and the plan identifier.
    rebuilt["lineage"]["prior_plan_id"]=prior_id
    identity={"dag":rebuilt["dag"],"old_spec":rebuilt["old_spec"],"new_spec":rebuilt["new_spec"],"prior_plan_id":prior_id}
    rebuilt["lineage"]["plan_id"]=_fingerprint(identity)
    # changed_from_prior is an unsigned history declaration, never a freshness gate.
    if type(lineage.get("changed_from_prior")) is not bool: raise ValueError("Invalid lineage change flag")
    rebuilt["lineage"]["changed_from_prior"]=lineage["changed_from_prior"]
    if lineage["changed_from_prior"]: rebuilt["result_state"]["status"]="stale_requires_confirmation_and_rerun"
    try: matches=_canonical(rebuilt)==_canonical(plan)
    except (TypeError,OverflowError,RecursionError) as exc: raise ValueError("Code plan must contain bounded JSON data") from exc
    if not matches: raise ValueError("Code-plan content or lineage was modified; regenerate from the reviewed inputs")
    return rebuilt

def code_plan_to_json(plan):
    return json.dumps(validate_code_plan(plan),indent=2,ensure_ascii=True,allow_nan=False)+"\n"

def code_plan_freshness(plan,dag,spec):
    """Check code provenance, never declare numerical results executed/current."""
    from .dag import validate_assumed_dag,assess_assumed_dag
    checked=validate_code_plan(plan); graph=validate_assumed_dag(dag); current_spec=_spec(spec)
    current=(checked["lineage"]["graph_fingerprint"]==_fingerprint(_graph_semantics(graph))
        and checked["lineage"]["graph_provenance_fingerprint"]==_fingerprint(graph)
        and checked["lineage"]["new_spec_fingerprint"]==_fingerprint(current_spec)
        and assess_assumed_dag(graph).get("status")=="assumed_confirmed")
    return {"code_plan_current":current,"numerical_results":"not_executed" if current else "stale",
        "rerun_required":True,"old_estimates_reusable":False}

def explain_code_plan(plan):
    plan=validate_code_plan(plan)
    before=", ".join(plan["adjustment_change"]["before"]) or "none"
    after=", ".join(plan["adjustment_change"]["after"]) or "none"
    return (f"Code-plan status: {plan['status']}. Proposed adjustment changes from {before} to {after}; "
        f"formula changes from {plan['formulas']['before']} to {plan['formulas']['after']}. "
        +" ".join(plan["change_reasons"])+" Previous numerical results are stale or unexecuted and cannot be reused. "
        "No code was executed or source overwritten. The graph is assumed, not verified; causal interpretation and estimator correctness remain unresolved.")
