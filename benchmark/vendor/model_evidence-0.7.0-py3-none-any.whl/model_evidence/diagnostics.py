"""Small executable adapters. Heuristic screens are evidence, not assumption proofs."""
import math
import warnings
import numpy as np
from scipy import stats
from scipy.optimize import linprog
from sklearn.exceptions import ConvergenceWarning
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, average_precision_score, brier_score_loss,
    log_loss, mean_absolute_error, mean_squared_error, r2_score, roc_auc_score, silhouette_score)
from .registry import describe_requirements, load_registry
from .report import MANUAL, evidence, make_report
from . import model_visuals as _visuals

MAX_CELLS=2_000_000
RATIONALE={
 "missingness":"Any nonfinite supplied value prevents these unmodified numeric adapters; sentinel codes need separate review.",
 "target_compatibility":"Target support must match the declared task before computing model-specific quantities.",
 "duplicate_entities":"Compare repeated IDs to zero at supplied row grain; repetition may be legitimate but needs grouped design.",
 "timing":"Features must be available no later than the prediction cutoff; metadata accuracy remains assumed.",
 "split_integrity":"Training/evaluation positions and supplied entity groups must not cross; temporal strategy requires strict forward order.",
 "time_order":"Strictly later evaluation with the caller's gap avoids direct ordering violations; label windows need separate review.",
 "identifiability":"Full column rank is necessary for unique unpenalized coefficients; 1e8 condition cutoff is an illustrative numerical screen.",
 "influence":"Cook 4/n is an exploratory inspection threshold, not a deletion rule.",
 "error_structure":"Studentized auxiliary-regression n*R2 uses a chi-square approximation at alpha .05; non-rejection is not proof.",
 "residual_shape":"Shapiro-Wilk alpha .05 is an illustrative shape screen; estimated residuals are dependent and the test is not an OLS prediction requirement.",
 "event_information":"Minority class events per parameter below 10 prompts review; this is not a universal sample-size rule.",
 "separation":"Feasibility of signed linear margins identifies complete/quasi separation within numerical tolerance; diagnostic columns alone are standardized.",
 "convergence":"Compare solver flag/iterations with fixed stopping configuration; convergence is not model validity.",
 "calibration":"Fixed ten-bin reliability is descriptive; n<100 or smaller class<20 warns about sparse estimates, not calibration failure.",
 "discrimination":"Compare ranked predictions with observed binary outcomes; AUC and AP do not measure causal effects or calibration.",
 "reference_baseline":"Compare supplied model and prespecified training-derived reference on identical rows using RMSE or accuracy.",
 "distance_geometry":"Constant columns and scale ratio above100 prompt inspection of chosen Euclidean geometry; no universal suitability criterion.",
 "cluster_stability":"Internal compactness/separation is not stability; independent resampling/domain evidence remains required."
}

def _visual_bundle(n, source_split, panels):
    """Compose only already-computed aggregates under the collector contract."""
    payload={"schema_version":_visuals.SCHEMA_VERSION,"source_split":source_split,
             "n":int(n),"privacy":_visuals.PRIVACY,"panels":panels}
    _visuals.validate_visual_evidence(payload)
    return payload


def _unavailable_visual(n, source_split, message, identifier="visual_unavailable"):
    return _visual_bundle(n,source_split,[_visuals.status_panel(identifier,
        "Visual evidence not assessed",n=n,source_split=source_split,message=message,
        limitations=["No finite-looking chart or missing values were substituted; existing evidence statuses still govern interpretation.",
                     "Aggregate-only output does not guarantee anonymity or verify study design."])])


def _collect_visual(collector, *args, n, source_split, **kwargs):
    """A bounded-chart limitation must not replace an existing numerical audit."""
    try:
        return collector(*args,source_split=source_split,**kwargs)
    except (ValueError,OverflowError,FloatingPointError):
        return _unavailable_visual(n,source_split,
            "The available arrays do not meet this visual collector's finite-value, shape or display bounds. No observations were dropped and no chart data were invented.")


def _aggregate_bars(identifier,title,labels,values,n,source_split,*,role,units,comparison,interpretation,limitations):
    return {"id":identifier,"title":title,"kind":"bars","role":role,"requirement":None,
        "status":"computed","n":int(n),"source_split":source_split,"units":units,
        "comparison":comparison,"threshold":None,"interpretation":interpretation,
        "limitations":list(limitations),"data":{"labels":list(labels),"values":[float(v) for v in values]},
        "axes":{"x":"Positions in the supplied comparison","y":units}}


def _raw_pca_visual(X, estimates):
    n=len(X)
    if not np.isfinite(X).all():
        return _unavailable_visual(n,"unknown","PCA inputs contain nonfinite values; no variance or geometry chart was constructed.")
    panels=[]
    limits=["This low-level suitability audit computed singular values only; no fitted component coefficients or score transform is available.",
            "Variance fractions describe the supplied centered input representation; scientific meaning and prediction value are not established.",
            "Aggregates can still be sensitive; row records and original feature names are withheld from this visual payload."]
    if "explained_variance_ratio" in estimates:
        values=estimates["explained_variance_ratio"]; labels=["component "+str(i+1) for i in range(len(values))]
        if len(values)>32:
            values=values[:31]+[float(sum(values[31:]))]; labels=labels[:31]+["remaining component ratios summed"]
        panels.append(_aggregate_bars("pca_variance","Supplied centered variance fractions",labels,values,n,"unknown",role="main_result",
            units="fraction of supplied centered-input variance",comparison="Squared singular values divided by their supplied total; any bounded remainder explicitly summed",
            interpretation="Fractions summarize this supplied representation; no component-selection or scientific-factor claim follows.",limitations=limits))
    else:
        panels.append(_visuals.status_panel("pca_variance","PCA variance fractions",n=n,source_split="unknown",
            message="Total centered variance is zero or unavailable; no explained-variance ratios are invented.",limitations=limits))
    for identifier,title in [("pca_scores","PCA score geometry"),("pca_loadings","PCA component coefficients")]:
        panels.append(_visuals.status_panel(identifier,title,n=n,source_split="unknown",
            message="This suitability audit has no existing fitted scores/components. Pass an existing supported fitted PCA for native projection/loadings; no extra transform was run.",limitations=limits))
    return _visual_bundle(n,"unknown",panels)


def _raw_clustering_visual(X, labels):
    n,p=X.shape
    if not np.isfinite(X).all():
        return _unavailable_visual(n,"unknown","Clustering inputs contain nonfinite values; no numerical geometry chart was constructed.")
    limits=["Only supplied integer assignments and input coordinates are available; no fitted centers or clustering model are reconstructed.",
            "Cluster positions replace original labels. Descriptive geometry and counts do not establish natural groups, stability or useful cluster count.",
            "Supplied input axes are not assumed to be a fitted Pipeline's transformed axes; aggregates can still be sensitive."]
    panels=[]
    _,counts=np.unique(labels,return_counts=True); k=len(counts)
    if k<=32:
        panels.append(_aggregate_bars("cluster_sizes","Supplied partition sizes",["label position "+str(i+1) for i in range(k)],
            counts,n,"unknown",role="main_result",units="observations (counts)",comparison="Count per supplied label position; denominator all supplied rows",
            interpretation="Counts describe the supplied partition only; no cluster model was refitted or selected.",limitations=limits))
    else:
        panels.append(_visuals.status_panel("cluster_sizes","Supplied partition sizes",n=n,source_split="unknown",
            message="More than 32 labels exceed this bounded display; labels are not merged.",limitations=limits))
    if p>=2:
        try:
            panels.append(_visuals.histogram2d_panel("cluster_geometry","First-two-supplied-input geometry",X[:,0],X[:,1],
                role="descriptive",requirement=None,source_split="unknown",units="observations per count cell",
                axes={"x":"Supplied input position 1","y":"Supplied input position 2"},
                comparison="All supplied rows, aggregated in the first two supplied coordinates; no new embedding",
                interpretation="This is supplied coordinate geometry, not evidence of stable or meaningful clusters.",limitations=limits))
        except (ValueError,OverflowError,FloatingPointError):
            panels.append(_visuals.status_panel("cluster_geometry","Supplied coordinate geometry",n=n,source_split="unknown",
                message="Supplied coordinates exceed this chart's finite display bounds; no rows were discarded.",limitations=limits))
    else:
        panels.append(_visuals.status_panel("cluster_geometry","First-two-input geometry",n=n,source_split="unknown",status="not_applicable",
            message="Only one supplied coordinate exists; no second axis is invented.",limitations=limits))
    for identifier,title in [("cluster_centers","Fitted cluster centers"),("cluster_distance","Distances to fitted centers")]:
        panels.append(_visuals.status_panel(identifier,title,n=n,source_split="unknown",
            message="No fitted centers were supplied. Centers and distances are not inferred from labels; pass a supported existing fitted KMeans for these panels.",limitations=limits))
    return _visual_bundle(n,"unknown",panels)


def _array(value, ndim, name):
    if np.ma.isMaskedArray(value) and np.ma.getmaskarray(value).any(): raise ValueError(name+" contains masked values; handle them explicitly within the analysis design")
    if np.iscomplexobj(value): raise ValueError(name+" must be real numeric values")
    try: a=np.asarray(value,dtype=float)
    except (TypeError,ValueError,OverflowError) as exc: raise ValueError(name+" must be numeric") from exc
    if a.ndim!=ndim or a.size==0 or a.size>MAX_CELLS: raise ValueError(name+" has invalid shape or exceeds local size bound")
    return a

def _xy(X,y):
    X=_array(X,2,"X"); y=_array(y,1,"y")
    if len(X)!=len(y) or len(y)<3: raise ValueError("X and y need matching lengths of at least three")
    return X,y

def _ev(req,status,diagnostic,n=None,observed=None,thresholds=None,limitations=None,remedies=None):
    observed=dict(observed or {}); observed.setdefault("group","all supplied rows")
    observed.setdefault("variables","supplied design/target for this diagnostic; column order retained")
    if status in {"not_checked","not_applicable"}: observed.setdefault("comparison","not computed or not applicable")
    thresholds=dict(thresholds or {}); thresholds.setdefault("configuration_source","model-evidence/0.2.0 defaults unless supplied argument")
    thresholds.setdefault("rationale",RATIONALE.get(req,"Interpret only the recorded check within its stated scope."))
    return evidence(req,status,diagnostic,sample_size=n,observed=observed,thresholds=thresholds,
        limitations=limitations,remedies=remedies,provenance={"implementation":"model-evidence/0.2.0","stage":"supplied_arrays"})

def _attest(items,attestations):
    if attestations is None: return items
    if not isinstance(attestations,dict): raise ValueError("attestations must be a requirement mapping")
    reg=load_registry()
    for req,a in attestations.items():
        if req not in MANUAL or req not in reg["requirements"]: raise ValueError("Attestation cannot replace an automated check")
        if not isinstance(a,dict) or set(a)-{"status","note","reviewer","basis"}: raise ValueError("Invalid attestation fields")
        if a.get("status") not in {"no_issue_detected","warning","fail","not_checked","not_applicable"}: raise ValueError("Invalid human status")
        if not all(isinstance(a.get(k),str) and 0<len(a[k].strip())<=4096 for k in ("reviewer","basis")): raise ValueError("Attestation needs reviewer and basis")
        if not isinstance(a.get("note",""),str): raise ValueError("Attestation note must be text")
        items=[e for e in items if not(e["requirement"]==req and e["source"]=="manual_required")]
        items.append(evidence(req,a["status"],a.get("note") or "Human attestation; not an automated diagnostic",source="human",
            limitations=["Human assertion is not independently verified."],provenance={"reviewer":a["reviewer"],"basis":a["basis"]}))
    return items

def _complete(method,purpose,items,attestations=None):
    ids=set(describe_requirements(method,purpose)["requirements"])
    present={e["requirement"] for e in items}
    reg=load_registry()
    for req in sorted(ids-present):
        items.append(evidence(req,"not_checked","Requires metadata, study documentation, or an unimplemented diagnostic",
            source="manual_required",limitations=["Cannot be determined from fit alone."],remedies=reg["requirements"][req]["remedies"]))
    return _attest(items,attestations)

def _common(X,y,metadata=None,binary=False):
    if metadata is None: metadata={}
    if not isinstance(metadata,dict) or set(metadata)-{"entity_ids","feature_available_times","prediction_times","split_evidence"}: raise ValueError("Unknown metadata fields")
    n=len(X); missing=int(np.size(X)-np.isfinite(X).sum()); cells=int(X.size+(0 if y is None else y.size))
    if y is not None: missing += int(len(y)-np.isfinite(y).sum())
    out=[_ev("missingness","fail" if missing else "no_issue_detected","Finite supplied values; no rows dropped or repaired",n,{"nonfinite_cells":missing,"total_cells":cells,"nonfinite_fraction":missing/cells,"variables":[f"x{i+1}" for i in range(X.shape[1])]+([] if y is None else ["target"])},{"maximum_nonfinite":0},
        ["Sentinel codes and missingness mechanisms need metadata and manual review."],["Define missingness handling within training folds; assess selection effects."])]
    if y is not None:
        valid=bool(np.isfinite(y).all() and (not binary or np.array_equal(np.unique(y),[0.,1.])))
        target_obs={"variables":["target"],"finite_count":int(np.isfinite(y).sum()),"unique_finite_values":int(len(np.unique(y[np.isfinite(y)])))}
        if binary: target_obs.update({"class_0_count":int(np.sum(y==0)),"class_1_count":int(np.sum(y==1)),"group":"observed classes 0 versus 1"})
        elif np.isfinite(y).any(): target_obs.update({"minimum":float(y[np.isfinite(y)].min()),"maximum":float(y[np.isfinite(y)].max())})
        out.append(_ev("target_compatibility","no_issue_detected" if valid else "fail","Requires numeric response" if not binary else "Requires both binary classes encoded 0/1",n,target_obs,{"support":"both classes 0/1" if binary else "finite numeric response"},limitations=["The scientific meaning and measurement of the target require human review."]))
    if "entity_ids" in metadata:
        ids=metadata["entity_ids"]
        if not isinstance(ids,(list,tuple,np.ndarray)) or len(ids)!=n or any(not isinstance(v,(str,int,np.integer)) or isinstance(v,bool) for v in ids): raise ValueError("Entity IDs must be nonmissing string/integer values aligned with rows")
        count=n-len(set(ids))
        out.append(_ev("duplicate_entities","warning" if count else "no_issue_detected","Repeated entity IDs at supplied row grain",n,{"duplicate_count":count,"row_denominator":n,"unique_entities":n-count,"duplicate_fraction":count/n,"variables":["entity ID (values withheld)"]},{"maximum_repeats_without_review":0},limitations=["Repeated entities may be legitimate; document grain and use group-aware evaluation."]))
    if "feature_available_times" in metadata or "prediction_times" in metadata:
        if not {"feature_available_times","prediction_times"}<=set(metadata): raise ValueError("Timing requires both feature and prediction availability")
        ft=_array(metadata["feature_available_times"],2,"feature_available_times"); pt=_array(metadata["prediction_times"],1,"prediction_times")
        if ft.shape!=X.shape or len(pt)!=n or not np.isfinite(ft).all() or not np.isfinite(pt).all(): raise ValueError("Timing metadata must be finite and align with X")
        late=int(np.sum(ft>pt[:,None]))
        out.append(_ev("timing","fail" if late else "no_issue_detected","Feature availability versus prediction cutoff in common numeric time units",n,{"late_cells":late,"availability_comparisons":int(ft.size),"late_fraction":late/ft.size,"variables":["feature availability","row prediction cutoff"]},{"maximum_late_cells":0,"comparison":"availability <= prediction cutoff"},["Metadata accuracy and label availability are not independently verified."]))
    if "split_evidence" in metadata:
        supplied=metadata["split_evidence"]
        if not isinstance(supplied,list) or any(not isinstance(e,dict) or e.get("requirement") not in {"split_integrity","time_order"} for e in supplied): raise ValueError("Only split audit evidence can be attached")
        out.extend(supplied)
    return out

def audit_split(train_indices,test_indices,*,groups=None,times=None,strategy="random",gap=0):
    """Audit positions in a shared row universe; never emit entity values."""
    for name,value in (("train_indices",train_indices),("test_indices",test_indices),("groups",groups),("times",times)):
        if np.ma.isMaskedArray(value) and np.ma.getmaskarray(value).any(): raise ValueError(name+" contains masked values; no mask is silently dropped")
    if strategy not in {"random","grouped","time"} or not isinstance(gap,(int,float)) or isinstance(gap,bool) or not math.isfinite(gap) or gap<0: raise ValueError("Invalid split strategy or gap")
    def indices(x):
        a=np.asarray(x)
        if a.ndim!=1 or not a.size or a.size>MAX_CELLS or a.dtype.kind not in "iu" or np.any(a<0): raise ValueError("Split positions must be nonnegative integer arrays")
        return a
    tr=indices(train_indices); te=indices(test_indices); n=len(tr)+len(te)
    overlap=len(np.intersect1d(tr,te)); repeats=len(tr)-len(np.unique(tr))+len(te)-len(np.unique(te))
    bad=bool(overlap or repeats); unknown=False; group_overlap=0
    if groups is not None:
        g=np.asarray(groups,dtype=object)
        if g.ndim!=1 or max(tr.max(),te.max())>=len(g) or any(v is None or (isinstance(v,(float,np.floating)) and not math.isfinite(v)) for v in g): raise ValueError("Groups must be nonmissing and cover positions")
        if any(not isinstance(v,(str,int,float,np.integer,np.floating)) or isinstance(v,bool) for v in g): raise ValueError("Groups must be scalar string/numeric labels")
        group_overlap=len(set(g[tr])&set(g[te])); bad=bad or group_overlap>0
    elif strategy=="grouped": unknown=True
    timing=None
    if strategy=="time":
        if times is None: unknown=True
        else:
            t=_array(times,1,"times")
            if max(tr.max(),te.max())>=len(t) or not np.isfinite(t).all(): raise ValueError("Times must be finite and cover positions")
            timing=bool(np.max(t[tr])+gap < np.min(t[te])); bad=bad or not timing
    status="fail" if bad else "not_checked" if unknown else "no_issue_detected"
    es=[_ev("split_integrity",status,"Disjoint rows; optional disjoint entities and strictly forward time",n,
        {"overlapping_positions":overlap,"duplicate_positions":int(repeats),"overlapping_groups":group_overlap,"training_rows":int(len(tr)),"evaluation_rows":int(len(te)),"group":"training versus evaluation","variables":["row positions"]+([] if groups is None else ["entity groups"]),"group_audit_supplied":groups is not None},
        {"gap":float(gap),"maximum_overlap":0,"strategy":strategy},["Disjoint positions do not rule out content leakage, repeated entities without metadata, or tuning on final outcomes."])]
    if strategy=="time": es.append(_ev("time_order","not_checked" if timing is None else "no_issue_detected" if timing else "fail","Strict training-before-evaluation order",n,
        observed={} if timing is None else {"training_maximum_time":float(np.max(t[tr])),"evaluation_minimum_time":float(np.min(t[te])),"group":"training versus evaluation","variables":["time"]},
        thresholds={"gap":float(gap),"comparison":"training maximum + gap < evaluation minimum"},limitations=["Choose gaps, label windows, and rolling-origin folds for the actual forecast horizon."]))
    return es

def audit_ols(X,y,purpose="association",metadata=None,attestations=None):
    X,y=_xy(X,y); n,p=X.shape; es=_common(X,y,metadata); est={}
    if np.isfinite(X).all() and np.isfinite(y).all():
        A=np.column_stack([np.ones(n),X]); rank=int(np.linalg.matrix_rank(A)); df=n-rank
        leverage=cooks=None
        coef=np.linalg.lstsq(A,y,rcond=None)[0]; fit=A@coef; res=y-fit; sse=float(res@res)
        cond=float(np.linalg.cond(A)); cond=cond if np.isfinite(cond) else 1e308
        es.append(_ev("identifiability","fail" if rank<p+1 or df<=0 else "warning" if cond>1e8 else "no_issue_detected","Design rank and condition-number screen",n,{"rank":rank,"parameters":p+1,"condition_number":cond},{"condition_warning":1e8},["Condition number depends on units; collinearity inflates coefficient uncertainty."]))
        est={"coefficients":coef.tolist(),"training_rmse":float(np.sqrt(sse/n)),"residual_df":int(df)}
        if rank==p+1 and df>0:
            # Work with the design pseudoinverse: normal equations square the condition number.
            projection=np.linalg.pinv(A); leverage=np.sum(A*projection.T,axis=1); denom=1-leverage
            hc3_valid=bool(np.all(denom>1e-12) and sse>0)
            influence_values={"max_leverage":float(leverage.max()),"hc3_covariance_available":hc3_valid}
            if hc3_valid:
                robust=(projection*((res/denom)**2))@projection.T
                est["hc3_standard_errors"]=np.sqrt(np.maximum(np.diag(robust),0)).tolist()
                cooks=(res**2/((p+1)*(sse/df)))*leverage/(denom**2)
                influence_values.update(max_cooks_distance=float(cooks.max()),high_influence_count=int(np.sum(cooks>4/n)))
                influence_status="warning" if np.any(cooks>4/n) else "no_issue_detected"
            else:
                influence_values.update(max_cooks_distance=None,high_influence_count=None)
                influence_status="warning"
            es.append(_ev("influence",influence_status,"Cook distance and leverage screen",n,influence_values,{"cooks_warning":4/n,"hc3_minimum_one_minus_leverage":1e-12},["Threshold is exploratory; inspect influential observations without automatic deletion.","HC3 standard errors and Cook distances are omitted if leverage is one/near one or residual variance is zero; no artificial denominator floor repairs the covariance."]))
            if n>p+5 and np.var(res**2)>1e-24:
                aux=res**2; pred=A@np.linalg.lstsq(A,aux,rcond=None)[0]; r2=max(0.,1-float(np.sum((aux-pred)**2)/np.sum((aux-aux.mean())**2)))
                lm=n*r2; pv=float(stats.chi2.sf(lm,p)) if p>0 else 1.
                es.append(_ev("error_structure","warning" if pv<.05 else "no_issue_detected","Studentized Breusch-Pagan/Koenker n*R2 screen (asymptotic; squared residuals on original design)",n,{"lm":lm,"p_value":pv,"chi_square_df":p,"auxiliary_r2":r2,"variables":["squared fitted residuals","original design columns"]},{"alpha":.05,"comparison":"p_value < alpha flags heteroskedasticity evidence"},["Nonsignificance is not homoskedasticity proof. HC3 does not fix dependence, misspecification, or endogeneity.","Normal errors are not required for OLS point prediction."],["Review residual plots; consider justified robust, clustered, or time-series inference."]))
            else: es.append(_ev("error_structure","not_checked","Residual variance screen degenerate or sample too small",n))
            if 3<=n<=5000 and np.ptp(res)>1e-12:
                sw=stats.shapiro(res)
                es.append(_ev("residual_shape","warning" if sw.pvalue<.05 else "no_issue_detected","Shapiro-Wilk residual screen",n,{"statistic":float(sw.statistic),"p_value":float(sw.pvalue)},{"alpha":.05},["Residuals are estimated and dependent. Test sensitivity changes with n; not a proof or universal OLS requirement."]))
            else: es.append(_ev("residual_shape","not_checked","Shapiro-Wilk omitted outside 3..5000 nondegenerate residuals",n))
        residual_scale=math.sqrt(sse/df) if df>0 and sse>0 else None
        residual_visuals=_collect_visual(_visuals.ols_visual_evidence,fit,res,A,n=n,source_split="training",
            leverage=leverage,cooks_distance=cooks,residual_scale=residual_scale)
        result_visuals=_collect_visual(_visuals.regression_visual_evidence,y,fit,n=n,source_split="training")
        if all(panel["id"]!="visual_unavailable" for panel in residual_visuals["panels"]+result_visuals["panels"]):
            est["visual_evidence"]=_visual_bundle(n,"training",result_visuals["panels"]+residual_visuals["panels"])
        else:
            est["visual_evidence"]=residual_visuals if residual_visuals["panels"][0]["id"]!="visual_unavailable" else result_visuals
    else:
        est["visual_evidence"]=_unavailable_visual(n,"training","OLS arrays contain nonfinite inputs; fitted residual and result charts were not computed.")
    es=_complete("ols",purpose,es,attestations)
    return make_report("ols",purpose,es,{"n":n,"p":p},est,["OLS is unweighted with an added intercept and no automatic preprocessing. Coefficient arrays follow intercept then supplied column order.","Training fit is not held-out predictive performance. HC3 errors are descriptive approximations; no confidence intervals or p-values for coefficients are certified."])

def audit_logistic(X,y,purpose="prediction",metadata=None,attestations=None):
    X,y=_xy(X,y); n,p=X.shape; es=_common(X,y,metadata,binary=True); est={}
    valid=np.isfinite(X).all() and np.isfinite(y).all() and np.array_equal(np.unique(y),[0.,1.])
    if valid:
        A=np.column_stack([np.ones(n),X]); rank=int(np.linalg.matrix_rank(A)); events=int(y.sum()); minority=min(events,n-events)
        condition=float(np.linalg.cond(A)); condition=condition if np.isfinite(condition) else 1e308
        es.append(_ev("identifiability","fail" if rank<p+1 else "warning" if condition>1e8 else "no_issue_detected","Logistic design rank and raw-scale condition screen",n,{"rank":rank,"parameters":p+1,"condition_number":condition},{"condition_warning":1e8},["Raw scale affects optimizer stopping criteria; review convergence and scale within training folds."]))
        es.append(_ev("event_information","warning" if minority/(p+1)<10 else "no_issue_detected","Minority events per parameter heuristic",n,{"events":events,"nonevents":n-events,"minority_per_parameter":minority/(p+1)},{"warning_below":10},["Ten is an illustrative screening threshold, not a sample-size rule or guarantee."]))
        # Positive affine column scaling preserves separation, improves LP tolerances,
        # and changes only the diagnostic design; the raw fitted model is untouched.
        scale=np.std(X,axis=0); scale=np.where(scale>0,scale,1.)
        lp_design=np.column_stack([np.ones(n),(X-X.mean(axis=0))/scale])
        margins=(2*y-1)[:,None]*lp_design
        complete=linprog(np.zeros(p+1),A_ub=-margins,b_ub=-np.ones(n),bounds=[(None,None)]*(p+1),method="highs")
        quasi=linprog(np.zeros(p+1),A_ub=np.vstack([-margins,-margins.sum(axis=0)]),b_ub=np.r_[np.zeros(n),-1.],bounds=[(None,None)]*(p+1),method="highs")
        separated=bool(complete.success or quasi.success)
        solver_known=complete.status in {0,2} and quasi.status in {0,2}
        es.append(_ev("separation","fail" if separated else "no_issue_detected" if solver_known else "not_checked","Linear-program feasibility screen on column-standardized diagnostic design for complete/quasi separation",n,{"complete_detected":bool(complete.success),"quasi_or_complete_detected":bool(quasi.success),"complete_solver_status":int(complete.status),"quasi_solver_status":int(quasi.status),"group":"class 0 versus class 1"},thresholds={"complete_signed_margin_minimum":1,"quasi_signed_margin_minimum":0,"quasi_total_margin_minimum":1},limitations=["Only the LP diagnostic design is standardized; the fitted model and supplied data are not repaired.","Numerical tolerance and high-dimensional designs can limit this screen; finite coefficients do not rule out separation."]))
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always",ConvergenceWarning)
            model=LogisticRegression(penalty=None,solver="lbfgs",max_iter=1000,tol=1e-8).fit(X,y)
        conv=not any(issubclass(w.category,ConvergenceWarning) for w in caught) and int(model.n_iter_[0])<1000
        prob=model.predict_proba(X)[:,1]
        es.append(_ev("convergence","no_issue_detected" if conv else "fail","Optimizer convergence flag",n,{"iterations":int(model.n_iter_[0]),"convergence_warnings":sum(issubclass(w.category,ConvergenceWarning) for w in caught)},{"max_iterations":1000,"solver":"lbfgs","tolerance":1e-8},["Optimizer convergence does not establish specification, identification, or finite unpenalized maximum likelihood under separation."]))
        est={"coefficients":[float(model.intercept_[0])]+model.coef_[0].tolist(),"training_log_loss":float(log_loss(y,prob,labels=[0,1])),"training_prevalence":float(y.mean())}
        est["visual_evidence"]=_collect_visual(_visuals.classification_visual_evidence,y,(prob>.5).astype(int),
            classes=[0,1],probabilities=prob,n=n,source_split="training")
        for panel in est["visual_evidence"]["panels"]:
            panel["limitations"].append("Displayed low-level logistic labels use the fixed probability > 0.5 rule; no threshold was selected from outcomes.")
    else:
        est["visual_evidence"]=_unavailable_visual(n,"training","Binary logistic fitting inputs are nonfinite or do not contain both encoded classes 0/1; no numerical chart was constructed.")
    return make_report("logistic",purpose,_complete("logistic",purpose,es,attestations),{"n":n,"p":p},est,
        ["Unpenalized binary logistic fit; no automated feature scaling, inference intervals, or effect interpretation. Training fit is not validation.","Discrimination and calibration are distinct. Rare-event AP depends on prevalence; high accuracy may conceal no event capture."])

def audit_prediction(y_true,y_pred,*,task="regression",probabilities=None,baseline_predictions=None,metadata=None,attestations=None,top_fraction=.1,split_role="unknown"):
    if not isinstance(split_role,str) or split_role not in {"unknown","training","validation","evaluation","final_holdout"}: raise ValueError("Unknown prediction split role")
    y=_array(y_true,1,"y_true"); pred=_array(y_pred,1,"y_pred")
    if len(y)!=len(pred) or len(y)<3 or task not in {"regression","classification"}: raise ValueError("Prediction arrays must align and task must be supported")
    if not isinstance(top_fraction,(float,int)) or isinstance(top_fraction,bool) or not 0<top_fraction<=1: raise ValueError("top_fraction must be within (0,1]")
    n=len(y); method="prediction_"+task; X=pred[:,None]; es=_common(X,y,metadata,binary=task=="classification"); est={}
    valid=np.isfinite(y).all() and np.isfinite(pred).all()
    if task=="classification":
        valid=bool(valid and np.array_equal(np.unique(y),[0.,1.]) and np.all(np.isin(pred,[0,1])))
        if not valid:
            es=[e for e in es if e["requirement"]!="target_compatibility"]+[_ev("target_compatibility","fail","Binary observed/predicted classes 0/1 and both observed classes required",n)]
    prob=None
    if probabilities is not None:
        if task!="classification": raise ValueError("Probabilities apply to classification only")
        prob=_array(probabilities,1,"probabilities")
        if len(prob)!=n or not np.isfinite(prob).all() or np.any((prob<0)|(prob>1)): raise ValueError("Probabilities must align and be in [0,1]")
    if valid:
        if task=="regression":
            est={"mae":float(mean_absolute_error(y,pred)),"rmse":float(np.sqrt(mean_squared_error(y,pred)))}
            if np.ptp(y)>0:
                with np.errstate(over="ignore",divide="ignore",invalid="ignore"):
                    raw_r2=float(r2_score(y,pred,force_finite=False))
                if math.isfinite(raw_r2) and abs(raw_r2)<=10**100:
                    est["r2"]=raw_r2
                else:
                    est["r2"]=None
                    est["metric_availability"]={"r2":{"status":"not_computable",
                        "reason":"R2 is nonfinite or exceeds the absolute report bound; no finite replacement was substituted",
                        "absolute_report_bound":10**100}}
            else:
                es=[e for e in es if e["requirement"]!="target_compatibility"]+[_ev("target_compatibility","warning","Constant response: R2 undefined and target variation unassessed",n)]
        else:
            est={"accuracy":float(accuracy_score(y,pred)),"event_prevalence":float(y.mean()),"prevalence_reference_ap":float(y.mean())}
            if prob is not None:
                est.update(roc_auc=float(roc_auc_score(y,prob)),average_precision=float(average_precision_score(y,prob)),brier=float(brier_score_loss(y,prob)),log_loss=float(log_loss(y,prob,labels=[0,1])))
                bins=np.minimum((prob*10).astype(int),9); counts=[]; means=[]; rates=[]; ece=0.
                for b in range(10):
                    mask=bins==b; k=int(mask.sum())
                    if k:
                        counts.append(k); means.append(float(prob[mask].mean())); rates.append(float(y[mask].mean())); ece+=k/n*abs(means[-1]-rates[-1])
                est["calibration"]={"bin_counts":counts,"mean_probability":means,"event_rate":rates,"ece_10bin":ece}
                k=max(1,int(math.ceil(top_fraction*n))); selected=np.argsort(-prob,kind="stable")[:k]
                est["queue_capture"]=float(y[selected].sum()/y.sum()); est["queue_fraction"]=k/n
                tied=bool(k<n and np.sort(prob)[::-1][k-1]==np.sort(prob)[::-1][k])
                es.append(_ev("calibration","warning" if n<100 or min(y.sum(),n-y.sum())<20 else "no_issue_detected","Brier score and fixed-bin calibration description",n,{"ece_10bin":ece,"bin_counts":counts,"bin_mean_probability":means,"bin_event_rate":rates,"group":"nonempty fixed probability bins","variables":["predicted probability","observed binary target"],"class_0_count":int(np.sum(y==0)),"class_1_count":int(np.sum(y==1))},{"small_sample_n":100,"small_class_n":20,"bins":10},["No calibration certification: bins are arbitrary and small cells unstable; compare calibration curves on appropriate evaluation data."]))
                es.append(_ev("discrimination","no_issue_detected","ROC AUC/AP and ranked queue capture",n,{"roc_auc":est["roc_auc"],"average_precision":est["average_precision"],"prevalence_reference_ap":float(y.mean()),"event_count":int(y.sum()),"queue_capacity":k,"events_captured":int(y[selected].sum()),"queue_capture":est["queue_capture"],"group":"ranked queue versus all observed events","variables":["predicted probability","binary target"]},{"queue_fraction_requested":float(top_fraction),"queue_fraction_actual":k/n,"comparison":"queue capture = events in selected queue / all observed events; no adequacy cutoff"},limitations=["AP is prevalence-dependent; ROC AUC is ranking, not calibration. Queue capture is recall within a workload budget, not accuracy.","Ties at the queue boundary use stable input order." if tied else "Queue cutoff was supplied, not optimized on holdout outcomes."]))
            else:
                es.append(_ev("calibration","not_checked","Probabilities not supplied",n))
                es.append(_ev("discrimination","not_checked","Ranking probabilities not supplied",n))
        if baseline_predictions is not None:
            base=_array(baseline_predictions,1,"baseline_predictions")
            if len(base)!=n or not np.isfinite(base).all() or (task=="classification" and not np.isin(base,[0,1]).all()): raise ValueError("Baseline predictions must be valid and align")
            if task=="regression":
                est["baseline_mae"]=float(mean_absolute_error(y,base)); est["baseline_rmse"]=float(np.sqrt(mean_squared_error(y,base))); better=est["rmse"]<est["baseline_rmse"]
            else: est["baseline_accuracy"]=float(accuracy_score(y,base)); better=est["accuracy"]>est["baseline_accuracy"]
            model_value=est["rmse"] if task=="regression" else est["accuracy"]
            reference_value=est["baseline_rmse"] if task=="regression" else est["baseline_accuracy"]
            es.append(_ev("reference_baseline","no_issue_detected" if better else "warning","Supplied prespecified reference compared on identical rows",n,{"improves_reference_metric":bool(better),"model_value":model_value,"reference_value":reference_value,"difference_model_minus_reference":model_value-reference_value,"metric":"rmse" if task=="regression" else "accuracy","group":"model versus prespecified reference on same evaluation rows","variables":["observed target","model prediction","reference prediction"]},{"comparison":"model RMSE < reference RMSE" if task=="regression" else "model accuracy > reference accuracy"},limitations=["Reference must be fit/chosen using training data; comparison is descriptive with no uncertainty estimate."]))
    if valid and task=="classification" and prob is not None:
        from .calibration import audit_calibration
        calibration=audit_calibration(y,prob,split_role=split_role)
        es=[row for row in es if not(row["requirement"]=="calibration" and row["source"]=="automated")]+calibration["evidence"]
        est.update(calibration["estimates"])
    if valid:
        if task=="regression":
            est["visual_evidence"]=_collect_visual(_visuals.regression_visual_evidence,y,pred,n=n,source_split=split_role)
        else:
            est["visual_evidence"]=_collect_visual(_visuals.classification_visual_evidence,y,pred,classes=[0,1],
                probabilities=prob,n=n,source_split=split_role)
    else:
        est["visual_evidence"]=_unavailable_visual(n,split_role,"Prediction inputs are nonfinite or incompatible with the declared target; no result chart was constructed.")
    metric_limits=(["R2 is unavailable because its computed value is nonfinite or outside the absolute report bound of 1e100. Other available metrics retain their own units and values; no finite-looking R2 was substituted."]
                   if "metric_availability" in est else [])
    return make_report(method,"prediction",_complete(method,"prediction",es,attestations),{"n":n},est,
        ["Metrics describe only supplied evaluation rows; provenance of held-out status needs human evidence. No holdout-driven repair or model selection is performed.","Permutation importance measures predictive reliance in an evaluation distribution, not causality; this release does not compute it."]+metric_limits)

def audit_pca(X,metadata=None,attestations=None):
    X=_array(X,2,"X"); n,p=X.shape
    if n<3: raise ValueError("PCA needs at least three rows")
    es=_common(X,None,metadata); est={}
    if np.isfinite(X).all():
        sd=np.std(X,axis=0); rank=int(np.linalg.matrix_rank(X-X.mean(axis=0)))
        bad=bool(np.any(sd==0)); ratios=sd[sd>0]; ratio=float(ratios.max()/ratios.min()) if len(ratios) else 0.
        es.append(_ev("distance_geometry","fail" if bad else "warning" if ratio>100 else "no_issue_detected","Constant-column and scale-spread screen (centered, not standardized)",n,{"constant_columns":int(np.sum(sd==0)),"scale_ratio":ratio,"centered_rank":rank},{"scale_ratio_warning":100},["Scaling and measurement choices need explicit human justification. PCA needs no universal normal-feature assumption."]))
        s=np.linalg.svd(X-X.mean(axis=0),compute_uv=False); v=s*s
        if v.sum()>0: est["explained_variance_ratio"]=(v/v.sum()).tolist()
    est["visual_evidence"]=_raw_pca_visual(X,est)
    return make_report("pca","description",_complete("pca","description",es,attestations),{"n":n,"p":p},est,["PCA variance explained describes a linear projection, not causal factors or supervised predictive value."])

def audit_clustering(X,labels,metadata=None,attestations=None):
    if np.ma.isMaskedArray(labels) and np.ma.getmaskarray(labels).any(): raise ValueError("Cluster labels contain masked values")
    X=_array(X,2,"X"); n,p=X.shape; lab=np.asarray(labels)
    if lab.ndim!=1 or len(lab)!=n or lab.dtype.kind not in "iu": raise ValueError("Cluster labels must be aligned integers")
    es=_common(X,None,metadata); est={}; k=len(np.unique(lab))
    if np.isfinite(X).all():
        sd=np.std(X,axis=0); constant=int(np.sum(sd==0)); ratio=float(sd.max()/sd[sd>0].min()) if np.any(sd>0) else 0.
        es.append(_ev("distance_geometry","fail" if constant else "warning" if ratio>100 else "no_issue_detected","Euclidean scale and constant-column screen",n,{"constant_columns":constant,"scale_ratio":ratio},{"scale_ratio_warning":100},["Euclidean distance, scaling, k, and cluster shape require domain justification. Labels are supplied, not fit or silently tuned."]))
        if 2<=k<n:
            est={"cluster_count":k,"silhouette_euclidean":float(silhouette_score(X,lab,sample_size=min(n,1000),random_state=2026))}
        else: es.append(_ev("cluster_stability","fail","Silhouette requires 2..n-1 distinct labels",n))
    est["visual_evidence"]=_raw_clustering_visual(X,lab)
    return make_report("kmeans","clustering",_complete("kmeans","clustering",es,attestations),{"n":n,"p":p},est,["Silhouette is internal compactness/separation, not evidence of real types or stability. Bootstrap/external validation is manual and unimplemented."])
