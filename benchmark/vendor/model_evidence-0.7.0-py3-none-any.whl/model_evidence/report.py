"""Deterministic evidence, fail-closed claims, and local narrative rendering."""
import json
import math
from .registry import load_registry, method_spec
from ._version import VERSION

SCHEMA_VERSION = "1.1.0"
STATUSES = {"fail", "warning", "not_checked", "not_applicable", "no_issue_detected"}
SOURCES = {"automated", "human", "manual_required"}
_BAYESIAN_MANUAL = {"prior_specification", "likelihood_specification", "posterior_predictive", "sensitivity_analysis", "conditional_error_model"}
TOP_FIELDS = {"schema_version", "registry_version", "library_version", "method", "purpose", "sample_sizes", "evidence", "estimates", "claims", "limitations"}
EVIDENCE_FIELDS = {"requirement", "status", "source", "diagnostic", "observed", "thresholds", "sample_size", "limitations", "remedies", "provenance"}
MANUAL = {"data_grain", "leakage", "timing", "evaluation_protocol", "independence", "functional_form", "exogeneity", "sampling_scope", "distance_geometry", "cluster_stability", "causal_design", "exchangeability", "positivity", "consistency", "interference", "stationarity", "randomization", "parallel_trends", "continuity", "no_manipulation", "exclusion_restriction", "monotonicity", "measurement_scale", "estimand", "sample_relationship", "test_prespecification", "distributional_approximation", "equal_variance", "pairing", "multiplicity", "count_distribution", "dispersion", "censoring", "grouping_structure", "random_effect_distribution", "conditional_feature_independence", "fit_association", "architecture_input_contract", "output_alignment", "sequence_semantics", "padding_mask", "reconstruction_target", "architecture_state"} | _BAYESIAN_MANUAL

def _strings(value):
    return isinstance(value, list) and len(value) <= 256 and all(isinstance(s,str) and len(s) <= 4096 for s in value)

def _json_data(value, depth=0):
    if depth > 12:
        raise ValueError("Report nesting exceeds limit")
    if value is None or isinstance(value, bool):
        return
    if isinstance(value, (float,int)):
        if abs(value)>10**100 or not math.isfinite(value):
            raise ValueError("Nonfinite numbers are forbidden")
    elif isinstance(value, str):
        if len(value) > 8192:
            raise ValueError("Text exceeds limit")
    elif isinstance(value, dict):
        if len(value) > 256 or not all(isinstance(k,str) and len(k) <= 128 for k in value):
            raise ValueError("Invalid object")
        for v in value.values(): _json_data(v, depth+1)
    elif isinstance(value, list):
        if len(value) > 2048: raise ValueError("Array exceeds limit")
        for v in value: _json_data(v, depth+1)
    else:
        raise ValueError("Report must contain JSON values only")

def validate_report(report):
    """Structural validation; evidence integrity/authenticity is not certified."""
    _json_data(report)
    reg = load_registry()
    if not isinstance(report,dict) or set(report) != TOP_FIELDS:
        raise ValueError("Invalid report fields")
    versions=(report["schema_version"],report["registry_version"],report["library_version"])
    if any(not isinstance(value,str) for value in versions) or versions not in {("1.0.0","0.1.0","0.1.0"),("1.1.0","0.2.0","0.2.0"),("1.1.0","0.3.0","0.3.0"),("1.1.0","0.4.0","0.4.0"),("1.1.0","0.5.0","0.5.0"),("1.1.0","0.6.0","0.6.0"),(SCHEMA_VERSION,reg["registry_version"],VERSION)}:
        raise ValueError("Unsupported contract version")
    method=method_spec(report["method"])
    if tuple(map(int,method.get("introduced_in","0.1.0").split("."))) > tuple(map(int,report["library_version"].split("."))):
        raise ValueError("Method is unavailable in the declared legacy version")
    if not isinstance(report["purpose"],str) or report["purpose"] not in reg["use_cases"]: raise ValueError("Unknown purpose")
    if not isinstance(report["sample_sizes"],dict) or not all(isinstance(v,int) and not isinstance(v,bool) and 0<=v<=1_000_000_000 for v in report["sample_sizes"].values()):
        raise ValueError("Invalid sample sizes")
    if not isinstance(report["estimates"],dict) or not _strings(report["limitations"]): raise ValueError("Invalid report values")
    if not isinstance(report["evidence"],list) or len(report["evidence"])>256: raise ValueError("Invalid evidence list")
    seen = set()
    for e in report["evidence"]:
        if not isinstance(e,dict) or set(e)!=EVIDENCE_FIELDS: raise ValueError("Invalid evidence fields")
        if not all(isinstance(e[k],str) for k in ("requirement","status","source")) or e["requirement"] not in reg["requirements"] or e["status"] not in STATUSES or e["source"] not in SOURCES: raise ValueError("Unknown evidence vocabulary")
        if e["source"]=="manual_required" and e["status"] not in {"not_checked","not_applicable"}: raise ValueError("Manual-required placeholder cannot assert diagnostic success")
        if e["source"]=="human" and e["requirement"] not in MANUAL: raise ValueError("Human evidence cannot replace an automated check")
        key=(e["requirement"],e["source"])
        if key in seen: raise ValueError("Duplicate requirement/source evidence")
        seen.add(key)
        if not isinstance(e["diagnostic"],str) or not all(isinstance(e[k],dict) for k in ("observed","thresholds","provenance")): raise ValueError("Invalid evidence values")
        if e["sample_size"] is not None and (not isinstance(e["sample_size"],int) or isinstance(e["sample_size"],bool) or not 0<=e["sample_size"]<=1_000_000_000): raise ValueError("Invalid evidence sample size")
        if not _strings(e["limitations"]) or not _strings(e["remedies"]): raise ValueError("Invalid evidence text")
        if e["source"] == "human" and not all(isinstance(e["provenance"].get(k),str) and e["provenance"][k].strip() for k in ("reviewer","basis")):
            raise ValueError("Human evidence needs reviewer and basis")
    if not isinstance(report["claims"],list): raise ValueError("Invalid claims")
    for c in report["claims"]:
        if not isinstance(c,dict) or set(c)!={"id","status","requirements","blockers"}: raise ValueError("Invalid claim fields")
        if not isinstance(c["id"],str) or not isinstance(c["status"],str) or c["id"] not in reg["claims"] or c["status"] not in {"blocked","supported_with_limitations"} or not _strings(c["requirements"]) or not _strings(c["blockers"]): raise ValueError("Invalid claim")
        if len(c["requirements"])>100 or len(set(c["requirements"]))!=len(c["requirements"]) or any(req not in reg["requirements"] for req in c["requirements"]): raise ValueError("Invalid claim requirements")
    return report

def evidence(requirement, status, diagnostic, *, source="automated", observed=None, thresholds=None, sample_size=None, limitations=None, remedies=None, provenance=None):
    return {"requirement":requirement,"status":status,"source":source,"diagnostic":diagnostic,
            "observed":observed or {},"thresholds":thresholds or {},"sample_size":sample_size,
            "limitations":limitations or [],"remedies":remedies or [],
            "provenance":provenance or {"implementation":"model-evidence/"+VERSION}}

def gate_claims(report):
    validate_report(report)
    reg=load_registry(); spec=method_spec(report["method"]); result=[]
    relevant={k:v for k,v in reg["claims"].items() if v["purpose"]==report["purpose"]}
    selected={k:v for k,v in relevant.items() if k in spec["claims"]} or relevant
    for cid,c in selected.items():
        if c["purpose"] != report["purpose"]: continue
        reqs=list(c["requirements"])
        if c.get("method_requirements",False): reqs += spec["requirements"]
        adapter = report.get("estimates", {}).get("adapter", {})
        family = adapter.get("model_family") if isinstance(adapter, dict) else None
        if not isinstance(family, str): family = None
        if cid == "evaluated_prediction" and family in {"nearest_neighbors", "naive_bayes"}:
            # Domain violations/unknowns block readiness, not calculation of
            # empirical error scores. NB dependence is not a prediction veto.
            reqs.append("predictor_domain")
        if cid == "exploratory_structure" and report["method"] in {"hierarchical_clustering", "dbscan"}:
            reqs.append("fit_association")
        if report["method"] == "architecture_output_review":
            reqs.append("output_alignment")
            context = report["estimates"].get("architecture_review", {})
            if not isinstance(context, dict): raise ValueError("Invalid architecture review metadata")
            if context.get("task") == "reconstruction": reqs.append("reconstruction_target")
            if context.get("architecture") in {"rnn", "transformer"} or context.get("sequence_context") is True:
                reqs += ["sequence_semantics", "padding_mask"]
            for requirement in ("architecture_input_contract", "architecture_state", "padding_mask", "leakage"):
                if any(e["requirement"] == requirement and e["status"] in {"fail", "warning"} for e in report["evidence"]): reqs.append(requirement)
        if cid=="coefficient_association":
            reqs += ["exogeneity"]
            if report["method"]=="logistic": reqs += ["convergence","separation","event_information"]
            if report["method"]=="poisson_glm": reqs += ["convergence","count_distribution","dispersion"]
        reqs=list(dict.fromkeys(reqs)); blockers=[]
        if cid not in spec["claims"] or report["purpose"] not in spec["use_cases"]: blockers.append("method_purpose_unsupported")
        if spec["coverage"]=="manual_only": blockers.append("adapter_manual_only")
        if family in {"nearest_neighbors", "naive_bayes"} and tuple(map(int,report["library_version"].split("."))) < (0,7,0):
            blockers.append("adapter_unavailable_in_report_version")
        implementation_version=spec.get("implementation_introduced_in",spec.get("introduced_in","0.1.0"))
        if tuple(map(int,report["library_version"].split("."))) < tuple(map(int,implementation_version.split("."))):
            blockers.append("adapter_unavailable_in_report_version")
        if cid in {"causal_effect","forecast_performance"}: blockers.append("strong_claim_not_implemented")
        for req in reqs:
            entries=[e for e in report["evidence"] if e["requirement"]==req]
            # Manual claims need explicit human evidence. A diagnostic is not an attestation.
            required=[e for e in entries if e["source"]==("human" if req in MANUAL else "automated")]
            if not required or any(e["status"]!="no_issue_detected" for e in required): blockers.append(req)
            if any(e["status"] in {"fail","warning"} for e in entries) and req not in blockers: blockers.append(req)
        result.append({"id":cid,"status":"blocked" if blockers else "supported_with_limitations","requirements":reqs,"blockers":blockers})
    return result

def make_report(method,purpose,evidence,sample_sizes=None,estimates=None,limitations=None):
    spec=method_spec(method)
    r={"schema_version":SCHEMA_VERSION,"registry_version":load_registry()["registry_version"],"library_version":VERSION,
       "method":method,"purpose":purpose,"sample_sizes":sample_sizes or {},"evidence":list(evidence),"estimates":estimates or {},"claims":[],
       "limitations":list(dict.fromkeys((limitations or [])+spec["limitations"]+[
           "Diagnostics can detect some problems; no_issue_detected and nonsignificant tests do not prove assumptions.",
           "Fit does not establish causality, external validity, or performance in another population.",
           "Reports are editable data, not signed attestations; verify provenance. Aggregates can still be sensitive."]))}
    # A missing implementation or context must remain visible in the checklist.
    present={e["requirement"] for e in r["evidence"]}
    for req in _report_required_ids(r):
        if req not in present:
            r["evidence"].append(globals()["evidence"](req,"not_checked",
                "No diagnostic or contextual evidence was supplied for this registry requirement.",
                source="manual_required",remedies=load_registry()["requirements"][req]["remedies"],
                limitations=["Unimplemented, unavailable and untestable conditions are unresolved; absence is not success."],
                provenance={"implementation":"model-evidence/"+VERSION,"coverage":"no_evidence_supplied"}))
    r["claims"]=gate_claims(r)
    return r


def _required_ids(method,purpose):
    reg=load_registry(); spec=method_spec(method)
    if purpose not in reg["use_cases"]: raise ValueError("Unknown purpose")
    relevant={k:v for k,v in reg["claims"].items() if v["purpose"]==purpose}
    selected={k:v for k,v in relevant.items() if k in spec["claims"]} or relevant
    ids=list(spec["requirements"])
    for cid,claim in selected.items():
        ids.extend(claim["requirements"])
        if claim.get("method_requirements",False): ids.extend(spec["requirements"])
        if cid=="coefficient_association":
            ids.append("exogeneity")
            if method=="logistic": ids.extend(["convergence","separation","event_information"])
    return list(dict.fromkeys(ids))


def _report_required_ids(report):
    """Canonical fitted-family checklist; unsigned metadata cannot select IDs.

    These are review requirements, not assumptions universally imposed on every
    estimator. In particular no normal-feature or homoskedastic-error rule is
    added to trees, SVM or neural prediction.
    """
    ids = _required_ids(report["method"], report["purpose"])
    adapter = report.get("estimates", {}).get("adapter", {})
    family = adapter.get("model_family") if isinstance(adapter, dict) else None
    if not isinstance(family, str): family = None
    profiles = {
        "unpenalized_linear": ["functional_form", "error_structure"],
        "penalized_linear": ["distance_geometry", "convergence"],
        "logistic": ["functional_form", "convergence"],
        "support_vector": ["distance_geometry", "convergence"],
        "tree": ["sampling_scope"], "forest": ["sampling_scope"],
        "boosting": ["sampling_scope", "convergence"],
        "histogram_boosting": ["sampling_scope", "convergence"],
        "feedforward_mlp": ["distance_geometry", "convergence"],
        "nearest_neighbors": ["predictor_domain", "distance_geometry"],
        "naive_bayes": ["predictor_domain", "conditional_feature_independence", "distributional_approximation"],
    }
    return list(dict.fromkeys(ids + profiles.get(family, [])))


def complete_adapter_requirements(report):
    """Account explicitly for every applicable fitted-family requirement."""
    present = {e["requirement"] for e in report["evidence"]}; registry = load_registry()
    family = report.get("estimates", {}).get("adapter", {}).get("model_family")
    for req in _report_required_ids(report):
        if req not in present:
            if family == "unpenalized_linear" and req == "error_structure" and report["purpose"] == "prediction":
                report["evidence"].append(evidence(req, "not_applicable",
                    "This existing-model prediction audit computes point predictions and observed errors, not coefficient standard errors, tests or confidence intervals.",
                    source="automated", limitations=["Normal errors and constant error variance are not required for these point-prediction error calculations. Appropriate dependence and uncertainty assumptions would need separate review for intervals or coefficient inference."],
                    provenance={"implementation": "family-applicability/0.7.0"}))
                continue
            if family in {"boosting", "histogram_boosting"} and req == "convergence":
                report["evidence"].append(evidence(req, "not_applicable",
                    "The supported boosting estimator builds a configured sequence of stages; reaching that stage budget is not an optimizer convergence test or a solver failure.",
                    source="automated", limitations=["Training-only stage selection, loss behavior, early-stopping provenance and held-out performance still require review. No optimality or convergence certificate is supplied."],
                    provenance={"implementation": "family-applicability/0.7.0"}))
                continue
            report["evidence"].append(evidence(req, "not_checked", "This fitted-family requirement was not assessed by an implemented diagnostic or supplied context.",
                source="manual_required", remedies=registry["requirements"][req]["remedies"],
                limitations=["Missing context is unresolved, never an automatic pass. Prediction metrics do not certify a model's scientific assumptions."],
                provenance={"implementation": "family-checklist/0.7.0"}))
    return report


def requirement_coverage(report):
    """Complete registry checklist, independent of saved claims or scientific truth.

    Implementation bookkeeping and evidence support are separate. Legacy sparse
    reports are projected without mutation; missing rows stay explicitly unknown.
    """
    validate_report(report)
    reg=load_registry(); spec=method_spec(report["method"]); rows=[]
    for req in _report_required_ids(report):
        entries=[e for e in report["evidence"] if e["requirement"]==req]
        required=[e for e in entries if e["source"]==("human" if req in MANUAL else "automated")]
        automated=[e for e in entries if e["source"]=="automated"]
        completed=[e for e in automated if e["status"] in {"no_issue_detected","warning","fail"}]
        if any(e["status"]=="fail" for e in entries): status="fail"
        elif any(e["status"]=="warning" for e in entries): status="warning"
        elif required and all(e["status"]=="no_issue_detected" for e in required): status="no_issue_detected"
        elif entries and all(e["status"]=="not_applicable" for e in entries): status="not_applicable"
        else: status="not_checked"
        implementation_version=spec.get("implementation_introduced_in",spec.get("introduced_in","0.1.0"))
        historical_manual=tuple(map(int,report["library_version"].split("."))) < tuple(map(int,implementation_version.split(".")))
        implementation=("manual_only_adapter" if spec["coverage"]=="manual_only" or historical_manual else
            "automated_evidence_recorded" if completed else "automated_check_not_completed" if automated else "no_automated_check_recorded")
        support=("Observed concern; corresponding interpretation remains blocked." if status in {"fail","warning"} else
            "Required evidence recorded; conditional support only, not proof of the assumption." if status=="no_issue_detected" else
            "Recorded as not applicable; cannot satisfy a required strong-claim condition." if status=="not_applicable" else
            "Unresolved: required evidence missing, unimplemented, unavailable or untestable here.")
        rows.append({"requirement":req,"label":reg["requirements"][req]["label"],"status":status,
            "evidence_sources":sorted({e["source"] for e in entries}),"diagnostic_support":implementation,
            "interpretation_support":support,"next_step":reg["requirements"][req]["remedies"][0]})
    return {"requirements":rows,"counts":{"total":len(rows),"with_recorded_evidence":sum(any(e["requirement"]==r["requirement"] and e["source"]!="manual_required" for e in report["evidence"]) for r in rows),
        "automated_evidence_recorded":sum(r["diagnostic_support"]=="automated_evidence_recorded" for r in rows),
        "unresolved":sum(r["status"]=="not_checked" for r in rows),"concerns":sum(r["status"] in {"fail","warning"} for r in rows)},
        "limitation":"Checklist covers this version's registry requirements, not every possible scientific threat. Diagnostic implementation is not evidence that an assumption is true; human attestations are not proof."}

def main_findings(report,limit=3):
    """Prioritize claim blockers for local human review; never a validity score.

    Full evidence remains authoritative. Unknown requirements are unresolved,
    not observed failures. Saved claim decisions are recomputed before ranking.
    """
    validate_report(report)
    if type(limit) is not int or not 1<=limit<=10: raise ValueError("Finding limit must be an integer from 1 to 10")
    reg=load_registry(); blockers={r for c in gate_claims(report) for r in c["blockers"] if r in reg["requirements"]}
    order={"fail":0,"warning":1,"not_checked":2,"not_applicable":3}
    rows={}
    for position,e in enumerate(report["evidence"]):
        req=e["requirement"]
        if e["status"] not in order or (e["status"]=="not_applicable" and req not in blockers): continue
        prior=rows.get(req)
        if prior is None or order[e["status"]]<order[prior[1]["status"]]: rows[req]=(position,e)
    actions={"reference_baseline":"Supply predictions from a prespecified training-derived reference on the same evaluation rows.",
        "evaluation_protocol":"Document the split and training-only selection history; obtain a fresh evaluation if these outcomes guided changes.",
        "data_grain":"Record the unit of analysis, entity structure and a named human justification.",
        "timing":"Verify that every feature was available at the prediction cutoff, including label windows.",
        "leakage":"Review source construction and split/preprocessing history; arrays cannot establish absence of leakage.",
        "independence":"Review repeated entities or time dependence before choosing covariance or evaluation methods.",
        "exogeneity":"Provide substantive design justification; residual tests and robust SE cannot establish exogeneity.",
        "functional_form":"Review training residual patterns and scientific mean specification; a changed model requires a reviewed refit.",
        "missingness":"Review missingness and preprocessing ownership; do not silently delete or impute records."}
    for req in sorted(blockers-set(rows)):
        if any(e["requirement"]==req and e["status"]=="no_issue_detected" for e in report["evidence"]):
            diagnostic="Required contextual or source-specific evidence is unresolved despite another recorded check."
        else: diagnostic="Required evidence is not supplied."
        rows[req]=(len(report["evidence"]),{"requirement":req,"status":"not_checked","source":"manual_required", "observed":{},"thresholds":{},"remedies":[],"diagnostic":diagnostic})
    if report['method']=='bayesian_posterior_review':
        workflow={'convergence':0,'prior_specification':1,'likelihood_specification':2,'posterior_predictive':3,'sensitivity_analysis':4}
        selected=sorted(rows.items(),key=lambda item:(0 if item[1][1]['status'] in {'fail','warning'} else 1,
            0 if item[0] in workflow else 1,workflow.get(item[0],9),order[item[1][1]['status']],item[1][0]))[:limit]
    else:
        selected=sorted(rows.items(),key=lambda item:(0 if item[0] in blockers else 1,order[item[1][1]["status"]],item[1][0],item[0]))[:limit]
    from copy import deepcopy
    return [{"requirement":req,"label":reg["requirements"][req]["label"],"status":e["status"],"source":e["source"],
             "blocks_claim":req in blockers,"observed":deepcopy(e["observed"]),"thresholds":deepcopy(e["thresholds"]),
             "next_step":(e["remedies"][0] if e["remedies"] else actions.get(req,"Review the full evidence and document the required justification before strengthening the claim."))}
            for req,(_,e) in selected]


def explain_report(report):
    """Local template, no LLM. Agent users must use the MCP privacy projection."""
    validate_report(report)
    spec=method_spec(report["method"]); reg=load_registry()
    def describe(e):
        observed=json.dumps(e["observed"],sort_keys=True,ensure_ascii=True,allow_nan=False) if e["observed"] else "no numerical comparison supplied"
        thresholds=json.dumps(e["thresholds"],sort_keys=True,ensure_ascii=True,allow_nan=False) if e["thresholds"] else "no numerical threshold; contextual review required"
        return (reg["requirements"][e["requirement"]]["label"]+": "+e["diagnostic"]+
            "; sample_size="+str(e["sample_size"])+"; observed/comparison="+observed+
            "; threshold/configuration="+thresholds+"; result="+e["status"]+" ("+e["source"]+")"+
            ("; limits="+" ".join(e["limitations"]) if e["limitations"] else ""))
    checked=[reg["requirements"][e["requirement"]]["label"] for e in report["evidence"] if e["source"]=="automated" and e["status"] not in {"not_checked","not_applicable"}]
    checks=", ".join(checked[:3])+(f" and {len(checked)-3} further diagnostics" if len(checked)>3 else "")
    details="\n\n".join(describe(e) for e in report["evidence"])
    keys=["mae","rmse","r2","baseline_mae","baseline_rmse","accuracy","baseline_accuracy","balanced_accuracy","f1_macro","log_loss","f1_weighted","roc_auc","average_precision","brier","training_rmse","training_log_loss","residual_df","n_components","retained_training_variance_fraction","fitted_cluster_count","supplied_cluster_count","supplied_inertia","mean_squared_centroid_distance","silhouette_euclidean"]
    brief={key:report["estimates"][key] for key in keys if key in report["estimates"]}
    brief=dict(list(brief.items())[:5])
    observations=json.dumps(brief,sort_keys=False,ensure_ascii=True,allow_nan=False) if brief else "the numerical and evidence summaries recorded below"
    statistical=report["estimates"].get("statistical_test")
    if isinstance(statistical,dict):
        effect=statistical["effect"]; interval=effect["confidence_interval"]
        interval_text=(str(interval["level"]*100)+"% conditional interval ["+str(interval["lower"])+", "+str(interval["upper"])+"]" if interval is not None else "effect interval unimplemented or not computable")
        observations=(effect["name"]+" = "+str(effect["estimate"])+" "+effect["units"]+"; "+interval_text+
            "; "+statistical["statistic_name"]+" = "+str(statistical["statistic"])+"; unadjusted p = "+str(statistical["p_value"])+
            "; n = "+str(report["sample_sizes"].get("n"))+"; split = "+str(statistical.get("source_split","unknown"))+
            ". These are conditional reference calculations, not an assumption pass or causal conclusion")
    survival=report['estimates'].get('survival')
    mixed=report['estimates'].get('mixed_model')
    weighting=report['estimates'].get('ipw')
    bayesian=report['estimates'].get('bayesian_review')
    if isinstance(survival,dict):
        observations=('observed events = '+str(survival['event_count'])+'; right censored = '+str(survival['censored_count'])+
            '; native median = '+str(survival['median_survival'])+' '+survival['time_units']+' ('+survival['median_status']+
            '). The risk table records actual denominators. Independent censoring and event/time-zero definitions remain design assumptions; no confidence band is supplied')
    elif isinstance(mixed,dict):
        points={row['term']:row['estimate'] for row in mixed['fixed_effects'][:3]}
        observations=('native fixed effects = '+json.dumps(points,ensure_ascii=True)+'; random-intercept variance = '+str(mixed['random_intercept_variance'])+
            '; residual variance = '+str(mixed['residual_variance'])+'; conditional ICC = '+str(mixed['conditional_icc'])+
            '. Native uncertainty is conditional on the original grouping, exogeneity, latent distribution and error model; it is not ordinary individual-IID inference')
    elif isinstance(weighting,dict):
        observations=('supplied-score '+str(weighting.get('estimand'))+' weighted group means = '+json.dumps(weighting['group_means'],ensure_ascii=True)+
            '; treated-minus-control weighted contrast = '+str(report['estimates'].get('weighted_contrast'))+
            ' '+str(weighting.get('outcome_units','outcome units (unspecified)'))+'. No effect SE, interval or p-value is implemented. This arithmetic does not identify a causal effect or repair confounding')
    elif isinstance(bayesian,dict):
        observations=('supplied MCMC scalar-summary review = '+str(bayesian['review_status'])+'; '+
            json.dumps(bayesian['supplied_summary'],ensure_ascii=True)+'. No original draws were examined, Rhat/ESS recomputed, sampler run or posterior estimate calculated')
    adapter=report["estimates"].get("adapter",{})
    if report["estimates"].get("adapter_status") in {"unsupported","failed"} and isinstance(adapter,dict):
        observations=json.dumps({"adapter_status":report["estimates"]["adapter_status"],"reason":str(adapter.get("reason","Explicit supported adapter required"))[:240]},ensure_ascii=True)
    full_observations=json.dumps(report["estimates"],sort_keys=True,ensure_ascii=True,allow_nan=False)
    claims=gate_claims(report)
    supported=[reg["claims"][c["id"]]["description"] for c in claims if c["status"]!="blocked"]
    blocked=[c["id"]+" ["+", ".join(c["blockers"])+"]" for c in claims if c["status"]=="blocked"]
    findings=main_findings(report)
    labels={"fail":"observed failure/concern","warning":"observed concern","not_checked":"unresolved evidence","not_applicable":"not applicable; required claim remains blocked"}
    top=[]
    for i,finding in enumerate(findings,1):
        observed={k:v for k,v in finding["observed"].items() if v is None or type(v) in {str,int,float,bool}}
        observed=dict(list(observed.items())[:4])
        comparison=(" Comparison: "+json.dumps(observed,ensure_ascii=True,allow_nan=False)+".") if observed else " Full comparison/context is in the evidence below."
        top.append(f"{i}. {finding['label']}: {labels[finding['status']]}"+("; blocks the corresponding claim." if finding["blocks_claim"] else ".")+comparison+" Next: "+finding["next_step"])
    triage="Main findings (prioritized for review, not a validity score):\n"+"\n".join(top) if top else "No further concerns were prioritized from these recorded checks; this does not verify untestable assumptions."
    coverage=requirement_coverage(report)
    coverage_text="Registry coverage (bookkeeping, not a validity score): "+json.dumps(coverage["counts"],sort_keys=True)+". "+coverage["limitation"]
    checklist="\n".join(r["label"]+": "+r["status"]+"; implementation="+r["diagnostic_support"]+"; "+r["interpretation_support"]+" Next: "+r["next_step"] for r in coverage["requirements"])
    return (f"We used {spec['name']} for purpose {report['purpose']}; checked {checks or 'no automated diagnostics'}; "
            f"observed {observations}; this supports {'; '.join(supported) if supported else 'only the recorded diagnostic observations; the intended strong claims are blocked'} "
            "subject to the recorded requirements and limitations below; it does not establish causality, external validity, diagnostic proof of assumptions, or deployment readiness."
            +"\n\n"+triage+(f"\n\nBlocked claims: {'; '.join(blocked)}." if blocked else "")+"\n\n"+coverage_text+"\n\nFull registry checklist:\n"+checklist+"\n\nFull evidence:\n"+details+
            "\n\nFull numerical results (local data): "+full_observations+"\n\nLimitations: "+" ".join(report["limitations"]))

def to_json(report):
    validate_report(report)
    # Recompute claim gates at every export, ignoring edited stored decisions.
    r=dict(report); r["claims"]=gate_claims(report)
    return json.dumps(r,indent=2,ensure_ascii=True,allow_nan=False)+"\n"
