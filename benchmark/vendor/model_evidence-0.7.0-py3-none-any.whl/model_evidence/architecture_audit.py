"""Supplied-output contracts, never framework/model inspection or training.

CNN/RNN/transformer/autoencoder labels identify caller-declared context. This
module computes only task metrics from explicit arrays and checks bounded
metadata consistency; favorable output metrics cannot validate an architecture.
"""
import math
import re

import numpy as np

from .diagnostics import audit_prediction, _common, _complete, _aggregate_bars
from .multiclass import audit_multiclass, _labels, _encoded, _check_index
from .report import evidence, make_report
from . import model_visuals as visuals

ARCHITECTURES = {"cnn", "rnn", "transformer", "autoencoder"}
METHOD = "architecture_output_review"
MAX_CELLS = 200_000
SPLITS = {"unknown", "training", "validation", "evaluation", "final_holdout"}
_META = {"stage", "input_shape", "layout", "sequence_lengths", "max_sequence_length",
         "padding_convention", "evaluated_padding_positions", "target_role",
         "evaluation_mode", "preprocessing_scope", "state_reset_policy", "framework", "output_units"}
LIMITS = [
    "Only supplied outputs/targets and declared metadata were inspected; no framework object, weights, tensors, tokenizer, masks, gradients or hidden state were accessed.",
    "Good reconstruction or prediction metrics do not establish representation meaning, anomaly detection, architecture correctness, calibration outside these rows, causality or external validity.",
    "Pretraining, fine-tuning and inference have different requirements; no universal training-from-scratch sample-size, normality or scaling threshold is imposed.",
    "Raw outputs, targets and per-sequence lengths are not retained. Aggregate metrics and metadata can still be sensitive.",
]


def _integer(value, name, *, minimum=0, maximum=1_000_000):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)) or not minimum <= value <= maximum:
        raise ValueError(name + " must be a bounded integer")
    return int(value)


def _numeric(value, name, ndim):
    if np.ma.isMaskedArray(value) and np.ma.getmaskarray(value).any():
        raise ValueError(name + " contains masked values; no missingness is repaired")
    if isinstance(value, (list, tuple)):
        raw = np.asarray(value, dtype=object)
        if raw.size > MAX_CELLS or any(isinstance(v, (bool, np.bool_, str, complex, np.complexfloating)) for v in raw.flat):
            raise ValueError(name + " cannot silently coerce boolean, text or complex cells")
    a = np.asarray(value)
    if a.ndim != ndim or a.size > MAX_CELLS or not a.size or a.dtype.kind not in "iuf":
        raise ValueError(name + " must be a bounded real numeric array of the required shape")
    a = np.asarray(a, dtype=float)
    if not np.isfinite(a).all() or np.any(np.abs(a) > 1e12):
        raise ValueError(name + " must be finite with absolute values <=1e12")
    return a


def _metadata(value):
    if value is None: return {}
    if not isinstance(value, dict) or set(value) - _META:
        raise ValueError("Unknown architecture_metadata fields; code, paths and framework objects are unsupported")
    result = dict(value)
    enums = {"stage": {"unknown", "training_from_scratch", "fine_tuning", "inference"},
             "evaluation_mode": {"unknown", "training", "evaluation"},
             "preprocessing_scope": {"unknown", "training_only", "evaluation_informed"},
             "target_role": {"unknown", "input", "clean_reference", "other"},
             "state_reset_policy": {"unknown", "between_entities", "continuous_stream"}}
    for key, allowed in enums.items():
        if key in result and (not isinstance(result[key], str) or result[key] not in allowed):
            raise ValueError("Unknown " + key + " declaration")
    for key in ("layout", "padding_convention", "framework", "output_units"):
        if key in result and (not isinstance(result[key], str) or not re.fullmatch(r"[A-Za-z0-9_, .()/-]{1,120}", result[key])):
            raise ValueError(key + " must be short printable metadata, never executable content")
    if "input_shape" in result:
        shape = result["input_shape"]
        if not isinstance(shape, (list, tuple)) or not 2 <= len(shape) <= 8:
            raise ValueError("input_shape must contain 2..8 positive dimensions with batch first")
        result["input_shape"] = [_integer(v, "input_shape dimension", minimum=1) for v in shape]
    for key in ("max_sequence_length", "evaluated_padding_positions"):
        if key in result: result[key] = _integer(result[key], key, minimum=1 if key == "max_sequence_length" else 0, maximum=1_000_000_000)
    if "sequence_lengths" in result:
        values = result["sequence_lengths"]
        if not isinstance(values, (list, tuple, np.ndarray)) or not 1 <= len(values) <= 100_000:
            raise ValueError("sequence_lengths must be a bounded aligned integer vector")
        result["sequence_lengths"] = [_integer(v, "sequence length") for v in values]
    return result


def _row(req, status, text, n, observed=None, *, source="automated", limits=None):
    return evidence(req, status, text, source=source, sample_size=n,
        observed={"group": "supplied task outputs and declared metadata", **(observed or {})},
        thresholds={"configuration": "Exact declared array/metadata comparisons; no universal adequacy cutoff"},
        limitations=LIMITS[:1] + list(limits or []),
        remedies=["Review the source data/model pipeline and rerun under a prespecified task, split and preprocessing protocol; do not silently repair outputs."],
        provenance={"implementation": "supplied-architecture/0.7.0", "framework_accessed": False, "model_fitted": False})


def _context_rows(architecture, info, n, task, split):
    shape = info.get("input_shape")
    mismatch = shape is not None and shape[0] != n
    rows = [_row("architecture_input_contract", "fail" if mismatch else "not_checked",
        "Declared batch dimension differs from supplied output rows" if mismatch else "Declared input metadata is recorded; no actual tensor/channel/layout or training representation was inspected", n,
        {"declared_input_shape": shape, "output_rows": n, "comparison": "declared batch-first input_shape[0] versus supplied output row count"}),
        _row("output_alignment", "no_issue_detected", "Supplied target/output row counts and explicit class/probability order were checked", n,
             {"paired_rows": n, "comparison": "each supplied target paired with one output in unchanged order"},
             limits=["Position/index agreement cannot prove the outputs were generated from these source records."]),
        _row("output_alignment", "not_checked", "Source-record to model-output correspondence needs independently justified provenance", n, source="manual_required"),
        _row("architecture_state", "not_checked", "Training/evaluation mode, layers, dropout/batch normalization and hidden-state behavior were not inspected", n, source="manual_required",
             observed={"declared_stage": info.get("stage", "unknown"), "declared_evaluation_mode": info.get("evaluation_mode", "unknown")})]
    if info.get("evaluation_mode") == "training" and split in {"evaluation", "final_holdout"}:
        rows.append(_row("architecture_state", "warning", "Caller declares training mode for evaluation outputs; review stochastic/stateful layer behavior", n,
                         {"declared_mode": "training", "declared_split": split}))
    if info.get("preprocessing_scope") == "evaluation_informed":
        rows.append(_row("leakage", "fail", "Caller reports evaluation-informed preprocessing; untouched evaluation is not established", n,
                         {"preprocessing_scope": "evaluation_informed", "comparison": "training-only selection/preprocessing required for untouched evaluation"}))
    sequential = architecture in {"rnn", "transformer"} or "sequence_lengths" in info
    lengths = info.get("sequence_lengths")
    if lengths is not None and len(lengths) != n: raise ValueError("sequence_lengths must align with every supplied task output")
    if sequential:
        rows.append(_row("sequence_semantics", "not_checked", "Order, windows, entity boundaries, truncation and state-reset/tokenization semantics require source review", n,
            {"declared_state_reset_policy": info.get("state_reset_policy", "unknown")}, source="manual_required"))
        maximum = info.get("max_sequence_length")
        exceeds = None if lengths is None or maximum is None else sum(v > maximum for v in lengths)
        padding_scored = info.get("evaluated_padding_positions")
        failed = bool(exceeds) or (padding_scored is not None and padding_scored > 0)
        observed = {"length_count": None if lengths is None else len(lengths),
                    "minimum_length": None if lengths is None else min(lengths),
                    "maximum_length": None if lengths is None else max(lengths),
                    "declared_max_sequence_length": maximum, "lengths_exceeding_declared_maximum": exceeds,
                    "declared_evaluated_padding_positions": padding_scored,
                    "declared_padding_convention": info.get("padding_convention", "unknown")}
        rows.append(_row("padding_mask", "fail" if failed else "not_checked",
            "Declared length or evaluated-padding inconsistency" if failed else "Declared length/padding scope recorded; no actual masks or token/step-level denominators inspected", n, observed,
            limits=["Boolean mask conventions differ between APIs. No universal True-means-padding rule is assumed.", "These contracts evaluate one scalar/class per supplied row, not token/step-level generation or language-model perplexity."]))
    else:
        for req in ("sequence_semantics", "padding_mask"):
            rows.append(_row(req, "not_applicable", "Sequence-specific contract not selected for these row-level outputs; this is not an architecture-wide exemption", n, source="manual_required"))
    rows.append(_row("reconstruction_target", "not_checked" if task == "reconstruction" else "not_applicable",
        "Reconstruction target, feature weighting/units and corruption/anomaly protocol need review" if task == "reconstruction" else "No reconstruction task requested", n,
        {"declared_target_role": info.get("target_role", "unknown")}, source="manual_required"))
    return rows


def audit_supplied_architecture(architecture, payload, y, *, purpose="prediction", metadata=None,
        attestations=None, split_role="unknown", baseline_predictions=None, positive_label=None):
    """Audit explicit output arrays for one declared architecture/task.

    ``payload`` has task plus predictions/classes/probabilities, or reconstruction.
    Architecture-specific validation remains manual/unimplemented. No arbitrary
    framework object, model loading, callback or source execution is accepted.
    """
    if not isinstance(architecture, str) or architecture not in ARCHITECTURES:
        raise ValueError("Expected cnn, rnn, transformer or autoencoder")
    if not isinstance(split_role, str) or split_role not in SPLITS: raise ValueError("Unknown split role")
    if not isinstance(payload, dict) or set(payload) - {"task", "predictions", "classes", "probabilities", "reconstruction", "architecture_metadata"}:
        raise ValueError("Unknown supplied-output contract fields")
    task = payload.get("task")
    if not isinstance(task, str) or task not in {"regression", "classification", "reconstruction"}:
        raise ValueError("task must be regression, classification or reconstruction")
    if task == "reconstruction" and architecture != "autoencoder":
        raise ValueError("The bounded reconstruction contract is explicitly scoped to autoencoder outputs")
    if purpose != ("description" if task == "reconstruction" else "prediction"):
        raise ValueError("Prediction outputs need purpose prediction; reconstruction needs description")
    if metadata is not None and (not isinstance(metadata, dict) or set(metadata) - {"entity_ids", "split_evidence"}):
        raise ValueError("Output-only metadata supports entity_ids and prespecified split_evidence; original feature timing remains manual because source inputs are unavailable")
    info = _metadata(payload.get("architecture_metadata"))
    if task == "reconstruction":
        if set(payload) & {"predictions", "classes", "probabilities"}: raise ValueError("Reconstruction cannot silently mix classification outputs")
        truth = _numeric(y, "reconstruction target", 2); reconstructed = _numeric(payload.get("reconstruction"), "reconstruction", 2)
        if truth.shape != reconstructed.shape or truth.shape[0] < 3 or truth.shape[1] > 512:
            raise ValueError("Reconstruction matrices must align exactly, with >=3 rows and <=512 columns")
        _check_index(y, payload.get("reconstruction"), "reconstruction")
        columns = getattr(y, "columns", None); other_columns = getattr(payload.get("reconstruction"), "columns", None)
        if columns is not None and other_columns is not None and list(columns) != list(other_columns):
            raise ValueError("Reconstruction feature columns/order differ from target; align explicitly")
        n, p = truth.shape; delta = reconstructed - truth
        mse = float(np.mean(delta ** 2)); mae = float(np.mean(np.abs(delta))); rmse = math.sqrt(mse)
        values = {"mse": mse, "rmse": rmse, "mae": mae, "cell_denominator": int(truth.size), "n_features": p}
        rows = _common(reconstructed, None, metadata)
        for e in rows:
            if e["requirement"] == "missingness":
                e["observed"].update(total_cells=int(2 * truth.size), nonfinite_cells=0, variables=["supplied reconstruction and target cells"])
                e["limitations"].append("Original encoder inputs and preprocessing were not inspected.")
        rows.append(_row("target_compatibility", "no_issue_detected", "Finite equally shaped reconstruction/target matrices; no flattening, weighting or normalization applied", n,
                         {"rows": n, "features": p, "cell_denominator": int(truth.size)}))
        labels = ["reconstruction MAE", "reconstruction RMSE"]; metrics = [mae, rmse]
        if baseline_predictions is not None:
            baseline = _numeric(baseline_predictions, "reference reconstruction", 2)
            _check_index(y, baseline_predictions, "reference reconstruction")
            reference_columns = getattr(baseline_predictions, "columns", None)
            if columns is not None and reference_columns is not None and list(columns) != list(reference_columns):
                raise ValueError("Reference reconstruction columns/order differ from target")
            if baseline.shape != truth.shape: raise ValueError("Reference reconstruction must have the same declared cell support")
            diff = baseline - truth
            values.update(baseline_mae=float(np.mean(np.abs(diff))), baseline_rmse=float(np.sqrt(np.mean(diff ** 2))))
            labels += ["reference MAE", "reference RMSE"]; metrics += [values["baseline_mae"], values["baseline_rmse"]]
            rows.append(_row("reference_baseline", "no_issue_detected", "Supplied reconstruction/reference errors compared on identical cells", n,
                {"model_rmse": rmse, "reference_rmse": values["baseline_rmse"], "cell_denominator": int(truth.size)},
                limits=["Reference selection must be justified from training data; this comparison does not establish source independence or anomaly performance."]))
        units = info.get("output_units", "supplied feature units (unspecified)")
        panels = [_aggregate_bars("reconstruction_metrics", "Supplied reconstruction errors versus explicit reference", labels, metrics, n, split_role,
            role="main_result", units=units, comparison="Cell-weighted MAE and RMSE; each supplied cell receives equal weight",
            interpretation="These errors quantify reconstruction in the supplied representation; feature scales determine their meaning, not anomaly accuracy or semantic usefulness.", limitations=LIMITS)]
        panels.append(visuals.histogram_panel("reconstruction_row_error", "Distribution of per-row reconstruction RMSE", np.sqrt(np.mean(delta ** 2, axis=1)),
            role="diagnostic", requirement="reconstruction_target", source_split=split_role, units=units,
            comparison="Each row contributes its feature-averaged squared error square root", threshold=None,
            interpretation="The distribution exposes heterogeneous reconstruction error; no anomaly threshold is selected.", limitations=LIMITS))
        est = {"mae": mae, "rmse": rmse, "reconstruction": values,
               "visual_evidence": visuals._finish(n, split_role, panels)}
    else:
        if "reconstruction" in payload or "predictions" not in payload: raise ValueError("Prediction contracts require explicit predictions and cannot contain reconstruction")
        _check_index(y, payload["predictions"], "predictions")
        if baseline_predictions is not None: _check_index(y, baseline_predictions, "baseline_predictions")
        if task == "regression":
            if set(payload) & {"classes", "probabilities"} or positive_label is not None: raise ValueError("Regression cannot consume class/probability fields")
            base = audit_prediction(y, payload["predictions"], task="regression", baseline_predictions=baseline_predictions,
                                    metadata=metadata, split_role=split_role)
        else:
            classes, kind = _labels(payload.get("classes"), "classes", minimum=2, maximum=32)
            if len(set(classes)) != len(classes): raise ValueError("Class order must be explicit and unique")
            _check_index(y, payload["predictions"], "predictions")
            if len(classes) > 2:
                if positive_label is not None: raise ValueError("Multiclass output has no single positive label")
                base = audit_multiclass(y, payload["predictions"], classes=classes, probabilities=payload.get("probabilities"),
                                        baseline_predictions=baseline_predictions, metadata=metadata)
            else:
                observed = _encoded(y, "y_true", classes, kind); predicted = _encoded(payload["predictions"], "predictions", classes, kind, n=len(observed))
                positive = classes[1] if positive_label is None else positive_label
                if positive not in classes: raise ValueError("positive_label must belong to explicit classes")
                index = classes.index(positive); probability = None
                if payload.get("probabilities") is not None:
                    q = _numeric(payload["probabilities"], "probabilities", 2)
                    _check_index(y, payload["probabilities"], "probabilities")
                    columns = getattr(payload["probabilities"], "columns", None)
                    if columns is not None and list(columns) != classes: raise ValueError("Probability DataFrame columns must equal explicit class order")
                    if q.shape != (len(observed), 2) or np.any((q < 0) | (q > 1)) or not np.allclose(q.sum(axis=1), 1., rtol=0., atol=1e-8):
                        raise ValueError("Probabilities must be finite n-by-2 rows summing to one in declared order; no renormalization")
                    probability = q[:, index]
                baseline = None if baseline_predictions is None else (_encoded(baseline_predictions, "baseline_predictions", classes, kind, n=len(observed)) == index).astype(float)
                base = audit_prediction((observed == index).astype(float), (predicted == index).astype(float), task="classification",
                    probabilities=probability, baseline_predictions=baseline, metadata=metadata, split_role=split_role)
                binary_visual = visuals.classification_visual_evidence((observed == index).astype(int), (predicted == index).astype(int), classes=[0, 1],
                    probabilities=None if probability is None else np.column_stack((1. - probability, probability)), source_split=split_role)
                base["estimates"]["positive_label"] = positive
                base["estimates"]["visual_class_orientation"] = "class position 2 is the explicitly selected positive label; supplied probability columns were not changed"
            base["estimates"]["declared_class_order"] = classes
        n = base["sample_sizes"]["n"]; p = 0; rows = base["evidence"]; est = base["estimates"]
        # Supplied metrics do not mean the original model inputs passed a check.
        for e in rows:
            if e["requirement"] == "missingness": e["limitations"].append("Only supplied outputs/targets were checked; no original input tensor or preprocessing was inspected.")
        if task == "classification":
            visual = binary_visual if len(classes) == 2 else visuals.classification_visual_evidence(y, payload["predictions"], classes=classes,
                        probabilities=payload.get("probabilities"), source_split=split_role)
            est["visual_evidence"] = visual
    rows = [e for e in rows if not (e["source"] == "manual_required" and e["requirement"] in {"architecture_input_contract", "output_alignment", "architecture_state", "sequence_semantics", "padding_mask", "reconstruction_target"})]
    extra = _context_rows(architecture, info, n, task, split_role)
    # A supplied leakage declaration supersedes an automated placeholder.
    for e in extra:
        if e["source"] == "automated": rows = [old for old in rows if not (old["requirement"] == e["requirement"] and old["source"] == "automated")]
        rows.append(e)
    if split_role in {"training", "unknown"}:
        rows = [e for e in rows if not (e["requirement"] == "evaluation_protocol" and e["source"] == "automated")]
        rows.append(_row("evaluation_protocol", "warning", "Training or unknown split cannot establish untouched evaluation", n, {"source_split": split_role}))
    public_meta = {k: v for k, v in info.items() if k != "sequence_lengths"}
    est["architecture_review"] = {"architecture": architecture, "task": task, "declared_metadata": public_meta,
        "source_split": split_role,
        "sequence_context": architecture in {"rnn", "transformer"} or "sequence_lengths" in info,
        "framework_accessed": False, "model_refit": False, "architecture_checks_implemented": False,
        "metric_scope": "conditional supplied-output evaluation only; not a fitted architecture adapter"}
    return make_report(METHOD, purpose, _complete(METHOD, purpose, rows, attestations), {"n": n, "p": p}, est, LIMITS)
