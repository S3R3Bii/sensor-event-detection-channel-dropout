"""Exact method-specific rows for bounded0.6 reports; no recomputation."""


def extension_rows(report,context,rows,add):
    values=report['estimates'];method=report['method']
    def row(label,value,units,comparison,*,n=None,status='computed_comparison',threshold='No universal adequacy cutoff',limits=None,group='All supplied rows'):
        add(rows,label,stage='method-specific results',context=context,original=value,units=units,
            comparison=comparison,status=status,n=n,threshold=threshold,group=group,
            interpretation='Conditional supplied-data/model summary; required scientific assumptions remain separate.',
            limitations=limits or ['No causal, sampling or external-validity certificate follows from this value.'],
            source='retained method result; same values as figures',remedy='Review design, uncertainty and unresolved requirements before strengthening interpretation.')
    if method=='kaplan_meier' and isinstance(values.get('survival'),dict):
        d=values['survival'];units=d['time_units']
        for key,unit in [('event_count','observed events'),('censored_count','right-censored observations'),('censoring_fraction','fraction of supplied observations'),('median_survival',units)]:
            row(key.replace('_',' '),d[key],unit,d.get('median_definition','') if key=='median_survival' else 'Recorded event/censor counts; denominator supplied observations',status='not_checked' if d[key] is None else 'computed_comparison')
        for item in d['risk_table']:
            row('Native survival risk row',item,'time: '+units+'; survival: probability; risk/events/censors: observations',
                'Native risk set just before this observed time; event/censor tie convention retained; bounded selected rows must not be summed',
                group='Time '+str(item.get('time')),n=item.get('n_at_risk_before'),limits=['Conditional Greenwood SE is not a confidence band; undefined/unknown uncertainty remains null.',d['risk_table_scope']])
    elif method=='gaussian_mixed_intercept' and isinstance(values.get('mixed_model'),dict):
        d=values['mixed_model']
        for item in d['fixed_effects']:
            name=item['term']
            for key,unit in [('estimate','coefficient units'),('confidence_interval','coefficient units'),('standard_error','coefficient units'),('p_value','dimensionless')]:
                value=item.get(key)
                if key=='confidence_interval':value=[item.get('ci_lower'),item.get('ci_upper')] if item.get('ci_lower') is not None and item.get('ci_upper') is not None else None
                row('Fixed effect '+name+': '+key.replace('_',' '),value,unit,'Existing native fixed-effect '+d['uncertainty_reference'],
                    status='not_checked' if value is None else 'computed_comparison',threshold={'confidence_level':d['confidence_level'],'reference':d['uncertainty_reference']} if key=='confidence_interval' else {'reference':d['uncertainty_reference']},
                    limits=['Random-intercept grouping, exogeneity and conditional covariance assumptions remain unverified.','No variance-component significance test, group BLUP or individual-level IID claim is inferred.'])
        for key,unit in [('random_intercept_variance','squared response units'),('residual_variance','squared response units'),('conditional_icc','dimensionless variance fraction')]:
            row(key.replace('_',' '),d[key],unit,'Native cov_re[0,0], residual scale and tau2/(tau2+sigma2); no packed parameter substitution')
    elif method=='causal_weighting' and isinstance(values.get('ipw'),dict):
        d=values['ipw'];units=d.get('outcome_units','outcome units (unspecified)')
        for group,mean in d['group_means'].items():
            row('Weighted '+group+' mean',mean,units,'Arm-normalized supplied-propensity '+str(d.get('estimand'))+' weighted mean',group=group)
        row('Weighted contrast',values['weighted_contrast'],units,'Treated weighted mean minus control weighted mean; conditional arithmetic, not identified causation')
        for group,summary in d['weight_summary'].items():
            row(group+' weight/ESS summary',summary,'weights: dimensionless; counts: observations; ESS: effective observations',
                'ESS=(sum w)^2/sum w^2; actual versus effective counts, no automatic clipping or trimming',group=group)
        row('Effect uncertainty',None,units,'Estimated-propensity/design-aware effect SE/CI/p-value is not implemented',status='not_checked',limits=['No interval or p-value is manufactured from normalized weights.','Changing estimand or trimming changes the target question/population and requires explicit rerun.'])
    elif method=='bayesian_posterior_review' and isinstance(values.get('bayesian_review'),dict):
        for item in values['bayesian_review']['comparisons']:
            row('Supplied MCMC '+item['metric'],item['value'],item['units'],
                'Supplied scalar '+item['operator']+' '+str(item['reference'])+'; no chain diagnostic recomputed',
                status='warning' if item['concern'] else 'not_assessed',threshold={'operator':item['operator'],'reference':item['reference']},
                limits=['Summary provenance and scope are caller declarations.','Good scalar summaries do not prove convergence, prior/likelihood adequacy or posterior validity.'])
    elif method in {'hierarchical_clustering','dbscan'}:
        for key,unit in [('fitted_cluster_count','nonnoise clusters'),('noise_count','observations'),('noise_fraction','fraction of all supplied observations'),('silhouette','dimensionless internal separation'),('silhouette_n','scored nonnoise observations'),('silhouette_eligible_n','eligible nonnoise observations'),('silhouette_excluded_noise_count','excluded noise observations')]:
            if key in values:
                row(key.replace('_',' '),values[key],unit,'Supplied frozen-fit labels; noise excluded only from explicitly labeled silhouette denominator',
                    status='not_checked' if values[key] is None else 'computed_comparison',
                    limits=['Internal separation does not establish stability, natural groups, valid geometry or external relevance.','Current fitted-object configuration is editable and is not authenticated fit-time provenance.'])
        for identifier,size in zip(values.get('supplied_cluster_ids',[]),values.get('supplied_cluster_sizes',[])):
            row('Noise count' if identifier==-1 else 'Cluster size',size,'observations','Counts over all supplied rows, including a separate DBSCAN noise category',group='Noise (-1)' if identifier==-1 else 'Cluster '+str(identifier))
    elif method=='architecture_output_review':
        d=values.get('reconstruction',{})
        units=values.get('architecture_review',{}).get('declared_metadata',{}).get('output_units','supplied feature units (unspecified)')
        for key,unit in [('mse','squared '+units),('mae',units),('rmse',units),('cell_denominator','equally weighted supplied cells'),('n_features','supplied reconstruction columns'),('baseline_mae',units),('baseline_rmse',units)]:
            if key in d:row('Reconstruction '+key.replace('_',' '),d[key],unit,'Explicit target versus supplied reconstruction on identical rows/cells; no model executed',
                limits=['Reconstruction scores depend on target definition, units and feature weighting.','No anomaly threshold, semantic representation or architecture validity follows.'])
        row('Architecture inspection',None,'not assessed','Only explicit output arrays and declared metadata were inspected',status='not_checked',
            limits=['No CNN/RNN/transformer/autoencoder framework object, weights, masks, gradients or training state were accessed.'])
