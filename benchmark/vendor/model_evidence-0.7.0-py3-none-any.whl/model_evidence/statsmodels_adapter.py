"""Optional existing-fit statsmodels adapters; no fitting or pickle loading.

Only trusted, already constructed, exact stock results/model classes are read.
Formula prediction remains owned by the fitted statsmodels/Patsy design. The
adapter never accepts/evaluates a new formula or reconstructs preprocessing.
"""
from copy import deepcopy, copy
import math
import warnings
import numpy as np
from scipy.optimize import linprog
from sklearn.metrics import log_loss

from .diagnostics import _common, _attest, audit_prediction
from .report import evidence, make_report, gate_claims, validate_report

ADAPTER_VERSION="statsmodels-fitted/0.5.0"
MAX_CELLS=2_000_000


def is_statsmodels_candidate(value):
    return type(value).__module__.startswith("statsmodels.")


def _bad(reason,purpose,requirement=None,n=0,p=0):
    from .adapters import _unsupported
    return _unsupported(reason,purpose,n=n,p=p,failed_requirement=requirement,model_name="statsmodels fitted results")


def _array(value,ndim,name):
    if np.ma.isMaskedArray(value) and np.ma.getmaskarray(value).any():
        raise ValueError(name+" contains masked cells; no mask is silently removed")
    if np.iscomplexobj(value): raise ValueError(name+" must be real")
    try: a=np.asarray(value,dtype=float)
    except (ValueError,TypeError) as exc:
        raise ValueError(name+" must be numeric; raw conversion-error text is withheld") from exc
    if a.ndim!=ndim or not a.size or a.size>MAX_CELLS or not np.isfinite(a).all() or np.any(np.abs(a)>1e100):
        raise ValueError(name+" must contain bounded finite aligned values")
    return a


def _stock(result):
    """Exact-class allowlist; importing this optional library happens on demand."""
    from statsmodels.regression.linear_model import OLS, OLSResults, RegressionResultsWrapper
    from statsmodels.discrete.discrete_model import Logit, LogitResults, BinaryResultsWrapper
    from statsmodels.genmod.generalized_linear_model import GLM, GLMResults, GLMResultsWrapper
    from statsmodels.genmod.families import Binomial, Poisson
    from statsmodels.genmod.families import links
    from statsmodels.genmod.families.links import Logit as LogitLink
    wrappers={RegressionResultsWrapper,BinaryResultsWrapper,GLMResultsWrapper}
    raw=result._results if type(result) in wrappers else result
    if type(raw) is OLSResults and type(raw.model) is OLS: kind="ols"
    elif type(raw) is LogitResults and type(raw.model) is Logit: kind="logistic"
    elif type(raw) is GLMResults and type(raw.model) is GLM:
        if type(raw.model.family) is Binomial and type(raw.model.family.link) in {LogitLink,links.logit}:
            kind="logistic"
        elif type(raw.model.family) is Poisson and type(raw.model.family.link) in {links.Log,links.log}:
            kind="poisson_glm"
        else:
            raise ValueError("Only stock binomial-logit or Poisson-log GLM fitted results are supported; other families/custom links need a separate adapter")
    else:
        raise ValueError("Only exact stock OLS, Logit, binomial-logit and Poisson-log GLM fitted results are supported; weighted, regularized, generalized or subclassed results are not ordinary unpenalized fits")
    model=raw.model
    if any(getattr(model,key,None) is not None for key in ("offset","exposure")):
        raise ValueError("Offset/exposure models are unsupported by this bounded adapter")
    for key in ("freq_weights","var_weights","iweights","n_trials"):
        value=getattr(model,key,None)
        if value is not None and not np.all(np.asarray(value)==1):
            raise ValueError("Grouped-binomial or nonunit weighted fits are unsupported; no unweighted interpretation is invented")
    if any(bool(getattr(model,key,False)) for key in ("_has_freq_weights","_has_var_weights")):
        raise ValueError("Explicit frequency/variance-weighted GLM fits are unsupported by this unweighted adapter")
    orig_endog=getattr(model.data,"orig_endog",None)
    if orig_endog is not None and np.asarray(orig_endog).ndim>1 and np.asarray(orig_endog).shape[1]!=1:
        raise ValueError("Grouped or multi-column binomial outcomes are unsupported; individual 0/1 observations are required")
    # Native lazy properties populate a results cache. A shallow read view with
    # its own cache avoids adding derived values to the caller's result.
    view=copy(raw)
    view._cache=dict(getattr(raw,"_cache",{}))
    return view,kind


def _row_labels(value):
    index=getattr(value,"index",None)
    if not hasattr(index,"equals"): return None
    if index is not None and getattr(index,"has_duplicates",False):
        raise ValueError("Duplicate named row indexes cannot establish unique row alignment; supply explicitly reviewed unique positions/names")
    return index


def _input(result,X,y,kind):
    from .adapters import _input_info,_alignment
    n,p,features,named=_input_info(X)
    if n<3: raise ValueError("At least three observed prediction rows are required")
    _row_labels(X); _row_labels(y)
    target,alignment=_alignment(X,y,n)
    target=_array(target,1,"observed y")
    formula=hasattr(result.model.data,"design_info")
    names=list(result.model.exog_names)
    if formula:
        if not named: raise ValueError("Formula fitted results require named raw newdata; a transformed matrix is not accepted as raw formula input")
        raw_frame=getattr(result.model.data,"frame",None)
        if raw_frame is None: raise ValueError("Formula raw-input provenance is unavailable")
        # Native Patsy design_info owns factors, interactions and categories.
        # Reject a common double-transformation case before native prediction.
        if all(name in features for name in names) and any(name not in raw_frame.columns for name in names):
            raise ValueError("Already-transformed design columns were supplied to a raw formula adapter; provide original named variables")
    else:
        if p!=len(names): raise ValueError("Prediction matrix must include exactly the fitted design columns, including any original intercept; no column is silently added")
        original=getattr(result.model.data,"orig_exog",None)
        original_names=getattr(original,"columns",None)
        if named and original_names is not None and features!=list(original_names):
            raise ValueError("Named prediction design columns differ from the fitted names/order; no automatic reordering is performed")
        _array(X,2,"prediction design")
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        try: prediction=result.predict(X)
        except Exception as exc:
            # Native errors can contain raw categories/records. Do not copy them.
            raise ValueError("Native prediction failed; check the original formula variables, fitted categorical levels and finite values. Native error text is withheld") from exc
    pred_index=getattr(prediction,"index",None); input_index=getattr(X,"index",None)
    if pred_index is not None and input_index is not None and not pred_index.equals(input_index):
        raise ValueError("Native prediction changed the supplied row index/order; no rows are silently dropped or realigned")
    pred=_array(prediction,1,"native predictions")
    if len(pred)!=n: raise ValueError("Native prediction omitted or changed rows; no target realignment is inferred")
    if kind=="logistic" and (not np.isin(target,[0.,1.]).all() or not np.all((pred>=0)&(pred<=1))):
        raise ValueError("Binary statsmodels prediction requires individual target coding 0/1 and finite probabilities")
    if kind=="poisson_glm" and (np.any(target<0) or np.any(target>=2**53) or np.any(target!=np.floor(target)) or np.any(pred<=0)):
        raise ValueError("Poisson prediction requires nonnegative integer observed counts and strictly positive native mean predictions; no rounding or clipping occurs")
    return target,pred,n,p,features,alignment,len(caught),formula


def _coefficient_values(result,names):
    """Read existing covariance/reference choices, omitting undefined uncertainty."""
    params=_array(result.params,1,"fitted parameters")
    if len(params)!=len(names): raise ValueError("Fitted parameter names and values disagree")
    k=len(params)
    if not all(isinstance(name,str) and name and len(name)<=128 for name in names) or len(set(names))!=k:
        raise ValueError("Fitted coefficient names must be unique bounded strings")
    try:
        covariance=np.asarray(result.cov_params(),dtype=float)
        standard=np.asarray(result.bse,dtype=float)
        statistics=np.asarray(result.tvalues,dtype=float)
        pvalues=np.asarray(result.pvalues,dtype=float)
        interval=np.asarray(result.conf_int(alpha=.05),dtype=float)
        available=(covariance.shape==(k,k) and standard.shape==(k,) and statistics.shape==(k,) and pvalues.shape==(k,)
            and interval.shape==(k,2) and np.isfinite(covariance).all() and np.isfinite(standard).all()
            and np.isfinite(statistics).all() and np.isfinite(pvalues).all() and np.isfinite(interval).all()
            and np.all(standard>=0) and np.all((pvalues>=0)&(pvalues<=1)) and np.all(interval[:,0]<=interval[:,1]))
    except (ValueError,TypeError,AttributeError,np.linalg.LinAlgError): available=False
    def finite(value): return float(value) if available and math.isfinite(float(value)) and abs(float(value))<=1e100 else None
    table=[]
    for i,name in enumerate(names):
        table.append({"term":name,"estimate":float(params[i]),"standard_error":finite(standard[i]) if available else None,
            "statistic":finite(statistics[i]) if available else None,"p_value":finite(pvalues[i]) if available else None,
            "ci_lower":finite(interval[i,0]) if available else None,"ci_upper":finite(interval[i,1]) if available else None})
    values={"coefficients":params.tolist(),"coefficient_names":names,"coefficient_table":table,
        "covariance_type":str(getattr(result,"cov_type","unavailable"))[:128],"uncertainty_available":bool(available),
        "uncertainty_reference":"t with reported residual degrees of freedom" if bool(getattr(result,"use_t",False)) else "normal/asymptotic reference from existing result",
        "confidence_level":.95}
    if available:
        values["standard_errors"]=standard.tolist()
        values["coefficient_covariance"]=covariance.tolist()
    return values,available


def _logistic_evidence(result,A,y):
    n,k=A.shape; events=int(y.sum()); minority=min(events,n-events)
    ret=getattr(result,"mle_retvals",None)
    known=isinstance(ret,dict) and type(ret.get("converged")) in {bool,np.bool_}
    converged=bool(ret["converged"]) if known else getattr(result,"converged",None)
    if type(converged) not in {bool,np.bool_}: converged=None
    status="not_checked" if converged is None else "no_issue_detected" if converged else "fail"
    rows=[evidence("convergence",status,"Recorded native solver convergence state; fitting was not rerun",sample_size=n,
        observed={"native_converged":None if converged is None else bool(converged)},
        thresholds={"comparison":"native convergence flag is true; no certification of specification or separation"},
        limitations=["A successful optimizer flag does not establish finite unpenalized MLE or rule out separation."]),
        evidence("event_information","warning" if minority/k<10 else "no_issue_detected","Minority observed events per fitted parameter heuristic",sample_size=n,
            observed={"events":events,"nonevents":n-events,"parameters":k,"minority_per_parameter":minority/k},thresholds={"warning_below":10},
            limitations=["Ten is a screening heuristic, not a universal sample-size rule."])]
    # Same-design LP screen only; never fit a replacement logistic model.
    # Positive column rescaling preserves separation with or without an
    # intercept. Mean-centering a no-intercept design changes its model class.
    scale=np.std(A,axis=0)
    scale=np.where(scale>1e-12,scale,np.maximum(np.max(np.abs(A),axis=0),1.))
    D=A/scale
    margins=(2*y-1)[:,None]*D
    try:
        complete=linprog(np.zeros(k),A_ub=-margins,b_ub=-np.ones(n),bounds=[(None,None)]*k,method="highs")
        quasi=linprog(np.zeros(k),A_ub=np.vstack([-margins,-margins.sum(axis=0)]),b_ub=np.r_[np.zeros(n),-1.],bounds=[(None,None)]*k,method="highs")
        separated=bool(complete.success or quasi.success); known=complete.status in {0,2} and quasi.status in {0,2}
        rows.append(evidence("separation","fail" if separated else "no_issue_detected" if known else "not_checked",
            "Complete/quasi-separation LP screen on the stored design, without refitting",sample_size=n,
            observed={"complete_detected":bool(complete.success),"quasi_or_complete_detected":bool(quasi.success),"complete_solver_status":int(complete.status),"quasi_solver_status":int(quasi.status)},
            thresholds={"complete_signed_margin":1,"quasi_nonnegative_margins":0,"quasi_margin_sum":1},
            limitations=["Numerical feasibility and finite estimates do not prove absence of all separation/sparse-pattern problems."]))
    except (ValueError,TypeError,OverflowError):
        rows.append(evidence("separation","not_checked","Stored-design LP screen could not be computed; no successful screen is invented",sample_size=n))
    rows.append(evidence("error_structure","not_checked","Binary likelihood/covariance assumptions require design-specific review",source="manual_required",sample_size=n,
        limitations=["Native covariance was extracted, not validated. Robust covariance does not fix dependence, confounding or link misspecification."]))
    return rows


def _influence(result,n):
    try:
        influence=result.get_influence()
        leverage=np.asarray(influence.hat_matrix_diag,dtype=float)
        cooks=np.asarray(influence.cooks_distance[0],dtype=float)
        if leverage.shape!=(n,) or cooks.shape!=(n,) or not np.isfinite(leverage).all() or not np.isfinite(cooks).all():
            raise ValueError("Undefined native influence")
        return evidence("influence","warning" if np.any(cooks>4/n) else "no_issue_detected",
            "Native OLS leverage and Cook-distance screen on original fitting rows",sample_size=n,
            observed={"max_leverage":float(leverage.max()),"max_cooks_distance":float(cooks.max()),"high_influence_count":int(np.sum(cooks>4/n)),"observation_denominator":n},
            thresholds={"cooks_warning":4/n,"comparison":"Cook distance > 4/n is a review heuristic"},
            limitations=["Native internal influence is conditional on the existing OLS model. Unusual rows are not necessarily errors; no row is removed."])
    except (ValueError,TypeError,AttributeError,ArithmeticError,np.linalg.LinAlgError):
        return evidence("influence","not_checked","Native OLS influence is unavailable/undefined; no finite influence value is fabricated",sample_size=n,
            limitations=["Zero residual variance, leverage one, rank or degrees-of-freedom limits need review."])


def _poisson_deviance_terms(y,mu):
    """Stable unit-weight count contributions, including nearly equal means.

    Separate logarithms avoid overflow in y/mu for extreme ratios. Near
    equality, the convergent series of (1+r)*log(1+r)-r avoids subtracting
    two large, almost equal terms. No negative contribution is clipped.
    """
    from scipy.special import xlogy
    with np.errstate(over="ignore",under="ignore",invalid="ignore",divide="ignore"):
        terms=2*(xlogy(y,y)-xlogy(y,mu)-y+mu)
        r=(y-mu)/mu
        close=(y>0)&np.isfinite(r)&(np.abs(r)<=.01)
        if np.any(close):
            q=r[close]
            # phi(r)=sum_{k=2}^12 (-1)^k*r^k/[k*(k-1)].
            # |r|<=.01 makes the omitted remainder negligible in float64.
            coefficients=[(-1.)**k/(k*(k-1)) for k in range(2,13)]
            terms[close]=2*mu[close]*q*q*np.polynomial.polynomial.polyval(q,coefficients)
    return terms


def _poisson_values(y,mu,*,df=None,baseline=None):
    """Count loss and conditional-variance summaries; no refitting or repair."""
    y=_array(y,1,"observed counts"); mu=_array(mu,1,"Poisson means")
    if len(y)!=len(mu) or np.any(y<0) or np.any(y>=2**53) or np.any(y!=np.floor(y)) or np.any(mu<=0):
        raise ValueError("Poisson summaries require aligned nonnegative integer counts and strictly positive finite means")
    def safe(value):
        value=float(value)
        return value if math.isfinite(value) and abs(value)<=1e100 else None
    with np.errstate(over="ignore",under="ignore",invalid="ignore",divide="ignore"):
        terms=_poisson_deviance_terms(y,mu)
        deviance=safe(np.sum(terms))
        pearson=safe(np.sum(((y-mu)/np.sqrt(mu))**2))
        rmse=safe(np.sqrt(np.mean((y-mu)**2)))
        mae=safe(np.mean(np.abs(y-mu)))
    if deviance is not None and deviance<0:
        # A negative rounded statistic is not silently clipped to a perfect fit.
        deviance=None
    n=len(y); observed_zeros=int(np.sum(y==0)); expected_zeros=float(np.exp(-mu).sum())
    dispersion=pearson/df if pearson is not None and df is not None and math.isfinite(df) and df>0 else None
    values={"poisson_deviance":deviance,"mean_poisson_deviance":None if deviance is None else deviance/n,
        "pearson_chi2":pearson,"dispersion":safe(dispersion) if dispersion is not None else None,
        "rmse":rmse,"mae":mae,
        "poisson_zero_comparison":{"observed_zero_count":observed_zeros,"expected_zero_count":expected_zeros,
            "observation_denominator":n,"observed_zero_fraction":observed_zeros/n,"expected_zero_fraction":expected_zeros/n,
            "model":"Conditional Poisson with supplied means; descriptive zero comparison, not zero-inflation certification"},
        "poisson_metric_configuration":{"mean_domain":"strictly positive finite expected counts","observed_domain":"nonnegative integer counts",
            "deviance_definition":"sum 2*(y*log(y/mu)-y+mu), with y*log(y/mu)=0 at y=0",
            "deviance_numerics":"Near-equality convergent series at relative difference <=0.01; separate logarithms otherwise avoid ratio overflow",
            "pearson_definition":"sum (y-mu)^2/mu; ratio uses native positive training residual df only",
            "null_or_nonfinite_policy":"Undefined, negative rounded or oversized metrics remain null; no clipping/replacement fit"}}
    if baseline is not None:
        base=_array(baseline,1,"count baseline predictions")
        if len(base)!=n: raise ValueError("Count baseline predictions must align to the same supplied rows")
        if np.all(base>0):
            with np.errstate(over="ignore",under="ignore",invalid="ignore",divide="ignore"):
                b=safe(np.sum(_poisson_deviance_terms(y,base)))
            values["baseline_mean_poisson_deviance"]=None if b is None or b<0 else b/n
        else:
            values["baseline_mean_poisson_deviance"]=None
            values["poisson_metric_configuration"]["baseline_deviance_limit"]="Nonpositive baseline means are outside this Poisson-score domain; ordinary point-error reference metrics remain separately labeled"
    return values


def _poisson_evidence(result,y,mu,*,training):
    n=len(y); df=float(result.df_resid) if training else None
    values=_poisson_values(y,mu,df=df)
    ret=getattr(result,"mle_retvals",None)
    from_mle=isinstance(ret,dict) and type(ret.get("converged")) in {bool,np.bool_}
    native=ret["converged"] if from_mle else getattr(result,"converged",None)
    converged=bool(native) if type(native) in {bool,np.bool_} else None
    rows=[evidence("convergence","not_checked" if converged is None else "no_issue_detected" if converged else "fail",
        "Recorded native Poisson GLM convergence state; no fitting was rerun",sample_size=n,
            observed={"native_converged":converged,"native_flag_source":"mle_retvals.converged" if from_mle else "converged" if converged is not None else "unavailable"},thresholds={"comparison":"native convergence flag versus true"},
        limitations=["Convergence does not establish the log-mean specification, valid covariance, independent errors or a Poisson conditional distribution."]),
        evidence("count_distribution","not_checked","Conditional count distribution and common exposure unit require substantive justification",source="manual_required",sample_size=n,
            observed={"minimum_observed_count":float(np.min(y)),"maximum_observed_count":float(np.max(y)),
                "count_coding":"nonnegative integers","link":"log","zero_comparison":values["poisson_zero_comparison"]},
            limitations=["Integer support and a descriptive zero comparison do not prove a Poisson conditional distribution, equidispersion, equal observation exposure, independence or absence of excess-zero mechanisms."]),
        evidence("error_structure","not_checked","Existing covariance and Poisson likelihood assumptions need design-specific review",source="manual_required",sample_size=n,
            limitations=["Native covariance is extracted, not validated. Robust covariance does not repair dependent counts, confounding, missing exposure or an incorrect conditional mean."])]
    ratio=values["dispersion"]
    if training:
        status="not_checked" if ratio is None else "warning" if ratio>1.5 or ratio<.5 else "no_issue_detected"
        rows.append(evidence("dispersion",status,"Pearson count residual sum divided by actual native training residual degrees of freedom",sample_size=n,
            observed={"pearson_chi2":values["pearson_chi2"],"native_residual_df":df if math.isfinite(df) else None,"ratio":ratio,
                "group":"original Poisson training rows","comparison":"Pearson/df ratio versus illustrative Poisson variance reference one"},
            thresholds={"expected_reference":1,"warning_above":1.5,"warning_below":.5,"configuration":"Illustrative review heuristic; not an assumption test or a covariance/model-selection rule"},
            limitations=["Reference depends on a correct conditional mean, independence and adequate information. Non-rejection or an apparently near-one ratio cannot establish equidispersion.",
                "No robust/negative-binomial/zero-inflated replacement, covariance scaling, trimming or automatic correction is applied."],
            remedies=["Review exposure, dependence and the mean specification; any new estimator/covariance needs justified design and a reviewed rerun."]))
    else:
        rows.append(evidence("dispersion","not_checked","No training-df dispersion diagnostic is assigned to held-out rows",source="manual_required",sample_size=n,
            observed={"pearson_chi2_on_supplied_rows":values["pearson_chi2"],"training_df_reused":False},
            limitations=["Supplied-row Poisson loss is descriptive predictive evaluation. Training residual degrees of freedom are not a held-out dispersion denominator."]))
    return rows,values


def _native_visuals(report,result,kind,y,pred,A=None):
    """Collect bounded aggregate plots from the same existing result/prediction."""
    from .model_visuals import (regression_visual_evidence,classification_visual_evidence,ols_visual_evidence,
        histogram_panel,histogram2d_panel,status_panel,validate_visual_evidence,SCHEMA_VERSION,PRIVACY)
    source=report["estimates"]["adapter"]["source_split"]
    # The numerical adapter has a wider finite-value bound than the bounded
    # plotting contract. Keep the numerical report and explicitly unassessed
    # figure instead of clipping values or rejecting a valid existing fit.
    if any(np.any(np.abs(v)>1e40) for v in (y,pred,y-pred)) or (A is not None and np.any(np.abs(A)>1e40)):
        visual={"schema_version":SCHEMA_VERSION,"source_split":source,"n":len(y),"privacy":PRIVACY,
            "panels":[status_panel("native_plot_range","Native fitted-model visual range",n=len(y),source_split=source,
                message="Actual values exceed the aggregate plotting contract's absolute 1e40 bound; numerical results remain separately available. No value is clipped or row removed.",
                limitations=["No numerical chart was generated for this range; this is not a successful diagnostic."])]}
        validate_visual_evidence(visual);report["estimates"]["visual_evidence"]=visual
        return
    if kind=="logistic":
        visual=classification_visual_evidence(y,(pred>=.5).astype(int),classes=[0,1],probabilities=pred,source_split=source)
    elif kind=="ols" and A is not None and source=="training":
        leverage=cooks=None
        try:
            influence=result.get_influence()
            lev=np.asarray(influence.hat_matrix_diag,dtype=float); cook=np.asarray(influence.cooks_distance[0],dtype=float)
            if lev.shape==(len(y),) and cook.shape==(len(y),) and np.isfinite(lev).all() and np.isfinite(cook).all():
                leverage,cooks=lev,cook
        except (ValueError,TypeError,AttributeError,ArithmeticError,np.linalg.LinAlgError): pass
        vif=[None]*A.shape[1]
        varying=np.flatnonzero(np.std(A,axis=0)>0)
        # The centered inverse-correlation identity is used only for a bounded
        # full-rank actual design with an existing intercept. It is not raw
        # feature VIF for a Pipeline or an invented no-intercept regression.
        if getattr(result.model,"k_constant",0)==1 and 1<=len(varying)<=12:
            try:
                Z=A[:,varying]-A[:,varying].mean(axis=0)
                norms=np.sqrt(np.sum(Z*Z,axis=0)); C=(Z/norms).T@(Z/norms)
                if np.linalg.matrix_rank(C)==len(varying):
                    diagonal=np.diag(np.linalg.inv(C))
                    for j,value in zip(varying,diagonal):
                        if math.isfinite(float(value)) and value>=1-1e-10: vif[int(j)]=float(value)
            except (ValueError,TypeError,ArithmeticError,np.linalg.LinAlgError): pass
        scale=float(result.scale)
        visual=ols_visual_evidence(pred,y-pred,A,source_split=source,feature_names=list(result.model.exog_names),
            leverage=leverage,cooks_distance=cooks,vif=vif,residual_scale=math.sqrt(scale) if math.isfinite(scale) and 0<scale<=1e80 else None)
        visual["panels"].insert(0,regression_visual_evidence(y,pred,source_split=source)["panels"][0])
    else:
        visual=regression_visual_evidence(y,pred,source_split=source)
    if kind=="poisson_glm":
        with np.errstate(over="ignore",invalid="ignore",divide="ignore"):
            pearson=(y-pred)/np.sqrt(pred)
        limits=["Conditional Poisson variance scaling, not a normal-error requirement or proof of the count distribution.",
            "Supplied rows retain their stated split; no primary fit, covariance correction or model selection occurs."]
        if np.isfinite(pearson).all() and np.all(np.abs(pearson)<=1e40):
            visual["panels"].append(histogram2d_panel("poisson_pearson_vs_mean","Pearson count residual versus expected count",pred,pearson,
                role="diagnostic",requirement="dispersion",source_split=source,units="observations per count cell",
                axes={"x":"Expected count (native mean)","y":"Pearson-scaled count residual"},
                comparison="Actual supplied count residuals scaled by sqrt(native mean), aggregated into bins",interpretation="Patterns can reveal count-mean/variance concerns; they do not identify a remedy or certify equidispersion.",limitations=limits))
            visual["panels"].append(histogram_panel("poisson_pearson_distribution","Pearson count residual distribution",pearson,
                role="diagnostic",requirement="dispersion",source_split=source,units="observations per histogram bin",
                axes={"x":"Pearson-scaled count residual","y":"Number of observations"},
                comparison="Histogram of actual scaled count residuals; no normal-reference pass criterion",interpretation="A descriptive residual screen conditional on the Poisson variance model; expected discreteness is not a normality failure.",limitations=limits))
        else:
            visual["panels"].append(status_panel("poisson_pearson_unavailable","Pearson count residual plots",n=len(y),source_split=source,requirement="dispersion",
                message="Scaled residuals are undefined or outside the bounded plotting range; no residual was clipped or replaced.",limitations=limits))
        with np.errstate(over="ignore",invalid="ignore",divide="ignore"):
            terms=_poisson_deviance_terms(y,pred)
            devres=np.sign(y-pred)*np.sqrt(terms)
        if np.isfinite(devres).all() and np.all(np.abs(devres)<=1e40):
            visual["panels"].append(histogram2d_panel("poisson_deviance_vs_mean","Signed deviance count residual versus expected count",pred,devres,
                role="diagnostic",requirement="functional_form",source_split=source,units="observations per count cell",
                axes={"x":"Expected count (native mean)","y":"Signed square-root deviance residual"},
                comparison="Signed square root of each actual Poisson deviance contribution versus native expected count",interpretation="Patterns describe a conditional count-mean diagnostic; no distributional pass or automatic replacement model follows.",limitations=limits))
            visual["panels"].append(histogram_panel("poisson_deviance_distribution","Signed deviance count residual distribution",devres,
                role="diagnostic",requirement="count_distribution",source_split=source,units="observations per histogram bin",
                axes={"x":"Signed square-root deviance residual","y":"Number of observations"},
                comparison="Histogram of signed square-root Poisson deviance contributions; no normal-reference acceptance cutoff",interpretation="Discreteness and skew in count residuals need context; this display does not certify a Poisson distribution.",limitations=limits))
        else:
            visual["panels"].append(status_panel("poisson_deviance_unavailable","Signed deviance count residual plots",n=len(y),source_split=source,requirement="count_distribution",
                message="Deviance residuals are numerically undefined or outside the bounded plotting range; no negative rounded contribution or residual was clipped.",limitations=limits))
    validate_visual_evidence(visual)
    report["estimates"]["visual_evidence"]=visual


def audit_statsmodels(model,X=None,y=None,*,purpose="prediction",baseline_predictions=None,
                     positive_label=None,metadata=None,attestations=None,split_role="unknown"):
    """Extract an existing stock fit or evaluate native predictions; never refit.

    Association/description read original fitting rows with X=y=None. Prediction
    with X/y omitted is explicitly training-only. External prediction requires
    both X and y with original matrix/formula input ownership.
    """
    if purpose not in {"prediction","association","description"}:
        return _bad("This fitted adapter supports prediction, association and description only; causal/forecast design is not established by this fit",purpose)
    if metadata is not None and (not isinstance(metadata,dict) or set(metadata)-{"entity_ids","feature_available_times","prediction_times","split_evidence","residual_order"}):
        return _bad("Unknown metadata keys; supported keys are entity_ids, feature_available_times, prediction_times, split_evidence and residual_order",purpose)
    supplied=deepcopy(metadata or {}); order=supplied.pop("residual_order",None)
    try:
        result,kind=_stock(model)
    except ImportError:
        return _bad("Optional statsmodels dependency is unavailable; install the documented statsmodels extra in the chosen environment",purpose)
    except (ValueError,TypeError,AttributeError) as exc:
        return _bad(str(exc),purpose)
    try:
        A=_array(result.model.exog,2,"stored design"); target=_array(result.model.endog,1,"stored target")
        n,k=A.shape
        if n<3 or k>2048 or len(target)!=n: raise ValueError("Stored design and target need at least three aligned rows and a bounded parameter count")
        if float(result.nobs)!=n: raise ValueError("Stored nobs and design rows disagree; reused or stale model state is unsupported")
        if kind=="poisson_glm" and (not math.isfinite(float(result.df_resid)) or float(result.df_resid)!=n-int(np.linalg.matrix_rank(A))):
            raise ValueError("Stored Poisson residual degrees of freedom disagree with actual unweighted design rank; reused or stale fit state is unsupported")
        if kind=="logistic" and not np.array_equal(np.unique(target),[0.,1.]): raise ValueError("Stored binary target must contain both individual classes encoded 0/1")
        if kind=="poisson_glm" and (np.any(target<0) or np.any(target>=2**53) or np.any(target!=np.floor(target))):
            raise ValueError("Stored Poisson target must contain finite nonnegative integer counts; no negative/fractional count is rounded or repaired")
        # LogitResults.fittedvalues are the linear predictor, unlike GLM's
        # fitted means. Native predict() supplies response probabilities.
        stored_fitted=_array(result.fittedvalues,1,"stored fitted values")
        fitted=_array(result.predict(),1,"native training predictions") if kind=="logistic" else stored_fitted
        if len(fitted)!=n: raise ValueError("Stored fitted values and design rows disagree")
        if kind=="poisson_glm" and np.any(fitted<=0): raise ValueError("Native Poisson mean predictions must be strictly positive; zero/negative means are not clipped")
        params=_array(result.params,1,"fitted parameters")
        linear=A@params
        expected=linear if kind=="ols" else result.model.cdf(linear) if type(result.model).__name__=="Logit" else result.model.family.link.inverse(linear)
        if not np.allclose(fitted,expected,rtol=1e-9,atol=1e-10): raise ValueError("Stored design/parameters and fitted values disagree; reused or modified result state is unsupported")
        stored_expected=linear if type(result.model).__name__=="Logit" else expected
        if not np.allclose(stored_fitted,stored_expected,rtol=1e-9,atol=1e-10): raise ValueError("Stored fitted state disagrees with the native model's prediction scale")
        if np.any(np.abs(fitted)>1e100): raise ValueError("Stored fitted values exceed the report numeric bound")
        removed=len(getattr(result.model.data,"missing_row_idx",[]) or [])
        formula=hasattr(result.model.data,"design_info")
        cov_type=str(getattr(result,"cov_type","unavailable"))[:128]
    except (ValueError,TypeError,AttributeError,OverflowError) as exc:
        return _bad(str(exc),purpose,"identifiability")
    training=X is None and y is None
    if (X is None)!=(y is None): return _bad("Provide both external X and observed y, or omit both for original training-fit extraction; y alone cannot replace the stored target",purpose,"split_integrity",n,k)
    if not training and purpose!="prediction":
        return _bad("Coefficient association/description uses the original existing fit: omit X and y. New observed outcomes cannot generate or validate that fit's coefficient inference",purpose,None,n,k)
    if positive_label is not None and (isinstance(positive_label,(bool,np.bool_)) or not isinstance(positive_label,(int,float,np.integer,np.floating)) or positive_label!=1):
        return _bad("Statsmodels binary encoding is explicitly 0/1 with event 1; other positive_label mappings are unsupported",purpose,"target_compatibility",n,k)
    if kind=="poisson_glm" and positive_label is not None:
        return _bad("Count prediction has no binary positive_label or class-probability mapping",purpose,"target_compatibility",n,k)
    adapter={"library":"statsmodels","library_version":__import__("statsmodels").__version__,
        "estimator_type":type(result.model).__name__,"results_type":type(result).__name__,"model_refit":False,
        "formula_input":formula,"covariance_type":cov_type,"use_t":bool(getattr(result,"use_t",False)),
        "training_rows_removed":removed,"training_design_assessed":True,
        "source_split":"training" if training else split_role,
        "preprocessing_owner":"Existing native formula/Patsy design" if formula else "Existing caller-supplied design matrix including its intercept"}
    if kind=="logistic": adapter.update(class_order=[0,1],positive_label=1,link="logit",coefficient_scale="log odds per stored design unit")
    if kind=="poisson_glm":
        scale=float(getattr(result,"scale",float("nan")))
        adapter.update(link="log",coefficient_scale="log expected count per stored design unit; common unverified observation exposure",
            native_fit_scale=scale if math.isfinite(scale) and 0<scale<=1e100 else None,
            count_precision_limit="Observed counts must be integers smaller than 2**53; no lossy large-integer coding is accepted")
    limitations=["This is an unsigned mutable in-memory fitted object; historical selection, measurement and fit provenance are not authenticated.",
        "The existing covariance/reference choice is extracted, not certified. Coefficients are conditional associations, not causal effects.",
        "Only aggregate original-fit summaries are emitted; no raw rows, row indexes or original formula text are copied."]
    try:
        if not training:
            observed,pred,m,p,features,alignment,warning_count,formula=_input(result,X,y,kind)
            if order is not None: return _bad("residual_order applies only to original training OLS diagnostics; it cannot relabel held-out residuals as training evidence",purpose,"independence",m,p)
            baseline=baseline_predictions
            if baseline is not None:
                from .adapters import _alignment
                _row_labels(baseline); baseline,_=_alignment(X,baseline,m)
            # Timing metadata refers to original raw inputs, not the 1-column
            # prediction array consumed by the common evaluator.
            ft=supplied.pop("feature_available_times",None); pt=supplied.pop("prediction_times",None)
            report=audit_prediction(observed,pred if kind in {"ols","poisson_glm"} else (pred>=.5).astype(int),task="regression" if kind in {"ols","poisson_glm"} else "classification",
                probabilities=pred if kind=="logistic" else None,baseline_predictions=baseline,metadata=supplied,attestations=attestations,split_role=split_role)
            if kind=="poisson_glm":
                count_rows,count_values=_poisson_evidence(result,observed,pred,training=False)
                if baseline is not None: count_values.update(_poisson_values(observed,pred,baseline=baseline))
                report=make_report("poisson_glm",purpose,report["evidence"]+count_rows,report["sample_sizes"],{**report["estimates"],**count_values},report["limitations"])
            if (ft is None)!=(pt is None): raise ValueError("Feature availability and prediction cutoff metadata must be supplied together")
            if ft is not None:
                ft=_array(ft,2,"feature availability"); pt=_array(pt,1,"prediction cutoffs")
                if ft.shape!=(m,p) or len(pt)!=m: raise ValueError("Timing metadata must match the raw native-prediction input shape")
                late=int(np.sum(ft>pt[:,None]))
                report["evidence"]=[e for e in report["evidence"] if not(e["requirement"]=="timing" and e["source"]=="manual_required")]
                report["evidence"].append(evidence("timing","fail" if late else "no_issue_detected","Raw feature availability versus prediction cutoff",sample_size=m,
                    observed={"late_cells":late,"availability_comparisons":int(ft.size)},thresholds={"maximum_late_cells":0,"comparison":"feature availability <= prediction cutoff in caller-defined common units"},limitations=["Metadata accuracy and outcome availability remain unverified."]))
            report["sample_sizes"].update(p=p,training_n=n)
            adapter.update(input_feature_names=features,row_alignment=alignment,prediction_warning_count=warning_count,training_design_assessed=False)
            report["estimates"].update(adapter_status="supported_prediction",adapter=adapter)
        else:
            if baseline_predictions is not None and purpose!="prediction": raise ValueError("Baseline predictions apply to prediction purpose only")
            if purpose=="prediction":
                if baseline_predictions is not None:
                    base_index=_row_labels(baseline_predictions)
                    fit_index=getattr(result.model.data,"row_labels",None)
                    if base_index is not None and fit_index is not None and hasattr(fit_index,"equals") and not fit_index.equals(base_index):
                        raise ValueError("Training baseline index differs from retained fitting-row labels/order; no silent alignment is performed")
                report=audit_prediction(target,fitted if kind in {"ols","poisson_glm"} else (fitted>=.5).astype(int),task="regression" if kind in {"ols","poisson_glm"} else "classification",
                    probabilities=fitted if kind=="logistic" else None,baseline_predictions=baseline_predictions,metadata=supplied,attestations=attestations,split_role="training")
                if kind=="poisson_glm":
                    if order is not None: raise ValueError("residual_order is implemented for original OLS only, not a Poisson dependence diagnostic")
                    count_rows,count_values=_poisson_evidence(result,target,fitted,training=True)
                    if baseline_predictions is not None: count_values.update(_poisson_values(target,fitted,df=float(result.df_resid),baseline=baseline_predictions))
                    report=make_report("poisson_glm",purpose,report["evidence"]+count_rows,report["sample_sizes"],{**report["estimates"],**count_values},report["limitations"])
            else:
                es=_common(A,target,supplied,binary=kind=="logistic")
                rank=int(np.linalg.matrix_rank(A)); condition=float(np.linalg.cond(A))
                condition=condition if math.isfinite(condition) else None
                df=float(result.df_resid)
                bad=rank<k or not math.isfinite(df) or df<=0
                es.append(evidence("identifiability","fail" if bad else "warning" if condition is None or condition>1e8 else "no_issue_detected",
                    "Stored native design rank, residual degrees of freedom and condition-number screen",sample_size=n,
                    observed={"rank":rank,"parameters":k,"residual_df":df if math.isfinite(df) else None,"condition_number":condition},thresholds={"condition_warning":1e8,"minimum_positive_residual_df":0},
                    limitations=["Raw units affect conditioning. Rank-deficient coefficients are not separately identified."]))
                if kind=="ols":
                    times_index=_row_labels(order.get("times")) if isinstance(order,dict) else None
                    fit_index=getattr(result.model.data,"row_labels",None)
                    if times_index is not None and hasattr(fit_index,"equals") and not fit_index.equals(times_index):
                        raise ValueError("Ordering time index differs from retained fitting-row labels/order; no silent realignment is performed")
                    try:
                        from .ordered_diagnostics import ols_diagnostics
                        diagnostics=ols_diagnostics(target-fitted,A,fitted,order=order,source_split="training")
                        es.extend(diagnostics["evidence"])
                    except ImportError:
                        diagnostics={"estimates":{},"limitations":["Optional ordered diagnostic module unavailable."]}
                        es.append(evidence("error_structure","not_checked","Error-structure diagnostic not executed",source="manual_required",sample_size=n))
                    es.append(_influence(result,n))
                elif kind=="logistic":
                    if order is not None: raise ValueError("residual_order is currently supported for original training OLS diagnostics only")
                    diagnostics={"estimates":{},"limitations":[]}; es.extend(_logistic_evidence(result,A,target))
                else:
                    if order is not None: raise ValueError("residual_order is implemented for original OLS only, not a Poisson dependence diagnostic")
                    count_rows,count_values=_poisson_evidence(result,target,fitted,training=True)
                    es.extend(count_rows); diagnostics={"estimates":count_values,"limitations":["Poisson count loss and Pearson/df summaries are conditional screens, not identification, independent-count or equidispersion proofs."]}
                values,uncertainty=_coefficient_values(result,list(result.model.exog_names))
                values.update(training_rmse=float(np.sqrt(np.mean((target-fitted)**2))) if kind=="ols" else None,
                    residual_df=df if math.isfinite(df) else None,**diagnostics["estimates"])
                if kind=="logistic":
                    values.pop("training_rmse",None); values["training_log_loss"]=float(log_loss(target,fitted,labels=[0,1]))
                elif kind=="poisson_glm":
                    values["training_rmse"]=values.pop("rmse",None)
                    values["training_mae"]=values.pop("mae",None)
                if not uncertainty:
                    es=[e for e in es if not(e["requirement"]=="error_structure" and e["source"]=="automated")]
                    es.append(evidence("error_structure","fail","Native covariance/standard errors/intervals are undefined or invalid; uncertainty is omitted",sample_size=n,
                        limitations=["No finite denominator, replacement fit or invented uncertainty repairs this result."]))
                report=make_report(kind,purpose,_attest(es,attestations),{"n":n,"p":k},values,diagnostics["limitations"])
            report["estimates"].update(adapter_status="supported_statsmodels_fit",adapter=adapter)
            report["sample_sizes"].update(training_n=n,p=k)
            report["evidence"].append(evidence("evaluation_protocol","warning","Stored fitting rows are training diagnostics, regardless of caller split label",sample_size=n,
                observed={"requested_split_role":split_role,"effective_source_split":"training"},limitations=["Training fit is not untouched evaluation; supply external X and observed y for prediction evaluation."]))
        if removed:
            for item in report["evidence"]:
                if item["requirement"]=="missingness" and item["source"]=="automated":
                    if item["status"]!="fail": item["status"]="warning"
                    item["observed"]["training_rows_removed_by_original_fit"]=removed
                    item["limitations"].append("Original fitting dropped rows. The audit did not delete or restore any row and cannot establish a missingness mechanism.")
        if split_role in {"training","unknown"} and not training:
            report["evidence"].append(evidence("evaluation_protocol","warning","No untouched evaluation role is established for supplied external rows",sample_size=report["sample_sizes"]["n"],
                observed={"source_split":split_role},limitations=["Caller-declared split history cannot be reconstructed from an existing result."]))
        # Visuals use the same already computed native means/observations. No
        # row-level pair/identifier is stored in the report or MCP projection.
        try:
            _native_visuals(report,result,kind,target if training else observed,fitted if training else pred,A if training else None)
        except ImportError:
            report["limitations"].append("Aggregate visual collector is unavailable in this build; no fabricated diagnostic panel is substituted.")
        for item in report["evidence"]: item["provenance"]["adapter"]=ADAPTER_VERSION
        report["limitations"].extend(limitations)
        report["claims"]=gate_claims(report); validate_report(report)
        return report
    except (ValueError,TypeError,AttributeError,OverflowError,np.linalg.LinAlgError) as exc:
        return _bad(str(exc),purpose,"target_compatibility",n,k)
