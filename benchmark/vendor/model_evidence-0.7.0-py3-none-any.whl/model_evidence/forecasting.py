"""Bounded existing-fit ARIMA forecast evidence; no fitting or model selection.

The caller supplies a fitted stock statsmodels ARIMA and explicit regular-grid
training/evaluation time metadata. All computations run on a private copy so
native state-space caches cannot mutate the supplied fitted object. Original
observations, timestamps, forecast vectors and interval endpoints are not saved
in the default aggregate report. Aggregates can nevertheless be sensitive.
"""
from copy import deepcopy
import math
import warnings

import numpy as np

from . import model_visuals as visuals
from .diagnostics import _attest
from .report import evidence, make_report

ADAPTER_VERSION = "arima-forecast/0.6.0"
MAX_ROWS = 200_000
MAX_HORIZON = 2048
SPLITS = {"unknown", "training", "validation", "evaluation", "final_holdout"}
METADATA = {"train_times", "evaluation_times", "time_unit", "ljungbox_lag",
            "seasonal_period", "interval_level"}
LIMITS = [
    "Forecast performance is a conditional evaluation at one supplied origin, not a deployment, stationarity or causal guarantee.",
    "Time metadata and split labels are caller declarations; they do not verify training-only selection, content leakage, original time meaning or untouched evaluation.",
    "Native prediction intervals condition on the fitted model and its distributional assumptions; observed coverage at one origin is descriptive and usually imprecise.",
    "No model refit, order selection, covariance correction, data repair, threshold tuning or automatic test switching occurs.",
    "The default report withholds individual observations, forecast vectors, native time labels and interval endpoints. Aggregate metrics and count cells can still be sensitive.",
]


def is_forecast_candidate(model):
    """Dispatch hint only. The audit still enforces exact native stock types."""
    return type(model).__module__ == "statsmodels.tsa.arima.model"


def _array(value, name, *, maximum=MAX_ROWS):
    if np.ma.isMaskedArray(value):
        raise ValueError(name + " must not contain masked cells")
    raw = np.asarray(value)
    if (raw.ndim != 1 or not 1 <= raw.size <= maximum or raw.dtype.kind not in "iuf"
            or raw.dtype.kind == "b"):
        raise ValueError(name + " must be a bounded one-dimensional real numeric array; no coercion or row removal occurs")
    a = np.array(raw, dtype=float, copy=True)
    if not np.isfinite(a).all() or np.any(np.abs(a) > 1e40):
        raise ValueError(name + " must be finite with absolute values at most1e40")
    return a


def _bad(reason, purpose, req=None, n=0):
    from .adapters import _unsupported
    return _unsupported(reason, purpose, n=n, failed_requirement=req,
                        model_name="stock statsmodels ARIMA forecast")


def _ev(req, status, diagnostic, n, observed=None, thresholds=None, limitations=None, remedies=None):
    return evidence(req, status, diagnostic, observed=observed or {}, thresholds=thresholds or {},
                    sample_size=n, limitations=limitations or [], remedies=remedies or [],
                    provenance={"adapter": ADAPTER_VERSION})


def _stock(result):
    from statsmodels.tsa.arima.model import ARIMA, ARIMAResults, ARIMAResultsWrapper
    raw = result._results if type(result) is ARIMAResultsWrapper else result
    if type(raw) is not ARIMAResults or type(raw.model) is not ARIMA:
        raise ValueError("Only exact stock already-fitted statsmodels ARIMA results are supported; SARIMAX, subclasses and custom objects require a separate adapter")
    model = raw.model
    spec = model._spec_arima
    if int(spec.k_exog) != 0:
        raise ValueError("User exogenous regressors are unsupported by this bounded forecast adapter; native deterministic trend is allowed")
    if tuple(model.seasonal_order) != (0, 0, 0, 0):
        raise ValueError("Seasonal ARIMA/SARIMA is not implemented by this bounded adapter")
    if bool(getattr(raw, "_has_fixed_params", False)):
        raise ValueError("Fixed/constrained parameter fits require a separate diagnostic degree-of-freedom policy")
    if not 1 <= int(model.k_states) <= 64:
        raise ValueError("Native state dimension exceeds this bounded adapter's64-state limit")
    if int(raw.nobs) * int(model.k_states)**2 > 2_000_000:
        raise ValueError("Native state covariance dimensions exceed this bounded adapter's2million-cell copy budget")
    train = _array(model.endog.reshape(-1), "fitted training observations")
    orig = _array(np.asarray(model.data.orig_endog).reshape(-1), "original fitting observations")
    if len(train) < 12 or len(train) != int(raw.nobs) or not np.array_equal(train, orig):
        raise ValueError("At least12 retained fitting observations and unchanged complete original rows are required; dropped/missing fitting rows are unsupported")
    if getattr(model, "k_endog", 1) != 1:
        raise ValueError("Only univariate ARIMA is supported")
    params = _array(raw.params, "native fitted parameters", maximum=64)
    index = getattr(model.data, "row_labels", None)
    if index is not None:
        if getattr(index, "has_duplicates", False) or not getattr(index, "is_monotonic_increasing", True):
            raise ValueError("Native fitting row labels must be unique and ordered; no sorting occurs")
    # Deepcopy is deliberately performed only after exact-class and numeric checks.
    # Native get_forecast can populate state-space/model caches as well as results.
    view = deepcopy(result)
    raw_view = view._results if type(view) is ARIMAResultsWrapper else view
    return view, raw_view, train, params


def _time_context(metadata, training_n, observed_n):
    supplied = {"train_times", "evaluation_times"} <= set(metadata)
    if not supplied:
        return None
    train = _array(metadata["train_times"], "train_times")
    evaluation = _array(metadata["evaluation_times"], "evaluation_times", maximum=MAX_HORIZON)
    if len(train) != training_n or len(evaluation) != observed_n:
        raise ValueError("Time metadata must align with all native fitting rows and all observed future rows")
    if np.any(np.abs(train) > 1e12) or np.any(np.abs(evaluation) > 1e12):
        raise ValueError("Numeric time coordinates must have absolute values at most1e12; use an explicitly declared relative origin/unit")
    unit = metadata.get("time_unit")
    if not isinstance(unit, str) or not 1 <= len(unit.strip()) <= 128:
        raise ValueError("time_unit must explicitly name the common numeric time units")
    step = float(train[1] - train[0])
    if step <= 0 or np.any(np.diff(train) <= 0) or np.any(np.diff(evaluation) <= 0) or evaluation[0] <= train[-1]:
        raise ValueError("Training times must be strictly increasing in fitted row order")
    atol = max(step * 1e-10, float(np.spacing(max(float(np.max(np.abs(train))), float(np.max(np.abs(evaluation))), 1.))) * 4)
    if atol >= step*.25:
        raise ValueError("Time cadence is too small relative to its absolute origin for a safe grid comparison; supply an explicitly declared relative origin")
    if not np.allclose(np.diff(train), step, rtol=1e-10, atol=atol):
        raise ValueError("Training times must have one regular cadence; irregular series are unsupported")
    expected = train[-1] + step * np.arange(1, observed_n + 1)
    if not np.allclose(evaluation, expected, rtol=0, atol=atol):
        raise ValueError("Evaluation times must be the contiguous future steps immediately after the native fitting origin at the same cadence; gaps/overlap/reordering are unsupported")
    return {"training_rows": training_n, "evaluation_rows": observed_n,
            "cadence": step, "time_unit": unit.strip(),
            "first_evaluation_offset_from_training_end": float(evaluation[0] - train[-1]),
            "maximum_horizon_steps": observed_n, "overlapping_time_points": 0,
            "absolute_times_withheld": True}


def _native_time_context(raw, context):
    """Do not reinterpret native calendar spacing as arbitrary numeric units."""
    index = getattr(raw.model.data, "row_labels", None)
    if index is None:
        return
    dtype = getattr(index, "dtype", None)
    kind = getattr(dtype, "kind", "")
    if kind in {"M", "m"} and hasattr(index, "asi8"):
        unit = context["time_unit"]
        if unit == "steps":
            if not np.isclose(context["cadence"], 1., rtol=0, atol=1e-10):
                raise ValueError("Native calendar index declared in steps requires exactly one numeric step per native row")
            return
        scales = {"nanoseconds": 1., "microseconds": 1e3, "milliseconds": 1e6,
                  "seconds": 1e9, "minutes": 60e9, "hours": 3600e9,
                  "days": 86400e9, "weeks": 604800e9}
        if unit not in scales:
            raise ValueError("Native calendar index requires explicit common units nanoseconds/microseconds/milliseconds/seconds/minutes/hours/days/weeks, or steps; arbitrary position units cannot be called calendar units")
        native_steps = np.diff(index.asi8.astype(np.longdouble)) / scales[unit]
        if not np.allclose(native_steps, context["cadence"], rtol=1e-10, atol=1e-10):
            raise ValueError("Declared numeric cadence/time_unit contradicts native fitted calendar spacing; no unit conversion is inferred")
    elif type(index).__name__ == "PeriodIndex":
        if context["time_unit"] != "steps" or not np.isclose(context["cadence"], 1., rtol=0, atol=1e-10):
            raise ValueError("Native PeriodIndex is supported only with explicit one-step numeric period positions; calendar duration is not inferred")
    elif kind in {"i", "u", "f"}:
        native_steps = np.diff(np.asarray(index, dtype=float))
        if not np.allclose(native_steps, context["cadence"], rtol=1e-10, atol=1e-10):
            raise ValueError("Declared numeric cadence contradicts the native fitted numeric index; no rescaling or sorting is inferred")


def _unknown_report(train_n, observed_n, reason, attestations):
    rows = [_ev("time_order", "not_checked", reason, train_n + observed_n,
                {"training_rows": train_n, "evaluation_rows": observed_n},
                {"required": "Aligned numeric train_times/evaluation_times/time_unit, valid future split and observed future outcomes"},
                remedies=["Supply explicit regular-grid time metadata and future observed values; select model/order using training-only data."])]
    panel = visuals.status_panel("forecast_error_metrics", "Forecast performance unresolved", n=max(train_n, observed_n),
        source_split="unknown", message=reason, role="main_result", requirement="time_order",
        limitations=LIMITS)
    estimates = {"adapter_status": "not_checked", "adapter": {"version": ADAPTER_VERSION,
        "model_refit": False, "source_split": "unknown", "forecast_computed": False,
        "reason": reason}, "visual_evidence": visuals._finish(max(train_n, observed_n), "unknown", [panel])}
    # Complete placeholders first so attestations cannot hide a missing requirement.
    report = make_report("arima", "forecasting", rows, {"n": observed_n, "training_n": train_n}, estimates, LIMITS)
    report["evidence"] = _attest(report["evidence"], attestations)
    from .report import gate_claims
    report["claims"] = gate_claims(report)
    return report


def _dependence(raw, metadata, n):
    lag = metadata.get("ljungbox_lag")
    if lag is None:
        return _ev("error_structure", "not_checked", "Training innovation serial-dependence test was not prespecified", n,
                   thresholds={"configuration": "No lag supplied; no data-dependent lag selection"},
                   remedies=["Prespecify ljungbox_lag from training/design context; this does not select a model automatically."]), None
    if type(lag) is not int or not 1 <= lag <= 40:
        raise ValueError("ljungbox_lag must be an integer from1 to40")
    from statsmodels.stats.diagnostic import acorr_ljungbox
    native = np.asarray(raw.filter_results.standardized_forecasts_error)
    if native.ndim != 2 or native.shape[0] != 1:
        raise ValueError("Native standardized one-step innovations are unavailable")
    burn = max(int(raw.loglikelihood_burn), int(raw.filter_results.nobs_diffuse))
    retained = _array(native[0, burn:], "post-initialization standardized innovations")
    p, _, q = tuple(raw.model.order)
    model_df = int(p + q)
    summary = {"training_innovations": len(retained), "native_initialization_rows_excluded": burn,
               "lag": lag, "model_df": model_df, "reference_df": lag - model_df,
               "model_df_policy": "AR order plus MA order; no holdout degrees of freedom"}
    if lag <= model_df or lag >= len(retained) or np.ptp(retained) == 0:
        return _ev("error_structure", "not_checked", "Prespecified Ljung-Box reference is unavailable for this lag/df or degenerate innovation series", len(retained),
                   summary, {"required": "model_df < lag < retained training innovation count and nonzero spread"},
                   limitations=["No p-value or artificial denominator is substituted."]), None
    native_test = acorr_ljungbox(retained, lags=[lag], model_df=model_df, return_df=True)
    statistic = float(native_test.iloc[0]["lb_stat"])
    pv = float(native_test.iloc[0]["lb_pvalue"])
    if not math.isfinite(statistic) or not math.isfinite(pv):
        return _ev("error_structure", "not_checked", "Native Ljung-Box statistic/reference was nonfinite", len(retained), summary,
                   limitations=["No finite substitute is invented."]), None
    summary.update(statistic=statistic, p_value=pv)
    status = "warning" if pv < .05 or len(retained) < 50 else "no_issue_detected"
    row = _ev("error_structure", status, "Native Ljung-Box screen of standardized training one-step innovations after native initialization", len(retained), summary,
        {"alpha": .05, "small_training_innovation_count_warning": 50, "lag_prespecified_by_caller": True},
        limitations=["Nonsignificance does not prove independent errors, correct dynamics, stationarity, interval calibration or future validity.",
                     "The p+q reference adjustment is a bounded ARMA diagnostic policy; small samples and model selection can invalidate nominal reference inference."],
        remedies=["Review training dynamics and design; a revised order requires a reviewed training-only refit and fresh final evaluation."])
    return row, summary


def audit_forecast(model, observed=None, *, purpose="forecasting", metadata=None, attestations=None,
                   split_role="unknown", baseline_predictions=None):
    """Audit a fitted univariate nonseasonal ARIMA at one explicit future origin.

    Required numerical context: metadata train_times/evaluation_times/time_unit.
    Optional metadata: ljungbox_lag, seasonal_period (reference only), interval_level.
    Unknown context returns an unresolved report before calling get_forecast.
    Invalid objects/values return an actionable unsupported report, never repair.
    """
    if purpose != "forecasting":
        return _bad("This bounded ARIMA route supports forecasting only, not coefficient, causal or in-sample descriptive claims", purpose)
    if not isinstance(split_role, str) or split_role not in SPLITS:
        raise ValueError("Invalid split_role")
    if metadata is None:
        metadata = {}
    if not isinstance(metadata, dict) or set(metadata) - METADATA:
        raise ValueError("Unknown forecasting metadata fields")
    level = metadata.get("interval_level", .95)
    if type(level) not in {float, int} or not math.isfinite(level) or not .5 < level < 1:
        raise ValueError("interval_level must be finite and strictly between.5 and1")
    lag = metadata.get("ljungbox_lag")
    if lag is not None and (type(lag) is not int or not 1 <= lag <= 40):
        raise ValueError("ljungbox_lag must be an integer from1 to40")
    try:
        view, raw, train, params = _stock(model)
    except (ImportError, ValueError, TypeError, AttributeError, OverflowError) as exc:
        reason = str(exc) if isinstance(exc, ValueError) else "Optional statsmodels is unavailable or native stock fitted state is incomplete; no forecast computed"
        return _bad(reason, purpose, "missingness" if "fitting observations must be finite" in reason else None)
    n_train = len(train)
    if observed is None:
        if baseline_predictions is not None:
            raise ValueError("A forecast reference requires aligned future observed outcomes")
        return _unknown_report(n_train, 0, "Observed future outcomes are absent; no in-sample fit is relabeled as forecast performance", attestations)
    try:
        target = _array(observed, "observed future outcomes", maximum=MAX_HORIZON)
        if getattr(getattr(observed, "index", None), "has_duplicates", False):
            raise ValueError("Observed future row indexes must be unique and aligned; no aggregation occurs")
    except (ValueError, TypeError, OverflowError) as exc:
        reason = str(exc)
        return _bad(reason, purpose, "missingness" if "finite" in reason or "masked" in reason else "target_compatibility")
    try:
        context = _time_context(metadata, n_train, len(target))
        if context is not None:
            _native_time_context(raw, context)
    except (ValueError, TypeError, OverflowError) as exc:
        return _bad(str(exc), purpose, "time_order")
    n = len(target)
    if context is None or split_role in {"unknown", "training"}:
        return _unknown_report(n_train, n, "Explicit aligned future time metadata and a validation/evaluation/final_holdout split are required before forecasting", attestations)
    # If caller supplies pandas time arrays, verify their row labels against y.
    try:
        visuals._align(observed, metadata["evaluation_times"])
    except ValueError as exc:
        return _bad(str(exc), purpose, "time_order", n)
    rows = [_ev("missingness", "no_issue_detected", "All supplied native fitting and future observed values are finite; no row removed", n_train+n,
                {"nonfinite_cells": 0, "training_rows": n_train, "evaluation_rows": n}, {"maximum_nonfinite": 0},
                ["Sentinel codes, missingness mechanisms and original collection completeness remain unverified."]),
            _ev("target_compatibility", "no_issue_detected", "Univariate finite numeric future response matches this supported ARIMA route", n,
                {"response_count": n, "response_dimensions": 1}, {"support": "univariate real-valued response"},
                ["Scientific response meaning and measurement need separate evidence."]),
            _ev("time_order", "no_issue_detected", "Declared regular numeric time grid: every supplied evaluation row is a contiguous future step after the original fitting origin", n_train+n,
                context, {"comparison": "evaluation step j = training end + j*training cadence; j starts1", "absolute_tolerance_policy": "floating-point cadence tolerance"},
                ["This checks the supplied numeric grid, not the accuracy of time metadata, label windows or original collection order."])]
    retvals = getattr(view, "mle_retvals", None)
    converged = retvals.get("converged") if isinstance(retvals, dict) else None
    converged = bool(converged) if isinstance(converged, (bool, np.bool_)) else None
    rows.append(_ev("convergence", "no_issue_detected" if converged is True else "warning" if converged is False else "not_checked",
        "Native stored optimizer convergence flag", n_train,
        {"converged": converged}, {"required_flag": True},
        ["A true optimizer flag is not proof of global optimum, valid dynamics, stationarity or reliable inference."]))
    try:
        native_rank = int(raw._rank)
    except (ValueError, TypeError, AttributeError):
        native_rank = None
    rows.append(_ev("identifiability", "warning" if native_rank is not None and native_rank < len(params) else "not_checked",
        "Native covariance rank screen; full rank cannot establish structural identification", n_train,
        {"native_covariance_rank": native_rank, "parameter_count": len(params)},
        {"rank_concern": "native covariance rank below parameter count"},
        ["A full-rank covariance is only a numerical screen; structural identification and near-boundary behavior remain unresolved."]))
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            prediction = view.get_forecast(steps=n)
            means = _array(prediction.predicted_mean, "native future means", maximum=MAX_HORIZON)
            intervals = np.asarray(prediction.conf_int(alpha=1-float(level)), dtype=float)
        if means.shape != target.shape or intervals.shape != (n, 2) or not np.isfinite(intervals).all() or np.any(np.abs(intervals)>1e40) or np.any(intervals[:,0] > intervals[:,1]):
            raise ValueError("Native forecast means/intervals must be finite, ordered and align with every observed future row")
        predicted_index = getattr(prediction.predicted_mean, "index", None)
        target_index = getattr(observed, "index", None)
        if predicted_index is not None and hasattr(target_index, "equals") and not predicted_index.equals(target_index):
            raise ValueError("Native forecast row labels differ from observed future labels; no realignment is inferred")
        dep_row, dependence = _dependence(raw, metadata, n_train)
    except (ValueError, TypeError, AttributeError, OverflowError) as exc:
        return _bad(str(exc), purpose, "time_order", n)
    rows.append(dep_row)
    period = metadata.get("seasonal_period")
    if period is not None and (type(period) is not int or not 2 <= period <= n_train):
        raise ValueError("seasonal_period for the reference must be an integer from2 through the number of native training rows")
    if baseline_predictions is None:
        if period is None:
            reference = np.repeat(train[-1], n)
            reference_kind = "training_last_value_naive"
        else:
            reference = np.resize(train[-period:], n)
            reference_kind = "training_seasonal_naive"
        baseline_provenance = "Constructed only from native fitting outcomes; reference choice still requires prespecification"
    else:
        try:
            visuals._align(observed, baseline_predictions)
            reference = _array(baseline_predictions, "reference forecast", maximum=MAX_HORIZON)
            if reference.shape != target.shape:
                raise ValueError("Reference forecasts must align with every observed future row")
        except (ValueError, TypeError, OverflowError) as exc:
            return _bad(str(exc), purpose, "reference_baseline", n)
        reference_kind = "caller_supplied_reference"
        baseline_provenance = "Caller supplied values; their construction/selection provenance remains unverified"
    error = target - means
    baseline_error = target - reference
    mae, rmse = float(np.mean(np.abs(error))), float(np.sqrt(np.mean(error*error)))
    baseline_mae, baseline_rmse = float(np.mean(np.abs(baseline_error))), float(np.sqrt(np.mean(baseline_error*baseline_error)))
    covered = int(np.sum((target >= intervals[:,0]) & (target <= intervals[:,1])))
    coverage = covered/n
    width = float(np.mean(intervals[:,1] - intervals[:,0]))
    rows.append(_ev("reference_baseline", "warning" if rmse > baseline_rmse else "no_issue_detected",
        "Model versus same-row reference forecast absolute/squared errors", n,
        {"rmse": rmse, "baseline_rmse": baseline_rmse, "mae": mae, "baseline_mae": baseline_mae,
         "reference_kind": reference_kind, "reference_period": period, "error_denominator": n},
        {"comparison": "model RMSE versus reference RMSE on identical supplied future rows", "automatic_model_selection": False},
        [baseline_provenance, "A lower observed error neither proves superiority in another origin/population nor justifies selecting a model on this final holdout."],
        ["Retain prespecified reference and model; if this evaluation informed changes obtain a fresh final evaluation."]))
    rows.append(_ev("calibration", "warning" if n < 30 or coverage < float(level) else "no_issue_detected",
        "Descriptive native prediction-interval coverage and mean width at one future origin", n,
        {"covered_count": covered, "forecast_count": n, "empirical_coverage": coverage,
         "native_interval_level": float(level), "mean_interval_width": width},
        {"comparison": "covered supplied future values / supplied future values versus native nominal level", "small_evaluation_count_warning": 30},
        ["Forecast errors across horizons from one origin are dependent. This is not an independent-binomial coverage test or proof of calibrated future intervals.",
         "Wide intervals can cover more outcomes while being less useful; coverage and width must be considered together."]))
    values = {"mae": mae, "rmse": rmse, "baseline_mae": baseline_mae, "baseline_rmse": baseline_rmse,
        "forecast_interval_coverage": coverage, "forecast_interval_level": float(level),
        "mean_forecast_interval_width": width, "forecast_covered_count": covered,
        "forecast_origin_count": 1, "forecast_horizon_count": n,
        "training_innovation_dependence": dependence,
        "adapter_status": "supported_bounded", "adapter": {"version": ADAPTER_VERSION,
            "model_family": "univariate_nonseasonal_ARIMA", "order": list(raw.model.order),
            "native_parameter_count": len(params), "reference_kind": reference_kind,
            "reference_period": period, "source_split": split_role, "model_refit": False,
            "forecast_computed": True, "native_prediction_warning_count": len(caught),
            "row_alignment": "native_forecast_labels_checked_when_both_present;otherwise_explicit_positional_time_grid",
            "original_fit_mutated": False}}
    limits = LIMITS + [baseline_provenance]
    metric_labels = ["model MAE", "model RMSE", "reference MAE", "reference RMSE"]
    try:
        error_panel = visuals.histogram_panel("forecast_errors", "Future forecast error distribution", error, role="diagnostic",
            requirement="error_structure", source_split=split_role, units="observed minus native predicted response",
            comparison="All future errors in fixed bounded count bins; these are not fitted training residuals",
            interpretation="The distribution describes these future errors; it does not certify stationarity, independent innovations or future performance.", limitations=limits)
    except (ValueError, OverflowError, FloatingPointError):
        error_panel = visuals.status_panel("forecast_errors", "Future forecast error distribution", n=n,
            source_split=split_role, message="Future errors exceed this bounded chart's numeric display range; no observations were dropped and no chart values were invented.",
            requirement="error_structure", limitations=limits)
    panels = [visuals._bars("forecast_error_metrics", "Future forecast errors versus reference", metric_labels,
        [mae, rmse, baseline_mae, baseline_rmse], n, split_role, role="main_result", requirement="reference_baseline",
        units="response units", comparison="Same supplied future rows; MAE = mean absolute error, RMSE = square root mean squared error",
        interpretation="Observed model/reference errors at one origin; lower is better on these rows only.", limitations=limits),
        error_panel,
        visuals._bars("forecast_interval_coverage", "Native interval coverage comparison", ["observed coverage", "native nominal level"],
            [coverage, float(level)], n, split_role, role="diagnostic", requirement="calibration", units="fraction of future observations",
            comparison="Observed covered count divided by supplied forecast count versus conditional native interval level",
            interpretation="Observed coverage and native nominal level are distinct; one-origin coverage is uncertain and does not establish calibrated intervals.", limitations=limits)]
    if dependence is None:
        panels.append(visuals.status_panel("forecast_dependence", "Training innovation dependence", n=n_train,
            source_split="training", message=dep_row["diagnostic"], requirement="error_structure",
            limitations=dep_row["limitations"]))
    else:
        panels.append(visuals._bars("forecast_dependence", "Training Ljung-Box comparison", ["native p-value", "prespecified alpha"],
            [dependence["p_value"], .05], dependence["training_innovations"], "training", requirement="error_structure", units="probability scale",
            comparison="Native Ljung-Box p-value versus alpha.05 at caller-prespecified lag and AR+MA df adjustment",
            interpretation="Small p-values flag a specific serial-dependence concern; a larger p-value does not prove independent innovations.",
            limitations=dep_row["limitations"]))
    values["visual_evidence"] = {"schema_version": visuals.SCHEMA_VERSION, "source_split": "mixed",
        "n": max(n_train, n), "privacy": visuals.PRIVACY, "panels": panels}
    visuals.validate_visual_evidence(values["visual_evidence"])
    report = make_report("arima", purpose, rows, {"n": n, "training_n": n_train, "forecast_origins": 1}, values, LIMITS)
    report["evidence"] = _attest(report["evidence"], attestations)
    from .report import gate_claims
    report["claims"] = gate_claims(report)
    return report
