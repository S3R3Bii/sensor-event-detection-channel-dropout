"""Causal questions and cited retrospective evidence, never a causality certificate.

The module assesses supplied documentation. It neither reads papers nor validates
unseen records. Editable reports are data, not instructions or signed evidence.
"""
from copy import deepcopy
import json
import math
from .dag import assess_assumed_dag, validate_assumed_dag

CAUSAL_SCHEMA_VERSION = "1.1.0"
CAUSAL_REGISTRY_VERSION = "0.1.0"
DESIGNS = {
    "randomized_trial": ("randomization", "allocation_concealment", "assignment_adherence"),
    "observational_adjustment": ("confounding_dag", "exchangeability", "positivity"),
    "matching": ("confounding_dag", "exchangeability", "positivity", "matching_design"),
    "weighting": ("confounding_dag", "exchangeability", "positivity", "weight_design"),
    "did": ("parallel_counterfactual_trends", "no_anticipation", "stable_composition", "no_concurrent_shocks"),
    "rd": ("threshold_assignment", "no_manipulation", "continuity", "local_estimand"),
    "iv": ("instrument_relevance", "instrument_independence", "exclusion", "monotonicity", "local_estimand"),
}
COMMON_IDENTIFICATION = ("assumed_dag", "temporality", "consistency", "interference", "selection_missingness", "measurement", "post_treatment_adjustment")
ESTIMATOR_COMMON = ("estimator_specification", "estimand_alignment", "uncertainty_dependence")
ESTIMATOR_DESIGN = {
    "randomized_trial": ("assignment_analysis",),
    "observational_adjustment": ("nuisance_model_specification",),
    "matching": ("matching_estimator",),
    "weighting": ("weight_stability",),
    "did": ("staggered_timing_heterogeneity",),
    "rd": ("bandwidth_polynomial",),
    "iv": ("weak_instrument_inference",),
}
REPORTING = ("reporting_transparency", "data_code_availability", "sensitivity_analysis")
DIAGNOSTICS = ("covariate_balance", "empirical_overlap", "placebo_checks", "sensitivity_checks")
STATUSES = {"reported_support", "not_reported", "unavailable", "not_assessed", "not_applicable", "contradicted"}
AVAILABILITY = {"available", "unavailable", "not_reported", "not_assessed"}
SOURCE_TYPES = {"paper", "supplement", "protocol", "registry", "analysis_code", "data_reanalysis", "author_response", "reviewer_assessment"}
ESTIMANDS = {"ATE", "ATT", "ATC", "CATE", "LATE", "ITT", "per_protocol", "local_effect", "other"}
CLAIM_FIELDS = {"population", "treatment", "comparator", "outcome", "estimand", "time_zero", "follow_up", "identification_strategy"}
EVIDENCE_FIELDS = {"requirement", "status", "citation", "page", "section", "source_type", "observed_results", "available_data", "available_code", "unknowns"}
AUDIT_FIELDS = {"schema_version", "registry_version", "claim", "review_mode", "available_data", "available_code", "unknowns", "adjustment_variables", "evidence", "matrix", "language_gate", "coverage", "limitations", "dag", "assumed_dag"}

# These are prompts for expert assessment, not interchangeable statistical tests.
PROMPTS = {
    "assumed_dag": "Supply, inspect, and explicitly confirm the assumed directional DAG, its source, observed/unobserved nodes, timing and exposure/outcome. Confirmation is an attestation, not verification.",
    "temporality": "Align eligibility, assignment/exposure, and start of follow-up at time zero; address immortal time and reverse causation.",
    "consistency": "Define treatment versions, comparator, exposure measurement, and outcome under the intervention of interest.",
    "interference": "Explain whether one unit's treatment can change another unit's outcome; define clusters or exposure mapping when relevant.",
    "selection_missingness": "Assess sampling/selection, loss to follow-up, missing exposure/outcomes, and assumptions for censoring or imputation.",
    "measurement": "Assess exposure, covariate, and outcome validity, timing, and differential measurement error.",
    "post_treatment_adjustment": "Justify adjustment using pre-treatment causes and a causal graph; flag mediators, colliders, and post-treatment variables.",
    "randomization": "Document random sequence generation and implementation for the actual assignment unit.",
    "allocation_concealment": "Document concealment before assignment and possible departures from allocation.",
    "assignment_adherence": "Distinguish effect of assignment from receipt/adherence and assess deviations and co-interventions.",
    "confounding_dag": "State subject-matter causal graph and confounding domains; justify the adjustment set and excluded variables.",
    "exchangeability": "Justify conditional exchangeability with subject knowledge and sensitivity analysis; measured balance cannot establish no unmeasured confounding.",
    "positivity": "Justify treatment availability within target covariate strata; empirical overlap is a limited diagnostic, not proof of population positivity.",
    "matching_design": "Report matching covariates, distance/caliper, replacement, discarded units, and resulting target population.",
    "weight_design": "Specify propensity or sampling weights, target estimand, stabilization, and any preplanned truncation.",
    "parallel_counterfactual_trends": "Justify trends in untreated potential outcomes on the chosen scale; pre-trend non-rejection does not prove this assumption.",
    "no_anticipation": "Assess treatment anticipation, timing misclassification, and effects before recorded adoption.",
    "stable_composition": "Assess panel membership, population composition, spillovers, and treatment timing changes.",
    "no_concurrent_shocks": "Assess other events or policies affecting treated and comparison groups differently.",
    "threshold_assignment": "Document running variable, cutoff, treatment rule, compliance, and sharp versus fuzzy design.",
    "no_manipulation": "Assess sorting/control of the running variable near the cutoff; a density test cannot prove its absence.",
    "continuity": "Justify continuity of potential outcomes and other determinants at the threshold, or an explicit local randomization argument.",
    "local_estimand": "State which cutoff/complier population is identified; justify any extrapolation separately.",
    "instrument_relevance": "Document instrument-treatment relationship and appropriate weak-instrument diagnostics.",
    "instrument_independence": "Justify instrument as-if-random assignment relative to potential outcomes and confounders.",
    "exclusion": "Justify why the instrument affects outcome only through treatment; outcome fit and first-stage strength cannot establish exclusion.",
    "monotonicity": "Justify no-defiers or other restrictions needed for the stated IV estimand; do not treat it as a universal IV assumption.",
    "estimator_specification": "Specify estimator, links, covariate forms, identification formula, and model-dependent assumptions.",
    "estimand_alignment": "Connect the fitted contrast and analytic population to the stated estimand, comparator, horizon, and effect scale.",
    "uncertainty_dependence": "Address clustering, repeated measures, matching/weight estimation uncertainty, sample size, and inference method.",
    "assignment_analysis": "For assignment effects, preserve assignment groups; per-protocol effects need additional confounding assumptions.",
    "nuisance_model_specification": "Assess treatment/outcome model specification and any cross-fitting or doubly robust conditions.",
    "matching_estimator": "Explain pair/set structure, unmatched exclusions, variance estimation, and post-match analysis.",
    "weight_stability": "Inspect extreme weights/effective sample size and uncertainty; truncation changes the analysis and may change its target.",
    "staggered_timing_heterogeneity": "Check timing cohorts, comparison groups, treatment-effect heterogeneity, and estimator suitability for staggered adoption.",
    "bandwidth_polynomial": "Report bandwidth/kernel/local polynomial choices, robust inference, and prespecified sensitivity analyses.",
    "weak_instrument_inference": "Use inference appropriate for instrument strength; state exactly which IV estimand and restrictions apply.",
    "reporting_transparency": "Locate protocol, prespecification, outcome/analysis selection, effect uncertainty, deviations, and limitations.",
    "data_code_availability": "Record the actual availability and reviewed scope of data/code; unavailable material is not evidence of failed practice.",
    "sensitivity_analysis": "Document sensitivity to plausible identifying-assumption violations and alternative design choices without outcome-driven selection.",
    "covariate_balance": "Inspect measured pre-treatment covariate balance; numerical balance does not address unmeasured confounding.",
    "empirical_overlap": "Inspect observed propensity support and sparsity; sample overlap does not prove structural positivity.",
    "placebo_checks": "Assess prespecified negative controls/placebos or design-specific falsification; non-rejection is not identification proof.",
    "sensitivity_checks": "Assess design-specific sensitivity analyses; no universal threshold certifies causation.",
}
LIMITATIONS = [
    "This is a structured assessment of supplied evidence, not a causal-validity score or a certification of causation.",
    "Document-only review assesses reported support; it cannot validate unseen data, code, randomization, or analytic conduct.",
    "Not reported, unavailable, and not assessed are distinct from contradicted; absent reporting is not failed practice.",
    "Balance, overlap, pre-trend, placebo, density, and first-stage checks cannot prove exchangeability, exclusion, or parallel counterfactual trends.",
    "All identifying assumptions remain substantive claims requiring expert judgement; this release never authorizes unconditional causal language.",
    "Evidence text, citations, population descriptions, and aggregates can be sensitive; this local audit is not exposed by the default MCP tools.",
]

def _text(value, name, maximum=4096):
    if not isinstance(value, str) or not value.strip() or len(value) > maximum:
        raise ValueError("Invalid " + name)
    return value

def _texts(values, name):
    if not isinstance(values, list) or len(values) > 128:
        raise ValueError("Invalid " + name)
    return [_text(v, name) for v in values]

def _member(value, vocabulary):
    return isinstance(value, str) and value in vocabulary

def causal_requirements(design, estimand=None):
    """Return design-specific requirements and actual numerical coverage."""
    if not isinstance(design, str) or design not in DESIGNS:
        raise ValueError("Unknown identification strategy")
    rows = []
    specific = DESIGNS[design]
    # Monotonicity is a LATE/complier interpretation restriction, not a generic
    # requirement of every IV model. Other IV estimands need explicit alignment.
    if design == "iv" and estimand not in {None, "LATE", "local_effect"}:
        specific = tuple(r for r in specific if r not in {"monotonicity", "local_estimand"})
    if design == "randomized_trial" and estimand == "per_protocol":
        specific += ("confounding_dag", "exchangeability", "positivity")
    groups = [("identification", COMMON_IDENTIFICATION + specific, True),
              ("estimator", ESTIMATOR_COMMON + ESTIMATOR_DESIGN[design], True),
              ("reporting", REPORTING, False), ("diagnostic", DIAGNOSTICS, False)]
    for category, requirements, critical in groups:
        for rid in requirements:
            rows.append({"requirement": rid, "category": category, "critical": critical,
                         "question": PROMPTS[rid],
                         "implementation": "numerical_helper" if rid in {"covariate_balance", "empirical_overlap"} else "manual_assessment"})
    return rows

def _claim(claim):
    if not isinstance(claim, dict) or not CLAIM_FIELDS <= set(claim) or set(claim) - CLAIM_FIELDS - {"estimand_details", "dag_mapping"}:
        raise ValueError("Causal claim needs population, treatment, comparator, outcome, estimand, time_zero, follow_up, identification_strategy")
    result = {k: _text(v, "claim field") for k, v in claim.items() if k!="dag_mapping"}
    if "dag_mapping" in claim:
        mapping=claim["dag_mapping"]
        if not isinstance(mapping,dict) or set(mapping)!={"exposure_node","outcome_node","basis"}:
            raise ValueError("Claim DAG mapping needs exposure_node, outcome_node and explicit basis")
        result["dag_mapping"]={k:_text(v,"claim DAG mapping",64 if k!="basis" else 4096) for k,v in mapping.items()}
    if result["estimand"] not in ESTIMANDS:
        raise ValueError("Unknown estimand; use other with estimand_details")
    if result["estimand"] == "other" and not result.get("estimand_details"):
        raise ValueError("Other estimand needs estimand_details")
    causal_requirements(result["identification_strategy"])
    return result

def _evidence(entries, allowed, review_mode, available_data):
    if not isinstance(entries, list) or len(entries) > 256:
        raise ValueError("Evidence must be a bounded list")
    result = []
    for entry in entries:
        if not isinstance(entry, dict) or set(entry) != EVIDENCE_FIELDS:
            raise ValueError("Evidence needs requirement/status, exact citation/page/section, source_type, observed_results, data/code availability and unknowns")
        if not _member(entry["requirement"], allowed) or not _member(entry["status"], STATUSES) or not _member(entry["source_type"], SOURCE_TYPES):
            raise ValueError("Unknown evidence vocabulary")
        if not _member(entry["available_data"], AVAILABILITY) or not _member(entry["available_code"], AVAILABILITY):
            raise ValueError("Invalid evidence availability")
        for key in ("citation", "page", "section", "observed_results"):
            _text(entry[key], key)
        _texts(entry["unknowns"], "evidence unknowns")
        if entry["source_type"] == "data_reanalysis" and (review_mode == "document_only" or available_data != "available" or entry["available_data"] != "available"):
            raise ValueError("Data reanalysis requires declared available data and local_reanalysis mode")
        result.append(deepcopy(entry))
    return result

def _adjustments(variables):
    if not isinstance(variables, list) or len(variables) > 256:
        raise ValueError("Adjustment variables must be a bounded list")
    seen = set()
    for v in variables:
        if not isinstance(v, dict) or set(v) != {"name", "timing", "role", "included"}:
            raise ValueError("Adjustment variable needs name/timing/role/included")
        _text(v["name"], "adjustment variable name", 128)
        if v["name"] in seen or not _member(v["timing"], {"pre_treatment", "post_treatment", "unknown"}) or not _member(v["role"], {"confounder", "mediator", "collider", "unknown"}) or not isinstance(v["included"], bool):
            raise ValueError("Invalid adjustment variable")
        seen.add(v["name"])
    return deepcopy(variables)

def _combined_status(entries):
    if not entries: return "not_assessed"
    # Conflicting or unresolved evidence cannot be laundered by adding support.
    for status in ("contradicted", "unavailable", "not_assessed", "not_reported", "not_applicable"):
        if any(e["status"] == status for e in entries): return status
    return "reported_support"

def assess_causal_claim(claim, evidence=None, *, review_mode="document_only", available_data="unavailable", available_code="unavailable", unknowns=None, adjustment_variables=None, dag=None):
    """Build a cited claim-to-evidence matrix without equating silence with failure.

    ``reported_support`` describes the supplied source, never verified truth.
    No paper content or analysis results are inferred. One audit covers one
    estimand/result; mediation and longitudinal treatment need specialist review.
    """
    claim = _claim(claim)
    if not _member(review_mode, {"document_only", "local_reanalysis"}):
        raise ValueError("Unknown review mode")
    if not _member(available_data, AVAILABILITY) or not _member(available_code, AVAILABILITY):
        raise ValueError("Invalid availability")
    unknowns = _texts([] if unknowns is None else unknowns, "unknowns")
    variables = _adjustments([] if adjustment_variables is None else adjustment_variables)
    dag_input = validate_assumed_dag(dag) if dag is not None else None
    dag_assessment = assess_assumed_dag(dag_input)
    dag_confirmed = dag_assessment["status"] == "assumed_confirmed"
    mapping = claim.get("dag_mapping",{})
    mapping_matches = bool(dag_input is not None and mapping.get("exposure_node")==dag_assessment["exposure"] and mapping.get("outcome_node")==dag_assessment["outcome"])
    requirements = causal_requirements(claim["identification_strategy"], claim["estimand"])
    entries = _evidence([] if evidence is None else evidence, {r["requirement"] for r in requirements}, review_mode, available_data)
    flags = []
    if any(v["included"] and v["timing"] == "post_treatment" for v in variables):
        flags.append("included_post_treatment_variable")
    if any(v["included"] and v["role"] in {"mediator", "collider"} for v in variables):
        flags.append("included_mediator_or_collider")
    if any(v["included"] and v["timing"] == "unknown" for v in variables):
        flags.append("adjustment_timing_unknown")
    graph_roles = dag_assessment["roles"]
    unobserved_common_cause = any("candidate_common_cause" in r.get("roles",[]) and "unobserved" in r.get("roles",[]) for r in graph_roles.values())
    for variable in variables:
        if not variable["included"]: continue
        roles = graph_roles.get(variable["name"], {}).get("roles", [])
        if dag_input is not None and variable["name"] not in graph_roles:
            flags.append("adjustment_variable_absent_from_dag")
        if "treatment_descendant" in roles: flags.append("adjusting_assumed_treatment_descendant")
        if "mediator_path" in roles: flags.append("adjusting_assumed_mediator")
        if "collider" in roles: flags.append("adjusting_assumed_collider")
        if "unobserved" in roles: flags.append("adjusting_unobserved_node")
    flags = list(dict.fromkeys(flags))
    matrix = []
    for req in requirements:
        items = [deepcopy(e) for e in entries if e["requirement"] == req["requirement"]]
        status = _combined_status(items)
        row_flags = list(flags) if req["requirement"] == "post_treatment_adjustment" else []
        if req["requirement"] == "assumed_dag":
            # A confirmation attestation cannot erase contradictory or unknown
            # cited graph evidence. With no separate entry, keep the graph's
            # explicit human attestation as the limited reported support.
            status = (_combined_status(items) if items else "reported_support") if dag_confirmed and mapping_matches else ("contradicted" if any(e["status"]=="contradicted" for e in items) else "not_assessed")
            if not dag_confirmed: row_flags.append("dag_confirmation_unresolved")
            if not mapping_matches: row_flags.append("claim_dag_question_mismatch")
        elif req["requirement"] in {"confounding_dag", "exchangeability", "post_treatment_adjustment", "estimand_alignment"} and not dag_confirmed:
            row_flags.append("dag_confirmation_unresolved")
        if req["requirement"] in {"confounding_dag", "exchangeability", "post_treatment_adjustment", "estimand_alignment"} and not mapping_matches:
            row_flags.append("claim_dag_question_mismatch")
        if req["requirement"] in {"confounding_dag", "exchangeability"} and unobserved_common_cause:
            row_flags.append("assumed_unobserved_common_cause_requires_identification_review")
        matrix.append({**req, "assessment_status": status, "evidence": items, "flags": row_flags})
    unresolved = [r["requirement"] for r in matrix if r["critical"] and (r["assessment_status"] != "reported_support" or r["flags"])]
    documentation_complete = not unresolved
    gate = {"strong_causal_language": "blocked", "conditional_interpretation": "eligible_for_expert_review" if documentation_complete else "blocked",
            "blockers": list(dict.fromkeys(unresolved + flags)),
            "reason": "This release does not certify identification or execute causal effect estimators; even complete reported support permits only expert review of conditional interpretation."}
    coverage = {"claim_and_evidence_validation": "implemented", "design_requirement_matrix": "implemented",
                "assumed_dag_validation_and_confirmation": "implemented",
                "post_treatment_adjustment_screen": "implemented", "covariate_balance": "numerical_helper",
                "empirical_overlap": "numerical_helper", "causal_effect_estimation": "not_implemented",
                "dag_identification_algorithm": "not_implemented", "placebo_tests": "manual_assessment_only",
                "parallel_trend_tests": "manual_assessment_only", "rd_density_tests": "manual_assessment_only",
                "iv_strength_tests": "manual_assessment_only", "sensitivity_tests": "manual_assessment_only"}
    return {"schema_version": CAUSAL_SCHEMA_VERSION, "registry_version": CAUSAL_REGISTRY_VERSION,
            "claim": claim, "review_mode": review_mode, "available_data": available_data,
            "available_code": available_code, "unknowns": unknowns, "adjustment_variables": variables,
            "dag": dag_input, "assumed_dag": dag_assessment,
            "evidence": entries, "matrix": matrix, "language_gate": gate,
            "coverage": coverage, "limitations": list(LIMITATIONS)}

def _rebuild(audit):
    if not isinstance(audit, dict) or set(audit) != AUDIT_FIELDS or audit["schema_version"] != CAUSAL_SCHEMA_VERSION or audit["registry_version"] != CAUSAL_REGISTRY_VERSION:
        raise ValueError("Invalid causal audit contract")
    return assess_causal_claim(audit["claim"], audit["evidence"], review_mode=audit["review_mode"],
                              available_data=audit["available_data"], available_code=audit["available_code"],
                              unknowns=audit["unknowns"], adjustment_variables=audit["adjustment_variables"],dag=audit["dag"])

def validate_causal_audit(audit):
    """Reject edited derived decisions; does not authenticate cited evidence."""
    rebuilt = _rebuild(audit)
    if rebuilt != audit:
        raise ValueError("Causal audit derived fields do not match supplied evidence")
    return audit

def explain_causal_audit(audit):
    """Recompute language gates, ignoring any edited stored decisions."""
    checked = _rebuild(audit)
    counts = {s: sum(r["assessment_status"] == s for r in checked["matrix"]) for s in sorted(STATUSES)}
    observations = ", ".join(f"{k}={v}" for k, v in counts.items() if v)
    gate = checked["language_gate"]
    support = ("a complete set of reported critical assessments eligible for expert review of conditional interpretation"
               if gate["conditional_interpretation"] == "eligible_for_expert_review" else
               "only the documented support and gaps; conditional causal interpretation remains blocked")
    return (f"We used a {checked['claim']['identification_strategy']} evidence framework for purpose causal inference; "
            f"checked {len(checked['matrix'])} design, estimator, reporting, and diagnostic requirements; observed {observations}; "
            f"this supports {support} subject to the supplied sources and their limitations; "
            "it does not establish that the reported practices occurred, validate unseen data, or prove causation. "
            "Not reported is not the same as not done. "
            + ("Unresolved critical requirements or adjustment flags: " + ", ".join(gate["blockers"]) + ". " if gate["blockers"] else "")
            + "Assumed DAG status: "+checked["assumed_dag"]["status"]+". "
            + ("Assumed edges: "+"; ".join(checked["assumed_dag"]["edge_list"])+". " if checked["assumed_dag"]["edge_list"] else "No directional DAG was supplied; graph-dependent interpretations remain unresolved. ")
            + "Strong causal language is blocked in this release. No universal causal-validity score is computed.")

def causal_to_json(audit):
    return json.dumps(_rebuild(audit), indent=2, ensure_ascii=True, allow_nan=False) + "\n"

def balance_overlap(X, treatment, *, propensity=None, weights=None, smd_threshold=0.1, overlap_bounds=(0.05, 0.95), dag=None, covariate_names=None, estimand="ATE"):
    """Measured pre-treatment balance/empirical overlap; no causal certification.

    Pooled weighted within-group sample variances define SMD. No automatic
    matching, weighting, clipping, imputation, repair, or estimator selection.
    The heuristic cutoffs are configurable screens, not universal standards.
    """
    import numpy as np
    for name,value in (("X",X),("treatment",treatment),("weights",weights),("propensity",propensity)):
        if np.ma.isMaskedArray(value) and np.ma.getmaskarray(value).any(): raise ValueError(name+" contains masked values; no mask is silently dropped")
    try:
        if np.iscomplexobj(X) or np.iscomplexobj(treatment):
            raise ValueError("Complex covariates/treatment are not supported")
        X = np.asarray(X, dtype=float)
        treatment = np.asarray(treatment)
    except (TypeError, ValueError) as exc:
        raise ValueError("Numeric covariates and binary treatment required") from exc
    if X.ndim != 2 or not 4 <= len(X) <= 200000 or not 1 <= X.shape[1] <= 256 or X.size > 2000000 or not np.isfinite(X).all() or np.abs(X).max() > 1e12:
        raise ValueError("Finite bounded 2D covariates required, with 4..200000 rows and 1..256 columns")
    if treatment.ndim != 1 or len(treatment) != len(X) or not np.isin(treatment, [0, 1]).all():
        raise ValueError("Treatment must be a binary aligned vector")
    if not _member(estimand, ESTIMANDS): raise ValueError("Unknown estimand")
    if covariate_names is None:
        if dag is not None: raise ValueError("Explicit covariate_names required to compare with an assumed DAG")
        names = ["covariate_"+str(i+1) for i in range(X.shape[1])]
    else:
        if not isinstance(covariate_names,list) or len(covariate_names)!=X.shape[1] or not all(isinstance(n,str) and n.strip() and len(n)<=64 for n in covariate_names) or len(set(covariate_names))!=len(covariate_names):
            raise ValueError("Unique aligned covariate names required")
        names = list(covariate_names)
    dag_assessment = assess_assumed_dag(dag)
    if dag is not None:
        graph_names = {n["name"] for n in dag_assessment["nodes"]}
        if any(n not in graph_names for n in names): raise ValueError("Every covariate must name a supplied DAG node")
        if dag_assessment["exposure"] in names or dag_assessment["outcome"] in names:
            raise ValueError("Exposure and outcome cannot be included as balance covariates")
    if not isinstance(smd_threshold, (float, int)) or isinstance(smd_threshold, bool) or not math.isfinite(smd_threshold) or smd_threshold <= 0:
        raise ValueError("Positive finite SMD threshold required")
    if not isinstance(overlap_bounds, (tuple, list)) or len(overlap_bounds) != 2 or any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) for v in overlap_bounds) or not 0 < overlap_bounds[0] < overlap_bounds[1] < 1:
        raise ValueError("Overlap bounds must lie strictly inside [0,1]")
    if weights is not None and np.iscomplexobj(weights): raise ValueError("Complex weights are not supported")
    w = np.ones(len(X)) if weights is None else np.asarray(weights, dtype=float)
    if w.ndim != 1 or len(w) != len(X) or not np.isfinite(w).all() or np.any(w < 0) or np.any(w>1e100) or not np.any(w > 0):
        raise ValueError("Nonnegative finite aligned weights required")
    original_weights = w.copy()
    # Rescale weights for numerical stability; scale has no statistical effect.
    w = w / w.max()
    means, variances, ess, sizes, weight_summaries, variance_denominators = [], [], [], [], [], []
    for group in (0, 1):
        mask = (treatment == group) & (w > 0)
        sizes.append(int(mask.sum()))
        if mask.sum() < 2: raise ValueError("At least two positively weighted units in each treatment arm required")
        g, wg = X[mask], w[mask]
        total = wg.sum(); sumsq = np.square(wg).sum(); denominator = total - sumsq / total
        if denominator <= 0: raise ValueError("Insufficient effective variance information")
        mean = np.average(g, axis=0, weights=wg)
        means.append(mean)
        variances.append(np.sum(wg[:, None] * np.square(g - mean), axis=0) / denominator)
        ess.append(float(total * total / sumsq))
        original = original_weights[treatment == group]
        weight_summaries.append({"raw_count":int((treatment==group).sum()),"positive_weight_count":int(mask.sum()),
            "zero_weight_count":int((original==0).sum()),"minimum":float(original.min()),"maximum":float(original.max()),
            "mean":float(original.mean()),"sum":float(original.sum()),"effective_sample_size":ess[-1]})
        variance_denominators.append(float(denominator))
    pooled = np.sqrt((variances[0] + variances[1]) / 2)
    difference = np.abs(means[1] - means[0])
    smds = [float(d / s) if s > 0 else (0.0 if d == 0 else None) for d, s in zip(difference, pooled)]
    warning = any(s is None or s > smd_threshold for s in smds)
    comparisons = []
    for i,name in enumerate(names):
        smd = smds[i]
        comparison = "undefined" if smd is None else ("above_threshold" if smd>smd_threshold else "at_or_below_threshold")
        roles = dag_assessment["roles"].get(name,{}).get("roles",[])
        node = next((n for n in dag_assessment["nodes"] if n["name"]==name),None)
        graph_flags=[]
        if "treatment_descendant" in roles: graph_flags.append("assumed_treatment_descendant")
        if "mediator_path" in roles: graph_flags.append("assumed_mediator")
        if "collider" in roles: graph_flags.append("assumed_collider")
        if "unobserved" in roles: graph_flags.append("unobserved_node_cannot_be_verified_by_supplied_measurement")
        confirmed = dag_assessment["status"]=="assumed_confirmed"
        if node and node["timing"]!="pre_treatment": graph_flags.append("not_declared_pre_treatment")
        if not confirmed:
            graph_interpretation="The directional DAG is missing or unconfirmed; this is a measured arm comparison only, with graph-dependent causal interpretation unresolved."
        elif graph_flags:
            graph_interpretation="Under the explicitly assumed DAG, this variable has adjustment-role cautions: "+", ".join(graph_flags)+". Balance cannot justify adjustment or a total-effect interpretation; specialist review is required."
        elif "candidate_common_cause" in roles and node and node["observed"] and node["timing"]=="pre_treatment":
            graph_interpretation="Under the explicitly assumed DAG, this is an observed pre-treatment candidate common cause of exposure and outcome. The comparison assesses measured balance for this covariate; it cannot establish exchangeability or validate the assumed arrows."
        else:
            graph_interpretation="Under the explicitly assumed DAG, no safe adjustment-set conclusion is computed for this variable. The comparison describes its measured arm distributions only."
        numeric_text=("Absolute SMD is undefined because pooled variation is zero while arm means differ; flag the comparison." if smd is None else
            f"Absolute SMD {smd:.6g} is {'above' if smd>smd_threshold else 'at or below'} the configured screen {smd_threshold:.6g}.")
        comparisons.append({"covariate":name,"control_mean":float(means[0][i]),"treated_mean":float(means[1][i]),
            "control_variance":float(variances[0][i]),"treated_variance":float(variances[1][i]),
            "absolute_mean_difference":float(difference[i]),"pooled_standard_deviation":float(pooled[i]),
            "absolute_standardized_mean_difference":smd,"comparison":comparison,
            "threshold":float(smd_threshold),"assumed_graph_roles":roles,"graph_flags":graph_flags,
            "numeric_interpretation":numeric_text,"dag_interpretation":graph_interpretation})
    balance = {"status": "warning" if warning else "no_issue_detected",
               "absolute_standardized_mean_differences": smds,
               "undefined_smd_count": sum(s is None for s in smds),
               "smd_threshold": float(smd_threshold), "positively_weighted_arm_sizes": sizes,
               "effective_sample_sizes": ess,
               "raw_arm_sizes":[int((treatment==g).sum()) for g in (0,1)],
               "arm_order":["control_0","treated_1"],"arm_weight_summaries":weight_summaries,
               "variance_denominators_after_common_weight_rescaling":variance_denominators,
               "variance_formula":"sum(w*(x-weighted_mean)^2)/(sum(w)-sum(w^2)/sum(w)); common rescaling cancels",
               "smd_formula":"abs(treated_mean-control_mean)/sqrt((treated_variance+control_variance)/2)",
               "threshold_rationale":"User-configured descriptive heuristic; 0.1 is a conventional screen, not a significance test or causal-identification guarantee.",
               "comparisons":comparisons,
               "interpretation":("No issue was detected by these measured SMD comparisons: every defined absolute SMD is at or below the configured threshold. " if not warning else "At least one measured SMD is above the configured threshold or undefined; the comparison is flagged. ")+
                   "See each arm mean, variance, denominator, and graph-specific caveat. This does not prove exchangeability, causal identification, or that adjustment is appropriate.",
               "limitations": ["Measured covariates only; numerical balance cannot establish exchangeability or exclude unmeasured confounding.",
                               "Zero pooled variance with a nonzero difference is undefined and flagged; constant equal columns have SMD zero.",
                               "No covariate timing is inferred; supply only appropriate pre-treatment variables."]}
    overlap = {"status": "not_checked", "limitations": ["No propensity scores supplied; population positivity is not assessed."]}
    if propensity is not None:
        if np.iscomplexobj(propensity): raise ValueError("Complex propensity scores are not supported")
        p = np.asarray(propensity, dtype=float)
        if p.ndim != 1 or len(p) != len(X) or not np.isfinite(p).all() or np.any((p < 0) | (p > 1)):
            raise ValueError("Finite aligned propensity probabilities in [0,1] required")
        ranges = [[float(p[treatment == g].min()), float(p[treatment == g].max())] for g in (0, 1)]
        lower, upper = max(r[0] for r in ranges), min(r[1] for r in ranges)
        extremes = int(((p < overlap_bounds[0]) | (p > overlap_bounds[1])).sum())
        disjoint = lower > upper
        overlap = {"status": "fail" if disjoint else ("warning" if extremes else "no_issue_detected"),
                   "arm_propensity_ranges": ranges, "common_support_interval": None if disjoint else [lower, upper],
                   "outside_screen_bounds_count": extremes, "screen_bounds": list(overlap_bounds),
                   "sample_size": int(len(p)),
                   "comparison":{"common_support_lower":lower,"common_support_upper":upper,"ranges_disjoint":disjoint,
                       "outside_bounds_count":extremes,"total_count":int(len(p))},
                   "interpretation":("Observed arm propensity ranges are disjoint. " if disjoint else "Observed arm propensity ranges intersect. ")+
                       f"{extremes} of {len(p)} scores are outside the configured bounds [{overlap_bounds[0]}, {overlap_bounds[1]}]. This compares observed scores only; it does not establish population positivity or a correct propensity model.",
                   "limitations": ["Observed propensity support only; no proof of structural positivity or correctness of the propensity model.",
                                   "Ranges and heuristic cutoffs hide local sparsity and multivariate overlap problems; inspect distributions and design context."]}
    return {"registry_version": CAUSAL_REGISTRY_VERSION, "estimand":estimand,"assumed_dag":dag_assessment,
            "balance": balance, "overlap": overlap,
            "graph_dependent_interpretation":"conditional_on_assumed_dag" if dag_assessment["status"]=="assumed_confirmed" else "unresolved",
            "estimand_caution":"This helper compares weighted measured distributions; supplied weights are not verified as appropriate for "+estimand+". Total effects can be distorted by treatment-descendant, mediator or collider adjustment; direct effects need a separate estimand and identification argument.",
            "causal_language": "blocked", "privacy": "These aggregate diagnostics can be sensitive; no automatic disclosure is authorized."}
