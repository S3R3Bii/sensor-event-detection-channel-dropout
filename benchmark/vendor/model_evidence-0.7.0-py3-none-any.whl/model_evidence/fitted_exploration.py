"""Bounded audits of existing stock sklearn PCA and KMeans fits.

No fitting, component/cluster selection, preprocessing repair or raw-record
export occurs. Stored training statistics and supplied-row summaries have
different names and provenance. These are descriptive, not causal, adapters.
"""
import math
import warnings

import numpy as np
import sklearn
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from sklearn.utils.validation import check_is_fitted

from .diagnostics import _common, _complete, _collect_visual, _unavailable_visual
from . import model_visuals as _visuals
from .report import evidence, make_report

MAX_CELLS = 2_000_000
MAX_FEATURES = 2048
MAX_ABSOLUTE_INPUT = 1e12
SILHOUETTE_LIMIT = 1000
SILHOUETTE_SEED = 2026
SPLITS = {"unknown", "training", "validation", "evaluation", "final_holdout"}
SOURCES = {
    "pca": "https://scikit-learn.org/stable/modules/generated/sklearn.decomposition.PCA.html",
    "kmeans": "https://scikit-learn.org/stable/modules/generated/sklearn.cluster.KMeans.html",
    "silhouette": "https://scikit-learn.org/stable/modules/generated/sklearn.metrics.silhouette_score.html",
}


def _unmasked(value, name):
    if np.ma.isMaskedArray(value) and bool(np.ma.getmaskarray(value).any()):
        raise ValueError(name + " contains masked values; converting to a plain array would discard missingness")
    return value


def _integer(value, name, maximum=1_000_000_000):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)) or not 0 < value <= maximum:
        raise ValueError(name + " must be a bounded positive integer in the fitted state")
    return int(value)


def _features(model, X):
    _unmasked(X, "Exploratory input")
    if np.iscomplexobj(X):
        raise ValueError("Exploratory input must contain real numeric values")
    try:
        values = np.asarray(X, dtype=float)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("PCA/KMeans need their original finite numeric feature representation") from exc
    if values.ndim != 2 or not 3 <= len(values) or not 1 <= values.shape[1] <= MAX_FEATURES or values.size > MAX_CELLS:
        raise ValueError("Exploratory input needs at least three rows, 1..2048 columns and at most 2 million cells")
    if not np.isfinite(values).all() or np.any(np.abs(values) > MAX_ABSOLUTE_INPUT):
        raise ValueError("Exploratory input must be finite with absolute values <=1e12; no rows are repaired")
    columns = getattr(X, "columns", None)
    named = columns is not None
    if named:
        names = [name.item() if isinstance(name, np.generic) else name for name in columns]
        valid = lambda name: ((isinstance(name, str) and bool(name.strip()) and len(name) <= 128) or
            (type(name) in {int, float} and abs(name) <= 1e100 and math.isfinite(name)))
        if any(not valid(name) for name in names) or len(set(names)) != len(names):
            raise ValueError("Exploratory pandas columns must have distinct bounded string/numeric names")
    else:
        names = ["x" + str(i + 1) for i in range(values.shape[1])]
    fitted_p = _integer(getattr(model, "n_features_in_", None), "n_features_in_", MAX_FEATURES)
    if values.shape[1] != fitted_p:
        raise ValueError("Input feature count differs from the frozen fit; supply its original feature representation")
    fitted_names = getattr(model, "feature_names_in_", None)
    if fitted_names is not None and named and list(fitted_names) != names:
        raise ValueError("Input feature names/order differ from the frozen fit; reorder explicitly outside this audit")
    alignment = "named_feature_order_verified" if fitted_names is not None and named else "positional_only; original feature identity is not verified"
    return values, names, alignment


def _vector(value, size, name, *, allow_nan=False):
    _unmasked(value, "Stored " + name)
    if np.iscomplexobj(value): raise ValueError("Stored " + name + " must be real numeric values")
    try:
        vector = np.asarray(value, dtype=float)
    except (TypeError, ValueError, OverflowError) as exc:
        raise ValueError("Invalid stored " + name) from exc
    if vector.shape != (size,) or np.any(np.isinf(vector)) or (not allow_nan and not np.isfinite(vector).all()):
        raise ValueError("Invalid shape/nonfinite values in stored " + name)
    if np.any(np.abs(vector[np.isfinite(vector)]) > 1e100):
        raise ValueError("Stored " + name + " exceeds the report numeric bound")
    return vector


def _geometry(X, names, *, model_issue=False):
    # Scaling the working calculation avoids avoidable variance underflow for
    # tiny finite columns. It does not change the supplied model or its inputs.
    scale = np.max(np.abs(X), axis=0)
    working = X / np.where(scale > 0, scale, 1.)
    sd = np.std(working, axis=0, ddof=0) * scale
    constant_mask = np.max(X, axis=0) == np.min(X, axis=0)
    constant = int(np.sum(constant_mask))
    sd_underflow = int(np.sum((~constant_mask) & (sd == 0)))
    positive = sd[sd > 0]
    log_ratio = float(np.log10(positive.max()) - np.log10(positive.min())) if len(positive) and not sd_underflow else None
    ratio = float(10. ** log_ratio) if log_ratio is not None and log_ratio <= 100 else None
    status = "fail" if constant or model_issue else "warning" if sd_underflow or (log_ratio is not None and log_ratio > 2) else "no_issue_detected"
    row = evidence("distance_geometry", status, "Supplied-feature constants and scale spread; frozen model coordinates are unchanged",
        observed={"group": "all supplied rows", "variables": names, "constant_columns": constant,
            "scale_ratio": ratio, "log10_scale_ratio": log_ratio, "scale_sd_underflow_columns": sd_underflow,
            "scale_ratio_exceeds_numeric_bound": bool(log_ratio is not None and log_ratio > 100)},
        thresholds={"constant_columns": 0, "scale_ratio_review": 100,
            "rationale": "An illustrative unit/scale review, not a universal validity boundary; no universal normal-feature requirement."},
        sample_size=len(X), limitations=["Scaling, measurement and the scientific suitability of Euclidean/variance geometry require human justification.",
            "Raw source grain, feature meaning and preprocessing history cannot be inferred from a fitted object."],
        remedies=["Review the existing coordinate system and measurement scale; any changed preprocessing needs a reviewed training-only refit."],
        provenance={"implementation": "fitted-exploration", "stage": "supplied_features"})
    if sd_underflow:
        row["limitations"].append("Some varying columns have standard deviations below floating-point resolution; their computed zero is not a constant-feature finding, and scale ratios are left unknown.")
    return row


def _adapter(model, names, alignment, split_role, *, training_n, extra=None):
    value = {"estimator_type": type(model).__name__, "sklearn_version": sklearn.__version__,
        "input_feature_names": names, "feature_alignment": alignment, "row_alignment": "supplied order; source entity identity is not verified",
        "source_split": split_role, "training_rows": training_n, "model_refit": False,
        "preprocessing_owner": "caller supplied the frozen model's feature representation; no preprocessing is fitted or repaired",
        "training_design_reconstructed": False, "raw_records_retained": False,
        "method_specific_scope": "descriptive fitted PCA/KMeans summaries; scientific meaning, generalization and causality are not established"}
    value.update(extra or {})
    return value


def audit_fitted_exploration(model, X, *, purpose, metadata=None, attestations=None, split_role="unknown"):
    """Describe a stock fitted PCA or KMeans object without refitting it.

    PCA requires ``purpose='description'``; KMeans requires ``'clustering'``.
    Exploration Pipelines/custom subclasses are unsupported because recovering
    their coordinate ownership would need a separately verified adapter.
    The high-level fitted adapter converts these ValueErrors into actionable
    unsupported reports. Timing/group metadata uses the supplied raw X shape.
    """
    if type(model) not in {PCA, KMeans}:
        raise ValueError("Only exact stock fitted sklearn PCA/KMeans objects are supported for exploration; Pipelines need a verified coordinate adapter")
    expected = "description" if type(model) is PCA else "clustering"
    if purpose != expected:
        raise ValueError(type(model).__name__ + " requires purpose='" + expected + "'; this is not a prediction or causal-effect adapter")
    if not isinstance(split_role, str) or split_role not in SPLITS:
        raise ValueError("Use a declared unknown/training/validation/evaluation/final_holdout split role")
    try:
        check_is_fitted(model)
    except (ValueError, TypeError, AttributeError) as exc:
        raise ValueError("Fit PCA/KMeans outside this audit using training-only choices, then pass the frozen fit") from exc
    values, names, alignment = _features(model, X)
    n, p = values.shape
    rows = _common(values, None, metadata)
    for row in rows:
        if row["requirement"] == "missingness": row["observed"]["variables"] = names
    limits = ["This is a frozen-object descriptive audit, not a new fit, model selection, causal identification or external-validity assessment.",
        "Fitted parameters, split declarations and human attestations are local editable evidence, not authenticated provenance.",
        "Aggregates, feature names and projection/cluster summaries may still be sensitive. No raw row records are exported."]
    if alignment.startswith("positional_only"):
        limits.append("Feature identity/order is positional only; an unnamed array cannot establish its original scientific feature mapping.")
    if split_role in {"unknown", "training"}:
        limits.append("The supplied role is unknown/training; these summaries cannot be called untouched held-out generalization results.")
    if type(model) is PCA:
        report = _pca(model, X, values, names, alignment, split_role, rows, limits, attestations)
    else:
        report = _kmeans(model, X, values, names, alignment, split_role, rows, limits, attestations)
    return report


def _parameter_visual_provenance(payload, parameter_ids, training_n, n, split_role):
    """Stored-fit parameters and supplied-row projections have different sources."""
    for panel in payload["panels"]:
        if panel["id"] in parameter_ids:
            panel["source_split"]="training"
            panel["n"]=training_n
            panel["limitations"].append("This parameter panel comes from the stored training fit; its n is the fitted training-row count, not the supplied projection/evaluation count.")
    payload["n"]=max(n,training_n)
    payload["source_split"]="mixed" if any(panel["source_split"]!=split_role for panel in payload["panels"]) else split_role
    try:
        _visuals.validate_visual_evidence(payload)
    except ValueError:
        return _unavailable_visual(n,split_role,"Stored training parameter provenance exceeds this bounded visual contract; no sample counts were relabeled or invented.")
    return payload


def _pca(model, original_X, X, names, alignment, split_role, rows, limits, attestations):
    n, p = X.shape
    components = _integer(getattr(model, "n_components_", None), "n_components_", p)
    training_n = _integer(getattr(model, "n_samples_", None), "n_samples_")
    _unmasked(model.components_, "Stored PCA components")
    if np.iscomplexobj(model.components_): raise ValueError("Stored PCA components must be real")
    matrix = np.asarray(model.components_, dtype=float)
    if matrix.shape != (components, p) or not np.isfinite(matrix).all():
        raise ValueError("Stored PCA components do not match the fitted feature/component shape")
    _vector(model.mean_, p, "mean_")
    _unmasked(model.whiten, "Stored PCA whiten parameter")
    variance = _vector(model.explained_variance_, components, "explained_variance_")
    singular = _vector(model.singular_values_, components, "singular_values_")
    ratios = _vector(model.explained_variance_ratio_, components, "explained_variance_ratio_", allow_nan=True)
    if np.any(variance < 0) or np.any(singular < 0):
        raise ValueError("Stored PCA variance/singular values must be nonnegative")
    ratios_valid = bool(np.isfinite(ratios).all() and np.all(ratios >= 0) and np.all(ratios <= 1 + 1e-8) and ratios.sum() <= 1 + 1e-8)
    if not ratios_valid and not (np.all(np.isnan(ratios)) and np.all(variance == 0)):
        raise ValueError("Stored PCA variance ratios are inconsistent or nonfinite")
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        native_projection = model.transform(original_X)
        _unmasked(native_projection, "Native PCA projection")
        if np.iscomplexobj(native_projection): raise ValueError("Native PCA projection must be real")
        projected = np.asarray(native_projection, dtype=float)
    if projected.shape != (n, components) or not np.isfinite(projected).all() or np.any(np.abs(projected) > 1e100):
        raise ValueError("Frozen PCA projection is nonfinite or inconsistent; no projection summary was invented")
    geometry = _geometry(X, names, model_issue=not ratios_valid)
    geometry["observed"].update({"training_rows": training_n, "fitted_components": components,
        "training_variance_ratio_available": ratios_valid, "zero_training_component_variances": int(np.sum(variance == 0))})
    if not ratios_valid:
        geometry["limitations"].append("The stored fit has zero/underflowed total variance; explained-variance fractions are undefined and are omitted rather than fabricated.")
    rows.append(geometry)
    adapter = _adapter(model, names, alignment, split_role, training_n=training_n, extra={
        "component_names": ["PC" + str(i + 1) for i in range(components)], "whiten": bool(model.whiten),
        "variance_statistics_split": "stored_training_fit", "projection_statistics_split": "supplied_rows",
        "projection_operation": "native frozen PCA.transform; no fit, inverse reconstruction or component selection",
        "native_operation_warning_count": len(captured), "primary_source": SOURCES["pca"]})
    estimates = {"adapter_status": "supported_exploration", "adapter": adapter,
        "n_components": components, "training_explained_variance": variance.tolist(), "training_singular_values": singular.tolist(),
        "supplied_projection_mean": projected.mean(axis=0).tolist(), "supplied_projection_sd": projected.std(axis=0, ddof=1).tolist()}
    if ratios_valid:
        estimates["training_explained_variance_ratio"] = ratios.tolist()
        estimates["retained_training_variance_fraction"] = float(ratios.sum())
        visual=_collect_visual(_visuals.pca_visual_evidence,projected,matrix,ratios,n=n,source_split=split_role)
        estimates["visual_evidence"]=_parameter_visual_provenance(visual,{"pca_variance","pca_loadings"},training_n,n,split_role)
    else:
        estimates["visual_evidence"]=_unavailable_visual(n,split_role,"The stored training fit has undefined explained-variance ratios; a finite-looking PCA variance/projection chart was not substituted.")
    limits.extend(["Explained variance and singular values come from the stored training fit, not from re-estimation on the supplied rows.",
        "Projection means/SD describe only supplied rows in frozen component coordinates; whitened component scores use the fitted training scale.",
        "Explained variance is not supervised predictive value and components are not validated causal or latent scientific factors.",
        "No component-count selection or distributional uncertainty is implemented."])
    return make_report("pca", "description", _complete("pca", "description", rows, attestations),
        {"n": n, "p": p, "training_n": training_n}, estimates, limits)


def _kmeans(model, original_X, X, names, alignment, split_role, rows, limits, attestations):
    n, p = X.shape
    k = _integer(getattr(model, "n_clusters", None), "n_clusters", MAX_FEATURES)
    _unmasked(model.cluster_centers_, "Stored KMeans centers")
    if np.iscomplexobj(model.cluster_centers_): raise ValueError("Stored KMeans centers must be real")
    centers = np.asarray(model.cluster_centers_, dtype=float)
    if centers.shape != (k, p) or not np.isfinite(centers).all() or np.any(np.abs(centers) > MAX_ABSOLUTE_INPUT):
        raise ValueError("Stored KMeans centers must be finite and match the frozen feature/count shape and numeric bound")
    _unmasked(model.labels_, "Stored KMeans training assignments")
    stored_labels = np.asarray(model.labels_)
    if stored_labels.ndim != 1 or not 1 <= len(stored_labels) <= 1_000_000_000:
        raise ValueError("Stored KMeans training-label count is unavailable or invalid")
    training_n = int(len(stored_labels))
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        native_labels = model.predict(original_X)
        _unmasked(native_labels, "Native KMeans assignments")
        labels = np.asarray(native_labels)
    if labels.shape != (n,) or labels.dtype.kind not in "iu" or np.any(labels < 0) or np.any(labels >= k):
        raise ValueError("Native KMeans predictions must be aligned integer assignments to the frozen centers")
    residual = X - centers[labels]
    inertia = float(np.sum(residual ** 2))
    if not math.isfinite(inertia) or abs(inertia) > 1e100:
        raise ValueError("Supplied-row squared distances exceed the report numeric bound")
    geometry = _geometry(X, names)
    if inertia == 0 and np.any(residual != 0):
        if geometry["status"] != "fail": geometry["status"] = "warning"
        geometry["limitations"].append("Squared distances underflowed floating-point range; the displayed numerical zero is not proof of exact or meaningful clusters.")
    geometry["observed"].update({"fitted_centers": k, "supplied_rows": n, "supplied_inertia": inertia,
        "inertia_denominator": "unweighted sum of squared Euclidean distances to each native assigned frozen center; no division or supplied weights",
        "native_operation_warning_count": len(captured)})
    rows.append(geometry)
    counts = np.bincount(labels, minlength=k)
    supplied_k = int(np.sum(counts > 0))
    sample_n = min(n, SILHOUETTE_LIMIT)
    selected = np.random.RandomState(SILHOUETTE_SEED).permutation(n)[:sample_n]
    sample_labels = labels[selected]
    sample_k = len(np.unique(sample_labels))
    score = None
    if 2 <= sample_k < sample_n:
        native_score = silhouette_score(X[selected], sample_labels, metric="euclidean")
        _unmasked(native_score, "Native silhouette score")
        computed = float(native_score)
        if not math.isfinite(computed) or not -1 - 1e-8 <= computed <= 1 + 1e-8:
            raise ValueError("Native silhouette computation returned an invalid value")
        score = computed
    rows.append(evidence("cluster_stability", "not_checked", "Internal Euclidean silhouette is descriptive; resampling/external stability was not assessed",
        observed={"group": "supplied predicted clusters", "variables": names, "supplied_cluster_count": supplied_k,
            "silhouette_sample_rows": sample_n, "sample_cluster_count": int(sample_k), "silhouette_euclidean": score,
            "silhouette_unavailable_reason": None if score is not None else "Requires 2..sample_n-1 distinct predicted groups in the fixed sample"},
        thresholds={"silhouette_range": [-1, 1], "adequacy_cutoff": None, "sample_limit": SILHOUETTE_LIMIT,
            "sample_seed": SILHOUETTE_SEED, "rationale": "No universal silhouette cutoff proves natural groups or stable clusters."},
        sample_size=n, limitations=["Sampling can omit rare groups; the fixed sample is not stratified and undefined comparisons are omitted.",
            "A high score does not establish real classes, population stability, a useful k, causality or external validity."],
        remedies=["Use prespecified resampling/external validation and domain review; do not select k using a final evaluation set."],
        provenance={"implementation": "fitted-exploration", "primary_source": SOURCES["silhouette"]}))
    iterations = _integer(getattr(model, "n_iter_", None), "n_iter_")
    maximum = _integer(model.max_iter, "max_iter")
    rows.append(evidence("convergence", "warning" if iterations >= maximum else "no_issue_detected",
        "Stored KMeans iteration count versus configured limit; no optimization was rerun",
        observed={"iterations": iterations, "configured_maximum": maximum, "group": "stored training fit", "variables": "frozen centers"},
        thresholds={"review_if": "iterations >= configured maximum", "rationale": "Reaching a limit prompts review; an earlier stop does not prove a global optimum or meaningful clusters."},
        sample_size=training_n, limitations=["The adapter cannot reconstruct solver history, initialization sensitivity or whether warnings were previously discarded."],
        remedies=["Review the original training convergence and initialization sensitivity; any refit is an explicit separate action."]))
    adapter = _adapter(model, names, alignment, split_role, training_n=training_n, extra={
        "cluster_ids": list(range(k)), "assignment_operation": "native frozen KMeans.predict; no fit or center selection",
        "inertia_statistics_split": "supplied_rows; stored training inertia is not reused",
        "inertia_weighting": "unweighted supplied rows; no sample weights are accepted by this audit",
        "native_operation_warning_count": len(captured), "primary_source": SOURCES["kmeans"]})
    estimates = {"adapter_status": "supported_exploration", "adapter": adapter,
        "fitted_cluster_count": k, "supplied_cluster_count": supplied_k, "supplied_cluster_sizes": counts.tolist(),
        "supplied_inertia": inertia, "mean_squared_centroid_distance": inertia / n, "silhouette_sample_size": sample_n}
    if score is not None: estimates["silhouette_euclidean"] = score
    visual=_collect_visual(_visuals.kmeans_visual_evidence,X,labels,centers,n=n,source_split=split_role)
    estimates["visual_evidence"]=_parameter_visual_provenance(visual,{"cluster_centers"},training_n,n,split_role)
    limits.extend(["Supplied-row inertia is recomputed against native assignments to the frozen centers; stored training inertia is not assigned to new data.",
        "Supplied counts, mean distances, inertia and silhouette are unweighted. A model originally fitted with sample weights still uses its frozen centers, but these summaries do not recreate weighted training metrics or weighted effective sample sizes.",
        "Counts, inertia and silhouette depend on supplied coordinates and sample composition; no universal Gaussian-feature requirement is imposed.",
        "No automatic cluster-count selection, stability resampling, population uncertainty, natural-class claim or outlier deletion is implemented."])
    return make_report("kmeans", "clustering", _complete("kmeans", "clustering", rows, attestations),
        {"n": n, "p": p, "training_n": training_n}, estimates, limits)
