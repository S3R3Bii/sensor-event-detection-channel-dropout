"""Explicitly launched, loopback-only human editor for assumed causal DAGs.

The server exposes an in-memory editor, not filesystem access or code execution.
Drawing or confirming arrows never verifies causality or numerically adjusts an
effect. Close the terminal (Ctrl+C) to stop; JSON export is an explicit browser
download. All graph semantics come from the shared causal/DAG implementation.
"""
from __future__ import annotations
import argparse
from copy import deepcopy
import json
from importlib.resources import files
from http.server import BaseHTTPRequestHandler, HTTPServer
import secrets
import socket
import threading
from time import monotonic
from urllib.parse import urlsplit

from .dag import validate_assumed_dag, assess_assumed_dag
from .mcp_adapter import strict_json

MAX_BODY=1_048_576
EDITOR_VERSION="1.0.0"
MAX_HISTORY=128
HTTP_CLOSE_DRAIN_BYTES=65_536
HTTP_CLOSE_DRAIN_SECONDS=.1

def _object(value,required,optional=()):
    if not isinstance(value,dict) or set(value)-set(required)-set(optional) or set(required)-set(value):
        raise ValueError("Invalid editor action fields")
    return value

def _text(value,name,maximum=512):
    if not isinstance(value,str) or not value.strip() or len(value)>maximum:
        raise ValueError(name+" must be nonempty bounded text")
    return value.strip()

def default_graph():
    return {"nodes":[{"name":"Z","observed":True,"timing":"pre_treatment"},
                     {"name":"T","observed":True,"timing":"at_treatment"},
                     {"name":"Y","observed":True,"timing":"post_treatment"}],
        "edges":[["Z","T"],["Z","Y"],["T","Y"]],"exposure":"T","outcome":"Y",
        "supplied_by":"Local editor operator","source":"Synthetic starting example; replace with reviewed assumptions",
        "confirmation_status":"unconfirmed","confirmation_basis":"","revision":0,"confirmed_revision":None,
        "history":[{"revision":0,"action":"created","description":"Created an unconfirmed synthetic teaching graph; no causal assumptions verified."}]}

def default_spec(graph):
    return {"schema_version":"1.0.0","design":"observational_adjustment","estimator":"ols",
        "exposure":graph["exposure"],"outcome":graph["outcome"],"outcome_role":"analysis_outcome",
        "estimand":"ATE","effect_type":"total","treatment_type":"binary","outcome_type":"continuous","adjustment_set":[]}

class EditorState:
    """Bounded, in-memory revision state; no persistence or auto-confirmation."""
    def __init__(self,graph=None):
        self.graph=validate_assumed_dag(default_graph() if graph is None else deepcopy(graph))
        # Opening even a confirmed supplied graph requires a fresh local confirmation.
        self.graph.update(confirmation_status="unconfirmed",confirmation_basis="",confirmed_revision=None)
        self.spec=default_spec(self.graph)
        self.previous_spec=deepcopy(self.spec)
        self.plan=None
        self.archived_plan=None
        self.imported_history=[]

    @property
    def revision(self): return self.graph["revision"]

    def _commit(self,candidate,spec,action,description,*,confirm=False):
        if len(self.graph["history"])>=MAX_HISTORY: raise ValueError("History limit reached; export this revision before starting a new editor session")
        candidate["revision"]=self.revision+1
        candidate["history"]=deepcopy(self.graph["history"])+[{"revision":candidate["revision"],"action":action,"description":description}]
        if confirm:
            candidate["confirmation_status"]="confirmed"; candidate["confirmed_revision"]=candidate["revision"]
        else:
            candidate.update(confirmation_status="unconfirmed",confirmation_basis="",confirmed_revision=None)
        checked=validate_assumed_dag(candidate)
        spec=self._validate_spec(spec,checked)
        if self.plan is not None and self.plan.get("status")=="supported_conditional_template": self.previous_spec=deepcopy(self.spec)
        if action=="import": self.previous_spec=default_spec(checked)
        self.graph=checked; self.spec=deepcopy(spec)
        if self.plan is not None: self.archived_plan=deepcopy(self.plan)
        self.plan=None

    def _check_revision(self,value):
        if type(value) is not int or value!=self.revision: raise ValueError("Stale editor revision; reload the current state before editing")

    def action(self,action,payload=None,*,expected_revision=None):
        self._check_revision(expected_revision)
        if not isinstance(action,str): raise ValueError("Invalid editor action")
        payload={} if payload is None else payload
        candidate=deepcopy(self.graph); spec=deepcopy(self.spec)
        names={n["name"] for n in candidate["nodes"]}
        description=""
        if action=="add_node":
            _object(payload,{"name","observed","timing"}); name=_text(payload["name"],"Node name",64)
            if name in names: raise ValueError("Node already exists")
            candidate["nodes"].append({"name":name,"observed":payload["observed"],"timing":payload["timing"]})
            description="Added node "+name
        elif action in {"remove_node","rename_node","update_node"}:
            required={"name"} if action=="remove_node" else {"name","new_name"} if action=="rename_node" else {"name","observed","timing"}
            _object(payload,required); name=_text(payload["name"],"Node name",64)
            if name not in names: raise ValueError("Unknown node")
            if action=="remove_node":
                if name in {candidate["exposure"],candidate["outcome"]}: raise ValueError("Assign another exposure/outcome before removing its current node")
                candidate["nodes"]=[n for n in candidate["nodes"] if n["name"]!=name]
                candidate["edges"]=[e for e in candidate["edges"] if name not in e]
                spec["adjustment_set"]=[n for n in spec["adjustment_set"] if n!=name]; description="Removed node "+name+" and its edges/adjustment selection"
            elif action=="rename_node":
                new=_text(payload["new_name"],"New node name",64)
                if new in names: raise ValueError("New node name already exists")
                for n in candidate["nodes"]:
                    if n["name"]==name: n["name"]=new
                candidate["edges"]=[[new if p==name else p for p in e] for e in candidate["edges"]]
                for key in ("exposure","outcome"):
                    if candidate[key]==name: candidate[key]=new; spec[key]=new
                spec["adjustment_set"]=[new if p==name else p for p in spec["adjustment_set"]]
                description="Renamed node "+name+" to "+new+" including references"
            else:
                for n in candidate["nodes"]:
                    if n["name"]==name: n.update(observed=payload["observed"],timing=payload["timing"])
                description="Changed observed/timing assumptions for "+name
        elif action in {"add_edge","remove_edge","reverse_edge"}:
            _object(payload,{"source","target"}); edge=[payload["source"],payload["target"]]
            if not all(isinstance(p,str) and p in names for p in edge): raise ValueError("Edge endpoints must reference existing nodes")
            if action=="add_edge":
                if edge in candidate["edges"]: raise ValueError("Edge already exists")
                candidate["edges"].append(edge)
            else:
                if edge not in candidate["edges"]: raise ValueError("Unknown directed edge")
                candidate["edges"].remove(edge)
                if action=="reverse_edge":
                    reverse=edge[::-1]
                    if reverse in candidate["edges"]: raise ValueError("Reverse edge already exists")
                    candidate["edges"].append(reverse)
            description=action.replace("_"," ").capitalize()+": "+edge[0]+" -> "+edge[1]
        elif action=="set_roles":
            _object(payload,{"exposure","outcome"})
            if not all(isinstance(payload[k],str) and payload[k] in names for k in payload): raise ValueError("Roles must reference existing nodes")
            candidate.update(payload); spec.update(payload); description="Changed exposure/outcome roles"
        elif action=="set_adjustment":
            _object(payload,{"names"}); selected=payload["names"]
            if not isinstance(selected,list) or any(not isinstance(n,str) or n not in names or n in {candidate["exposure"],candidate["outcome"]} for n in selected) or len(set(selected))!=len(selected): raise ValueError("Adjustment set must contain distinct existing covariate nodes, excluding exposure and outcome")
            spec["adjustment_set"]=sorted(selected); description="Changed proposed adjustment set to "+(", ".join(selected) or "none")+"; no numerical adjustment performed"
        elif action=="set_spec":
            allowed={"design","estimator","estimand","effect_type","treatment_type","outcome_type","outcome_role"}
            _object(payload,allowed)
            spec.update({k:_text(v,k,64) for k,v in payload.items()}); description="Changed intended design, estimand or estimator specification"
        elif action=="set_provenance":
            _object(payload,{"supplied_by","source"})
            candidate.update({k:_text(v,k,512) for k,v in payload.items()}); description="Changed source/provenance of the assumed graph"
        elif action=="confirm":
            _object(payload,{"reviewer","basis"})
            candidate["supplied_by"]=_text(payload["reviewer"],"Reviewer",256)
            candidate["confirmation_basis"]=_text(payload["basis"],"Confirmation basis",2048)
            description="Explicit human confirmation of this assumed graph by "+candidate["supplied_by"]+"; not verification"
        elif action=="import":
            _object(payload,{"document"}); document=payload["document"]
            if not isinstance(document,dict): raise ValueError("Imported JSON must be an editor export or DAG object")
            if len(self.imported_history)>=8: raise ValueError("Imported-history limit reached; export before starting another editor session")
            raw=document.get("graph",document); imported=validate_assumed_dag(raw)
            incoming_spec=document.get("analysis_spec",default_spec(imported))
            incoming_spec=self._import_spec(incoming_spec,imported)
            # Imported confirmation and derived reports/code are never trusted.
            imported_history=deepcopy(imported.get("history",[]))
            self._commit(imported,incoming_spec,"import","Imported graph JSON; discarded stored confirmation and stale derived interpretation")
            self.imported_history=self.imported_history+[imported_history]
            return self.snapshot()
        elif action=="generate_plan":
            _object(payload,set())
            from .code_plan import generate_code_plan
            self.plan=generate_code_plan(self.graph,self.previous_spec,self.spec,prior_plan=self.archived_plan)
            return self.snapshot()
        else: raise ValueError("Unknown bounded editor action")
        if candidate==self.graph and spec==self.spec and action!="confirm": return self.snapshot()
        self._commit(candidate,spec,action,description,confirm=action=="confirm")
        return self.snapshot()

    def _import_spec(self,spec,graph):
        return self._validate_spec(spec,graph)

    def _validate_spec(self,spec,graph):
        expected=set(default_spec(graph)); _object(spec,expected)
        if any(not isinstance(v,str) or len(v)>64 for k,v in spec.items() if k!="adjustment_set"): raise ValueError("Invalid imported analysis specification")
        if spec["schema_version"]!="1.0.0" or spec["exposure"]!=graph["exposure"] or spec["outcome"]!=graph["outcome"]: raise ValueError("Imported specification must match graph exposure/outcome and version")
        names={n["name"] for n in graph["nodes"]}; selected=spec["adjustment_set"]
        if not isinstance(selected,list) or any(not isinstance(n,str) or n not in names or n in {graph["exposure"],graph["outcome"]} for n in selected) or len(set(selected))!=len(selected): raise ValueError("Invalid adjustment set")
        choices={"design":{"randomized_trial","observational_adjustment","matching","weighting","did","rd","iv"},
            "estimator":{"ols","logistic","other"},"estimand":{"ATE","ATT","ATC","CATE","LATE","ITT","per_protocol","local_effect"},
            "effect_type":{"total","direct"},"treatment_type":{"binary","continuous","categorical","other"},
            "outcome_type":{"continuous","binary","count","survival","other"},"outcome_role":{"analysis_outcome","other"}}
        if any(spec[k] not in choices[k] for k in choices): raise ValueError("Unknown or unsupported editor analysis specification value")
        return deepcopy(spec)

    def snapshot(self):
        from .causal import assess_causal_claim,explain_causal_audit
        assessment=assess_assumed_dag(self.graph)
        by_name={n["name"]:n for n in self.graph["nodes"]}
        adjustments=[{"name":n,"timing":by_name[n]["timing"] if by_name[n]["timing"] in {"pre_treatment","post_treatment"} else "unknown","role":"unknown","included":True} for n in self.spec["adjustment_set"]]
        claim={"population":"Unspecified population; supply study-specific evidence outside this editor", "treatment":self.graph["exposure"],"comparator":"Unspecified comparator",
            "outcome":self.graph["outcome"],"estimand":self.spec["estimand"],
            "time_zero":"Unspecified time zero","follow_up":"Unspecified follow-up",
            "identification_strategy":self.spec["design"],"dag_mapping":{"exposure_node":self.graph["exposure"],"outcome_node":self.graph["outcome"],"basis":"Explicit current editor exposure/outcome role selections for this draft; not an empirical validation."}}
        report=assess_causal_claim(claim,dag=self.graph,adjustment_variables=adjustments,
            unknowns=["Editor graph is assumed, not verified. No data, estimation or code execution occurs.","Population, comparator, time zero and follow-up are unspecified in this editor draft."])
        return {"editor_schema_version":EDITOR_VERSION,"graph":deepcopy(self.graph),"analysis_spec":deepcopy(self.spec),
            "previous_analysis_spec":deepcopy(self.previous_spec),"adjustment_set":deepcopy(self.spec["adjustment_set"]),
            "assessment":assessment,"causal_report":report,"narrative":explain_causal_audit(report),
            "code_plan":deepcopy(self.plan),"archived_code_plan":deepcopy(self.archived_plan),
            "code_plan_stale":self.plan is None and self.archived_plan is not None,
            "imported_history":deepcopy(self.imported_history),
            "limitations":["Human confirmation is an attestation, not proof; arrows are assumptions.","Editing relationships does not numerically adjust an effect. No analysis code is executed.","Imported confirmations and derived results are invalidated. Export/import history is editable, not signed.","At most 128 actions per session; export before starting a new session. Up to eight imported history sets are retained."]}

class EditorServer(HTTPServer):
    def __init__(self,address=("127.0.0.1",0),state=None):
        if address[0]!="127.0.0.1": raise ValueError("Editor binds only to IPv4 loopback")
        self.state=EditorState() if state is None else state
        self.token=secrets.token_urlsafe(32)
        self.lock=threading.Lock()
        super().__init__(address,EditorHandler)

    @property
    def origin(self): return "http://127.0.0.1:"+str(self.server_address[1])

    def shutdown_request(self,request):
        """Bounded staged close; discarded bytes never become another request.

        Early body/auth rejections can leave in-flight bytes on Windows. Closing
        immediately can reset TCP before the client receives the HTTP response
        (RFC9112 section 9.6). Half-close the write side, discard at most 64 KiB
        for at most 100 ms total, then close. This is transport cleanup, not parsing or
        accepting a larger body, and is not a guarantee against host aborts.
        """
        deadline=monotonic()+HTTP_CLOSE_DRAIN_SECONDS
        remaining=HTTP_CLOSE_DRAIN_BYTES
        try:
            request.shutdown(socket.SHUT_WR)
            while remaining>0:
                wait=min(HTTP_CLOSE_DRAIN_SECONDS,deadline-monotonic())
                if wait<=0: break
                request.settimeout(wait)
                chunk=request.recv(min(8192,remaining))
                if not chunk: break
                remaining-=len(chunk)
        except OSError:
            # Includes timeout, a peer already closed/reset, or an unusable socket.
            # The response was already generated; never reprocess or retry it.
            pass
        finally:
            self.close_request(request)

class EditorHandler(BaseHTTPRequestHandler):
    def log_message(self,*args): pass

    def _send(self,status,data,content_type="application/json; charset=utf-8"):
        raw=data.encode("utf-8") if isinstance(data,str) else json.dumps(data,ensure_ascii=True,allow_nan=False).encode("utf-8")
        self.send_response(status); self.send_header("Content-Type",content_type); self.send_header("Content-Length",str(len(raw)))
        self.send_header("Cache-Control","no-store"); self.send_header("X-Content-Type-Options","nosniff")
        self.send_header("Referrer-Policy","no-referrer")
        self.send_header("Content-Security-Policy",f"default-src 'none'; style-src 'unsafe-inline'; script-src 'nonce-{self.server.token}'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'none'")
        self.end_headers(); self.wfile.write(raw)

    def _trusted(self,token=False):
        expected=urlsplit(self.server.origin).netloc
        if self.headers.get("Host")!=expected: return False
        origin=self.headers.get("Origin")
        if origin is not None and origin!=self.server.origin: return False
        return not token or secrets.compare_digest(self.headers.get("X-Editor-Token",""),self.server.token)

    def do_GET(self):
        if not self._trusted(): self._send(403,{"error":"Local origin/host required"}); return
        if self.path=="/":
            html=files("model_evidence.resources").joinpath("dag_editor.html").read_text(encoding="utf-8").replace("__EDITOR_TOKEN__",self.server.token)
            self._send(200,html,"text/html; charset=utf-8")
        elif self.path=="/api/state" and self._trusted(token=True):
            with self.server.lock: self._send(200,self.server.state.snapshot())
        else: self._send(404,{"error":"Unknown route"})

    def do_POST(self):
        if not self._trusted(token=True): self._send(403,{"error":"Local origin and editor token required"}); return
        if self.path!="/api/action": self._send(404,{"error":"Unknown route"}); return
        if self.headers.get("Transfer-Encoding") is not None or self.headers.get("Content-Type","").split(";")[0]!="application/json": self._send(415,{"error":"Bounded JSON body required"}); return
        try:
            length=int(self.headers.get("Content-Length","-1"))
            if not 0<length<=MAX_BODY: raise ValueError("Editor JSON body exceeds limit")
            request=strict_json(self.rfile.read(length),limit=MAX_BODY)
            _object(request,{"action","payload","expected_revision"})
            with self.server.lock: result=self.server.state.action(**request)
        except (ValueError,TypeError,KeyError) as exc:
            self._send(400,{"error":str(exc)[:512]}); return
        self._send(200,result)

    def do_OPTIONS(self): self._send(405,{"error":"Cross-origin access is not supported"})
    def do_PUT(self): self._send(405,{"error":"Method not supported"})
    def do_DELETE(self): self._send(405,{"error":"Method not supported"})

def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument("--port",type=int,default=0)
    args=parser.parse_args(argv)
    if not 0<=args.port<=65535: parser.error("port must be 0..65535")
    with EditorServer(("127.0.0.1",args.port)) as server:
        print("Model Evidence local DAG editor: "+server.origin,flush=True)
        print("Loopback only; no files or code executed. Ctrl+C stops the editor.",flush=True)
        try: server.serve_forever()
        except KeyboardInterrupt: pass

if __name__=="__main__": main()
