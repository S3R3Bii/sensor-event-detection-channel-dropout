"""Standard local reports: a figure and key-metrics table are always exported.

No network, server, arbitrary source execution, or data repair. Numerical APIs
remain pure; this explicit renderer writes a content-addressed report directory.
Figures, HTML tables, CSV and metrics JSON use one normalized row collection.
"""
from collections import Counter
from copy import deepcopy
import csv
import hashlib
from html import escape
import io
import json
import math
from pathlib import Path

RENDERER_VERSION="1.7.0"
MAX_BYTES=4_194_304
MAX_ROWS=2048
STATUS_LABELS={
    "fail":"Observed failure/concern", "warning":"Observed concern",
    "not_checked":"Unresolved/manual justification", "not_applicable":"Not applicable",
    "no_issue_detected":"No issue detected by this diagnostic",
    "reported_support":"Reported support; not independently verified",
    "not_reported":"Not reported; practice unknown", "unavailable":"Evidence unavailable",
    "not_assessed":"Not assessed", "contradicted":"Contradicted evidence",
    "blocked":"Blocked", "supported_with_limitations":"Supported with limitations",
    "proposed":"Proposed; not run", "not_run":"Not run",
    "computed_comparison":"Computed comparison; conditions still require review",
    "supported_conditional_template":"Conditional template; no code executed",
    "needs_confirmation":"Needs human confirmation", "no_supported_correction":"No supported correction",
}
COLORS={"fail":"#a92731","warning":"#926100","contradicted":"#a92731",
    "no_issue_detected":"#176b59","reported_support":"#176b59",
    "supported_with_limitations":"#176b59","not_applicable":"#596573"}
COLUMNS=("id","label","stage","group","variables","n","split","purpose","original","revised",
    "units","comparison","threshold","status","status_label","interpretation","limitations","source","remedy")

def _json(value):
    return json.dumps(value,sort_keys=True,ensure_ascii=True,allow_nan=False,separators=(",",":"))

def _bounded(value,depth=0):
    if depth>30: raise ValueError("Report nesting exceeds renderer limit")
    if value is None or type(value) is bool: return
    if type(value) in {int,float}:
        if abs(value)>10**100 or not math.isfinite(value): raise ValueError("Nonfinite or oversized report number")
    elif isinstance(value,str):
        if len(value)>65536: raise ValueError("Report text exceeds renderer limit")
        if any((ord(c)<32 and c not in "\t\n\r") or 0xD800<=ord(c)<=0xDFFF or ord(c)%65536 in {65534,65535} for c in value):
            raise ValueError("Report text contains characters invalid in XML/HTML exports")
    elif isinstance(value,list):
        if len(value)>10000: raise ValueError("Report array exceeds renderer limit")
        for v in value: _bounded(v,depth+1)
    elif isinstance(value,dict):
        if len(value)>2048 or not all(isinstance(k,str) and len(k)<=256 for k in value): raise ValueError("Invalid report object")
        for k in value: _bounded(k,depth+1)
        for v in value.values(): _bounded(v,depth+1)
    else: raise ValueError("Renderer accepts JSON values only")

def _display(value):
    if value is None: return "Not supplied / not run"
    if isinstance(value,str): return value
    if type(value) is float: return format(value,".9g")
    if type(value) is bool: return "true" if value else "false"
    if type(value) is int: return str(value)
    return json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False)

def _label(status): return STATUS_LABELS.get(status,"Unresolved/status: "+str(status))

def _row(rows,label,*,stage,context,original=None,revised=None,units="Not supplied",comparison="No numerical comparison supplied",
         threshold="Not supplied; contextual review required",status="not_assessed",interpretation="",limitations=None,
         group="All supplied rows",variables=None,n=None,source="supplied report",remedy="Review before interpretation"):
    rows.append({"id":"r"+str(len(rows)+1).zfill(4),"label":label,"stage":stage,"group":group,
        "variables":variables or "Not supplied", "n":n if n is not None else context.get("n"),
        "split":context["split"],"purpose":context["purpose"],"original":original,"revised":revised,
        "units":units,"comparison":comparison,"threshold":threshold,"status":status,"status_label":_label(status),
        "interpretation":interpretation,"limitations":limitations or [],"source":source,"remedy":remedy})

def _metric_unit(name):
    if name=="confidence_level":return "dimensionless confidence probability"
    if name in {'forecast_interval_coverage','forecast_interval_level'}:return 'dimensionless probability/fraction'
    if name=="noise_fraction":return "fraction of all supplied observations"
    if name=="silhouette":return "dimensionless silhouette [-1,1]"
    if name in {'mean_forecast_interval_width','weighted_contrast','unweighted_difference'}:return 'response/outcome units (not supplied)'
    if name in {"r2","accuracy","balanced_accuracy","roc_auc","average_precision","brier","brier_score",
        "event_prevalence","prevalence_reference_ap","queue_capture","queue_fraction","f1_macro","f1_weighted",
        "silhouette_euclidean","retained_training_variance_fraction"}: return "dimensionless"
    if name=="log_loss" or name=="training_log_loss": return "nats per observation"
    if "mae" in name or "rmse" in name: return "target units (not supplied)"
    if "count" in name or name in {"residual_df","cluster_count","n_components","silhouette_sample_size",
        "silhouette_n","silhouette_eligible_n","silhouette_requested_n","silhouette_sample_limit",
        "silhouette_pairwise_cell_cap"}: return "count"
    if name in {"supplied_inertia","mean_squared_centroid_distance"}: return "squared fitted-input units"
    return "model scale; units not supplied"


def _multiclass_rows(report,context,rows):
    """Normalize declared class aggregates, refusing contradictory count arrays."""
    estimates=report["estimates"]; classes=estimates.get("class_order")
    if not isinstance(classes,list) or not 3<=len(classes)<=32: raise ValueError("Multiclass class order is missing or invalid")
    numeric=all(type(v) in {int,float} for v in classes)
    text=all(isinstance(v,str) and v.strip() and len(v)<=128 and all(ord(c)>=32 for c in v) for v in classes)
    if not (numeric or text) or len(set(classes))!=len(classes): raise ValueError("Multiclass labels must be unique uniform scalar labels")
    n=context["n"]; k=len(classes); matrix=estimates.get("confusion_matrix")
    if type(n) is not int or n<3: raise ValueError("Multiclass report needs a positive observed sample denominator")
    support=estimates.get("class_support"); predicted=estimates.get("predicted_class_support"); per_class=estimates.get("per_class")
    if not isinstance(matrix,list) or len(matrix)!=k or any(not isinstance(v,list) or len(v)!=k or any(type(c) is not int or c<0 for c in v) for v in matrix):
        raise ValueError("Multiclass confusion matrix must have aligned nonnegative integer counts")
    if not isinstance(support,list) or not isinstance(predicted,list) or len(support)!=k or len(predicted)!=k or any(type(c) is not int or c<0 for c in support+predicted):
        raise ValueError("Multiclass supports must match the declared classes")
    if support!=[sum(row) for row in matrix] or predicted!=[sum(row[j] for row in matrix) for j in range(k)] or sum(support)!=n:
        raise ValueError("Multiclass counts, supports and sample size disagree")
    if not isinstance(per_class,list) or len(per_class)!=k: raise ValueError("Aligned per-class metrics are required")
    for i,item in enumerate(per_class):
        if not isinstance(item,dict) or type(item.get("class_label")) is bool or item.get("class_label")!=classes[i] or type(item.get("support")) is not int or type(item.get("predicted_count")) is not int or item.get("support")!=support[i] or item.get("predicted_count")!=predicted[i]:
            raise ValueError("Per-class labels/supports do not match declared order")
        for key in ("precision","recall","f1","prevalence","roc_auc_ovr","average_precision"):
            value=item.get(key)
            if value is not None and (type(value) not in {int,float} or not 0<=value<=1): raise ValueError("Per-class metrics must be probabilities or explicit null")
        if item.get("prevalence") is None or not math.isclose(item["prevalence"],support[i]/n,rel_tol=1e-9,abs_tol=1e-12):
            raise ValueError("Per-class prevalence disagrees with the observed denominator")
        tp=matrix[i][i]
        expected={"precision":tp/predicted[i] if predicted[i] else None,"recall":tp/support[i] if support[i] else None,
            "f1":2*tp/(support[i]+predicted[i]) if support[i]+predicted[i] else None}
        for metric,wanted in expected.items():
            value=item.get(metric)
            if (wanted is None)!=(value is None) or (wanted is not None and not math.isclose(value,wanted,rel_tol=1e-9,abs_tol=1e-12)):
                raise ValueError("Per-class decision metric disagrees with confusion counts")
        if item.get("ranking_score_status") not in {"computed","not_checked"} or not isinstance(item.get("ranking_score_limit"),str):
            raise ValueError("Per-class ranking coverage must be explicit")
        ranked=item["ranking_score_status"]=="computed"
        if ranked and (not 0<support[i]<n or any(item.get(key) is None for key in ("roc_auc_ovr","average_precision"))):
            raise ValueError("Ranking requires both outcome groups and actual scores")
        if not ranked and any(item.get(key) is not None for key in ("roc_auc_ovr","average_precision")):
            raise ValueError("Unassessed ranking cannot contain numerical scores")
        class_name=_display(classes[i]); common={"context":context,"group":"Declared class "+class_name,
            "n":n,"limitations":["Class labels and aggregates may be sensitive. No class-specific uncertainty interval, calibration curve or causal claim is supplied."],
            "remedy":"Review this class's denominator and decision costs; do not tune on final evaluation outcomes."}
        for metric,value,units,comparison,limit in (
            ("support",support[i],"observations","observed class count / all supplied observations",f"Denominator n={n}; absence is not successful sensitivity"),
            ("predicted_count",predicted[i],"observations","predicted class count / all supplied observations",f"Denominator n={n}; decisions use supplied class labels"),
            ("precision",item.get("precision"),"dimensionless","true positives / predictions of this class",f"Predicted denominator={predicted[i]}; undefined if zero"),
            ("recall",item.get("recall"),"dimensionless","true positives / observations of this class",f"Observed denominator={support[i]}; undefined if zero"),
            ("f1",item.get("f1"),"dimensionless","2 true positives / (2 true positives + false positives + false negatives)","Undefined conventions and macro denominators follow supplied metric_configuration"),
            ("prevalence",item["prevalence"],"dimensionless","observed class count / all supplied observations",f"Denominator n={n}; descriptive AP reference, not fitted probability"),
            ("roc_auc_ovr",item.get("roc_auc_ovr"),"dimensionless","one declared class versus all other observed classes",item["ranking_score_limit"]),
            ("average_precision",item.get("average_precision"),"dimensionless","one-vs-rest ranking; compare with this class's prevalence",item["ranking_score_limit"])):
            if metric in {"precision","recall","f1"}:
                comparison+="; true positives="+str(matrix[i][i])+", observed count="+str(support[i])+", predicted count="+str(predicted[i])
            _row(rows,"Class "+class_name+": "+metric.replace("_"," "),stage="multiclass per-class metrics",
                original=value,units=units,status="not_checked" if value is None else "not_assessed",comparison=comparison,threshold=limit,
                interpretation=("Undefined or not assessed; no numeric value is invented." if value is None else "Observed class-specific summary; aggregate accuracy can conceal poor performance for a rare class."),
                variables={"class_index":i,"class_label":classes[i],"metric":metric},**common)
        _row(rows,"Observed class "+class_name+": confusion counts",stage="multiclass confusion matrix",context=context,
            original=matrix[i],units="observations",group="Observed class "+class_name,n=n,status="not_assessed",
            variables={"observed_class_index":i,"observed_class":classes[i],"predicted_class_order":classes,"metric":"confusion_counts"},
            comparison="rows = observed; columns = predicted in the exact declared class order",threshold={"row_denominator":support[i],"total_observations":n},
            interpretation="Diagonal counts are correct label decisions; off-diagonal counts identify specific mistakes, not causes.",
            limitations=["No threshold was selected and no probability calibration or ROC curve is inferred from label counts."],
            remedy="Review class-specific errors and sampling scope before making an operational claim.")
    defined=[item["f1"] for item in per_class if item.get("f1") is not None]
    observed=[item["recall"] for item in per_class if item.get("recall") is not None]
    expected={"accuracy":sum(matrix[i][i] for i in range(k))/n,"balanced_accuracy":sum(observed)/len(observed),
        "f1_macro":sum(defined)/len(defined),"f1_weighted":sum(item["f1"]*support[i] for i,item in enumerate(per_class) if item.get("f1") is not None)/n}
    for metric,wanted in expected.items():
        value=estimates.get(metric)
        if type(value) not in {int,float} or not math.isclose(value,wanted,rel_tol=1e-9,abs_tol=1e-12): raise ValueError("Aggregate multiclass metric disagrees with class counts")
    configuration=estimates.get("metric_configuration")
    if not isinstance(configuration,dict) or type(configuration.get("macro_f1_defined_class_denominator")) is not int or type(configuration.get("balanced_accuracy_denominator")) is not int or configuration.get("macro_f1_defined_class_denominator")!=len(defined) or configuration.get("balanced_accuracy_denominator")!=len(observed):
        raise ValueError("Aggregate multiclass denominators disagree with defined class metrics")


def _exploration_rows(report,context,rows):
    estimates=report["estimates"]; adapter=estimates.get("adapter") or {}
    if not isinstance(adapter,dict): adapter={}
    if report["method"]=="pca":
        fields=("training_explained_variance_ratio","training_explained_variance","training_singular_values","supplied_projection_mean","supplied_projection_sd")
        present=[key for key in fields if key in estimates]
        if not present: return
        first=estimates[present[0]]
        if not isinstance(first,list) or not first: raise ValueError("PCA component summaries must be nonempty arrays")
        k=len(first); names=adapter.get("component_names",["PC"+str(i+1) for i in range(k)])
        if "n_components" in estimates and (type(estimates["n_components"]) is not int or estimates["n_components"]!=k): raise ValueError("Stored PCA component count disagrees with component summaries")
        if not isinstance(names,list) or len(names)!=k or not all(isinstance(v,str) and v.strip() for v in names) or len(set(names))!=k:
            raise ValueError("PCA component names must match stored arrays")
        if k>256: raise ValueError("PCA component summaries exceed renderer bound")
        for key in present:
            values=estimates[key]
            if not isinstance(values,list) or len(values)!=k or not all(type(v) in {int,float} for v in values): raise ValueError("PCA component summaries must align")
            if key!="supplied_projection_mean" and any(v<0 for v in values): raise ValueError("PCA nonnegative summaries contain a negative value")
            if key=="training_explained_variance_ratio" and (any(v>1 for v in values) or sum(values)>1+1e-8): raise ValueError("PCA variance fractions are invalid")
            if key=="training_explained_variance_ratio" and "retained_training_variance_fraction" in estimates:
                retained=estimates["retained_training_variance_fraction"]
                if type(retained) not in {int,float} or not math.isclose(retained,sum(values),rel_tol=1e-9,abs_tol=1e-12): raise ValueError("Stored PCA retained variance disagrees with component fractions")
            training=key.startswith("training_"); local=deepcopy(context)
            if training:
                local["split"]="stored training fit statistics; training rows not revalidated by this report"
                local["n"]=report["sample_sizes"].get("training_n")
            unit=("dimensionless variance fraction" if key.endswith("variance_ratio") else "squared fitted-input units" if key=="training_explained_variance" else
                "fitted-input units times square root of training observations" if key=="training_singular_values" else
                "dimensionless whitened component scores" if adapter.get("whiten") is True else "component-score units from fitted input scale; physical units not supplied")
            for i,value in enumerate(values):
                _row(rows,names[i]+": "+key.replace("_"," "),stage="stored PCA training summary" if training else "supplied PCA projection summary",
                    context=local,original=value,units=unit,status="not_assessed",variables={"component_index":i,"component_name":names[i],"metric":key},
                    comparison="stored fitted component; no PCA fit or component selection performed by the renderer" if training else "aggregate transformed scores on the supplied rows; distinct from stored training variance",
                    threshold="No universal adequacy cutoff; component and scaling choices require justification",
                    interpretation="Variance captured or projected score summaries do not establish independent, causal or supervised predictive factors.",
                    limitations=["Training and supplied-row summaries describe different datasets. Component signs and scale depend on the supplied fitted transformation."],
                    remedy="Review training-only component selection, scaling, sampling scope and the intended use.")
        if "training_explained_variance_ratio" not in estimates:
            _row(rows,"Stored PCA explained variance",stage="stored PCA training summary",context=context,status="not_checked",
                interpretation="Stored component variance fractions were not supplied; no scree plot is invented.")
    elif report["method"]=="kmeans" and "supplied_cluster_sizes" in estimates:
        sizes=estimates["supplied_cluster_sizes"]; cluster_ids=adapter.get("cluster_ids")
        if not isinstance(sizes,list) or not sizes or len(sizes)>256 or not isinstance(cluster_ids,list) or len(cluster_ids)!=len(sizes) or any(type(v) is not int for v in cluster_ids) or cluster_ids!=list(range(len(sizes))):
            raise ValueError("K-means cluster IDs and sizes must align")
        if any(type(v) is not int or v<0 for v in sizes) or sum(sizes)!=context["n"]: raise ValueError("K-means cluster sizes must sum to supplied n")
        for metric,wanted in (("fitted_cluster_count",len(sizes)),("supplied_cluster_count",sum(v>0 for v in sizes))):
            if metric in estimates and (type(estimates[metric]) is not int or estimates[metric]!=wanted): raise ValueError("K-means cluster counts disagree with supplied sizes")
        if "silhouette_euclidean" in estimates and (type(estimates["silhouette_euclidean"]) not in {int,float} or not -1<=estimates["silhouette_euclidean"]<=1): raise ValueError("Euclidean silhouette must lie in [-1,1]")
        for metric in ("supplied_inertia","mean_squared_centroid_distance"):
            if metric in estimates and (type(estimates[metric]) not in {int,float} or estimates[metric]<0): raise ValueError("K-means squared-distance metrics must be nonnegative")
        if "supplied_inertia" in estimates and "mean_squared_centroid_distance" in estimates and not math.isclose(estimates["mean_squared_centroid_distance"],estimates["supplied_inertia"]/context["n"],rel_tol=1e-9,abs_tol=1e-12): raise ValueError("K-means mean distance disagrees with unweighted supplied inertia/n")
        for cluster_id,value in zip(cluster_ids,sizes):
            _row(rows,"Cluster "+_display(cluster_id)+": supplied size",stage="supplied K-means cluster sizes",context=context,
                original=value,units="observations",status="not_assessed",variables={"cluster_id":cluster_id,"metric":"supplied_cluster_size"},
                comparison="assigned count / supplied n with fixed supplied fitted centroids",threshold={"denominator_n":context["n"]},
                interpretation="An assignment count does not prove a stable, natural or causal category; zero counts mean no supplied rows assigned to that fitted cluster.",
                limitations=["Cluster labels are arbitrary IDs. No centroids, assignments, raw records or automatic refit are exposed."],
                remedy="Review distance/scaling and independent stability evidence; do not select k using a final evaluation split.")

def _calibration_rows(report,context,rows):
    """Normalize independently checkable bin arithmetic; adequacy stays unknown."""
    detail=report["estimates"].get("calibration_detail")
    if detail is None: return
    if not isinstance(detail,dict) or detail.get("adequacy_status")!="not_assessed" or detail.get("recalibration_fitted") is not False or detail.get("model_selection_performed") is not False:
        raise ValueError("Calibration detail must keep adequacy unassessed and recalibration unperformed")
    bins=detail.get("bins"); config=detail.get("configuration",{}); n=detail.get("sample_size")
    if not isinstance(config,dict) or config.get("strategy")!="uniform" or not isinstance(bins,list) or not 1<=len(bins)<=50 or type(config.get("n_bins")) is not int or config.get("n_bins")!=len(bins) or type(n) is not int or n<1 or n!=context["n"]:
        raise ValueError("Calibration bin configuration and sample denominator disagree")
    confidence=config.get("confidence_level")
    if type(confidence) not in {int,float} or not 0<confidence<1: raise ValueError("Invalid calibration confidence level")
    from scipy.stats import norm
    from .calibration import _wilson
    z=float(norm.isf((1-float(confidence))/2)); total=events=0; ece=gap_total=0.; mean_sum=0.
    role=detail.get("split_role")
    if role not in {"unknown","training","validation","evaluation","final_holdout"}: raise ValueError("Unknown calibration split")
    scope=dict(context);scope["split"]="caller-declared "+role+"; calibration adequacy unassessed"
    for i,item in enumerate(bins):
        if not isinstance(item,dict): raise ValueError("Invalid calibration bin")
        count=item.get("count"); count_events=item.get("event_count")
        if type(count) is not int or type(count_events) is not int or not 0<=count_events<=count or type(item.get("bin_index")) is not int or item.get("bin_index")!=i:
            raise ValueError("Calibration counts/index invalid")
        lower=item.get("lower_bound");upper=item.get("upper_bound")
        if type(lower) not in {int,float} or type(upper) not in {int,float} or not math.isclose(lower,i/len(bins),abs_tol=1e-12) or not math.isclose(upper,(i+1)/len(bins),abs_tol=1e-12):
            raise ValueError("Calibration boundaries differ from declared uniform bins")
        if item.get("left_inclusive") is not (i==0) or item.get("right_inclusive") is not True: raise ValueError("Calibration bin ownership is ambiguous")
        mean=item.get("mean_probability");rate=item.get("event_rate");gap=item.get("observed_minus_predicted");interval=item.get("event_rate_wilson_interval")
        if count:
            if any(type(v) not in {int,float} for v in (mean,rate,gap)) or not lower-1e-12<=mean<=upper+1e-12 or not math.isclose(rate,count_events/count,abs_tol=1e-12) or not math.isclose(gap,rate-mean,abs_tol=1e-12):
                raise ValueError("Calibration bin rates/gaps disagree with counts and probabilities")
            expected=_wilson(count_events,count,z)
            if not isinstance(interval,list) or len(interval)!=2 or any(type(v) not in {int,float} for v in interval) or any(not math.isclose(v,w,rel_tol=1e-9,abs_tol=1e-12) for v,w in zip(interval,expected)):
                raise ValueError("Calibration interval disagrees with declared Wilson method")
            ece+=count/n*abs(gap);gap_total+=count/n*gap;mean_sum+=count*mean
        elif any(v is not None for v in (mean,rate,gap,interval)) or count_events:
            raise ValueError("Empty calibration bins must remain explicitly unassessed")
        total+=count;events+=count_events
        common={"stage":"calibration bins","context":scope,"group":"Uniform probability bin "+str(i+1),"n":count,
            "threshold":{"probability_interval":[lower,upper],"left_inclusive":i==0,"right_inclusive":True,"confidence":confidence,"adequacy_cutoff":None},
            "status":"not_checked","interpretation":"Observed bin summary; calibration adequacy remains unresolved. Empty bins provide no evidence.",
            "limitations":["Pointwise Wilson intervals assume independent Bernoulli observations within each bin; no simultaneous band, mean-probability uncertainty or calibration proof.","No recalibration or model selection is performed; do not tune on final evaluation outcomes."],
            "remedy":"Review bin denominators, probability gaps and domain costs; fit any proposed recalibration on separate training/calibration data."}
        for metric,value,units,comparison in (("calibration_count",count,"observations","bin observations / all supplied observations n="+str(n)),
            ("calibration_events",count_events,"events","observed event count / this bin's observations"),
            ("calibration_mean_probability",mean,"probability","mean supplied event-1 probability in this bin"),
            ("calibration_event_rate",rate,"event fraction","observed events / bin observations"),
            ("calibration_gap",gap,"probability points","observed event fraction minus mean probability"),
            ("calibration_interval",interval,"event fraction","pointwise Wilson interval for this bin's event proportion")):
            _row(rows,"Calibration bin "+str(i+1)+": "+metric.removeprefix("calibration_").replace("_"," "),original=value,units=units,comparison=comparison,
                variables={"bin_index":i,"metric":metric,"bounds":[lower,upper]},**common)
    if total!=n or detail.get("event_count")!=events or detail.get("nonevent_count")!=n-events:
        raise ValueError("Calibration counts do not match sample/class denominators")
    for key,expected in (("ece",ece),("signed_gap",gap_total),("mean_probability",mean_sum/n),("event_prevalence",events/n)):
        value=detail.get(key)
        if type(value) not in {int,float} or not math.isclose(value,expected,rel_tol=1e-9,abs_tol=1e-12): raise ValueError("Calibration aggregate disagrees with bin values: "+key)


def _statistical_rows(report,context,rows):
    detail=report["estimates"].get("statistical_test")
    if detail is None: return
    required={"procedure","computational_status","statistic_name","statistic","p_value","degrees_of_freedom","alternative","null","effect","groups","configuration","warnings","limitations"}
    if not isinstance(detail,dict) or not required<=set(detail) or detail["procedure"]!=report["method"] or detail["computational_status"] not in {"computed","not_computable"}:
        raise ValueError("Statistical result must declare its actual procedure and computational support")
    if not isinstance(detail["configuration"],dict): raise ValueError("Statistical configuration must be an object")
    if not isinstance(detail["effect"],dict) or not {"name","estimate","units","confidence_interval"}<=set(detail["effect"]):
        raise ValueError("Statistical effect/interval contract missing")
    for key in ("statistic","p_value"):
        value=detail[key]
        if value is not None and type(value) not in {int,float}: raise ValueError("Invalid statistical numeric value")
    if detail["p_value"] is not None and not 0<=detail["p_value"]<=1: raise ValueError("Statistical p-value must lie in zero to one")
    effect=detail["effect"]; estimate=effect["estimate"]; interval=effect["confidence_interval"]
    if estimate is not None and type(estimate) not in {int,float}: raise ValueError("Invalid statistical effect estimate")
    if interval is not None:
        if not isinstance(interval,dict) or not {"level","lower","upper","method"}<=set(interval): raise ValueError("Incomplete statistical interval")
        if any(type(interval[k]) not in {int,float} for k in ("level","lower","upper")) or not 0<interval["level"]<1 or interval["lower"]>interval["upper"]:
            raise ValueError("Invalid statistical interval bounds/level")
        if estimate is None or not interval["lower"]-1e-12<=estimate<=interval["upper"]+1e-12: raise ValueError("Effect estimate and reported interval disagree")
        configured=detail["configuration"].get("confidence_level")
        if type(configured) not in {int,float} or not math.isclose(configured,interval["level"],rel_tol=0,abs_tol=1e-12):
            raise ValueError("Statistical interval level contradicts the configured confidence level")
    if not isinstance(detail["null"],dict) or not {"parameter","value"}<=set(detail["null"]): raise ValueError("Statistical null hypothesis is missing")
    if not isinstance(detail["groups"],list) or len(detail["groups"])>64: raise ValueError("Invalid statistical group aggregates")
    if not isinstance(detail["configuration"],dict) or any(not isinstance(detail[key],list) or not all(isinstance(item,str) for item in detail[key]) for key in ("warnings","limitations")):
        raise ValueError("Invalid statistical configuration/limitation fields")
    if detail["computational_status"]=="computed":
        groups=detail["groups"]; sizes=report["sample_sizes"]; procedure=detail["procedure"]
        if not groups or any(not isinstance(g,dict) or type(g.get("n")) is not int or g["n"]<0 for g in groups):
            raise ValueError("Computed statistical results require explicit nonnegative group denominators")
        counts=[g["n"] for g in groups]; total=sizes.get("n")
        paired={"paired_t_test","wilcoxon_signed_rank","pearson_correlation","spearman_correlation","friedman"}
        if procedure in paired:
            if any(n!=total for n in counts): raise ValueError("Paired/repeated group counts contradict the number of units/pairs")
            if "n_records" in sizes and sizes["n_records"]!=2*total: raise ValueError("Paired record denominator contradicts pair count")
            if "measurements" in sizes and sizes["measurements"]!=total*len(groups): raise ValueError("Repeated measurement denominator contradicts blocks and conditions")
        elif sum(counts)!=total:
            raise ValueError("Statistical group denominators contradict total sample size")
        if "groups" in sizes and sizes["groups"]!=len(groups): raise ValueError("Declared group count contradicts group summaries")
        if "conditions" in sizes and sizes["conditions"]!=len(groups): raise ValueError("Declared condition count contradicts repeated group summaries")
        for key,pos in (("n_x",0),("n_y",1)):
            if key in sizes and (len(counts)<=pos or sizes[key]!=counts[pos]): raise ValueError("Named sample denominator contradicts group summary")
        if procedure=="binomial_test":
            group=groups[0]
            if group.get("successes")!=sizes.get("successes") or group.get("failures")!=sizes.get("failures") or group["successes"]+group["failures"]!=total:
                raise ValueError("Binomial event counts contradict the trial denominator")
        if procedure in {"chi_square","fisher_exact"}:
            group=groups[0]; table=group.get("observed_counts")
            if not isinstance(table,list) or len(table)!=sizes.get("rows") or not table or any(not isinstance(row,list) or len(row)!=sizes.get("columns") for row in table):
                raise ValueError("Contingency table dimensions contradict declared categories")
            if any(type(v) is not int or v<0 for row in table for v in row): raise ValueError("Contingency frequencies must be nonnegative integers")
            row_totals=[sum(row) for row in table]; column_totals=[sum(row[j] for row in table) for j in range(len(table[0]))]
            if sum(row_totals)!=total or group.get("row_totals")!=row_totals or group.get("column_totals")!=column_totals:
                raise ValueError("Contingency margins/count denominator contradict observed cells")
    alpha=detail.get("alpha",.05)
    if type(alpha) not in {int,float} or not 0<alpha<1: raise ValueError("Invalid statistical alpha")
    comparison=detail.get("p_comparison")
    if comparison is not None:
        expected="not computable" if detail["p_value"] is None else "p < alpha" if detail["p_value"]<alpha else "p >= alpha"
        if not isinstance(comparison,dict) or comparison.get("comparison")!=expected or comparison.get("alpha")!=alpha:
            raise ValueError("Statistical p-value comparison is inconsistent")
    limits=detail["limitations"]+detail["warnings"]+[
        "Conditional reference calculation, not proof of assumptions, a probability the null is true, equivalence or causality.",
        "A p-value can round to zero in floating-point arithmetic; it is not mathematical impossibility."]
    common={"stage":"statistical comparison","context":context,"status":"not_assessed" if detail["computational_status"]=="computed" else "not_checked",
            "group":"supplied statistical samples/count aggregates","source":"declared procedure; deterministic numerical computation",
            "limitations":limits,"remedy":"Review the full design/assumption checklist, effect interval and prespecified multiplicity family before interpreting."}
    _row(rows,"Test statistic: "+str(detail["statistic_name"]),original=detail["statistic"],units="procedure-specific reference statistic",
         comparison=detail["null"],threshold=detail["configuration"],variables={"metric":"test_statistic"},
         interpretation="The statistic compares the supplied observations with the explicitly stated null/reference.",**common)
    _row(rows,"Unadjusted p value",original=detail["p_value"],units="dimensionless tail probability under null/reference",
         comparison=detail["null"],threshold={"alpha":alpha,"configuration":"prespecified by argument/default; no assumption pass verdict"},
         variables={"metric":"test_pvalue"},interpretation="An unadjusted tail probability; does not measure effect size or validate assumptions. Multiple comparisons may require a separately justified adjustment.",**common)
    _row(rows,"Degrees of freedom",original=detail["degrees_of_freedom"],units="reference degrees of freedom",
         comparison="Actual procedure-specific reference; exact/rank methods may not use a df parameter",threshold=detail["configuration"],
         variables={"metric":"test_df"},interpretation="Undefined/inapplicable degrees of freedom are retained as missing, never replaced with zero.",**common)
    _row(rows,"Effect: "+str(effect["name"]),original=estimate,units=effect["units"],comparison=detail["null"],
         threshold="Effect scale differs by procedure; inspect its stated estimand",variables={"metric":"test_effect","name":effect["name"]},
         interpretation="The observed effect estimate is distinct from the p-value; its scientific interpretation remains conditional.",**common)
    _row(rows,"Effect confidence interval",original=None if interval is None else [interval["lower"],interval["upper"]],units=effect["units"],
         comparison="Conditional interval for the named effect; no interval invented where unimplemented",threshold=interval or "Not implemented or not computable for this effect",
         variables={"metric":"test_effect_interval"},interpretation="Interval reference conditions and confidence level must be reviewed; coverage is not established by the chart.",**common)
    for i,group in enumerate(detail["groups"]):
        if not isinstance(group,dict): raise ValueError("Statistical group summaries must be objects")
        label=group.get("label",group.get("group","group "+str(i+1)))
        if not isinstance(label,str): raise ValueError("Statistical group label must be text")
        for metric,value in group.items():
            if metric in {"label","group"}: continue
            if metric=="n" and (type(value) is not int or value<0): raise ValueError("Group sample size must be a nonnegative integer")
            _row(rows,label+": "+metric.replace("_"," "),original=value,units="observations (count)" if metric=="n" else "as stated by group summary; variable units may be unspecified",
                 comparison="Actual aggregate for the declared group; no raw records returned",threshold="No universal adequacy cutoff",
                 variables={"metric":"test_group_"+metric,"group_index":i,"group_label":label},n=group.get("n",context["n"]),
                 interpretation="Sample/count aggregate; paired differences are separately labeled when used by the procedure.",**{**common,"group":label})


def _multiplicity(report):
    from .multiplicity import validate_multiplicity_result
    validate_multiplicity_result(report); canonical=deepcopy(report)
    context={"method":"Multiplicity adjustment: "+report["method"],"purpose":"association","split":"caller-declared prespecified hypothesis family; provenance unverified",
             "n":report["n_hypotheses"],"sample_sizes":{"n_hypotheses":report["n_hypotheses"]},"coverage":"executable bounded adjustment"}
    rows=[]
    for item in report["rows"]:
        _row(rows,"Hypothesis "+item["hypothesis_id"],stage="multiplicity adjustment",context=context,
             original=item["original_pvalue"],revised=item["adjusted_pvalue"],units="dimensionless p value",
             comparison="Original versus adjusted p value for this declared family",threshold={"alpha":report["alpha"],"reject_at_alpha":item["reject_at_alpha"]},
             status="not_assessed",variables={"metric":"multiplicity_pvalue","hypothesis":item["hypothesis_id"]},
             interpretation="Adjustment changes the multiple-testing decision rule; it does not repair invalid marginal p-values, design or effect estimates.",
             limitations=report["limitations"],remedy="Review family definition, valid marginal tests and method dependence conditions before interpretation.",source="deterministic multiplicity calculation")
    for assumption in report["assumptions"]:
        _row(rows,assumption["id"],stage="adjustment assumption",context=context,original=assumption["description"],units="evidence status",
             status=assumption["status"],source=assumption["source"],interpretation=assumption["description"],limitations=report["limitations"],
             remedy="Supply design/family evidence; computation alone cannot establish these conditions.")
    narrative=("We used "+report["method"]+" for the declared family of "+str(report["n_hypotheses"])+" hypotheses. The original p-values remain unchanged; adjusted values and decisions are shown separately. Effect estimates, confidence intervals, data and models were not changed. Valid marginal p-values and family/design conditions remain unresolved; this does not establish causality or repair invalid tests.")
    return canonical,context,rows,narrative,None


def _core(report):
    from .report import validate_report,gate_claims,explain_report
    from .registry import method_spec,load_registry,describe_requirements
    validate_report(report); canonical=deepcopy(report); canonical["claims"]=gate_claims(canonical)
    spec=method_spec(canonical["method"]); reg=load_registry(); method=canonical["method"]
    split=("supplied evaluation rows; provenance not independently verified" if method.startswith("prediction_") else
           "supplied fitting rows; training diagnostics" if method in {"ols","logistic"} else
           "supplied count-model rows; source role stated per panel" if method=="poisson_glm" else
           "supplied future forecast rows; native training diagnostics labeled separately" if method=='arima' else
           "supplied right-censored follow-up rows; time-zero/censoring design unverified" if method=='kaplan_meier' else
           "stored original mixed-model fitting rows; grouped conditional specification" if method=='gaussian_mixed_intercept' else
           "supplied weighting rows; propensity/design provenance unverified" if method=='causal_weighting' else
           "caller-supplied MCMC summary only; no original draws examined" if method=='bayesian_posterior_review' else
           "supplied task outputs/targets only; no framework model or original input inspected" if method=='architecture_output_review' else "supplied exploratory rows")
    adapter=canonical["estimates"].get("adapter")
    role=adapter.get("source_split",adapter.get("split_role")) if isinstance(adapter,dict) else None
    if method=='architecture_output_review':role=canonical['estimates'].get('architecture_review',{}).get('source_split')
    if isinstance(role,str) and role in {"unknown","training","validation","evaluation","final_holdout"}:
        split="caller-declared source split: "+role+"; "+split
    if "statistical_test" in canonical["estimates"]:
        split="caller-declared source split: "+str(role or "unknown")+"; supplied statistical samples/counts; design not independently verified"
    context={"method":spec["name"],"purpose":canonical["purpose"],"split":split,"n":canonical["sample_sizes"].get("n"),
        "sample_sizes":canonical["sample_sizes"],"coverage":spec["coverage"]}
    if method=='arima' and isinstance(adapter,dict) and adapter.get('model_family')=='univariate_nonseasonal_ARIMA':
        context['method']='Existing nonseasonal univariate ARIMA forecast audit'
    rows=[]
    if spec["coverage"]!="manual_only":
        _statistical_rows(canonical,context,rows)
        if method=="prediction_multiclass": _multiclass_rows(canonical,context,rows)
        if method in {"pca","kmeans"}: _exploration_rows(canonical,context,rows)
        _calibration_rows(canonical,context,rows)
        for name,value in canonical["estimates"].items():
            # Do not coerce booleans or adapter metadata into measurements.
            if type(value) not in {int,float} or name.startswith("baseline_"): continue
            baseline=canonical["estimates"].get("baseline_"+name)
            baseline=baseline if type(baseline) in {int,float} else None
            comparison="model versus supplied prespecified reference on identical rows" if baseline is not None else "descriptive supplied value; no adequacy cutoff"
            threshold="Not supplied; contextual review required"
            if method=="prediction_multiclass" and name in {"f1_macro","balanced_accuracy","f1_weighted"}:
                configuration=canonical["estimates"].get("metric_configuration",{})
                threshold=configuration
                comparison=("unweighted mean over classes with defined F1; absent/undefined classes are not silently assigned a score" if name=="f1_macro" else
                    "mean recall over observed true classes; absent true classes are not evaluated" if name=="balanced_accuracy" else
                    "support-weighted mean over defined per-class F1 values; weighting can conceal rare-class errors")
            elif method=="kmeans" and name in {"supplied_inertia","mean_squared_centroid_distance"}:
                comparison=("unweighted sum of squared distances from supplied rows to their fixed fitted centroid assignments" if name=="supplied_inertia" else
                    "unweighted supplied inertia / supplied observation count")
                threshold={"denominator_n":context["n"],"selection":"No k or centroid refit; no universal acceptable inertia"}
            metric_context=context
            if method=="pca" and name in {"retained_training_variance_fraction","n_components"} and "training_explained_variance_ratio" in canonical["estimates"]:
                metric_context=deepcopy(context); metric_context["split"]="stored training fit statistics; training rows not revalidated by this report"
                metric_context["n"]=canonical["sample_sizes"].get("training_n")
            metric_units=_metric_unit(name)
            if method=='architecture_output_review' and isinstance(canonical['estimates'].get('reconstruction'),dict) and name in {'mae','rmse'}:
                metric_units=canonical['estimates'].get('architecture_review',{}).get('declared_metadata',{}).get('output_units','supplied feature units (unspecified)')
            _row(rows,name.replace("_"," "),stage="future forecast evaluation" if method=='arima' else "evaluation" if method.startswith("prediction_") or (method=="poisson_glm" and role in {"validation","evaluation","final_holdout"}) else "conditional weighting calculation" if method=='causal_weighting' else "fitting/exploration",
                context=metric_context,original=value,revised=baseline,units=canonical['estimates'].get('ipw',{}).get('outcome_units',metric_units) if method=='causal_weighting' and name in {'weighted_contrast','unweighted_difference'} else metric_units,status="not_assessed",
                comparison=comparison,threshold=threshold,
                interpretation="A measured summary is not proof of assumptions, external validity, or a causal effect.",
                limitations=["Metrics are reported on the stated split. Numerical uncertainty is not supplied."],variables=name,
                remedy="Review provenance, reference choice and uncertainty before making decisions.")
        for name in ("coefficients","hc3_standard_errors","explained_variance_ratio"):
            values=canonical["estimates"].get(name)
            if not isinstance(values,list): continue
            if name=="explained_variance_ratio" and (not all(type(value) in {int,float} and 0<=value<=1 for value in values) or sum(values)>1+1e-8):
                raise ValueError("PCA variance fractions must be finite fractions with total at most one")
            for i,value in enumerate(values):
                if type(value) not in {int,float}: continue
                names=canonical["estimates"].get("coefficient_names")
                if names is not None and (not isinstance(names,list) or len(names)!=len(values) or not all(isinstance(v,str) and v for v in names)): raise ValueError("Coefficient names must align with actual parameter order")
                term=names[i] if name!="explained_variance_ratio" and names is not None else ("intercept" if name!="explained_variance_ratio" and i==0 else ("component "+str(i+1) if name=="explained_variance_ratio" else "x"+str(i)))
                _row(rows,name.replace("_"," ")+": "+term,stage="fitting/exploration",context=context,original=value,
                    units="dimensionless variance fraction" if name=="explained_variance_ratio" else "coefficient units (feature/target units not supplied)",
                    status="not_assessed",comparison="supplied fitted summary; no adequacy cutoff",variables=term,
                    interpretation="Column-order labels are explicit placeholders. A coefficient, standard error or variance fraction does not establish assumptions or causality.",
                    limitations=["No unreported interval, unit or effect interpretation is inferred."],remedy="Review design, units and required evidence.")
        table=canonical["estimates"].get("coefficient_table")
        if table is not None:
            names=canonical["estimates"].get("coefficient_names");coefficients=canonical["estimates"].get("coefficients")
            if not isinstance(table,list) or not isinstance(names,list) or len(table)!=len(names) or not isinstance(coefficients,list) or len(coefficients)!=len(names): raise ValueError("Native coefficient table must align with named parameters")
            for i,item in enumerate(table):
                if not isinstance(item,dict) or item.get("term")!=names[i] or item.get("estimate")!=coefficients[i]: raise ValueError("Native coefficient names/estimates disagree")
                interval=[item.get("ci_lower"),item.get("ci_upper")]
                if any(value is None for value in interval): interval=None
                elif any(type(value) not in {int,float} for value in interval) or interval[0]>interval[1]: raise ValueError("Invalid native coefficient interval")
                for metric,value,unit in (("standard error",item.get("standard_error"),"coefficient units"),("p value",item.get("p_value"),"dimensionless"),("confidence interval",interval,"coefficient units")):
                    if value is not None and metric!="confidence interval" and (type(value) not in {int,float} or value<0 or (metric=="p value" and value>1)): raise ValueError("Invalid native coefficient uncertainty")
                    _row(rows,"Native "+names[i]+": "+metric,stage="existing fitted uncertainty",context=context,original=value,units=unit,
                        comparison="Existing fitted result's "+str(canonical["estimates"].get("covariance_type","unspecified"))+" covariance; no covariance selected or primary fit recomputed",
                        threshold={"confidence_level":canonical["estimates"].get("confidence_level"),"reference":canonical["estimates"].get("uncertainty_reference")},status="not_checked" if value is None else "not_assessed",
                        variables={"term":names[i],"metric":"native_"+metric.replace(" ","_")},
                        interpretation="Extracted uncertainty is conditional on the original specification and reference assumptions; it does not certify those assumptions or a causal effect.",
                        limitations=["Covariance type alone cannot establish exogeneity, independence, conditional-mean specification or validity of inference."],source="existing statsmodels fitted result",remedy="Review the original design, covariance policy and unresolved evidence before coefficient inference.")
    else:
        _row(rows,"Method-specific numerical diagnostics",stage="coverage",context=context,status="not_checked",
            interpretation="This method adapter is manual-only. No numerical diagnostic chart is invented from supplied estimates.",
            limitations=spec["limitations"],remedy="Use the documented manual checklist or a supported supplied-prediction audit.")
    from .extended_rows import extension_rows
    extension_rows(canonical,context,rows,_row)
    seen=set()
    for e in canonical["evidence"]:
        seen.add(e["requirement"]); observed=e["observed"]; thresholds=e["thresholds"]
        _row(rows,reg["requirements"][e["requirement"]]["label"],stage="diagnostic evidence",context=context,
            original=observed or None,units="as stated in comparison; unspecified units remain unknown",
            comparison=e["diagnostic"],threshold=thresholds or "No numerical threshold; contextual review required",
            status=e["status"],interpretation=("This diagnostic reports no detected issue within its stated comparison; it does not prove the assumption."
                if e["status"]=="no_issue_detected" else e["diagnostic"]),limitations=e["limitations"],
            group=observed.get("group","All supplied rows"),variables=observed.get("variables",e["requirement"]),n=e["sample_size"],
            source=e["source"],remedy=" ".join(e["remedies"]) or "Review the limitations and required contextual evidence.")
    requirements=describe_requirements(method,canonical["purpose"])["requirements"]
    for key,item in requirements.items():
        if key not in seen:
            _row(rows,item["label"],stage="unassessed requirement",context=context,status="not_checked",
                interpretation="No evidence was supplied or executed for this requirement.",limitations=["Absent evidence does not prove failed practice."],
                variables=key,source="no evidence supplied",remedy=" ".join(item["remedies"]))
    for c in canonical["claims"]:
        _row(rows,"Claim: "+c["id"],stage="claim gate",context=context,original=c["status"],comparison={"required":c["requirements"],"blockers":c["blockers"]},
            units="claim status",status=c["status"],interpretation=reg["claims"][c["id"]]["description"],
            limitations=["Claim gate recomputed from evidence. Editable evidence is not authenticated."],remedy="Resolve critical evidence before stronger interpretation.")
    return canonical,context,rows,explain_report(canonical),None

def _causal(report):
    from .causal import causal_to_json,explain_causal_audit
    canonical=json.loads(causal_to_json(report)); claim=canonical["claim"]
    context={"method":claim["identification_strategy"]+" causal evidence audit","purpose":"causal_inference",
        "split":canonical["review_mode"]+"; unseen data are not validated","n":None,"sample_sizes":{},"coverage":"documentary/design assessment"}
    rows=[]
    for field,value in claim.items():
        _row(rows,"Claim specification: "+field,stage="scientific question",context=context,original=value,status="not_assessed",
            units="stated question",comparison="supplied specification, not independently verified",interpretation="Defines the question reviewed; it is not a result.")
    for m in canonical["matrix"]:
        items=m["evidence"]
        citations=[{"citation":e["citation"],"page":e["page"],"section":e["section"],"source_type":e["source_type"],
            "observed_results":e["observed_results"]} for e in items]
        _row(rows,m["requirement"].replace("_"," "),stage=m["category"],context=context,original=citations or None,
            units="documentary evidence",comparison=m["question"],threshold="critical requirement" if m["critical"] else "contextual requirement",
            status=m["assessment_status"],interpretation=("Reported support is conditional on the exact cited source; it does not validate unseen conduct." if m["assessment_status"]=="reported_support" else
                "Not reported, unavailable and not assessed remain distinct from contradicted practice."),
            limitations=["Implementation: "+m["implementation"]]+m["flags"],variables=m["requirement"],source=citations or "no exact source supplied",
            remedy="Resolve the stated design/evidence question with substantive review; no automatic numerical repair.")
    _row(rows,"Strong causal language",stage="claim gate",context=context,original=canonical["language_gate"]["strong_causal_language"],
        status="blocked",units="claim status",comparison=canonical["language_gate"]["blockers"],interpretation=canonical["language_gate"]["reason"],
        limitations=canonical["limitations"])
    return canonical,context,rows,explain_causal_audit(canonical),canonical["dag"]

def _code_plan(report):
    from .code_plan import validate_code_plan,explain_code_plan
    canonical=deepcopy(validate_code_plan(deepcopy(report)))
    context={"method":"bounded Python/R code plan","purpose":"reviewable code proposal","split":"not executed; prior estimates cannot be reused",
        "n":None,"sample_sizes":{},"coverage":canonical["supported_case"]}; rows=[]
    for label,key in (("Adjustment set","adjustment_change"),("Formula","formulas")):
        item=canonical[key]
        _row(rows,label,stage="code proposal",context=context,original=item["before"],revised=item["after"],units="specification",
            status=canonical["status"],comparison="before versus proposed; no model or data changed by this report",
            interpretation=" ".join(canonical["change_reasons"]),limitations=canonical["limitations"],remedy="Review and execute an approved fresh analysis before using results.")
    _row(rows,"Numerical result freshness",stage="provenance",context=context,original=canonical["result_state"],units="state",status="blocked",
        interpretation="Old estimates remain stale or unexecuted; code generation does not rerun them.",limitations=canonical["unresolved_assumptions"],remedy=canonical["tests_to_rerun"])
    return canonical,context,rows,explain_code_plan(canonical),canonical["dag"]

def _correction(report):
    from .corrections import validate_correction_report,explain_correction_report
    checked=validate_correction_report(deepcopy(report)); canonical=deepcopy(checked if isinstance(checked,dict) else report)
    context={"method":"OLS conventional versus HC3 covariance comparison","purpose":"inference sensitivity; not causal identification",
        "split":canonical.get("source_split",canonical.get("provenance",{}).get("source_split","supplied fitting rows")),
        "n":canonical.get("sample_sizes",{}).get("n"),"sample_sizes":canonical.get("sample_sizes",{}),"coverage":"same-fit covariance comparison"}
    rows=[]
    for c in canonical.get("comparison_rows",[]):
        for label,a,b,unit in (("coefficient","estimate","estimate",c.get("units","coefficient units not supplied")),
            ("standard error","conventional_se","hc3_se",c.get("units","coefficient units not supplied")),
            ("confidence interval","conventional_ci","hc3_ci",c.get("units","coefficient units not supplied")),
            ("p value","conventional_p","hc3_p","probability")):
            _row(rows,c["term"]+": "+label,stage="same-fit correction comparison",context=context,original=c.get(a),revised=c.get(b),units=unit,
                status=canonical["status"],comparison="conventional covariance versus HC3 on identical fitted coefficients",
                threshold=canonical.get("configuration",{}),interpretation="Covariance changes uncertainty, not the fitted coefficients, predictions or training error. Inferential validity remains conditional.",
                limitations=canonical.get("limitations",[]),variables=c["term"],remedy="Review dependence, exogeneity and specification before inference.")
    original=canonical.get("original") or {}; revised=canonical.get("revised") or {}
    if original.get("inference"):
        def reference(inference):
            return {k:inference.get(k) for k in ("reference_distribution","reference_df","confidence_level","critical_value")}
        _row(rows,"Inference reference and interval configuration",stage="uncertainty configuration",context=context,
            original=reference(original["inference"]),revised=reference(revised["inference"]) if revised.get("inference") else None,
            units="reference distribution / probability",status=canonical["status"],comparison="declared reference used to recompute each interval and p-value",
            threshold=canonical.get("configuration",{}),interpretation="The HC3 reference is approximate; matching the arithmetic does not prove the inferential conditions.",limitations=canonical.get("limitations",[]))
    before=original.get("fit",{}).get("training_metrics",{}); after=revised.get("fit",{}).get("training_metrics",{})
    for name,value in before.items():
        if type(value) not in {int,float}: continue
        _row(rows,("Unchanged training " if revised else "Original training ")+name,stage="same-fit quantities",context=context,original=value,revised=after.get(name),units=_metric_unit(name),status=canonical["status"],
            comparison="same fitted model; covariance correction cannot change this metric",interpretation="Training error is unchanged, not magically corrected." if revised else "The original training value is retained; no valid revised inference was computed.",
            limitations=["No held-out evaluation or calibration correction is performed."])
    for card in canonical.get("what_changes",[]):
        label=card.get("issue",card.get("name",card.get("correction","Correction applicability")))
        _row(rows,str(label),stage="correction applicability",context=context,original=card.get("original",card.get("original_metrics")),revised=card.get("revised",card.get("revised_metrics")),status=card.get("status","not_run"),
            units=card.get("units","as stated; otherwise unknown"),comparison=card.get("reason",card.get("rationale","See declared applicability")),
            threshold=card.get("required_conditions",card.get("applicability","conditions must be reviewed")),interpretation=card.get("conclusion",card.get("interpretation","Correction is not automatically justified by a failed diagnostic.")),
            limitations=card.get("remaining_assumptions",card.get("limitations",[])),remedy=card.get("rerun_requirements",card.get("remedy","Review applicability before any change.")))
    for requirement in canonical.get("requirements",[]):
        _row(rows,"Condition: "+requirement["id"],stage="correction conditions",context=context,original=requirement["status"],units="evidence status",
            status=requirement["status"],comparison=requirement["requirement"],interpretation="Human justification is separate from arithmetic and is not proved by HC3.",
            source=requirement["source"],variables=requirement["id"],limitations=["Reviewer/basis: "+_display(requirement.get("reviewer"))+" / "+_display(requirement.get("basis"))])
    for name,status in canonical.get("gates",{}).items():
        _row(rows,"Claim gate: "+name,stage="claim gate",context=context,original=status,status="blocked" if status=="blocked" else "supported_with_limitations",
            units="claim status",comparison="recomputed correction requirements",interpretation="Computed uncertainty changes cannot establish causality, deployment validity, or unstated inferential assumptions.",limitations=canonical.get("limitations",[]))
    if not rows: _row(rows,"Covariance correction",stage="correction applicability",context=context,status=canonical.get("status","blocked"),interpretation="No valid numerical comparison was available; no corrected values are invented.",limitations=canonical.get("limitations",[]))
    return canonical,context,rows,explain_correction_report(canonical),None

def normalize_report(report):
    """Pure normalized model consumed by all standard figure/table exports."""
    _bounded(report)
    if not isinstance(report,dict) or len(_json(report).encode())>MAX_BYTES: raise ValueError("Invalid or oversized report")
    if "method" in report and "evidence" in report: kind="diagnostic"; data=_core(report)
    elif "matrix" in report and "claim" in report: kind="causal_audit"; data=_causal(report)
    elif "old_spec" in report and "new_spec" in report: kind="code_plan"; data=_code_plan(report)
    elif report.get("kind")=="ols_covariance_comparison": kind="correction"; data=_correction(report)
    elif report.get("kind")=="multiplicity_adjustment": kind="multiplicity"; data=_multiplicity(report)
    else: raise ValueError("Unknown report contract; no numerical figure can be inferred")
    canonical,context,rows,narrative,dag=data
    if len(rows)>MAX_ROWS: raise ValueError("Report exceeds renderer row bound")
    return {"renderer_version":RENDERER_VERSION,"report_kind":kind,"context":context,"rows":rows,"narrative":narrative,
        "limitations":canonical.get("limitations",[]),"dag":dag,"report":canonical}


def _priority_findings(model):
    """Three evidence-based priorities, never a p-value/significance ranking.

    Returned rows are independent display copies. Unknown evidence remains
    unresolved; it is never relabeled an observed diagnostic failure.
    """
    rows=model["rows"]; report=model["report"]; kind=model["report_kind"]
    if kind=="diagnostic":
        from .report import main_findings
        findings=[]
        for finding in main_findings(report,limit=3):
            candidates=[r for r in rows if r["variables"]==finding["requirement"] or r["label"]==finding["label"]]
            row=next((r for r in candidates if r["status"]==finding["status"] and r["source"]==finding["source"]),
                next((r for r in candidates if r["status"]==finding["status"]),candidates[0] if candidates else None))
            if row is None:
                row=next((r for r in rows if r["stage"]=="coverage"),None)
            if row is None: continue
            item=deepcopy(row)
            item.update({"status":finding["status"],"status_label":_label(finding["status"]),
                "original":finding["observed"] or None,"threshold":finding["thresholds"] or row["threshold"],
                "remedy":finding["next_step"],"priority_reason":"Blocks the requested claim" if finding["blocks_claim"] else "Observed concern or unresolved evidence",
                "source":finding["source"],"evidence_status":row["status"]})
            if finding["status"]!=row["status"]:
                item["interpretation"]="Required contextual or source-specific evidence is unresolved. A different recorded diagnostic does not provide that justification."
                item["limitations"].append("This priority concerns missing required evidence, not an observed failure of the separate recorded diagnostic.")
            findings.append(item)
        return findings
    critical=set()
    if kind=="causal_audit":
        critical={r["requirement"] for r in report["matrix"] if r["critical"]}
    elif kind=="correction" and report["gates"]["conditional_inference"]=="blocked":
        critical={r["id"] for r in report["requirements"]}
    order={"fail":0,"contradicted":0,"warning":1,"blocked":2,"no_supported_correction":2,
        "not_checked":3,"not_reported":3,"unavailable":3,"not_assessed":3,"needs_confirmation":3,"not_run":3,"proposed":3,"not_applicable":4}
    candidates=[(i,r) for i,r in enumerate(rows) if r["status"] in order and r["stage"] not in {"scientific question","claim gate"}
        and (r["status"]!="not_applicable" or isinstance(r["variables"],str) and r["variables"] in critical)]
    candidates.sort(key=lambda pair:(0 if isinstance(pair[1]["variables"],str) and pair[1]["variables"] in critical else 1,order[pair[1]["status"]],pair[0]))
    if not candidates:
        candidates=[(i,r) for i,r in enumerate(rows) if r["stage"]=="claim gate" and r["status"]=="blocked"]
    findings=[]; seen=set()
    for _,row in candidates:
        key=_json(row["variables"]) if row["variables"]!="Not supplied" else row["label"]
        if key in seen: continue
        seen.add(key); item=deepcopy(row)
        item["priority_reason"]="Critical evidence for the requested interpretation" if isinstance(row["variables"],str) and row["variables"] in critical else "Observed concern or unresolved evidence"
        if row["status"]=="not_applicable": item["priority_reason"]="Critical requirement marked not applicable; the corresponding claim remains unresolved"
        item["evidence_status"]=row["status"]; findings.append(item)
        if len(findings)==3: break
    return findings


def _claim_boundary(model):
    report=model["report"]; kind=model["report_kind"]
    if kind=="diagnostic":
        blocked=[c["id"].replace("_"," ") for c in report["claims"] if c["status"]=="blocked"]
        eligible=[c["id"].replace("_"," ") for c in report["claims"] if c["status"]=="supported_with_limitations"]
        return (("Interpretations currently blocked: "+", ".join(blocked)+". " if blocked else "")+
            ("Eligible only with the stated limitations: "+", ".join(eligible)+". " if eligible else "")+
            "Measured fit and diagnostic summaries do not establish assumptions, causality, or external validity.")
    if kind=="causal_audit":
        return "Strong causal language remains blocked. Reported evidence and the assumed DAG require substantive review; document-only assessment does not validate unseen data or prove identification."
    if kind=="correction":
        return ("HC3 comparison: "+report["status"]+"; conditional inference: "+report["gates"]["conditional_inference"]+
            ". Covariance changes uncertainty for the same fit; coefficients, predictions and training errors are not repaired. Causal and deployment claims remain blocked.")
    if kind=="multiplicity":
        return "Multiplicity-adjusted p-values are conditional calculations. Valid marginal p-values, the declared family and applicable dependence conditions remain unverified. Effects, intervals, models and design are unchanged."
    return ("Code-plan status: "+report["status"]+". No code was executed. Existing numerical results are stale or unexecuted and require a reviewed fresh analysis; a proposed adjustment does not prove identification.")


def _key_rows(model):
    """A stable metric-first subset; selection never depends on significance."""
    rows=model["rows"]
    if model['report'].get('method')=='gaussian_mixed_intercept':
        terms=model['report'].get('estimates',{}).get('mixed_model',{}).get('fixed_effects',[])
        primary=[]
        for term in terms[:2]:
            for suffix in ('estimate','confidence interval'):
                primary.extend(r for r in rows if r['label']=='Fixed effect '+term['term']+': '+suffix)
        primary.extend(r for r in rows if r['label'] in {'random intercept variance','residual variance','conditional icc'})
        return primary[:8],len(primary)
    method=model['report'].get('method')
    if method in {'hierarchical_clustering','dbscan'}:
        labels=('fitted cluster count','noise count','noise fraction','silhouette','silhouette n',
                'silhouette eligible n','silhouette excluded noise count')
        primary=[row for label in labels for row in rows if row['stage']=='method-specific results'
                 and row['label']==label and type(row['original']) in {int,float}]
        return primary[:8],len(primary)
    if method=='architecture_output_review' and isinstance(model['report'].get('estimates',{}).get('reconstruction'),dict):
        labels=('Reconstruction rmse','Reconstruction mae','Reconstruction mse','Reconstruction cell denominator',
                'Reconstruction n features','Reconstruction baseline rmse','Reconstruction baseline mae')
        primary=[row for label in labels for row in rows if row['stage']=='method-specific results'
                 and row['label']==label and type(row['original']) in {int,float}]
        return primary[:8],len(primary)
    if _panel_rows(model,"test_effect"):
        primary=[r for metric in ("test_effect","test_effect_interval","test_statistic","test_pvalue","test_df") for r in _panel_rows(model,metric)]
        candidates=primary+_panel_rows(model,"test_group_n")
        return candidates[:8],len(candidates)
    intervals=[r for r in rows if r["label"].endswith(": confidence interval") and isinstance(r["original"],list)
        and len(r["original"])==2 and all(type(v) in {int,float} for v in r["original"])]
    numerical=[r for r in rows if type(r["original"]) in {int,float} and r["stage"]!="claim gate"]
    if model["report_kind"]=="correction":
        candidates=intervals+sorted(numerical,key=lambda r:0 if ": standard error" in r["label"] else 1 if r["stage"]=="same-fit quantities" else 2)
    else:
        priority={"rmse":0,"training rmse":0,"mae":1,"training mae":1,"r2":2,"accuracy":0,"balanced accuracy":1,"f1 macro":2,"f1 weighted":3,"roc auc":3,
            "average precision":4,"event prevalence":5,"brier":6,"brier score":6,"log loss":4,"training log loss":7,
            "retained training variance fraction":0,"n components":1,"supplied inertia":0,"mean squared centroid distance":1,
            "silhouette euclidean":2,"fitted cluster count":3,"supplied cluster count":4,"silhouette sample size":5}
        candidates=sorted(numerical,key=lambda r:priority.get(r["label"],8))
    return candidates[:8],len(candidates)


def _brief(value,limit=520):
    text=_display(value)
    return text if len(text)<=limit else text[:limit]+" ... [excerpt; see full supporting evidence]"

def _dag_svg(dag,top):
    if not dag:
        return '<text x="28" y="'+str(top+28)+'" class="body">Unresolved: no assumed DAG supplied; no arrows are inferred.</text>',96,1200
    nodes=[n["name"] for n in dag["nodes"]]; parents={n:[] for n in nodes}; children={n:[] for n in nodes}
    for a,b in dag["edges"]: parents[b].append(a); children[a].append(b)
    levels={}; pending=[n for n in nodes if not parents[n]]
    while pending:
        n=pending.pop(0); levels[n]=max([levels[p]+1 for p in parents[n]] or [0])
        for child in children[n]:
            if child not in levels and child not in pending and all(p in levels for p in parents[child]): pending.append(child)
    groups={level:[n for n in nodes if levels[n]==level] for level in set(levels.values())}
    width=max(1200,(max(levels.values())+1)*210+70); height=max(290,max(map(len,groups.values()))*72+90)
    points={n:(120+levels[n]*210,top+65+(i+1)*(height-90)/(len(group)+1)) for group in groups.values() for i,n in enumerate(group)}
    out=['<text x="28" y="'+str(top+22)+'" class="label">Assumed DAG: '+escape(dag["confirmation_status"])+'. Confirmation is an attestation, not verification.</text>']
    for a,b in dag["edges"]:
        x1,y1=points[a]; x2,y2=points[b]; bend=-55 if abs(levels[b]-levels[a])>1 else 0
        out.append(f'<path d="M {x1+70:g} {y1:g} Q {(x1+x2)/2:g} {(y1+y2)/2+bend:g} {x2-74:g} {y2:g}" fill="none" stroke="#566979" stroke-width="2" marker-end="url(#arrow)"/>')
    for node in dag["nodes"]:
        name=node["name"]; x,y=points[name]; label=name if len(name)<=21 else name[:18]+"..."
        out.append(f'<g><title>{escape(name)}; observed={node["observed"]}; timing={escape(node["timing"])}</title><rect x="{x-72:g}" y="{y-22:g}" width="144" height="44" rx="6" fill="#ffffff" stroke="#304e66"'+(' stroke-dasharray="5 3"' if not node["observed"] else '')+f'/><text x="{x:g}" y="{y+4:g}" text-anchor="middle" class="body">{escape(label)}</text></g>')
    return "".join(out),height,width

def _status_svg(model):
    """An accessible SVG using the same exact row data as the supporting table."""
    rows=model["rows"]; context=model["context"]; parts=[]; y=112; width=1200
    if model["report_kind"] in {"causal_audit","code_plan"}:
        dag,height,width=_dag_svg(model["dag"],y); parts.append(dag); y+=height+20
    counts=Counter(r["status"] for r in rows)
    parts.append(f'<text x="28" y="{y}" class="label">Evidence/status visual — counts of table rows, not a validity score</text>'); y+=28
    for status,count in sorted(counts.items()):
        color=COLORS.get(status,"#526887")
        parts.append(f'<text x="28" y="{y+16}" class="body">{escape(_label(status))}: {count}</text><rect x="540" y="{y}" width="{max(3,450*count/max(1,len(rows))):g}" height="20" fill="{color}"/><text x="1005" y="{y+16}" class="body">{count} / {len(rows)} rows</text>'); y+=29
    numerical=[r for r in rows if type(r["original"]) in {int,float} and r["stage"]!="claim gate"]
    # Separate row scales avoid conflating different metric units.
    visible=numerical[:12]
    if visible:
        y+=24; parts.append(f'<text x="28" y="{y}" class="label">Actual key values — {len(visible)} of {len(numerical)} numeric rows; each row has its own scale</text>'); y+=30
        for r in visible:
            a=r["original"]; b=r["revised"] if type(r["revised"]) in {int,float} else None
            lo=min(0,a,b if b is not None else a); hi=max(0,a,b if b is not None else a); span=hi-lo or 1
            xa=550+350*(a-lo)/span; xb=None if b is None else 550+350*(b-lo)/span
            attrs='data-row-id="'+r["id"]+'" data-original="'+escape(_json(a),quote=True)+'" data-revised="'+escape(_json(b),quote=True)+'"'
            parts.append(f'<g {attrs}><title>{escape(r["label"])}; original={escape(_display(a))}; revised/reference={escape(_display(b))}; {escape(r["units"])}</title><text x="28" y="{y+16}" class="body">{escape(r["label"][:56])}</text><line x1="550" y1="{y+9}" x2="900" y2="{y+9}" stroke="#9baab4"/><circle cx="{xa:g}" cy="{y+9}" r="6" fill="#125c75"/>')
            if b is not None: parts.append(f'<rect x="{xb-5:g}" y="{y+4}" width="10" height="10" fill="#a35c00"/>')
            parts.append(f'<text x="925" y="{y+16}" class="body">{escape(_display(a))} / {escape(_display(b))}</text></g>'); y+=30
        parts.append(f'<text x="28" y="{y+18}" class="small">Circle: original/observed. Square: revised/reference. Units, exact values, thresholds and caveats are in the supporting table.</text>'); y+=36
    else:
        parts.append(f'<text x="28" y="{y+25}" class="body">No assessed numerical comparison available: no numerical chart is invented.</text>'); y+=55
    parts.append(f'<text x="28" y="{y+20}" class="small">Status labels are diagnostic/evidence descriptions. No issue detected does not prove assumptions or causality.</text>')
    meta=escape(_json({"context":context,"rows":rows}),quote=False)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" role="img" aria-labelledby="title desc" viewBox="0 0 {width} {y+60}"><title id="title">{escape(context["method"])}: figure and supporting key metrics</title><desc id="desc">Purpose: {escape(context["purpose"])}. Split: {escape(context["split"])}. n={escape(_display(context["n"]))}. All exact plotted values derive from the same metrics rows as the table. No validity score.</desc><metadata id="metrics-data">{meta}</metadata><defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z" fill="#566979"/></marker></defs><style>.title{{font:700 24px system-ui,sans-serif;fill:#183249}}.label{{font:600 15px system-ui,sans-serif;fill:#183249}}.body{{font:13px system-ui,sans-serif;fill:#203d50}}.small{{font:12px system-ui,sans-serif;fill:#435c6b}}</style><rect width="100%" height="100%" fill="#f8fbfd"/><text x="28" y="38" class="title">{escape(context["method"])}</text><text x="28" y="66" class="body">Purpose: {escape(context["purpose"])}; n={escape(_display(context["n"]))}; units are row-specific</text><text x="28" y="88" class="small">Split: {escape(context["split"])}</text>'+"".join(parts)+'</svg>')

def _panel_rows(model,metric):
    return [r for r in model["rows"] if isinstance(r["variables"],dict) and r["variables"].get("metric")==metric]


def _plot_style():
    return {"font.family":"DejaVu Sans","svg.fonttype":"none","svg.hashsalt":"model-evidence-render-"+RENDERER_VERSION,"text.usetex":False,"text.parse_math":False}


def _export_plot(model,figure,selected,description):
    """Export actual plotted row values; no source arrays or models are read."""
    import xml.etree.ElementTree as ET
    svg_buffer=io.BytesIO(); png_buffer=io.BytesIO()
    figure.savefig(svg_buffer,format="svg",metadata={"Date":None,"Creator":"Model Evidence renderer "+RENDERER_VERSION})
    figure.savefig(png_buffer,format="png",dpi=140,metadata={"Software":"Model Evidence renderer "+RENDERER_VERSION})
    figure.clear()
    root=ET.fromstring(svg_buffer.getvalue()); ns="http://www.w3.org/2000/svg"; ET.register_namespace("",ns)
    root.set("role","img"); root.set("aria-labelledby","title desc"); context=model["context"]
    title=ET.Element("{"+ns+"}title",{"id":"title"}); title.text=context["method"]+": diagnostic figure"
    desc=ET.Element("{"+ns+"}desc",{"id":"desc"}); desc.text=description+" Purpose: "+context["purpose"]+"; n="+_display(context["n"])+"; split: "+context["split"]+". No validity score."
    metadata=ET.Element("{"+ns+"}metadata",{"id":"metrics-data"}); metadata.text=_json({"context":context,"rows":model["rows"]})
    for row in selected:
        ET.SubElement(metadata,"{"+ns+"}g",{"data-row-id":row["id"],"data-original":_json(row["original"]),"data-revised":_json(row["revised"])})
    root.insert(0,title); root.insert(1,desc); root.insert(2,metadata)
    return ET.tostring(root,encoding="unicode"),png_buffer.getvalue()


def _plot_title(model):
    context=model["context"]
    return context["method"]+"\nPurpose: "+context["purpose"]+"; supplied n="+_display(context["n"])+"\nSplit: "+context["split"]


def _short_label(value,limit=18):
    text=_display(value)
    return text if len(text)<=limit else text[:limit-3]+"..."


def _multiclass_figure(model):
    import matplotlib
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    matrix_rows=_panel_rows(model,"confusion_counts"); support=_panel_rows(model,"support")
    k=len(matrix_rows); matrix=[r["original"] for r in matrix_rows]
    labels=[str(i+1)+": "+_short_label(r["variables"]["observed_class"]) for i,r in enumerate(matrix_rows)]
    ranking=any(r["original"] is not None for r in _panel_rows(model,"roc_auc_ovr"))
    with matplotlib.rc_context(_plot_style()):
        figure=Figure(figsize=(18 if ranking else 13,max(7,3.8+k*.36)),layout="constrained"); FigureCanvasAgg(figure)
        axes=figure.subplots(1,3 if ranking else 2,squeeze=False).ravel(); selected=list(matrix_rows)+list(support)
        image=axes[0].imshow(matrix,cmap="Blues",vmin=0,aspect="equal",interpolation="nearest")
        maximum=max(max(row) for row in matrix)
        for i,row in enumerate(matrix):
            for j,count in enumerate(row): axes[0].text(j,i,str(count),ha="center",va="center",fontsize=max(5,10-k//8),color="white" if count>maximum*.5 else "#183249")
        axes[0].set_xticks(range(k),labels=labels,rotation=60,ha="right",fontsize=7)
        axes[0].set_yticks(range(k),labels=labels,fontsize=7)
        axes[0].set_xlabel("Predicted class (declared order)"); axes[0].set_ylabel("Observed class (declared order)")
        axes[0].set_title("Confusion matrix: actual observation counts",fontsize=10)
        figure.colorbar(image,ax=axes[0],shrink=.65,label="Observations")
        for metric,offset,color,hatch in (("precision",-.23,"#28708e","//"),("recall",0.,"#a76c13",".."),("f1",.23,"#4c7d57","xx")):
            records=_panel_rows(model,metric); selected.extend(records)
            first=next((j for j,r in enumerate(records) if r["original"] is not None),-1)
            for i,row in enumerate(records):
                value=row["original"]
                if value is None:
                    axes[1].text(1.02,i+offset,metric+" undefined",fontsize=6,va="center")
                else:
                    axes[1].barh(i+offset,value,height=.2,color=color,hatch=hatch,label=metric if i==first else None)
                    if k<=12: axes[1].text(min(value+.015,1.015),i+offset,format(value,".3g"),fontsize=7,va="center")
        axes[1].set_yticks(range(k),labels=[label+" (n="+str(row["original"])+")" for label,row in zip(labels,support)],fontsize=7)
        axes[1].invert_yaxis(); axes[1].set_xlim(0,1.35); axes[1].set_xlabel("Dimensionless; no universal adequacy cutoff")
        axes[1].set_title("Per-class label metrics and observed support",fontsize=10); axes[1].legend(fontsize=8,loc="upper right")
        axes[1].grid(axis="x",alpha=.2)
        if ranking:
            for metric,offset,color,hatch in (("roc_auc_ovr",-.16,"#28708e","//"),("average_precision",.16,"#a76c13","..")):
                records=_panel_rows(model,metric); selected.extend(records)
                first=next((j for j,r in enumerate(records) if r["original"] is not None),-1)
                for i,row in enumerate(records):
                    if row["original"] is None: axes[2].text(1.01,i+offset,"undefined",fontsize=6,va="center")
                    else: axes[2].barh(i+offset,row["original"],height=.27,color=color,hatch=hatch,label=metric if i==first else None)
            prevalence=_panel_rows(model,"prevalence"); selected.extend(prevalence)
            axes[2].scatter([r["original"] for r in prevalence],range(k),marker="|",color="#1f2933",label="class prevalence (AP reference)",zorder=3)
            axes[2].set_yticks(range(k),labels=labels,fontsize=7); axes[2].invert_yaxis(); axes[2].set_xlim(0,1.2)
            axes[2].set_xlabel("Dimensionless; ranking is not calibration"); axes[2].set_title("Stored one-vs-rest rank scores; no ROC curve",fontsize=10)
            axes[2].legend(fontsize=7,loc="upper right"); axes[2].grid(axis="x",alpha=.2)
        figure.suptitle(_plot_title(model)+"\nAll declared classes shown, including absent or rare classes. Undefined values are not plotted.\n"+
            ("AP depends on prevalence; scores do not certify calibration or causality." if ranking else "No eligible ranking scores supplied; no probability or ROC/AP plot is invented from labels."),fontsize=10)
        return _export_plot(model,figure,selected,"Ordered confusion-matrix counts and class-specific metrics. All classes retain their observed and predicted denominators; full labels and undefined-score explanations are in the visible table.")


def _pca_figure(model):
    import matplotlib
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    ratios=_panel_rows(model,"training_explained_variance_ratio")
    fitted=bool(ratios)
    if not ratios: ratios=[r for r in model["rows"] if r["label"].startswith("explained variance ratio:")]
    means=_panel_rows(model,"supplied_projection_mean"); sds=_panel_rows(model,"supplied_projection_sd")
    visible=ratios[:32]; selected=list(visible); show_scores=bool(means)
    with matplotlib.rc_context(_plot_style()):
        figure=Figure(figsize=(13,8 if show_scores else 5),layout="constrained"); FigureCanvasAgg(figure)
        axes=figure.subplots(2 if show_scores else 1,1,squeeze=False).ravel()
        labels=[r["variables"].get("component_name") if isinstance(r["variables"],dict) else r["variables"] for r in visible]
        axes[0].bar(range(len(visible)),[r["original"] for r in visible],color="#28708e",hatch="//")
        axes[0].set_xticks(range(len(visible)),labels=labels,rotation=45,ha="right",fontsize=8)
        axes[0].set_ylim(0,1.05); axes[0].set_ylabel("Dimensionless variance fraction")
        axes[0].set_title("Component variance fractions; "+str(len(visible))+" of "+str(len(ratios))+" components in stored order\n"+visible[0]["split"]+"; n="+_display(visible[0]["n"]),fontsize=10)
        axes[0].grid(axis="y",alpha=.2)
        if show_scores:
            mean_rows=means[:32]; positions=list(range(len(mean_rows))); names=[r["variables"]["component_name"] for r in mean_rows]
            if len(sds)==len(means):
                sd_rows=sds[:32]; axes[1].errorbar(positions,[r["original"] for r in mean_rows],yerr=[r["original"] for r in sd_rows],fmt="o",capsize=4,color="#a76c13"); selected.extend(sd_rows)
                score_title="Supplied projection mean +/- one observed SD (descriptive spread, not a confidence interval)"
            else:
                axes[1].scatter(positions,[r["original"] for r in mean_rows],marker="o",color="#a76c13"); score_title="Supplied projection means; SD not supplied"
            selected.extend(mean_rows); axes[1].set_xticks(positions,labels=names,rotation=45,ha="right",fontsize=8)
            axes[1].set_ylabel(mean_rows[0]["units"],fontsize=8); axes[1].set_title(score_title+"\n"+mean_rows[0]["split"]+"; n="+_display(mean_rows[0]["n"]),fontsize=9)
            axes[1].grid(axis="y",alpha=.2)
        provenance=("Stored training variance and supplied-row projections remain distinct; no fit or component selection performed." if fitted else
            "Variance fractions from supplied centered observations; training split is not established. No fit or component selection performed by the renderer.")
        figure.suptitle(_plot_title(model)+"\n"+provenance+"\nVariance captured is not causal or supervised predictive evidence. Full component arrays remain in exports.",fontsize=10)
        return _export_plot(model,figure,selected,"PCA component variance fractions and, when supplied, projection means with descriptive standard deviations. First 32 components at most are plotted in stored order; all exact rows remain in the supporting exports.")


def _kmeans_figure(model):
    import matplotlib
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    sizes=_panel_rows(model,"supplied_cluster_size"); visible=sizes[:32]
    silhouette=next((r for r in model["rows"] if r["label"]=="silhouette euclidean" and type(r["original"]) in {int,float}),None)
    with matplotlib.rc_context(_plot_style()):
        figure=Figure(figsize=(12,7),layout="constrained"); FigureCanvasAgg(figure); axes=figure.subplots(2,1,gridspec_kw={"height_ratios":[3,1]})
        axes[0].bar(range(len(visible)),[r["original"] for r in visible],color="#28708e",hatch="//")
        axes[0].set_xticks(range(len(visible)),labels=["Cluster "+_display(r["variables"]["cluster_id"]) for r in visible],rotation=45,ha="right",fontsize=8)
        axes[0].set_ylabel("Assigned observations (count)"); axes[0].set_title("Supplied-row assignments to fixed fitted centroids; "+str(len(visible))+" of "+str(len(sizes))+" fitted clusters shown",fontsize=10)
        axes[0].grid(axis="y",alpha=.2); selected=list(visible)
        if silhouette:
            selected.append(silhouette); axes[1].scatter([silhouette["original"]],[0],marker="o",color="#a76c13")
            axes[1].set_xlim(-1.05,1.05); axes[1].set_yticks([]); axes[1].set_xlabel("Euclidean silhouette (dimensionless -1 to 1); no validity/pass cutoff")
            axes[1].set_title("Stored supplied-row silhouette = "+_display(silhouette["original"])+"; sampling denominator/limitations in the table",fontsize=9)
        else:
            axes[1].set_axis_off(); axes[1].text(.02,.5,"Silhouette not supplied or undefined. No zero value is substituted; see supporting evidence.",transform=axes[1].transAxes,fontsize=10)
        figure.suptitle(_plot_title(model)+"\nCluster IDs are arbitrary; counts and internal geometry do not establish stable, natural or causal types.\nNo centroid fitting, k selection or model repair performed. Inertia and distance units are in the key table.",fontsize=10)
        return _export_plot(model,figure,selected,"Supplied-row cluster sizes and a measured silhouette only when supplied. First 32 cluster IDs at most are plotted in stored order; all counts remain in the supporting exports.")


def _calibration_figure(model):
    import matplotlib
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    counts=_panel_rows(model,"calibration_count"); means=_panel_rows(model,"calibration_mean_probability")
    rates=_panel_rows(model,"calibration_event_rate"); intervals=_panel_rows(model,"calibration_interval")
    selected=counts+means+rates+intervals
    nonempty=[i for i,row in enumerate(counts) if row["original"]>0]
    with matplotlib.rc_context(_plot_style()):
        figure=Figure(figsize=(12,8),layout="constrained");FigureCanvasAgg(figure)
        axes=figure.subplots(2,1,gridspec_kw={"height_ratios":[3,1]})
        xs=[means[i]["original"] for i in nonempty];ys=[rates[i]["original"] for i in nonempty]
        below=[rates[i]["original"]-intervals[i]["original"][0] for i in nonempty]
        above=[intervals[i]["original"][1]-rates[i]["original"] for i in nonempty]
        axes[0].plot([0,1],[0,1],linestyle="--",color="#536675",label="equal observed/mean-probability reference")
        axes[0].errorbar(xs,ys,yerr=[below,above],fmt="o",capsize=4,color="#126079",label="observed bin event rate + pointwise Wilson interval")
        for i,x,y in zip(nonempty,xs,ys): axes[0].annotate("n="+str(counts[i]["original"]),(x,y),xytext=(5,5),textcoords="offset points",fontsize=8)
        axes[0].set_xlim(-.03,1.03);axes[0].set_ylim(-.03,1.03)
        axes[0].set_xlabel("Mean supplied event-1 probability (dimensionless)");axes[0].set_ylabel("Observed event fraction (dimensionless)")
        axes[0].set_title("Reliability description; calibration adequacy remains unassessed",fontsize=11)
        axes[0].legend(fontsize=8,loc="best");axes[0].grid(alpha=.2)
        axes[1].bar(range(len(counts)),[r["original"] for r in counts],color="#28708e",hatch="//")
        axes[1].set_xticks(range(len(counts)),labels=[str(i+1) for i in range(len(counts))],fontsize=8)
        axes[1].set_xlabel("Fixed uniform probability bin in declared order; empty bins remain unassessed")
        axes[1].set_ylabel("Observations (count)");axes[1].grid(axis="y",alpha=.2)
        figure.suptitle(_plot_title(model)+"\nPointwise intervals assume independent Bernoulli observations within bins; design is unverified.\nNo simultaneous band, calibration proof, recalibration or model selection.",fontsize=10)
        return _export_plot(model,figure,selected,"Binary reliability description with actual bin counts and pointwise Wilson intervals, derived from the same normalized table rows. Empty bins have no probability/event-rate estimate. A diagonal reference is not a passed calibration test.")


def _statistical_figure(model):
    import matplotlib
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    import textwrap
    effect=_panel_rows(model,"test_effect")[0]; interval=_panel_rows(model,"test_effect_interval")[0]
    probability=_panel_rows(model,"test_pvalue")[0]; statistic=_panel_rows(model,"test_statistic")[0]
    groups=_panel_rows(model,"test_group_n"); selected=[effect,interval,probability,statistic]+groups
    with matplotlib.rc_context(_plot_style()):
        detail=model["report"]["estimates"]["statistical_test"];warnings=detail["warnings"]
        figure=Figure(figsize=(12,8 if warnings else 7),layout="constrained"); FigureCanvasAgg(figure); axes=figure.subplots(2,1)
        estimate=effect["original"]; bounds=interval["original"]
        if type(estimate) in {int,float}:
            if isinstance(bounds,list):
                axes[0].errorbar([estimate],[0],xerr=[[max(0,estimate-bounds[0])],[max(0,bounds[1]-estimate)]],fmt="o",capsize=5,color="#126079",clip_on=False)
            else:
                axes[0].scatter([estimate],[0],marker="o",color="#126079",clip_on=False)
            axes[0].set_yticks([]); axes[0].set_xlabel(effect["units"])
            concise_bounds=("["+format(bounds[0],".6g")+", "+format(bounds[1],".6g")+"]") if bounds is not None else None
            axes[0].set_title(effect["label"]+" = "+_display(estimate)+("; interval "+concise_bounds if bounds is not None else "; interval unimplemented/not computable"),fontsize=10)
            if model["report"]["method"] in {"anova","chi_square","binomial_test","mann_whitney"}: axes[0].set_xlim(0,1)
            if model["report"]["method"] in {"pearson_correlation","spearman_correlation","wilcoxon_signed_rank"}: axes[0].set_xlim(-1,1)
            axes[0].grid(axis="x",alpha=.2)
        else:
            axes[0].set_axis_off();axes[0].text(.02,.6,"No computable effect estimate; no zero substituted.\nReview the recorded input/design/reference limitations.",transform=axes[0].transAxes,fontsize=11)
        if groups:
            axes[1].bar(range(len(groups)),[r["original"] for r in groups],color="#28708e",hatch="//")
            axes[1].set_xticks(range(len(groups)),labels=[_short_label(r["variables"]["group_label"],24) for r in groups],fontsize=8,rotation=15)
            axes[1].set_ylabel("Observed count (group / pairs)");axes[1].grid(axis="y",alpha=.2)
        else:
            axes[1].set_axis_off();axes[1].text(.02,.6,"Group count chart not applicable/supplied.\nExact count-table denominators and reference details remain in the key-metrics table.",transform=axes[1].transAxes,fontsize=10)
        axes[1].set_title(statistic["label"]+" = "+_display(statistic["original"])+"; unadjusted p = "+_display(probability["original"])+"\nP-value is conditional on null/reference; no assumption pass verdict or causal conclusion.",fontsize=10)
        warning_text=("\nReference/sample concern: "+textwrap.fill(warnings[0][:240],110)+
            ("\n"+str(len(warnings)-1)+" further concern(s) in the supporting table." if len(warnings)>1 else "")) if warnings else "\nNo numerical concern flagged by this procedure; manual design assumptions remain unresolved."
        figure.suptitle(_plot_title(model)+"\nObserved effect/counts with conditional interval where implemented; design and multiplicity require review."+warning_text,fontsize=10)
        return _export_plot(model,figure,selected,"Selected statistical procedure: actual effect/conditional interval and group counts from the identical supporting table rows. A non-significant p-value is not proof of assumptions or equivalence.")


def _multiplicity_figure(model):
    import matplotlib
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    records=_panel_rows(model,"multiplicity_pvalue"); visible=records[:40]
    with matplotlib.rc_context(_plot_style()):
        figure=Figure(figsize=(12,max(5,2+len(visible)*.28)),layout="constrained");FigureCanvasAgg(figure);axis=figure.subplots()
        positions=list(range(len(visible)))
        axis.scatter([r["original"] for r in visible],positions,marker="o",label="Original p value",color="#126079")
        axis.scatter([r["revised"] for r in visible],positions,marker="s",label="Adjusted p value",color="#a76614")
        axis.axvline(model["report"]["alpha"],linestyle="--",color="#555",label="Declared alpha")
        axis.set_yticks(positions,labels=[r["label"] for r in visible],fontsize=8);axis.invert_yaxis();axis.set_xlim(-.02,1.02)
        axis.set_xlabel("Dimensionless p value; no effect-size/design repair");axis.grid(axis="x",alpha=.2);axis.legend(fontsize=8)
        figure.suptitle(_plot_title(model)+"\n"+str(len(visible))+" of "+str(len(records))+" hypotheses shown; complete family in table. Validity/dependence assumptions remain unresolved.",fontsize=10)
        return _export_plot(model,figure,visible,"Original and adjusted p-values for the declared family, preserving input order; effect estimates and confidence intervals unchanged. All table rows exported even if figure is bounded to40 hypotheses.")


def _figure_artifacts(model):
    method=model["report"].get("method")
    if model["report_kind"]=="multiplicity": return _multiplicity_figure(model)
    if _panel_rows(model,"test_effect"): return _statistical_figure(model)
    if _panel_rows(model,"calibration_count"): return _calibration_figure(model)
    if method=="prediction_multiclass": return _multiclass_figure(model)
    if method=="pca" and (_panel_rows(model,"training_explained_variance_ratio") or any(r["label"].startswith("explained variance ratio:") for r in model["rows"])): return _pca_figure(model)
    if method=="kmeans" and _panel_rows(model,"supplied_cluster_size"): return _kmeans_figure(model)
    selected,total=_key_rows(model)
    intervals=[r for r in model["rows"] if r["label"].endswith(": confidence interval") and isinstance(r["original"],list)
        and len(r["original"])==2 and all(type(v) in {int,float} for v in r["original"])]
    if not selected or model["report_kind"] in {"causal_audit","code_plan"}:
        return _status_svg(model),None
    # Scientific numerical figures use the installed standard plotting library.
    # FigureCanvasAgg avoids pyplot, GUI windows, and backend changes.
    import matplotlib
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    import xml.etree.ElementTree as ET
    with matplotlib.rc_context({"font.family":"DejaVu Sans","svg.fonttype":"none","svg.hashsalt":"model-evidence-render-"+RENDERER_VERSION,"text.usetex":False,"text.parse_math":False}):
        figure=Figure(figsize=(12,max(4,2.3+len(selected)*1.05)),layout="constrained")
        FigureCanvasAgg(figure)
        axes=figure.subplots(len(selected),1,squeeze=False).ravel()
        for axis,row in zip(axes,selected):
            a=row["original"]; b=row["revised"]
            is_interval=row in intervals
            if is_interval:
                suffix=': estimate' if method=='gaussian_mixed_intercept' else ': coefficient'
                expected_label=row['label'].replace(': confidence interval',suffix)
                coefficient=next((r for r in model['rows'] if r['label']==expected_label),None)
                if coefficient is None or type(coefficient['original']) not in {int,float}:raise ValueError('A displayed confidence interval needs its matching retained coefficient estimate')
                center=coefficient["original"]
                if not a[0]<=center<=a[1]:raise ValueError('Displayed interval does not contain its retained point estimate')
                axis.errorbar([center],[.2],xerr=[[center-a[0]],[a[1]-center]],fmt="o",capsize=4,color="#125c75")
                if isinstance(b,list) and len(b)==2:
                    axis.errorbar([center],[-.2],xerr=[[center-b[0]],[b[1]-center]],fmt="s",capsize=4,color="#a35c00")
                if isinstance(b,list) and len(b)==2:
                    axis.set_yticks([.2,-.2],labels=["Conventional","HC3"],fontsize=8);axis.set_ylim(-.6,.6)
                else:
                    axis.set_yticks([.2],labels=['Native conditional interval'],fontsize=8);axis.set_ylim(-.2,.6)
                lo=min(0,*a,*(b if isinstance(b,list) else a)); hi=max(0,*a,*(b if isinstance(b,list) else a))
            else:
                b=b if type(b) in {int,float} else None
                axis.scatter([a],[0],marker="o",color="#125c75",label="Original / observed",zorder=3)
                if b is not None: axis.scatter([b],[0],marker="s",color="#a35c00",label="Revised / reference",zorder=3)
                axis.set_yticks([])
                lo=min(0,a,b if b is not None else a); hi=max(0,a,b if b is not None else a)
            axis.set_xlabel(row["units"],fontsize=8)
            axis.set_title(row["label"]+": "+_display(a)+" / "+_display(b),loc="left",fontsize=9)
            margin=(hi-lo or 1)*.12
            axis.set_xlim(lo-margin,hi+margin); axis.axhline(0,color="#bbcbd6",linewidth=.8,zorder=1)
            axis.grid(axis="x",alpha=.25); axis.spines[["top","right","left"]].set_visible(False)
        context=model["context"]
        figure.suptitle(context["method"]+"\nPurpose: "+context["purpose"]+"; n="+_display(context["n"])+"\n"+
            "Split: "+context["split"]+f"\n{len(selected)} of {total} numeric/interval rows; separate units/scales. Circle=original; square=revised/reference. No validity score.",fontsize=11)
        svg_buffer=io.BytesIO(); png_buffer=io.BytesIO()
        figure.savefig(svg_buffer,format="svg",metadata={"Date":None,"Creator":"Model Evidence renderer "+RENDERER_VERSION})
        figure.savefig(png_buffer,format="png",dpi=140,metadata={"Software":"Model Evidence renderer "+RENDERER_VERSION})
        figure.clear()
    root=ET.fromstring(svg_buffer.getvalue()); ns="http://www.w3.org/2000/svg"; ET.register_namespace("",ns)
    root.set("role","img"); root.set("aria-labelledby","title desc")
    title=ET.Element("{"+ns+"}title",{"id":"title"}); title.text=context["method"]+": diagnostic figure"
    desc=ET.Element("{"+ns+"}desc",{"id":"desc"}); desc.text="Purpose "+context["purpose"]+"; split "+context["split"]+"; n="+_display(context["n"])+". Actual key metrics from the supporting table, with separate row scales; no assumption proof."
    metadata=ET.Element("{"+ns+"}metadata",{"id":"metrics-data"}); metadata.text=_json({"context":context,"rows":model["rows"]})
    # Machine-readable plotted values make cross-export consistency inspectable.
    for row in selected:
        item=ET.SubElement(metadata,"{"+ns+"}g",{"data-row-id":row["id"],"data-original":_json(row["original"]),
            "data-revised":_json(row["revised"] if type(row["revised"]) in {int,float} or row in intervals else None)})
    root.insert(0,title); root.insert(1,desc); root.insert(2,metadata)
    return ET.tostring(root,encoding="unicode"),png_buffer.getvalue()

def figure_svg(model):
    """Accessible SVG; numerical metrics use Matplotlib, DAG/status use SVG."""
    return _figure_artifacts(model)[0]

def _csv_cell(value):
    if type(value) in {int,float}: return value
    text=_display(value)
    # Values remain literal when opened in spreadsheet applications. Numeric
    # negatives are preserved; user-supplied formula-like strings are neutralized.
    if text.lstrip().startswith(("=","+","-","@")) or text.startswith(("\t","\r","\n")): text="'"+text
    return text

def _csv(rows):
    out=io.StringIO(newline=""); writer=csv.writer(out,lineterminator="\n"); writer.writerow(COLUMNS)
    for row in rows: writer.writerow([_csv_cell(row[k]) for k in COLUMNS])
    return out.getvalue()

def _html_priorities(model,findings):
    cards=[]
    for row in findings:
        prior=(" Supplied row status: "+_label(row["evidence_status"])+"; the required claim evidence remains unresolved."
            if row["evidence_status"]!=row["status"] else "")
        cards.append('<li data-finding-row-id="'+row["id"]+'" data-status="'+escape(row["status"],quote=True)+'">'
            '<h3>'+escape(row["label"])+' <span class="status">'+escape(row["status_label"])+'</span></h3>'
            '<p>'+escape(row["priority_reason"]+". "+prior)+'</p>'
            '<dl><dt>Observed / comparison</dt><dd>'+escape(_brief(row["original"]))+'; '+escape(_brief(row["comparison"]))+'</dd>'
            '<dt>Threshold / configuration</dt><dd>'+escape(_brief(row["threshold"]))+'</dd>'
            '<dt>What next</dt><dd>'+escape(_brief(row["remedy"]))+'</dd></dl>'
            '<p class="small">'+escape(_brief(row["interpretation"]))+' Limits: '+escape(_brief(row["limitations"],300))+
            ' n='+escape(_display(row["n"]))+'; source='+escape(_brief(row["source"],180))+'.</p></li>')
    return ('<section class="priority" aria-labelledby="claim-boundary-title"><h2 id="claim-boundary-title">Claim boundary and what next</h2>'
        '<p>'+escape(_claim_boundary(model))+'</p><h2>Priority findings</h2>'
        '<p class="small">Up to three critical blockers, observed concerns, or unresolved requirements. Order follows claim relevance and evidence status, never statistical significance. Unresolved evidence is not an observed failure.</p>'
        +('<ol>'+"".join(cards)+'</ol>' if cards else
          '<p>No priority flag was selected from the supplied evidence. This does not establish that every assumption holds; review the full supporting evidence and provenance.</p>')+'</section>')


def _html_key_table(model,findings):
    selected,total=_key_rows(model)
    if not selected:
        by_id={r["id"]:r for r in model["rows"]}
        selected=[by_id[r["id"]] for r in findings]
        if not selected: selected=model["rows"][:3]
        total=len(model["rows"])
    heads=("Key metric / evidence","Original / observed","Revised / reference","Units","n / source split","Comparison / threshold","Status")
    trs=[]
    for row in selected:
        cells=(row["label"],row["original"],row["revised"],row["units"],"n="+_display(row["n"])+"; "+row["split"],
            _brief(row["comparison"],220)+"; threshold/config: "+_brief(row["threshold"],220),row["status_label"])
        trs.append('<tr data-key-row-id="'+row["id"]+'">'+"".join('<td'+(' data-field="original"' if i==1 else ' data-field="revised"' if i==2 else '')+'>'+escape(_brief(v))+'</td>' for i,v in enumerate(cells))+'</tr>')
    return ('<section aria-labelledby="key-metrics-title"><h2 id="key-metrics-title">Key metrics and evidence</h2>'
        '<p class="small">'+str(len(selected))+' of '+str(total)+' metric/evidence rows shown. Selection follows metric type and source order; the complete unfiltered table and all exact values remain below and in CSV/JSON. No adequacy cutoff is invented.</p>'
        '<div class="table"><table aria-describedby="report-context"><caption>Visible key metrics / evidence with units and comparison</caption><thead><tr>'+
        "".join('<th scope="col">'+escape(h)+'</th>' for h in heads)+'</tr></thead><tbody>'+"".join(trs)+'</tbody></table></div></section>')


def _html_coverage(model):
    """Core registry completeness is bookkeeping, not scientific validity."""
    if model["report_kind"]!="diagnostic": return ""
    from .report import requirement_coverage
    coverage=requirement_coverage(model["report"]); rows=coverage["requirements"]; counts=coverage["counts"]
    labels={"total":"Applicable registry requirements",
        "with_recorded_evidence":"Requirements with automated or human evidence records, excluding manual placeholders",
        "automated_evidence_recorded":"Requirements with recorded completed automated diagnostics (including concerns)",
        "unresolved":"Requirements with unresolved evidence status","concerns":"Requirements with observed concerns"}
    implementation={"automated_evidence_recorded":"Automated diagnostic evidence recorded; this can include a concerning result",
        "automated_check_not_completed":"Automated check not completed / not applicable",
        "no_automated_check_recorded":"No automated check recorded",
        "manual_only_adapter":"Manual-only adapter: automated method diagnostic not implemented"}
    items="".join('<li>'+escape(labels.get(key,key.replace("_"," ")))+': <strong>'+escape(_display(value))+'</strong></li>' for key,value in counts.items())
    trs=[]
    for row in rows:
        sources=(", ".join("manual placeholder (not an executed check)" if source=="manual_required" else source for source in row["evidence_sources"])
            or "No evidence row supplied")
        cells=(_label(row["status"])+" ("+row["status"]+")",sources,implementation.get(row["diagnostic_support"],row["diagnostic_support"]),
            row["interpretation_support"],row["next_step"])
        trs.append('<tr data-requirement-id="'+escape(row["requirement"],quote=True)+'" data-status="'+escape(row["status"],quote=True)+'"><th scope="row">'+escape(row["label"])+'</th>'+
            "".join('<td>'+escape(_display(value))+'</td>' for value in cells)+'</tr>')
    return ('<section aria-labelledby="coverage-summary-title"><h2 id="coverage-summary-title">Requirement coverage and evidence completeness</h2>'
        '<p>Every applicable requirement in this version of the registry appears in the checklist. Diagnostic implementation and evidence supporting an interpretation are separate. Missing, unimplemented or untestable checks remain visible.</p>'
        '<ul>'+items+'</ul><p class="small">These counts describe checklist bookkeeping only. They are not a scientific validity percentage, a pass rate, or proof of assumptions. A recorded row can be an unresolved placeholder; a completed diagnostic can report a concern.</p>'
        '<details id="requirement-checklist"><summary>Full applicable requirement checklist: '+str(len(rows))+' entries, including unresolved and manual assessments</summary>'
        '<div class="table"><table><caption>Registry requirements: implementation coverage is separate from assumption-support evidence</caption><thead><tr>'+
        "".join('<th scope="col">'+escape(label)+'</th>' for label in ("Requirement","Evidence status","Evidence source(s)","Diagnostic implementation","Interpretation / assumption support","Next action"))+
        '</tr></thead><tbody>'+"".join(trs)+'</tbody></table></div></details><p class="small">'+escape(coverage["limitation"])+'</p></section>')


def _html_calibration_table(model):
    counts=_panel_rows(model,"calibration_count")
    if not counts: return ""
    metrics=("calibration_count","calibration_events","calibration_mean_probability","calibration_event_rate","calibration_gap","calibration_interval")
    columns={key:_panel_rows(model,key) for key in metrics}; rows=[]
    for i,record in enumerate(counts):
        bounds=record["variables"]["bounds"]
        label=("[" if i==0 else "(")+_display(bounds[0])+", "+_display(bounds[1])+"]"
        cells=''.join('<td data-metric-row-id="'+columns[key][i]["id"]+'">'+escape("Empty / unassessed" if columns[key][i]["original"] is None else _display(columns[key][i]["original"]))+'</td>' for key in metrics)
        rows.append('<tr><th scope="row">'+escape(label)+'</th>'+cells+'</tr>')
    return ('<section><h2>Calibration bins: counts and conditional uncertainty</h2><p>Counts are observations/events; probabilities, event fractions and gaps are dimensionless. Wilson intervals are pointwise binomial approximations, not simultaneous calibration bands. Empty bins provide no evidence. No adequacy threshold or recalibration was fitted.</p><div class="table"><table><caption>Exact values used by the reliability figure</caption><thead><tr>'+''.join('<th scope="col">'+escape(label)+'</th>' for label in ("Probability bin","Observations","Events","Mean probability","Event fraction","Observed minus predicted","Wilson event-fraction interval"))+'</tr></thead><tbody>'+''.join(rows)+'</tbody></table></div></section>')


def _html_multiclass_table(model):
    if model["report"].get("method")!="prediction_multiclass": return ""
    support=_panel_rows(model,"support"); metrics=("support","predicted_count","precision","recall","f1","prevalence","roc_auc_ovr","average_precision")
    columns={metric:_panel_rows(model,metric) for metric in metrics}; rows=[]
    for i,record in enumerate(support):
        cells=[]
        for metric in metrics:
            row=columns[metric][i]; value=row["original"]
            cells.append('<td data-metric-row-id="'+row["id"]+'">'+escape("Undefined / not assessed" if value is None else _display(value))+'</td>')
        limit=columns["roc_auc_ovr"][i]["threshold"]
        rows.append('<tr data-class-index="'+str(i)+'"><th scope="row">'+escape(_display(record["variables"]["class_label"]))+'</th>'+"".join(cells)+'<td>'+escape(_brief(limit))+'</td></tr>')
    configuration=model["report"]["estimates"].get("metric_configuration",{})
    return ('<section aria-labelledby="class-metrics-title"><h2 id="class-metrics-title">Every declared class: supports, decisions and rank scores</h2>'
        '<p>Observed/predicted support is an observation count; all other numeric columns are dimensionless. Precision uses predicted count, recall uses observed support, and prevalence uses supplied n='+escape(_display(model["context"]["n"]))+
        '. Undefined metrics remain explicitly unassessed. Class order is unchanged. AP depends on prevalence; AUC and AP do not certify calibration.</p>'
        '<p class="small">Macro F1 defined-class denominator='+escape(_display(configuration.get("macro_f1_defined_class_denominator")))+
        '; balanced accuracy observed-class denominator='+escape(_display(configuration.get("balanced_accuracy_denominator")))+
        '. Purpose and caller-declared source split are shown above. No class is hidden by aggregate accuracy.</p>'
        '<div class="table"><table><caption>All classes in exact declared order; no undefined value is replaced by zero</caption><thead><tr>'+
        "".join('<th scope="col">'+escape(label)+'</th>' for label in ("Declared class","Observed support","Predicted count","Precision","Recall","F1","Prevalence / AP reference","ROC AUC one-vs-rest","Average precision","Ranking coverage / limitations"))+
        '</tr></thead><tbody>'+"".join(rows)+'</tbody></table></div></section>')


def _html(model,svg,has_png=False,coordinated=""):
    heads=["Metric / requirement","Stage / group / variables","n / split / purpose","Original / observed","Revised / reference","Units","Comparison / threshold","Status","Plain interpretation / limits / remedy"]
    trs=[]
    for r in model["rows"]:
        cells=[r["label"],r["stage"]+"; "+_display(r["group"])+"; "+_display(r["variables"]),
            "n="+_display(r["n"])+"; "+r["split"]+"; "+r["purpose"],r["original"],r["revised"],r["units"],
            _display(r["comparison"])+"; threshold/config: "+_display(r["threshold"]),r["status_label"]+" ("+r["status"]+")",
            r["interpretation"]+" Limits: "+_display(r["limitations"])+" Remedy/review: "+_display(r["remedy"])+" Source: "+_display(r["source"])]
        trs.append('<tr data-row-id="'+r["id"]+'">'+"".join('<td'+(' data-field="original"' if i==3 else ' data-field="revised"' if i==4 else '')+'>'+escape(_display(v))+'</td>' for i,v in enumerate(cells))+"</tr>")
    title=escape(model["context"]["method"]); findings=_priority_findings(model)
    has_coordinated=bool(model["report"].get("estimates",{}).get("visual_evidence"))
    figure_open='<details><summary>Additional result, correction or status figure</summary>' if has_coordinated else ''
    figure_close='</details>' if has_coordinated else ''
    return ('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; img-src data:; base-uri \'none\'; form-action \'none\'">'
        '<title>'+title+' — Model Evidence report</title><style>body{font:16px/1.55 system-ui,sans-serif;color:#17364b;background:#f2f6f9;margin:0}main{max-width:1500px;margin:auto;padding:28px}h1{font-size:2rem;line-height:1.15}.note{background:#fff3cf;padding:16px;border-left:4px solid #986d00}.figure{overflow:auto;border:1px solid #b7cbd7;background:#fff}.figure svg{width:100%;min-width:1000px;height:auto;display:block}table{border-collapse:collapse;width:100%;font-size:13px;background:#fff}caption{text-align:left;font-weight:700;padding:15px 0}th,td{padding:10px;text-align:left;vertical-align:top;border:1px solid #cbd9e2;overflow-wrap:anywhere;min-width:100px}th{background:#e5eef4}.table{overflow:auto}a{color:#005b79;text-underline-offset:3px}a:focus{outline:3px solid #a86d00}.narrative{white-space:pre-wrap;overflow-wrap:anywhere}small{color:#456071}</style></head><body><main><h1>'+title+'</h1>'
        '<style>h2{font-size:1.35rem;margin-top:1.5rem}h3{font-size:1rem;margin:0}.priority{background:#fff;border:1px solid #b7cbd7;padding:0 20px 16px}.priority ol{padding-left:24px}.priority li{padding:12px 8px;border-top:1px solid #cbd9e2;overflow-wrap:anywhere}.priority p{margin:6px 0}.status{display:inline-block;border:1px solid #718b9b;border-radius:4px;padding:1px 7px;font-size:.85rem;font-weight:500}dt{font-weight:600}dd{margin-left:0;overflow-wrap:anywhere}dl{margin:10px 0}.small{color:#456071;font-size:.875rem}details{margin:20px 0;padding:12px;border:1px solid #b7cbd7;background:#fff}summary{font-weight:600;cursor:pointer;padding:8px}summary:focus{outline:3px solid #a86d00}</style>'
        '<p id="report-context">Purpose: '+escape(model["context"]["purpose"])+'. Split: '+escape(model["context"]["split"])+'. n='+escape(_display(model["context"]["n"]))+'. Sample sizes: '+escape(_display(model["context"].get("sample_sizes",{})))+'.</p>'
        '<p class="note">Visual figure and supporting metrics table are default outputs. They use identical normalized result rows. A diagnostic flag is not proof of assumptions or a causal-validity score. Local graphs, notes and aggregate results may be sensitive.</p>'
        '<p><a href="figure.svg">Export SVG figure</a>'+(' · <a href="figure.png">PNG figure</a>' if has_png else '')+' · <a href="metrics.csv">Metrics CSV</a> · <a href="metrics.json">Metrics JSON</a> · <a href="report.json">Validated report JSON</a></p>'
        +_html_priorities(model,findings)+coordinated+_html_coverage(model)+_html_key_table(model,findings)+
        figure_open+'<figure class="figure" aria-label="Diagnostic visual evidence">'+svg+'<figcaption>Values match the key metrics and supporting exports. Different metric rows use separate scales and units; no numerical diagnostic is fabricated for manual-only coverage. Any status counts describe table rows, not a validity score.</figcaption></figure>'+figure_close
        +_html_calibration_table(model)+_html_multiclass_table(model)+
        '<details id="full-evidence"><summary>Full supporting evidence: '+str(len(model["rows"]))+' rows, all comparisons, limitations, sources and remedies</summary>'
        '<div class="table"><table><caption>Supporting key metrics and claim-to-evidence table</caption><thead><tr>'+"".join('<th scope="col">'+escape(h)+'</th>' for h in heads)+'</tr></thead><tbody>'+"".join(trs)+'</tbody></table></div></details>'
        '<details><summary>Full narrative interpretation and limitations</summary><p class="narrative">'+escape(model["narrative"])+'</p></details>'
        '<p><small>Renderer '+RENDERER_VERSION+'. No scripts, remote assets, uploads, data repair or code execution. Numerical figures include PNG; DAG/status diagrams use SVG.</small></p></main></body></html>')

def render_report(report,output_dir):
    """Write HTML + SVG + CSV + JSON automatically; return their local manifest.

    A digest-named child directory avoids replacing an earlier report when its
    inputs change. Existing conflicting output files are refused before writes.
    This is a full local report, not the MCP privacy projection.
    """
    model=normalize_report(report); payload=_json(model); digest=hashlib.sha256(payload.encode()).hexdigest()
    root=Path(output_dir).expanduser().resolve(); target=root/(model["report_kind"]+"-"+digest[:16])
    svg,png=_figure_artifacts(model)
    from .overview import coordinated_artifacts
    coordinated_files,coordinated_html=coordinated_artifacts(model)
    contents={"report.html":_html(model,svg,has_png=png is not None,coordinated=coordinated_html),"figure.svg":svg,"metrics.csv":_csv(model["rows"]),
        "report.json":json.dumps(model["report"],indent=2,ensure_ascii=True,allow_nan=False)+"\n",
        "metrics.json":json.dumps({"renderer_version":RENDERER_VERSION,"context":model["context"],"rows":model["rows"]},indent=2,ensure_ascii=True,allow_nan=False)+"\n"}
    manifest={"renderer_version":RENDERER_VERSION,"report_kind":model["report_kind"],"content_sha256":digest,
        "output_dir":str(target),"html":str(target/"report.html"),"svg":str(target/"figure.svg"),"csv":str(target/"metrics.csv"),
        "json":str(target/"report.json"),"rows_json":str(target/"metrics.json"),"png":str(target/"figure.png") if png is not None else None,"row_count":len(model["rows"]),
        "overview_svg":str(target/"overview.svg"),"overview_png":str(target/"overview.png"),"visuals_json":str(target/"visuals.json")}
    portable=dict(manifest); portable["output_dir"]="."
    for key in ("html","svg","csv","json","rows_json","png","overview_svg","overview_png","visuals_json"):
        if portable[key] is not None: portable[key]=Path(portable[key]).name
    contents["manifest.json"]=json.dumps(portable,indent=2,ensure_ascii=True)+"\n"
    contents.update(coordinated_files)
    contents={name:text.encode("utf-8") if isinstance(text,str) else text for name,text in contents.items()}
    if png is not None: contents["figure.png"]=png
    if root.exists() and not root.is_dir(): raise ValueError("Output root is not a directory")
    if target.exists():
        if not target.is_dir() or target.is_symlink(): raise ValueError("Conflicting report output target")
        unknown=set(p.name for p in target.iterdir())-set(contents)
        if unknown: raise ValueError("Unrelated files exist in the report target; no overwrite")
        for name,data in contents.items():
            path=target/name
            if path.is_symlink() or (path.exists() and (not path.is_file() or path.read_bytes()!=data)):
                raise ValueError("Existing report output differs; no overwrite")
    target.mkdir(parents=True,exist_ok=True)
    for name,data in contents.items():
        path=target/name
        if path.is_symlink(): raise ValueError("Symlink report targets are forbidden")
        if not path.exists(): path.write_bytes(data)
    return manifest
