"""Bounded multiclass evaluation of supplied predictions, without model fitting.

Class order is explicit. Metrics describe only these rows; no probability is
invented from labels or margins, and proper scoring does not certify calibration.
"""
import math
import warnings

import numpy as np
import sklearn
from sklearn.metrics import (accuracy_score, average_precision_score,
    balanced_accuracy_score, confusion_matrix, f1_score, log_loss,
    precision_recall_fscore_support, roc_auc_score)

from .diagnostics import MAX_CELLS, _common, _complete
from .report import VERSION, evidence, make_report

MAX_CLASSES=32
METHOD="prediction_multiclass"


def _label(value):
    if isinstance(value,np.generic): value=value.item()
    if isinstance(value,bool) or value is None:
        raise ValueError("Class labels must be nonmissing text or finite numbers, not booleans")
    if isinstance(value,str):
        if not value or len(value)>128 or any(ord(c)<32 for c in value):
            raise ValueError("Text class labels must contain 1..128 printable characters")
        return value,"text"
    if type(value) in {int,float} and abs(value)<=1e100 and math.isfinite(value):
        return value,"numeric"
    raise ValueError("Class labels must be bounded finite scalar text or numbers")


def _labels(value,name,*,minimum=3,maximum=MAX_CELLS):
    if np.ma.isMaskedArray(value) and np.any(np.ma.getmaskarray(value)):
        raise ValueError(name+" contains masked values; explicit missingness handling is required before auditing")
    try: array=np.asarray(value,dtype=object)
    except (TypeError,ValueError,OverflowError) as exc: raise ValueError(name+" must be a one-dimensional label vector") from exc
    if array.ndim!=1 or not minimum<=len(array)<=maximum:
        raise ValueError(name+" must be a bounded one-dimensional label vector")
    native=[_label(v) for v in array.tolist()]
    if len({kind for _,kind in native})!=1:
        raise ValueError(name+" cannot mix text and numeric class labels")
    return [v for v,_ in native],native[0][1]


def _check_index(reference,value,name):
    left=getattr(reference,"index",None); right=getattr(value,"index",None)
    if callable(getattr(left,"equals",None)) and callable(getattr(right,"equals",None)) and not left.equals(right):
        raise ValueError(name+" pandas indexes differ from y_true in values or order; align explicitly")


def _encoded(value,name,classes,kind,n=None):
    values,actual_kind=_labels(value,name)
    if actual_kind!=kind: raise ValueError(name+" class-label type differs from declared classes")
    if n is not None and len(values)!=n: raise ValueError(name+" must align with every y_true row")
    mapping={label:i for i,label in enumerate(classes)}
    if any(v not in mapping for v in values): raise ValueError(name+" contains labels outside the explicit declared class order")
    return np.asarray([mapping[v] for v in values],dtype=int)


def _probabilities(value,y_true,classes,n):
    if np.ma.isMaskedArray(value) and np.any(np.ma.getmaskarray(value)):
        raise ValueError("Probabilities contain masked values; explicit missingness handling is required before auditing")
    _check_index(y_true,value,"probabilities")
    columns=getattr(value,"columns",None)
    if columns is not None:
        named,_=_labels(list(columns),"probability columns",maximum=MAX_CLASSES)
        if named!=classes: raise ValueError("Probability DataFrame columns must exactly match declared class order")
    if np.iscomplexobj(value): raise ValueError("Probabilities must be real numbers")
    try: array=np.asarray(value,dtype=float)
    except (TypeError,ValueError,OverflowError) as exc: raise ValueError("Probabilities must be a finite numeric matrix") from exc
    if array.ndim!=2 or array.shape!=(n,len(classes)) or array.size>MAX_CELLS:
        raise ValueError("Probabilities must have one row per outcome and one column per declared class, within the local size bound")
    if not np.isfinite(array).all() or np.any((array<0)|(array>1)):
        raise ValueError("Probabilities must be finite and within [0,1]")
    sums=array.sum(axis=1)
    if not np.allclose(sums,1.,rtol=0.,atol=1e-8):
        raise ValueError("Every probability row must sum to one within absolute tolerance 1e-8; no repair is performed")
    return array,sums


def _ev(requirement,status,diagnostic,n,observed=None,thresholds=None,limitations=None,remedies=None):
    observed=dict(observed or {}); observed.setdefault("group","all supplied multiclass evaluation rows")
    observed.setdefault("variables","observed labels, supplied predictions and declared class order")
    thresholds=dict(thresholds or {}); thresholds.setdefault("configuration_source","model-evidence/"+VERSION+" multiclass evaluator")
    return evidence(requirement,status,diagnostic,sample_size=n,observed=observed,thresholds=thresholds,
        limitations=limitations,remedies=remedies,
        provenance={"implementation":"model-evidence/"+VERSION,"sklearn_version":sklearn.__version__,
                    "stage":"supplied_predictions","fitting_performed":False})


def _finite_or_none(value):
    return float(value) if np.isfinite(value) else None


def audit_multiclass(y_true,predictions,*,classes,probabilities=None,baseline_predictions=None,metadata=None,attestations=None):
    """Audit supplied multiclass predictions in an explicit, unchanged class order.

    ``classes`` contains 3..32 unique fitted class labels. Probability columns
    correspond to that order. DataFrame/Series indexes must already agree; no
    rows, columns, labels or inputs are repaired, reordered or mutated. Only
    aggregate counts/metrics are retained. Missing observed classes warn and
    undefined per-class metrics are ``None``, never an invented perfect/zero
    diagnostic. Baselines must be prespecified and training-derived by caller.
    """
    class_order,kind=_labels(classes,"classes",maximum=MAX_CLASSES)
    if len(set(class_order))!=len(class_order): raise ValueError("Declared classes must be unique")
    _check_index(y_true,predictions,"predictions")
    encoded_y=_encoded(y_true,"y_true",class_order,kind)
    n=len(encoded_y); k=len(class_order)
    if n*k>MAX_CELLS: raise ValueError("Outcome-by-class comparisons exceed the local size bound")
    encoded_pred=_encoded(predictions,"predictions",class_order,kind,n)
    probability=sums=None
    if probabilities is not None: probability,sums=_probabilities(probabilities,y_true,class_order,n)
    baseline=None
    if baseline_predictions is not None:
        _check_index(y_true,baseline_predictions,"baseline_predictions")
        baseline=_encoded(baseline_predictions,"baseline_predictions",class_order,kind,n)

    labels=np.arange(k,dtype=int)
    support=np.bincount(encoded_y,minlength=k)
    predicted_support=np.bincount(encoded_pred,minlength=k)
    missing=np.flatnonzero(support==0).tolist()
    # Only encoded positions reach sklearn, preserving the declared probability
    # order even when string class names would otherwise be sorted by a metric.
    with warnings.catch_warnings(record=True) as emitted:
        warnings.simplefilter("always")
        precision,recall,fscore,_=precision_recall_fscore_support(encoded_y,encoded_pred,labels=labels,zero_division=np.nan)
        balanced=float(balanced_accuracy_score(encoded_y,encoded_pred))
        macro=float(f1_score(encoded_y,encoded_pred,labels=labels,average="macro",zero_division=np.nan))
        weighted=float(f1_score(encoded_y,encoded_pred,labels=labels,average="weighted",zero_division=np.nan))
        accuracy=float(accuracy_score(encoded_y,encoded_pred))
        matrix=confusion_matrix(encoded_y,encoded_pred,labels=labels).tolist()
    per_class=[]
    for i,class_label in enumerate(class_order):
        positive=int(support[i]); negative=n-positive
        eligible=positive>0 and negative>0
        per_class.append({"class_label":class_label,"support":positive,"predicted_count":int(predicted_support[i]),
            "precision":_finite_or_none(precision[i]),"recall":_finite_or_none(recall[i]),"f1":_finite_or_none(fscore[i]),
            "prevalence":positive/n,"roc_auc_ovr":float(roc_auc_score(encoded_y==i,probability[:,i])) if probability is not None and eligible else None,
            "average_precision":float(average_precision_score(encoded_y==i,probability[:,i])) if probability is not None and eligible else None,
            "ranking_score_status":"computed" if probability is not None and eligible else "not_checked",
            "ranking_score_limit":"One-vs-rest ranking is not calibration or causality; AP depends on this class prevalence." if probability is not None and eligible else
                "Class probabilities were not supplied." if probability is None else "Both positive and negative observed outcomes are required for this class's ranking comparison."})
    est={"accuracy":accuracy,"balanced_accuracy":balanced,
        "f1_macro":macro,"f1_weighted":weighted,"class_order":class_order,
        "class_support":support.tolist(),"predicted_class_support":predicted_support.tolist(),
        "confusion_matrix":matrix,"per_class":per_class,
        "metric_configuration":{"class_order":"explicit supplied order; labels encoded to positions without sorting probability columns",
            "balanced_accuracy_denominator":int(np.count_nonzero(support)),
            "balanced_accuracy_scope":"Mean recall over observed true classes; absent true classes are not evaluated.",
            "macro_f1_defined_class_denominator":int(np.isfinite(fscore).sum()),
            "undefined_metrics":"sklearn zero_division=np.nan; undefined per-class values exported as null; macro average excludes undefined values",
            "probability_row_sum_absolute_tolerance":1e-8,"uncertainty":"not_assessed","warning_count":len(emitted),
            "metric_warnings":list(dict.fromkeys(str(w.message)[:512] for w in emitted))[:3]}}
    es=_common(encoded_pred[:,None].astype(float),encoded_y.astype(float),metadata,binary=False)
    es=[row for row in es if row["requirement"]!="target_compatibility"]
    es.append(_ev("target_compatibility","warning" if missing else "no_issue_detected",
        "Explicit multiclass labels and measured class support on the supplied evaluation rows",n,
        {"declared_class_count":k,"observed_class_count":int(np.count_nonzero(support)),"class_order":class_order,
         "observed_class_counts":support.tolist(),"predicted_class_counts":predicted_support.tolist(),
         "missing_observed_class_positions":missing,"comparison":"Every supplied label maps to the explicit class order; counts sum to n="+str(n)},
        {"required_declared_classes":"3..32 distinct classes","full_class_coverage":"all declared classes observed before claiming complete multiclass evaluation",
         "rationale":"An absent class supplies no observed sensitivity estimate; label validity does not validate target meaning."},
        ["Target meaning, measurement, sampling and absent-class coverage require review.",
         "Undefined precision/recall/F1 values are null. Reported macro F1 excludes undefined class F1 values; balanced accuracy averages only observed-class recalls."],
        ["Inspect class support and the confusion matrix; obtain an appropriate independent evaluation sample rather than repairing this holdout."]))
    ranking=[{"class_label":r["class_label"],"positive_count":r["support"],"negative_count":n-r["support"],
              "roc_auc_ovr":r["roc_auc_ovr"],"average_precision":r["average_precision"],"prevalence_reference_ap":r["prevalence"],
              "status":r["ranking_score_status"]} for r in per_class]
    if probability is not None:
        # sklearn's log metric clips zero/one at floating-point epsilon, and may
        # normalize probability rows within its numerical tolerance internally.
        # This metric convention is explicit; caller arrays remain unchanged.
        with warnings.catch_warnings(record=True) as scoring_warnings:
            warnings.simplefilter("always")
            est["log_loss"]=float(log_loss(encoded_y,probability,labels=labels))
        est["metric_configuration"]["warning_count"]+=len(scoring_warnings)
        est["metric_configuration"]["metric_warnings"]=list(dict.fromkeys(est["metric_configuration"]["metric_warnings"]+
            [str(w.message)[:512] for w in scoring_warnings]))[:3]
        es.append(_ev("calibration","not_checked","Multiclass log loss is a proper score, not a calibration diagnostic",n,
            {"log_loss":est["log_loss"],"units":"nats per evaluation row","probability_cells":int(probability.size),
             "probability_row_sum_minimum":float(sums.min()),"probability_row_sum_maximum":float(sums.max()),
             "calibration_assessment":"not implemented; no binary curve is substituted"},
            {"row_sum_absolute_tolerance":1e-8,"scoring_convention":"sklearn log_loss clips endpoint probabilities at machine epsilon and normalizes within numerical tolerance",
             "rationale":"A single aggregate probability score cannot establish classwise calibration."},
            ["Classwise multiclass calibration curves and uncertainty are unimplemented. No calibrator is fitted or selected.",
             "Endpoint clipping is a numerical metric convention, not repair of the supplied records/probability array."],
            ["Assess classwise calibration on appropriate validation/evaluation data; any calibrator must be fitted using separate training/validation or cross-fitting, never this final holdout."]))
        sparse=bool(n<100 or min(support)<20)
        es.append(_ev("discrimination","warning" if missing or sparse else "no_issue_detected",
            "One-vs-rest ROC AUC/AP by declared class, only where both outcome groups are observed",n,
            {"class_comparisons":ranking,"eligible_classes":sum(r["ranking_score_status"]=="computed" for r in per_class),
             "class_denominator":k,"n":n},
            {"small_sample_n":100,"small_class_n":20,"comparison":"AUC is ranking; AP is compared descriptively with class prevalence; no universal adequacy cutoff",
             "rationale":"Sparse or absent classes limit rank diagnostics; these engineering warnings are not significance tests."},
            ["One-vs-rest AUC/AP does not measure probability calibration or prove assumptions. AP depends on prevalence.",
             "No uncertainty intervals, queue threshold selection or universal multiclass ranking certification is implemented."],
            ["Review each class's denominators and intended decision costs; do not report aggregate accuracy as sufficient evidence for rare classes."]))
    else:
        es.append(_ev("calibration","not_checked","Class probabilities not supplied; calibration and proper probability scores are not assessed",n,
            {"probabilities_supplied":False,"comparison":"labels alone versus required class-probability matrix"},
            {"required_input":"n by declared-class-count probabilities in explicit fitted class order"},
            ["Decision margins are not converted to probabilities and no probability model or calibrator is fitted."],
            ["Supply genuine predict_proba output in the fitted class order if probability evaluation is intended."]))
        es.append(_ev("discrimination","not_checked","Only class labels supplied; per-class ranking is not assessed",n,
            {"class_comparisons":ranking,"comparison":"discrete class labels cannot supply within-class probability ranking"},
            limitations=["Accuracy/confusion/F1 describe label decisions; no ROC/AP is invented from those labels."]))
    if baseline is not None:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore",UserWarning)
            est["baseline_accuracy"]=float(accuracy_score(encoded_y,baseline))
            est["baseline_balanced_accuracy"]=float(balanced_accuracy_score(encoded_y,baseline))
            est["baseline_f1_macro"]=float(f1_score(encoded_y,baseline,labels=labels,average="macro",zero_division=np.nan))
        difference=est["accuracy"]-est["baseline_accuracy"]
        es.append(_ev("reference_baseline","no_issue_detected" if difference>0 else "warning",
            "Supplied prespecified reference compared with model labels on identical evaluation rows",n,
            {"metric":"accuracy","model_value":est["accuracy"],"reference_value":est["baseline_accuracy"],
             "difference_model_minus_reference":difference,"row_denominator":n,
             "model_balanced_accuracy":est["balanced_accuracy"],"reference_balanced_accuracy":est["baseline_balanced_accuracy"],
             "model_macro_f1":est["f1_macro"],"reference_macro_f1":est["baseline_f1_macro"]},
            {"comparison":"primary reference comparison: model accuracy > reference accuracy; balanced accuracy/macro F1 also shown descriptively",
             "rationale":"Reference choice must be prespecified and training-derived, not learned from evaluation outcomes."},
            ["No training or choice history can be verified from supplied labels. The comparison has no uncertainty interval or universal acceptability threshold."],
            ["Review the prespecified reference, class-specific errors and sampling scope; do not tune the model from this final evaluation."]))
    return make_report(METHOD,"prediction",_complete(METHOD,"prediction",es,attestations),{"n":n,"classes":k},est,
        ["Metrics describe only supplied evaluation rows. Split, source, selection history, target meaning and population validity require independent evidence.",
         "No estimator, preprocessing, probability calibration, threshold, model selection, repair or causal effect is fitted here.",
         "Class labels and aggregate class counts may themselves be sensitive; this full local report is not the minimized MCP projection."])
